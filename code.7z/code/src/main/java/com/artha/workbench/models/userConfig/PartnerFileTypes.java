package com.artha.workbench.models.userConfig;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "userconfig.partnerfiletypes")
public class PartnerFileTypes implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4260503547097715094L;

	@Id
	@Column(name = "EntityFileTypeID")
	private Long entityFileTypeId;

	@Column(name = "EntityNameAbbr")
	private String entityNameAbbr;

	@Column(name = "EntityName")
	private String entityName;

	@Column(name = "ENTITYID")
	private Long entityId;

	@Column(name = "HSFileType")
	private String hsFileType;

	@Column(name = "Description")
	private String description;
	
	@Column(name = "FILETYPEID")
	private Long fileTypeId;
	
	
	@Column(name = "shortdescription")
	private String shortDescription;

	


	public PartnerFileTypes(String entityNameAbbr, String entityName, Long entityId) {
		super();
		this.entityNameAbbr = entityNameAbbr;
		this.entityName = entityName;
		this.entityId = entityId;
	}
	
	

	public Long getFileTypeId() {
		return fileTypeId;
	}



	public void setFileTypeId(Long fileTypeId) {
		this.fileTypeId = fileTypeId;
	}



	public PartnerFileTypes(Long entityFileTypeId, String hsFileType) {
		super();
		this.entityFileTypeId = entityFileTypeId;
		this.hsFileType = hsFileType;
	}

	
	public PartnerFileTypes(Long entityFileTypeId, String hsFileType , String description , Long fileTypeId, String shortDescription) {
		super();
		this.entityFileTypeId = entityFileTypeId;
		this.hsFileType = hsFileType;
		this.description = description;
		this.fileTypeId = fileTypeId;
		this.shortDescription = shortDescription;
	}
	
	public PartnerFileTypes(Long entityFileTypeId, Long entityId, String entityName, String hsFileType , String description , Long fileTypeId, String shortDescription) {
		super();
		this.entityFileTypeId = entityFileTypeId;
		this.entityId = entityId;
		this.entityName = entityName;
		this.hsFileType = hsFileType;
		this.description = description;
		this.fileTypeId = fileTypeId;
		this.shortDescription = shortDescription;
	}


	public PartnerFileTypes() {
		super();
	}

	public Long getEntityFileTypeId() {
		return entityFileTypeId;
	}

	public void setEntityFileTypeId(Long entityFileTypeId) {
		this.entityFileTypeId = entityFileTypeId;
	}

	public String getEntityNameAbbr() {
		return entityNameAbbr;
	}

	public void setEntityNameAbbr(String entityNameAbbr) {
		this.entityNameAbbr = entityNameAbbr;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public Long getEntityId() {
		return entityId;
	}

	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}

	public String getHsFileType() {
		return hsFileType;
	}

	public void setHsFileType(String hsFileType) {
		this.hsFileType = hsFileType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	

	public String getShortDescription() {
		return shortDescription;
	}



	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((entityFileTypeId == null) ? 0 : entityFileTypeId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PartnerFileTypes other = (PartnerFileTypes) obj;
		if (entityFileTypeId == null) {
			if (other.entityFileTypeId != null)
				return false;
		} else if (!entityFileTypeId.equals(other.entityFileTypeId))
			return false;
		return true;
	}

}
