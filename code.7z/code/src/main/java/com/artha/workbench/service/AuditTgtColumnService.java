package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.to.AuditTgtColumnTO;

public interface AuditTgtColumnService {

	List<AuditTgtColumnTO> getAuditTgtColumns(String taskId);
}
