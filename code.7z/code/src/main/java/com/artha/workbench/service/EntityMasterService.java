package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.EntityMaster;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EntityMasterService {

	List<EntityMaster> getEntityMasterList();

	void create(EntityMaster entityMaster);

	void update(EntityMaster entityMaster,boolean isReleaseChanged) throws JsonProcessingException;

	void saveEntityMaster(List<EntityMaster> entitytypes);

	void createAudit(List<EntityMaster> Dbentitymasterlist, List<EntityMaster> entities, List<EntityMaster> entityTypes,
			String reviewflag);

	int getmaxEntitymster();
	  public HashMap<String,Integer> loadEntityId();
	  
	  public HashMap<String,Integer> loadSelectedEntityId(int entityid);
	  
	  public HashMap<Integer,String> loadEntityIdMap();
	  
	  public long getEntityMasterDataCount();

	List<EntityMaster> getEntityMasterListByReleaseNo(Integer releaseNo);

	EntityMaster getPreviousEntityMaster(EntityMaster entityMaster) throws IOException;
	
	List<Integer> getEntityMasterReleaseNumbers(Set<Integer> entityIds,Integer selectedReleaseNumber);
	
	List<Integer> getAllEntityMasterReleaseIds(Integer selectedReleaseId);
	
	List<EntityMaster> getEntityMastersList(Set<Integer> entityIds,Integer selectedReleaseNumber);
}
