package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.datahub.Srcrecords;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class SrcrecordsDAOImpl extends BaseDAOImpl<Srcrecords, Integer> implements SrcrecordsDAO {

	public SrcrecordsDAOImpl() {
		super(Srcrecords.class);
	}

	public String getSrcrecid(String taskid) {
		TypedQuery<String> query = entityManager
				.createQuery("SELECT srcrec_id from Srcrecords where task_id = '" + taskid + "'", String.class);
		String srcrecid = query.getSingleResult();
		return srcrecid;
	}

	public String getTargetrecid(String taskid) {
		TypedQuery<String> query = entityManager
				.createQuery("SELECT tgtrecId from TgtRecords where taskId = '" + taskid + "'", String.class);
		String srcrecid = query.getSingleResult();
		return srcrecid;
	}

	public void deleteAllSrcRecords(List<String> taskIds) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Srcrecords> query = cb.createQuery(Srcrecords.class);
		Root<Srcrecords> root = query.from(Srcrecords.class);
		query.where(root.get("task_id").in(taskIds));
		deleteAll(this.entityManager.createQuery(query).getResultList());
	}

	public List<String> findSrcRecordsByTaskId(List<String> taskIds) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> query = cb.createQuery(String.class);
		Root<Srcrecords> root = query.from(Srcrecords.class);
		query.select(root.<String>get("srcrec_id")).where(root.get("task_id").in(taskIds));
		return this.entityManager.createQuery(query).getResultList();
	}

}
