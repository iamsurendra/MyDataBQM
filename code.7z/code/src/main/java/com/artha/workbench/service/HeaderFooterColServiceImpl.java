package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.EntityMasterDAO;
import com.artha.workbench.dao.FileTypeDAO;
import com.artha.workbench.dao.HeaderFooterColsDAO;
import com.artha.workbench.dao.HeaderFooterColsVwDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.metastore.HeaderFooterColVwKey;
import com.artha.workbench.models.metastore.HeaderFooterCols;
import com.artha.workbench.models.metastore.HeaderFooterColsVw;
import com.artha.workbench.models.metastore.Headerfootercolkey;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("headerFooterColsService")
public class HeaderFooterColServiceImpl implements HeaderFooterColsService {

	@Autowired
	HeaderFooterColsDAO headerFooterColsDAO;	

	@Autowired
	HeaderFooterColsVwDAO headerFooterColsVwDAO;

	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefDAO;

	@Autowired
	FileTypeDAO fileTypeDAO;

	@Autowired
	EntityMasterDAO entityMasterDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Transactional(readOnly = true)
	public List<HeaderFooterCols> getHeaderFooterColsList() {
		return headerFooterColsDAO.findAll();
	}

	@Transactional(readOnly = true)
	@Override
	public List<HeaderFooterColsVw> getHeaderFooterColsVwListByReleaseNo(Integer releaseNo) {
		return headerFooterColsVwDAO.getHeaderFooterColsVwListByReleaseNo(releaseNo);
	}
	
	@Transactional(readOnly = true)
	@Override
	public HeaderFooterColsVw getPreviousHeaderFooterColsVw(HeaderFooterColsVw headerFooterColsVw) throws IOException
	{
		Headerfootercolkey key = new Headerfootercolkey();
		key.setEntityFileTypeId(headerFooterColsVw.getEntityFileTypeId());
		key.setRecType(headerFooterColsVw.getRecType());
		key.setSeqNum(headerFooterColsVw.getSeqNum());
		key.setColumnID(headerFooterColsVw.getColumnID());
		String headerFooterColsVwJson = AppWebUtils.convertObjectToJson(key);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(headerFooterColsVw.getReleaseNo(), "HEADERFOOTERCOLS", headerFooterColsVwJson);
		HeaderFooterColsVw previousHeaderFooterColsVw = new HeaderFooterColsVw();
		if(releaseArchive!=null){
			previousHeaderFooterColsVw = AppWebUtils.convertJsonToObject(HeaderFooterColsVw.class, releaseArchive.getViewRecData());
		}
		return previousHeaderFooterColsVw;
		
	}
	@Transactional
	public void create(HeaderFooterColsVw headerFooterColsVw) {
		HeaderFooterCols headerFooterCol = new HeaderFooterCols();
		Headerfootercolkey key = new Headerfootercolkey();
		key.setEntityFileTypeId(headerFooterColsVw.getEntityFileTypeId());
		key.setRecType(headerFooterColsVw.getRecType());
		key.setSeqNum(headerFooterColsVw.getSeqNum());
		key.setColumnID(headerFooterColsVw.getColumnID());
		headerFooterCol.setHeaderFooterColKey(key);
		loadHeaderFooterCol(headerFooterColsVw, headerFooterCol);
		headerFooterColsDAO.create(headerFooterCol);
	}

	@Transactional
	public void update(HeaderFooterColsVw headerFooterColsVw,boolean isReleaseChanged) throws JsonProcessingException{
		Headerfootercolkey key = new Headerfootercolkey();
		key.setEntityFileTypeId(headerFooterColsVw.getEntityFileTypeId());
		key.setRecType(headerFooterColsVw.getRecType());
		key.setSeqNum(headerFooterColsVw.getSeqNum());
		key.setColumnID(headerFooterColsVw.getColumnID());
		checkForCyclicDependency(headerFooterColsVw);
		HeaderFooterCols headerFooterCol = headerFooterColsDAO.findOne(key);
		if(isReleaseChanged)
		{
			HeaderFooterColVwKey headerFooterColVwKey = new HeaderFooterColVwKey();
			headerFooterColVwKey.setColumnID(headerFooterColsVw.getColumnID());
			headerFooterColVwKey.setEntityName(headerFooterColsVw.getEntityName());
			headerFooterColVwKey.setFileMask(headerFooterColsVw.getFileMask());
			headerFooterColVwKey.setHSFileType(headerFooterColsVw.getHSFileType());
			headerFooterColVwKey.setRecType(headerFooterColsVw.getRecType());
			headerFooterColVwKey.setSeqNum(headerFooterColsVw.getSeqNum());
			HeaderFooterColsVw oldHeaderFooterColsVw = headerFooterColsVwDAO.findOne(headerFooterColVwKey);
			if(oldHeaderFooterColsVw!=null){
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldHeaderFooterColsVw.getReleaseNo());
				releaseArchiveKey.setReleaseId(headerFooterColsVw.getReleaseNo());
				releaseArchiveKey.setTableName("HEADERFOOTERCOLS");
				releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(headerFooterCol.getHeaderFooterColKey()));
				ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
				if(releaseArchive!=null){
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldHeaderFooterColsVw));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(headerFooterCol));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(headerFooterColVwKey));
					releaseArchiveDAO.update(releaseArchive);
				}else{
					releaseArchive = new ReleaseArchive();
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldHeaderFooterColsVw));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(headerFooterCol));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(headerFooterColVwKey));
					releaseArchiveDAO.create(releaseArchive);
				}
			}
		}
		if(headerFooterCol!=null){
			loadHeaderFooterCol(headerFooterColsVw,headerFooterCol);
			headerFooterColsDAO.update(headerFooterCol);
		}
	}
	
	private void checkForCyclicDependency(HeaderFooterColsVw headerFooterColsVw) throws JsonProcessingException	{
		Headerfootercolkey key = new Headerfootercolkey();
		key.setEntityFileTypeId(headerFooterColsVw.getEntityFileTypeId());
		key.setRecType(headerFooterColsVw.getRecType());
		key.setSeqNum(headerFooterColsVw.getSeqNum());
		key.setColumnID(headerFooterColsVw.getColumnID());
		String jsonId = AppWebUtils.convertObjectToJson(key);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(headerFooterColsVw.getReleaseNo(), "HEADERFOOTERCOLS", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	private HeaderFooterCols loadHeaderFooterCol(HeaderFooterColsVw headerFooterColsVw,
			HeaderFooterCols headerFooterCol) {
		headerFooterCol.setColumnName(headerFooterColsVw.getColumnName());
		headerFooterCol.setActive(headerFooterColsVw.getActive());
		headerFooterCol.setEffectiveDate(headerFooterColsVw.getEffectiveDate());
		headerFooterCol.setReleaseNo(headerFooterColsVw.getReleaseNo());
		return headerFooterCol;
	}
	
	@Transactional
	public HeaderFooterCols getHeaderFooterCol(HeaderFooterColsVw headerFooterColsVw){
		Headerfootercolkey key = new Headerfootercolkey();
		key.setEntityFileTypeId(headerFooterColsVw.getEntityFileTypeId());
		key.setRecType(headerFooterColsVw.getRecType());
		key.setSeqNum(headerFooterColsVw.getSeqNum());
		key.setColumnID(headerFooterColsVw.getColumnID());
		return headerFooterColsDAO.findOne(key);
	}
	
	

	@Transactional
	public List<HeaderFooterColsVw> getHeaderFooterColsVwList() {
		return headerFooterColsVwDAO.findAll();
	}

	@Transactional
	public void saveHeaderFooterCol(List<HeaderFooterCols> entitytypes) {
		headerFooterColsDAO.saveHeaderFooterCol(entitytypes);
	}

	@Transactional
	public List<HeaderFooterCols> getHeaderFooterColTempList() {
		return headerFooterColsDAO.findAll();
	}
	
	
	@Transactional
	public List<HeaderFooterCols> getHeadeFooterColsListByReleaseNo(Integer releaseNo){
		return headerFooterColsDAO.getHeadeFooterColsListByReleaseNo(releaseNo);
	}
	
	@Override
	@Transactional(readOnly=true)
	public List<Integer> getAllHeaderFooterColsReleaseIds(Integer selectedReleaseId){
		return headerFooterColsDAO.getAllHeaderFooterColsReleaseIds(selectedReleaseId);
	}
	
}
