package com.artha.workbench.models.datahub;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.envers.Audited;

import com.guvvala.framework.util.DateUtils;
import com.artha.workbench.models.metastore.AbstractModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Entity
@Table(name = "datahub.task")
@NamedQuery(name="FetchTaskByRights", query="SELECT task FROM Task task where task.task_id like ?1 ")
@Audited
@JsonPropertyOrder({"tableName","revRequired","task_id","status","modified_by","modified_on","owner","Revision_Type","last_upd_by"})
public class Task extends AbstractModel{

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "task_id", unique = true, nullable = false)
	private String task_id;

	@Column(name = "task_name")
	//@JsonIgnore
	private String task_name;

	@Column(name = "type_id")
	@JsonIgnore
	private Integer type_id;

	@Column(name = "created_by")
	//@JsonIgnore
	private String created_by;

	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	@JsonIgnore
	private Date created_on;

	@Column(name = "modified_by")
	private String modified_by;

	@Column(name = "modified_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modified_on;

	@Column(name = "owner")
	private String owner;

	@Column(name = "status")
	private String status;

	@Column(name = "star")
	@JsonIgnore
	private Integer star;

	@Column(name = "tags")
	@JsonIgnore
	private String tags;
	
	@Transient
	//@JsonIgnore
	private String createdOnString;
	
	@Transient
	//@JsonIgnore
	private String modifiedOnString;
	
	@Transient
	private String tableName="task";
	
	@Transient
	private String revRequired="true";
	
	@Transient
	@JsonProperty("Revision_Type")
	private String revision_type="1";
	
	@Transient
	@JsonProperty("LAST_UPD_BY")
	private String last_upd_by;
	

	public String getTask_id() {
		return task_id;
	}

	@Transient
	//@JsonIgnore
	private String typeStr;

	public String getTypeStr() {
		return typeStr;
	}

	public void setTypeStr(String typeStr) {
		this.typeStr = typeStr;
	}

	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}

	public String getTask_name() {
		return task_name;
	}

	public void setTask_name(String task_name) {
		this.task_name = task_name;
	}

	public Integer getType_id() {
		return type_id;
	}

	public void setType_id(Integer type_id) {
		this.type_id = type_id;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public Date getModified_on() {
		return modified_on;
	}

	public void setModified_on(Date modified_on) {
		this.modified_on = modified_on;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getStar() {
		return star;
	}

	public void setStar(Integer star) {
		this.star = star;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getCreatedOnString() {
		return createdOnString;
	}

	public void setCreatedOnString(String createdOnString) {
		this.createdOnString = createdOnString;
	}

	public String getModifiedOnString() {
		return modifiedOnString;
	}

	public void setModifiedOnString(String modifiedOnString) {
		this.modifiedOnString = modifiedOnString;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getRevision_type() {
		return revision_type;
	}

	public void setRevision_type(String revision_type) {
		this.revision_type = revision_type;
	}

	public String getRevRequired() {
		return revRequired;
	}

	public void setRevRequired(String revRequired) {
		this.revRequired = revRequired;
	}

	public String getLast_upd_by() {
		return last_upd_by;
	}

	public void setLast_upd_by(String last_upd_by) {
		this.last_upd_by = last_upd_by;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
	
	@PostLoad
	public void postLoad() {
		if(getCreated_on()!=null)
		setCreatedOnString(DateUtils.convertDateFormat(getCreated_on(), DateUtils.DISPLAY_DATE_TIME_FORMAT));
		if(getModified_on()!=null)
		setModifiedOnString(DateUtils.convertDateFormat(getModified_on(), DateUtils.DISPLAY_DATE_TIME_FORMAT));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((task_id == null) ? 0 : task_id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Task other = (Task) obj;
		if (task_id == null) {
			if (other.task_id != null)
				return false;
		} else if (!task_id.equals(other.task_id))
			return false;
		return true;
	}
	
	
	
}
