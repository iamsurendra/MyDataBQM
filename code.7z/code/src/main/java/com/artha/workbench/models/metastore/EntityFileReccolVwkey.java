package com.artha.workbench.models.metastore;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EntityFileReccolVwkey implements Serializable{

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	    @JsonProperty("FileMask")
		private String FileMask;
	    
	    @JsonProperty("EntityName")
		private String EntityName;
	    
	    @JsonProperty("HSFileType")
		private String HSFileType;
	    
	    @JsonProperty("ColumnID")
		private int ColumnID;
		
	    
	    @JsonProperty("EntityFileTypeID")
		private Integer EntityFileTypeID;
		
		public String getFileMask() {
			return FileMask;
		}
		public void setFileMask(String fileMask) {
			FileMask = fileMask;
		}
		public String getEntityName() {
			return EntityName;
		}
		public void setEntityName(String entityName) {
			EntityName = entityName;
		}
		public String getHSFileType() {
			return HSFileType;
		}
		public void setHSFileType(String hSFileType) {
			HSFileType = hSFileType;
		}
		public int getColumnID() {
			return ColumnID;
		}
		public void setColumnID(int columnID) {
			ColumnID = columnID;
		}
		public Integer getEntityFileTypeID() {
			return EntityFileTypeID;
		}
		public void setEntityFileTypeID(Integer entityFileTypeID) {
			EntityFileTypeID = entityFileTypeID;
		}
		
		
		
		
}
