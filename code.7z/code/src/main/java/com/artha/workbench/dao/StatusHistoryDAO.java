package com.artha.workbench.dao;

import com.artha.workbench.models.datahub.StatusHistory;
import com.guvvala.framework.dao.BaseDAO;

public interface StatusHistoryDAO extends BaseDAO<StatusHistory, Long> {

}
