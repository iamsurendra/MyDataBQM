package com.artha.workbench.models.userConfig;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "userconfig.filetypecolumns")
public class FileTypeColumns implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7305569676171387880L;

	@Id
	@Column(name = "EntityFileTypeID")
	private Integer entityFileTypeId;

	@Id
	@Column(name = "COLNAME")
	private String colName;

	@Column(name = "EntityNameAbbr")
	private String entityNameAbbr;

	@Column(name = "HSFileType")
	private String hsFileType;
	
	@Column(name = "HSFileName")
	private String hsFileName;
	
	@Column(name = "FileTypeID")
	private Long fileTypeId;
	
	@Column(name="COLID")
	private Long colId;

	@Transient
	private boolean writeMode;
	
	@Transient
	private boolean readMode;
	
	
	// getters & setters
	public Integer getEntityFileTypeId() {
		return entityFileTypeId;
	}

	public String getHsFileName() {
		return hsFileName;
	}

	public void setHsFileName(String hsFileName) {
		this.hsFileName = hsFileName;
	}

	public void setEntityFileTypeId(Integer entityFileTypeId) {
		this.entityFileTypeId = entityFileTypeId;
	}

	public String getEntityNameAbbr() {
		return entityNameAbbr;
	}

	public void setEntityNameAbbr(String entityNameAbbr) {
		this.entityNameAbbr = entityNameAbbr;
	}

	public String getHsFileType() {
		return hsFileType;
	}

	public void setHsFileType(String hsFileType) {
		this.hsFileType = hsFileType;
	}

	public String getColName() {
		return colName;
	}

	public void setColName(String colName) {
		this.colName = colName;
	}
	
	public boolean isWriteMode() {
		return writeMode;
	}

	public void setWriteMode(boolean writeMode) {
		this.writeMode = writeMode;
		if(writeMode){
			this.readMode = writeMode;
		}
	}

	public boolean isReadMode() {
		return readMode;
	}

	public void setReadMode(boolean readMode) {
		this.readMode = readMode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getFileTypeId() {
		return fileTypeId;
	}

	public void setFileTypeId(Long fileTypeId) {
		this.fileTypeId = fileTypeId;
	}
	
	

	public Long getColId() {
		return colId;
	}

	public void setColId(Long colId) {
		this.colId = colId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((colName == null) ? 0 : colName.hashCode());
		result = prime * result + ((entityFileTypeId == null) ? 0 : entityFileTypeId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FileTypeColumns other = (FileTypeColumns) obj;
		if (colName == null) {
			if (other.colName != null)
				return false;
		} else if (!colName.equals(other.colName))
			return false;
		if (entityFileTypeId == null) {
			if (other.entityFileTypeId != null)
				return false;
		} else if (!entityFileTypeId.equals(other.entityFileTypeId))
			return false;
		return true;
	}

}
