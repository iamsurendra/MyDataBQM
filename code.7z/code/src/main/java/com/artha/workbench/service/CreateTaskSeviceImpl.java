package com.artha.workbench.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.WBConstants;
import com.artha.workbench.dao.GroupRolesDAO;
import com.artha.workbench.dao.HssecurityroleDAO;
import com.artha.workbench.dao.PartnerFileTypesDAO;
import com.artha.workbench.dao.SrccolumnsDAO;
import com.artha.workbench.dao.SrcextraInfoDAO;
import com.artha.workbench.dao.SrcrecordsDAO;
import com.artha.workbench.dao.TaskDAO;
import com.artha.workbench.dao.TaskLayoutDAO;
import com.artha.workbench.dao.TaskcolLayoutDAO;
import com.artha.workbench.dao.TgtColumnsDAO;
import com.artha.workbench.dao.TgtRecordsDAO;
import com.artha.workbench.dao.UserDAO;
import com.artha.workbench.models.datahub.Srccolumns;
import com.artha.workbench.models.datahub.SrcextraInfo;
import com.artha.workbench.models.datahub.Srcrecords;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.models.datahub.TaskLayout;
import com.artha.workbench.models.datahub.TaskcolLayout;
import com.artha.workbench.models.datahub.TgtColumns;
import com.artha.workbench.models.datahub.TgtRecords;
import com.artha.workbench.models.userConfig.FileTypeColumns;
import com.artha.workbench.models.userConfig.PartnerFileTypes;
import com.artha.workbench.models.userConfig.User;
import com.guvvala.framework.util.AppUser;
import com.guvvala.framework.util.ThreadLocalUtil;

@Service("createTaskService")
public class CreateTaskSeviceImpl implements CreateTaskService {
	@Autowired
	TaskDAO taskDAO;

	@Autowired
	TgtColumnsDAO tgtColumnsDAO;

	@Autowired
	TgtRecordsDAO tgtRecordsDAO;

	@Autowired
	SrcrecordsDAO srcrecordsDAO;

	@Autowired
	SrccolumnsDAO srccolumnsDAO;

	@Autowired
	SrcextraInfoDAO srcextraInfoDAO;

	@Autowired
	GroupRolesDAO groupRolesDAO;

	@Autowired
	TaskLayoutDAO taskLayoutDAO;

	@Autowired
	TaskcolLayoutDAO taskColLayoutDAO;

	@Autowired
	UserDAO UserDAO;

	@Autowired
	HssecurityroleDAO hssecurityroleDAO;

	@Autowired
	PartnerFileTypesDAO partnerFileTypesDAO;

	@Autowired
	UserRolesService UserRolesService;

	List<Long> roleIds = new ArrayList<>();

	@Transactional
	public List<PartnerFileTypes> findPartnerByUser() {
		AppUser user = ThreadLocalUtil.getUser();
		setRoleIds(getRoleIdsByGroupId(user.getUserId().intValue()));
		if (!roleIds.isEmpty()) {
			List<Long> partnerIds = hssecurityroleDAO.findPartnerIdByRoleID(roleIds);
			if (partnerIds.isEmpty()) {
				return new ArrayList<>();
			} else {
				return partnerFileTypesDAO.findAllPartner(partnerIds);
			}
		} else {
			return partnerFileTypesDAO.findAllPartner();
		}

	}

	@Transactional
	public List<PartnerFileTypes> findFileTypeByPartner(Long partnerID) {
		AppUser user = ThreadLocalUtil.getUser();

		setRoleIds(getRoleIdsByGroupId(user.getUserId().intValue()));
		if (!roleIds.isEmpty()) {
			List<Long> entityTypeIds = hssecurityroleDAO.findEntityFileTypeId(partnerID, roleIds);
			if (entityTypeIds.isEmpty()) {
				return new ArrayList<>();
			} else {
				return partnerFileTypesDAO.findFileTypeByPartner(partnerID, entityTypeIds);
			}
		} else {
			return UserRolesService.findAllFileTypes(partnerID);
		}

	}

	// Generating RoleIds By using User GroupIds

	private List<Long> getRoleIdsByGroupId(Integer userId) {
		User user = UserDAO.findOne(userId.longValue());
		List<Long> list = new ArrayList<Long>();

		if (user.getGroupid() != null && !user.isAdmin() && !user.isSadmin()) {
			List<Integer> roleIds = groupRolesDAO.getGroupRoles(user.getGroupid());
			// Converting List of Integer into Long values
			for (Integer i : roleIds) {
				list.add(i.longValue());
			}
			return list;

		}
		return new ArrayList<>();
	}

	@Transactional
	public Task createTask(String taskId, String taskName, List<FileTypeColumns> columns, List<Srccolumns> access,
			String prefixForColId) {

		Task task = new Task();
		task.setTask_id(taskId);
		task.setTask_name(taskName);
		task.setType_id(2);
		task.setStar(5);
		task.setStatus("new");

		task.setCreated_on(new Date());
		task.setModified_on(new Date());
		task.setCreated_by(ThreadLocalUtil.getUserName());
		task.setModified_by(ThreadLocalUtil.getUserName());
		task.setOwner(ThreadLocalUtil.getUserName());
		taskDAO.create(task);
		createTgtRecords(taskId);
		createSrcRecord(taskId);
		createTgtcolumns(taskId, access, prefixForColId);
		createSrcColumns(taskId, access, columns, prefixForColId);
		createSrcExtraInfo(taskId, access, prefixForColId);
        return task;
	}

	private void createTgtRecords(String taskId) {
		TgtRecords tgtRecords = new TgtRecords();
		tgtRecords.setTaskId(taskId);
		tgtRecords.setTgtrecId(taskId);

		tgtRecordsDAO.create(tgtRecords);
	}

	private void createSrcRecord(String task_id) {
		Srcrecords srcrecords = new Srcrecords();
		srcrecords.setTask_id(task_id);
		srcrecords.setSrcrec_id(task_id);

		srcrecordsDAO.create(srcrecords);
	}

	private void createTgtcolumns(String taskId, List<Srccolumns> access, String prefixForColId) {

		Integer i = 0;
		TaskLayout taskLayout = new TaskLayout();
		taskLayout.setLayoutId(taskId);
		taskLayout.setTaskId(taskId);
		taskLayoutDAO.create(taskLayout);
		for (Srccolumns srccolumns : access) {

			TgtColumns tgtcolumns = new TgtColumns();
			TaskcolLayout taskcolLayout = new TaskcolLayout();
			// prefix = -158_8_0
			String id = prefixForColId.concat(WBConstants.UNDER_SCORE).concat(i.toString());

			tgtcolumns.setTgtcolId(id);
			tgtcolumns.setTgtrecId(taskId);
			//TODO
			//tgtcolumns.setTgtcolTimeStamp(new Date());
			//tgtcolumns.setIsModified(0);
			tgtcolumns.setDefColName(srccolumns.getCol_name());
			//tgtcolumns.setModifiedValue(srccolumns.getCol_value());
			tgtcolumns.setDefColType(WBConstants.STRING);
			tgtcolumns.setDefColIsKey(0);

			taskcolLayout.setColLayoutId(id);
			taskcolLayout.setLayoutId(taskId);
			taskcolLayout.setSchemaPk(srccolumns.getCol_name());
			taskcolLayout.setSequenceNo(i);

			tgtColumnsDAO.create(tgtcolumns);
			taskColLayoutDAO.create(taskcolLayout);
			i++;

		}
	}

	private void createSrcColumns(String taskId, List<Srccolumns> access, List<FileTypeColumns> columns,
			String prefixForColId) {

		Integer i = 0;

		for (Srccolumns srccol : access) {
			Srccolumns srccolumns = new Srccolumns();
			String id = prefixForColId.concat(WBConstants.UNDER_SCORE).concat(i.toString());
			i++;
			srccolumns.setSrccol_id(id);
			srccolumns.setSrcrec_id(taskId);
			srccolumns.setCol_name(srccol.getCol_name());
			srccolumns.setCol_value(srccol.getCol_value());
			srccolumns.setCol_type(WBConstants.STRING);
			srccolumns.setCol_iskey(0);
			srccolumnsDAO.create(srccolumns);
		}

	}

	private void createSrcExtraInfo(String taskId, List<Srccolumns> access, String taskIdSeq) {

		Integer i = 0;

		for (Srccolumns srccol : access) {

			SrcextraInfo srcextra = new SrcextraInfo();
			String id = WBConstants.HYPHEN.concat(taskIdSeq).concat(WBConstants.UNDER_SCORE).concat(i.toString());
			i++;
			srcextra.setId(id);
			srcextra.setSrcRecordId(taskId);
			srcextra.setInfoKey("administrator");
			srcextra.setInfoScope(srccol.getCol_name());
			srcextraInfoDAO.create(srcextra);
		}
	}

	// getters and setters
	public List<Long> getRoleIds() {
		return roleIds;
	}

	public void setRoleIds(List<Long> roleIds) {
		this.roleIds = roleIds;
	}

}
