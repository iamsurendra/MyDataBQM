package com.artha.workbench.dao;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.TablesDefinition;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class TablesDefinitonDAOImpl extends BaseDAOImpl<TablesDefinition,String> implements TablesDefinitonDAO{

	public TablesDefinitonDAOImpl() {
		super(TablesDefinition.class);
	}
	

}
