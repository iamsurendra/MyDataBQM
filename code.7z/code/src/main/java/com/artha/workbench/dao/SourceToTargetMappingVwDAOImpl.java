package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.SourceToTargetMappingVw;
import com.artha.workbench.models.metastore.SourceToTargetVwKey;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class SourceToTargetMappingVwDAOImpl extends
		BaseDAOImpl<SourceToTargetMappingVw, SourceToTargetVwKey> implements
		SourceToTargetMappingVwDAO {

	public SourceToTargetMappingVwDAOImpl() {
		super(SourceToTargetMappingVw.class);
	}
	
	@Transactional
	public List<SourceToTargetMappingVw> getSourceToTargetMappingVwByReleaseNo(Integer releaseNo)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SourceToTargetMappingVw> query = cb.createQuery(SourceToTargetMappingVw.class);
		Root<SourceToTargetMappingVw> root = query.from(SourceToTargetMappingVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	

	@Transactional
	public SourceToTargetMappingVw getSourceToTargetMappingVwByTableID(Integer sourceEFTId, Integer targetEFTId,Integer columnId)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SourceToTargetMappingVw> query = cb.createQuery(SourceToTargetMappingVw.class);
		Root<SourceToTargetMappingVw> root = query.from(SourceToTargetMappingVw.class);
		query.select(root);
		query.where(cb.and(cb.equal(root.get("sourceEntityFileTypeID"), sourceEFTId),cb.equal(root.get("targetEntityFileTypeID"), targetEFTId),cb.equal(root.get("ColumnID"), columnId)));
		List<SourceToTargetMappingVw> sourceToTargetMappingVws = this.entityManager.createQuery(query).getResultList();
		if(sourceToTargetMappingVws.isEmpty())
		{
			return null;
		}
		return sourceToTargetMappingVws.get(0);
	}
	

}
