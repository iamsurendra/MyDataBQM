package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.HeaderFooterCols;
import com.artha.workbench.models.metastore.HeaderFooterColsVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface HeaderFooterColsService {

	public List<HeaderFooterCols> getHeaderFooterColsList();

	public void create(HeaderFooterColsVw headerFooterColsVw);

	public void update(HeaderFooterColsVw headerFooterColsVw, boolean isReleaseChanged) throws JsonProcessingException;

	public List<HeaderFooterColsVw> getHeaderFooterColsVwList();

	public void saveHeaderFooterCol(List<HeaderFooterCols> entitytypes);

	public List<HeaderFooterCols> getHeaderFooterColTempList();

	public HeaderFooterCols getHeaderFooterCol(HeaderFooterColsVw headerFooterColsVw);

	public List<HeaderFooterColsVw> getHeaderFooterColsVwListByReleaseNo(Integer releaseNo);

	public HeaderFooterColsVw getPreviousHeaderFooterColsVw(HeaderFooterColsVw headerFooterColsVw) throws IOException;

	public List<HeaderFooterCols> getHeadeFooterColsListByReleaseNo(Integer releaseNo);

	List<Integer> getAllHeaderFooterColsReleaseIds(Integer selectedReleaseId);

}
