package com.artha.workbench.models.metastore;

import java.io.Serializable;

public class AbstractModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
