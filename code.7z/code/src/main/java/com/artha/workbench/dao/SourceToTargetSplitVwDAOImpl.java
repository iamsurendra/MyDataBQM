package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.SourceToTargetSplitVw;
import com.artha.workbench.models.metastore.SourceToTargetSplitVwKey;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class SourceToTargetSplitVwDAOImpl extends BaseDAOImpl<SourceToTargetSplitVw, SourceToTargetSplitVwKey> implements SourceToTargetSplitVwDAO {
	
	public SourceToTargetSplitVwDAOImpl() {
		super(SourceToTargetSplitVw.class);
	}

	public List<SourceToTargetSplitVw> getSourceToTargetSplitListByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SourceToTargetSplitVw> query = cb.createQuery(SourceToTargetSplitVw.class);
		Root<SourceToTargetSplitVw> root = query.from(SourceToTargetSplitVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNum"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}

}
