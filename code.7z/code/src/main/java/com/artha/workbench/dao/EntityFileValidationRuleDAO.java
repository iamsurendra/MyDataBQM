package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EntityFileValidationRule;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityFileValidationRuleDAO extends BaseDAO<EntityFileValidationRule, Integer> {
	public void saveEntityFileValidationRule(List<EntityFileValidationRule> entitytypes);

	public int getMaxvalidationruleid();

	public void deleteValidationRule();

	public void deleteValidationRuleDB();

	public void deleteEntityFileRuleXref();

	public void deleteEntityFileRuleParam();

	List<EntityFileValidationRule> getEntityFileValidationRulesById(List<Integer> ruleIds);
}
