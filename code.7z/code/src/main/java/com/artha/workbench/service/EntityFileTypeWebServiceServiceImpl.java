package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileTypeWebServiceDAO;
import com.artha.workbench.dao.EntityFileTypeWebServiceVwDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.metastore.EntityFileTypeWebService;
import com.artha.workbench.models.metastore.EntityFileTypeWebServiceId;
import com.artha.workbench.models.metastore.EntityFileTypeWebServiceVw;
import com.artha.workbench.models.metastore.EntityFileTypeWebServiceVwKey;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("entityFileTypeWebServiceService")
public class EntityFileTypeWebServiceServiceImpl implements EntityFileTypeWebServiceService {

	@Autowired
	EntityFileTypeWebServiceDAO entityFileTypeWebServiceDAO;

	@Autowired
	EntityFileTypeWebServiceVwDAO entityFileTypeWebServiceVwDAO;

	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Override
	@Transactional(readOnly = true)
	public List<Integer> getWebServiceIds() {
		return entityFileTypeWebServiceDAO.getWebServiceIds();
	}
	
	@Transactional
	public void create(EntityFileTypeWebServiceVw entityFileTypeWebServiceVw, EntityFileTypeWebService entityFileTypeWebService) {
		entityFileTypeWebService.setEntityFileTypeID(entityFileTypeWebServiceVw.getEntityfiletypeid());
		entityFileTypeWebService.setStepID(entityFileTypeWebServiceVw.getStepID());
		entityFileTypeWebService.setSeqOrder(entityFileTypeWebServiceVw.getSeqOrder());
		entityFileTypeWebService.setEndPointService(entityFileTypeWebServiceVw.getEndPointService());
		entityFileTypeWebService.setSoapAction(entityFileTypeWebServiceVw.getsOAPAction());
		entityFileTypeWebService.setAuthUser(entityFileTypeWebServiceVw.getAuthUser());
		entityFileTypeWebService.setAuthPass(entityFileTypeWebServiceVw.getAuthPass());
		entityFileTypeWebService.setProxyHost(entityFileTypeWebServiceVw.getProxyHost());
		entityFileTypeWebService.setProxyPort(entityFileTypeWebServiceVw.getProxyPort());
		entityFileTypeWebService.setProxyuser(entityFileTypeWebServiceVw.getProxyuser());
		entityFileTypeWebService.setProxypass(entityFileTypeWebServiceVw.getProxypass());
		entityFileTypeWebService.setMethodName(entityFileTypeWebServiceVw.getMethodName());
		entityFileTypeWebService.setCallTimeout(entityFileTypeWebServiceVw.getCallTimeout());
		entityFileTypeWebService.setPayload(entityFileTypeWebServiceVw.getPayload());
		entityFileTypeWebService.setActive(entityFileTypeWebServiceVw.getActive());
		entityFileTypeWebService.setEffectiveDate(entityFileTypeWebServiceVw.getEffectiveDate());
		entityFileTypeWebService.setxPathRootNode(entityFileTypeWebServiceVw.getxPathRootNode());
		entityFileTypeWebService.setxPathChildNode(entityFileTypeWebServiceVw.getxPathChildNode());
		entityFileTypeWebService.setxPathReturnNode(entityFileTypeWebServiceVw.getxPathReturnNode());
		entityFileTypeWebService.setExemptCondition(entityFileTypeWebServiceVw.getExemptCondition());
		
		entityFileTypeWebService.setReleaseNo(entityFileTypeWebServiceVw.getReleaseNo());
		entityFileTypeWebServiceDAO.create(entityFileTypeWebService);
	}
	
	@Transactional
	public int getmaxWebService() { 
		return entityFileTypeWebServiceDAO.getmaxWebService();
	}

	@Transactional
	public void update(EntityFileTypeWebServiceVw entityFileTypeWebServiceVw, boolean isReleaseChanged) throws JsonProcessingException {
		checkForCyclicDependency(entityFileTypeWebServiceVw);
		EntityFileTypeWebService entityFileTypeWebService = entityFileTypeWebServiceDAO.findOne(entityFileTypeWebServiceVw.getWebServiceID());
		
		if (isReleaseChanged) {
			EntityFileTypeWebServiceVwKey entityFileTypeWebServiceVwKey = new EntityFileTypeWebServiceVwKey();
			/*entityFileTypeWebServiceVwKey.setEntityfiletypeid(entityFileTypeWebServiceVw.getEntityfiletypeid());
			entityFileTypeWebServiceVwKey.setEntityname(entityFileTypeWebServiceVw.getEntityname());
			entityFileTypeWebServiceVwKey.setFilemask(entityFileTypeWebServiceVw.getFilemask());
			entityFileTypeWebServiceVwKey.setHsfiletype(entityFileTypeWebServiceVw.getHsfiletype());*/
			entityFileTypeWebServiceVwKey.setWebServiceID(entityFileTypeWebServiceVw.getWebServiceID());
			EntityFileTypeWebServiceVw oldEntity = entityFileTypeWebServiceVwDAO.findOne(entityFileTypeWebServiceVwKey);
			if(oldEntity!=null){
		    ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
			releaseArchiveKey.setReleaseId(entityFileTypeWebServiceVw.getReleaseNo());
			releaseArchiveKey.setTableName("ENTITYFILETYPEWEBSERVICE");
			EntityFileTypeWebServiceId entityFileTypeWebServiceId = new EntityFileTypeWebServiceId();
			entityFileTypeWebServiceId.setWebServiceID(entityFileTypeWebService.getWebServiceID());
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityFileTypeWebServiceId));
			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if(releaseArchive!=null){
				releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileTypeWebService));
				releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileTypeWebServiceVwKey));
				releaseArchiveDAO.update(releaseArchive);
			}else{
				releaseArchive = new ReleaseArchive();
				releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileTypeWebService));
				releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileTypeWebServiceVwKey));
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchiveDAO.create(releaseArchive);
			}
			}
		}
		if (entityFileTypeWebService != null) {
			loadEntityFileTypeWebServiceList(entityFileTypeWebService, entityFileTypeWebServiceVw);
			entityFileTypeWebServiceDAO.update(entityFileTypeWebService);
		}
	}
			
	@Transactional	
	private EntityFileTypeWebService loadEntityFileTypeWebServiceList(EntityFileTypeWebService eFTWebService, EntityFileTypeWebServiceVw eFTWebServiceVw ){
		eFTWebService.setEntityFileTypeID(eFTWebServiceVw.getEntityfiletypeid());
		eFTWebService.setReleaseNo(eFTWebServiceVw.getReleaseNo());
		eFTWebService.setStepID(eFTWebServiceVw.getStepID());
		eFTWebService.setSeqOrder(eFTWebServiceVw.getSeqOrder());
		eFTWebService.setEndPointService(eFTWebServiceVw.getEndPointService());
		eFTWebService.setSoapAction(eFTWebServiceVw.getsOAPAction());
		eFTWebService.setAuthUser(eFTWebServiceVw.getAuthUser());
		eFTWebService.setAuthPass(eFTWebServiceVw.getAuthPass());
		eFTWebService.setProxyHost(eFTWebServiceVw.getProxyHost());
		eFTWebService.setProxyPort(eFTWebServiceVw.getProxyPort());
		eFTWebService.setProxyuser(eFTWebServiceVw.getProxyuser());
		eFTWebService.setProxypass(eFTWebServiceVw.getProxypass());
		eFTWebService.setMethodName(eFTWebServiceVw.getMethodName());
		eFTWebService.setCallTimeout(eFTWebServiceVw.getCallTimeout());
		eFTWebService.setPayload(eFTWebServiceVw.getPayload());
		eFTWebService.setxPathRootNode(eFTWebServiceVw.getxPathRootNode());
		eFTWebService.setxPathChildNode(eFTWebServiceVw.getxPathChildNode());
		eFTWebService.setxPathReturnNode(eFTWebServiceVw.getxPathReturnNode());
		eFTWebService.setExemptCondition(eFTWebServiceVw.getExemptCondition());
		eFTWebService.setActive(eFTWebServiceVw.getActive());
		eFTWebService.setEffectiveDate(eFTWebServiceVw.getEffectiveDate());
		return eFTWebService;
		
	
	}

	private void checkForCyclicDependency(EntityFileTypeWebServiceVw entityFileTypeWebServiceVw)
			throws JsonProcessingException {
		EntityFileTypeWebServiceId entityFileTypeWebServiceId = new EntityFileTypeWebServiceId();
		entityFileTypeWebServiceId.setWebServiceID(entityFileTypeWebServiceVw.getWebServiceID());
		String jsonId = AppWebUtils.convertObjectToJson(entityFileTypeWebServiceId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(
				entityFileTypeWebServiceVw.getReleaseNo(), "ENTITYFILETYPEWEBSERVICE", jsonId);
		if (releaseArchive != null) {
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	@Transactional
	public List<EntityFileTypeWebService> getEntityFileTypeWebServiceList() {

		return entityFileTypeWebServiceDAO.findAll();

	}

	@Transactional(readOnly = true)
	public List<EntityFileTypeWebServiceVw> getEntityFileTypeWebServiceVwList() {
		return entityFileTypeWebServiceVwDAO.findAll();
	}
	
	@Transactional(readOnly = true)
	public List<EntityFileTypeWebService> getEntityFileTypeWebServicefList(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber){
		return entityFileTypeWebServiceDAO.getEntityFileTypeWebServicefList(entityFileTypeIds, selectedReleaseNumber);
		
	}
	
	@Transactional
	public List<EntityFileTypeWebServiceVw> getEntityFileTypeWebServiceVwListByReleaseNo(Integer releaseNo) {
		return entityFileTypeWebServiceVwDAO.getEntityFileTypeWebServiceVwListByReleaseNo(releaseNo);
	}
	
	
	@Transactional
	public List<EntityFileTypeWebService> getEntityFileTypeWebServiceListByReleaseNo(Integer releaseNo) {
		return entityFileTypeWebServiceDAO.getEntityFileTypeWebServiceListByReleaseNo(releaseNo);
	}

	@Override
	public EntityFileTypeWebServiceVw getPreviousEntityFileTypeWebServiceVw(EntityFileTypeWebServiceVw entityFileTypeWebServiceVw)
			throws IOException {
		EntityFileTypeWebServiceId entityFileTypeWebServiceId = new EntityFileTypeWebServiceId();
		entityFileTypeWebServiceId.setWebServiceID(entityFileTypeWebServiceVw.getWebServiceID());
		String entityFileTypeWebServiceVwJson = AppWebUtils.convertObjectToJson(entityFileTypeWebServiceId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(entityFileTypeWebServiceVw.getReleaseNo(), "ENTITYFILETYPEWEBSERVICE", entityFileTypeWebServiceVwJson);
		EntityFileTypeWebServiceVw previousEntityFileTypeWebServiceVw = new EntityFileTypeWebServiceVw();
		if(releaseArchive!=null){
			previousEntityFileTypeWebServiceVw = AppWebUtils.convertJsonToObject(EntityFileTypeWebServiceVw.class, releaseArchive.getViewRecData());
		}
		return previousEntityFileTypeWebServiceVw;
	}
	
	@Transactional
	public EntityFileTypeWebService getEntityFileTypeWebService(EntityFileTypeWebServiceVw entityFileTypeWebServiceVw) {
		EntityFileTypeWebService entityFileTypeWebService = entityFileTypeWebServiceDAO.findOne(entityFileTypeWebServiceVw.getWebServiceID());
		return entityFileTypeWebService;
	}
}
