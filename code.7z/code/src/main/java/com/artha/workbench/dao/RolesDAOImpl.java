package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.Roles;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class RolesDAOImpl extends BaseDAOImpl<Roles, Long> implements RolesDAO {

	public RolesDAOImpl() {
		super(Roles.class);
	}

	public boolean duplicateRoleName(String roleName) {
		TypedQuery<Roles> query = entityManager.createQuery("select r from Roles r where r.roleName='" + roleName + "'",
				Roles.class);
		List<Roles> roles = query.getResultList();
		if (roles.isEmpty()) {
			return false;
		} else {
			return true;
		}
	}
	
	@Override
	public List<Roles> getAllRoles() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Roles> query = cb.createQuery(Roles.class);
		Root<Roles> root = query.from(Roles.class);
		query.select(root);
		query.orderBy(cb.asc(root.get("roleName")));
		return entityManager.createQuery(query).getResultList();
	}
}
