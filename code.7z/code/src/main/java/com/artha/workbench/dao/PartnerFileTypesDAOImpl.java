package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.PartnerFileTypes;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class PartnerFileTypesDAOImpl extends BaseDAOImpl<PartnerFileTypes, Long>
		implements PartnerFileTypesDAO {

	public PartnerFileTypesDAOImpl() {
		super(PartnerFileTypes.class);
	}

	public List<String> findFileTypebyPartnerName(String partnerName) {
		TypedQuery<String> query = entityManager.createQuery(
				"select hsFileType from PartnerFileTypes where entityNameAbbr='" + partnerName + "'", String.class);
		return query.getResultList();

	}

	public List<Long> findFileTypebyPartnerIdFileId(Long partnerId , List<Long> fileTypeId) {
		TypedQuery<Long> query = entityManager.createQuery(
				"select entityFileTypeId from PartnerFileTypes where entityId = :partnerId AND  fileTypeId in :fileTypeId ", Long.class);
		query.setParameter("partnerId", partnerId);
		query.setParameter("fileTypeId", fileTypeId);
		return query.getResultList();

	}
	
	public List<String> findAllPartnerCodes() {
		TypedQuery<String> query = entityManager.createQuery(
				"select DISTINCT pft.entityNameAbbr from PartnerFileTypes pft", String.class);
		return query.getResultList();
	}

	public List<PartnerFileTypes> findAllPartner() {
		TypedQuery<PartnerFileTypes> query = entityManager.createQuery(
				"select new com.artha.workbench.models.userConfig.PartnerFileTypes(pft.entityNameAbbr,pft.entityName,pft.entityId) from PartnerFileTypes pft group by pft.entityNameAbbr,pft.entityName,pft.entityId order by UPPER(pft.entityName)", PartnerFileTypes.class);
		return query.getResultList();
	}

	public List<PartnerFileTypes> findAllFileTypes(Long partnerID) {
		TypedQuery<PartnerFileTypes> query = entityManager.createQuery(
				"select new com.artha.workbench.models.userConfig.PartnerFileTypes(pft.entityFileTypeId,pft.hsFileType,pft.description,pft.fileTypeId,pft.shortDescription) from PartnerFileTypes pft where entityId=" + partnerID + "group by pft.entityFileTypeId,pft.hsFileType,pft.description,pft.fileTypeId,pft.shortDescription order by UPPER(pft.description)",
				PartnerFileTypes.class);
		return query.getResultList();

	}

	public List<PartnerFileTypes> findAllFileTypes(List<Long> ids) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<PartnerFileTypes> cQuery = criteriaBuilder.createQuery(PartnerFileTypes.class);
		Root<PartnerFileTypes> root = cQuery.from(PartnerFileTypes.class);
		cQuery.select(root);
		cQuery.where(criteriaBuilder.in(root.get("entityFileTypeId")).value(ids))
		.orderBy(criteriaBuilder.asc(criteriaBuilder.upper(root.<String>get("entityName"))));
		return entityManager.createQuery(cQuery).getResultList();
	}

	public PartnerFileTypes findPartnerById(Long id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<PartnerFileTypes> cQuery = criteriaBuilder.createQuery(PartnerFileTypes.class);
		Root<PartnerFileTypes> root = cQuery.from(PartnerFileTypes.class);
		cQuery.select(root);
		cQuery.where(criteriaBuilder.equal(root.get("entityId"), id)).groupBy(root.get("entityNameAbbr"));
		List<PartnerFileTypes> pFileTypes = entityManager.createQuery(cQuery).getResultList();
		if (pFileTypes.isEmpty()) {
			return null;
		} else {
			return pFileTypes.get(0);
		}
	}
	
	public String findFileTypeAbbr(Long fileTypeId) {
		TypedQuery<String> query = entityManager.createQuery(
				"select hsFileType from PartnerFileTypes where entityFileTypeId=:entityFileTypeId group by hsFileType",String.class);
		
		query.setParameter("entityFileTypeId", fileTypeId);
        List<String> fileTypeAbbrList = query.getResultList();
        if(fileTypeAbbrList.isEmpty()){
        	return null;
        }
		return fileTypeAbbrList.get(0);
	}
	
	public String findPartnerAbbr(Long entityId) {
		TypedQuery<String> query = entityManager.createQuery(
				"select entityNameAbbr from PartnerFileTypes where entityId=:entityId group by entityNameAbbr",String.class);
		
		query.setParameter("entityId", entityId);
        List<String> partnerAbbrList = query.getResultList();
        if(partnerAbbrList.isEmpty()){
        	return null;
        }
		return partnerAbbrList.get(0);
	}
	
	public List<PartnerFileTypes> findAllPartner(List<Long> entityId) {
		TypedQuery<PartnerFileTypes> query = entityManager.createQuery(
				"select new com.artha.workbench.models.userConfig.PartnerFileTypes(pft.entityNameAbbr,pft.entityName,pft.entityId) from PartnerFileTypes pft where entityId in(:entityId) group by pft.entityNameAbbr,pft.entityName,pft.entityId order by UPPER(pft.entityName)", PartnerFileTypes.class);
		query.setParameter("entityId", entityId);
		return query.getResultList();
	}
	
	public List<PartnerFileTypes> findFileTypeByPartner(Long partnerID,List<Long> entityTypeIds) {
		TypedQuery<PartnerFileTypes> query = entityManager.createQuery(
				"select new com.artha.workbench.models.userConfig.PartnerFileTypes(pft.entityFileTypeId,pft.hsFileType,pft.description,pft.fileTypeId,pft.shortDescription) from PartnerFileTypes pft where entityId=:partnerID and entityFileTypeId in (:entityTypeIds) group by pft.entityFileTypeId,pft.hsFileType,pft.description,pft.fileTypeId,pft.shortDescription order by UPPER(pft.description)",
				PartnerFileTypes.class);
		query.setParameter("partnerID", partnerID);
		query.setParameter("entityTypeIds", entityTypeIds);
		return query.getResultList();

	}
	
	public List<PartnerFileTypes> getPartnerFileTypesBypartnerId(Long partnerId, List<Long> entityTypeIds) {
		TypedQuery<PartnerFileTypes> query = entityManager.createQuery(
				"select new com.artha.workbench.models.userConfig.PartnerFileTypes(pft.entityFileTypeId,pft.entityId,pft.entityName,pft.hsFileType,pft.description,pft.fileTypeId,pft.shortDescription) from PartnerFileTypes pft where entityId=:partnerID and entityFileTypeId in (:entityTypeIds) group by pft.entityFileTypeId,pft.entityId,pft.entityName,pft.hsFileType,pft.description,pft.fileTypeId,pft.shortDescription",
				PartnerFileTypes.class);
		query.setParameter("partnerID", partnerId);
		query.setParameter("entityTypeIds", entityTypeIds);
		return query.getResultList();
		
	}
	

}