package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.TableList;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class TableListDAOImpl extends BaseDAOImpl<TableList, Integer> implements TableListDAO {

	public TableListDAOImpl() {
		super(TableList.class);
	}

	public List<TableList> getTablelist(String statusFlag) {
		TypedQuery<TableList> query = entityManager.createQuery("from TableList where deletestatus ='N' ",
				TableList.class);
		return query.getResultList();
	}

	public List<TableList> getUploadList() {
		TypedQuery<TableList> query = entityManager
				.createQuery("from TableList where deletestatus ='N' and status = 'A' ", TableList.class);
		return query.getResultList();

	}

	public String getDescription(String tablename) {

		TypedQuery<String> query = entityManager
				.createQuery("SELECT description from TableList where tablename ='" + tablename + "'", String.class);

		List<String> descriptions = query.getResultList();
		if (descriptions.isEmpty()) {
			return null;
		}
		return descriptions.get(0);

	}

}
