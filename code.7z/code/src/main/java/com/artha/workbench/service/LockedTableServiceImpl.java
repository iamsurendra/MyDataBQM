package com.artha.workbench.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.LockedTablesDAO;
import com.artha.workbench.models.core.LockedTables;

@Service("lockedTableService")
public class LockedTableServiceImpl implements LockedTableService {
	
	@Autowired
	LockedTablesDAO lockedTablesDAO;
	
	
	@Transactional
	@Override
	public void createLockedTables(Integer tableId,Long userId,String tableName)
	{
		LockedTables lockedTables = lockedTablesDAO.findOne(tableId);
		if(lockedTables==null)
		{
		lockedTables = new LockedTables();
		lockedTables.setLoginid(userId);
		lockedTables.setTableno(tableId);
		lockedTables.setTablename(tableName);
		lockedTables.setCreatedOn(new Date());
		lockedTablesDAO.create(lockedTables);
		}
	}

	@Transactional
	@Override
	public boolean lockedByOtherUser(Integer tableId, Long userId)
	{
		LockedTables  lockedTables = lockedTablesDAO.findOne(tableId);
		if(null==lockedTables || lockedTables.getLoginid()==userId)
		{
			return false;
		}
		else
		{
			return true;
		}
		
	}
	
	@Transactional
	@Override
	public void unlockTable(Integer tableId)
	{
		LockedTables lockedTables = lockedTablesDAO.findOne(tableId);
		if(null!=lockedTables)
		lockedTablesDAO.delete(lockedTables);
	}
}
