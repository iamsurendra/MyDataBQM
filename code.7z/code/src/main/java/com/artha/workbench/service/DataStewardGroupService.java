package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.DataStewardGroups;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface DataStewardGroupService {

	public List<DataStewardGroups> getDataStewardGroupList();

	public void update(DataStewardGroups dataStewardGroups, boolean isReleaseChanged) throws JsonProcessingException;

	public void saveDataStewardGroups(List<DataStewardGroups> dataStewardGroups);

	public void create(DataStewardGroups dataStewardGroups);
	
	public List<DataStewardGroups> getDataStewardGroupsByReleaseNo(Integer releaseNo);
	
	public DataStewardGroups getPreviousDataStewardGroups(DataStewardGroups dataStewardGroups)throws IOException;
	
	public DataStewardGroups getDataStewardGroupsCheckDuplicate(DataStewardGroups dataStewardGroups);

}
