package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.ParameterMode;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.procedure.ProcedureOutputs;
import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.ReleasePackages;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class ReleasePackageDAOImpl extends BaseDAOImpl<ReleasePackages, Integer> implements ReleasePackageDAO {

	public ReleasePackageDAOImpl() {
		super(ReleasePackages.class);
	}

	public List<ReleasePackages> fetchReleasePackages() {
		boolean baseRelease = Boolean.TRUE;
		Query query = entityManager.createNamedQuery("ReleasePackages.findAll");
		List<ReleasePackages> releasePackagesList = query.getResultList();
		for (ReleasePackages releasePackages : releasePackagesList) {
			releasePackages.setBaseRelease(baseRelease);
			baseRelease = Boolean.FALSE;
		}
		return releasePackagesList;
	}
	
	@Override
	public Long getReleasePackageListCount(Set<String> releaseNames) {
		TypedQuery<Long> query = entityManager.createQuery("select count(*) from ReleasePackages where releasePackageName in(:param1)",
				Long.class);
		query.setParameter("param1", releaseNames);
		return query.getSingleResult();
	}
	
	public Integer freezeReleasePackageWithProc(Integer releasePackageId)
	{
		StoredProcedureQuery spQuery = entityManager.createNamedStoredProcedureQuery("metastore.SP_REL_MANAGMENT");
		//spQuery.registerStoredProcedureParameter("STATUS", Integer.class, ParameterMode.OUT);
		//spQuery.registerStoredProcedureParameter("RELEASE", Integer.class, ParameterMode.IN);
		spQuery.setParameter("RELEASE", releasePackageId);
		spQuery.execute();
		//final ProcedureOutputs po = spQuery.get
		//final String str = po.getOutputParameterValue(p1);
		Integer status = (Integer) spQuery.getOutputParameterValue("STATUS");
		return status;
	}
	public ReleasePackages getReleasePackageList(Integer releaseId,String releaseName) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<ReleasePackages> cQuery = cb.createQuery(ReleasePackages.class);
		Root<ReleasePackages> root = cQuery.from(ReleasePackages.class);
		cQuery.select(root);
		cQuery.where(cb.or(cb.equal(root.get("releasePackageName"), releaseName),cb.equal(root.get("releasePackageNo"), releaseId)));
		
		List<ReleasePackages> releasePackages = entityManager.createQuery(cQuery).getResultList();
		if(releasePackages.isEmpty()){
			return null;
		}
		return releasePackages.get(0);
	}
	
	
	@Override
	public Integer getMaxReleasePackageId(){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> cQuery = cb.createQuery(Integer.class);
		Root<ReleasePackages> root = cQuery.from(ReleasePackages.class);
		cQuery.select(cb.max(root.<Integer>get("releasePackageNo")));
		Integer maxValue = entityManager.createQuery(cQuery).getSingleResult();
		if(maxValue==null){
			return 0;
		}
		return maxValue;
	}
}
