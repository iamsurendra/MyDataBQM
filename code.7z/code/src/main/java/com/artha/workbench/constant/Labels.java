package com.artha.workbench.constant;

import com.guvvala.framework.util.BasePropertyEnum;

/**
 * 
 * @author Guvala
 *
 */
public enum Labels implements BasePropertyEnum {
	SYSTEMEXCEPTION("systemException");

	public final String key;
	public final String bundle = "com.artha.businessDWB.labels";

	Labels(String key) {
		this.key = key;
	}

	@Override
	public String getBundle() {
		return bundle;
	}

	@Override
	public String getKey() {
		return key;
	}

	@Override
	public Integer getStatusCode() {
		// TODO Auto-generated method stub
		return null;
	}

}
