package com.artha.workbench.service;

import java.util.LinkedList;
import java.util.List;

import com.artha.workbench.models.datahub.SrcColumnErrorInfo;
import com.artha.workbench.models.datahub.TgtColumns;


public interface PopUpService {

	String getSrcrecid(String taskid);

	String getTargetrecid(String taskid);

	LinkedList<SrcColumnErrorInfo> getPopuplist(String srcid, String tarrecid, Integer entityTypeId);

	void lockTask(String taskId, String userName, String lockType);

	public void updatePendingTasks(String taskid, String userName, String status);

	public void updatetgtrecords(String taskid, String userName);

	public void updateresolvedtask(String taskid, String userName);

	List<TgtColumns> getTargetPopuplist(String srcid);

	public void updateTargetCol(List<TgtColumns> targetLists, int ismodified);

	public void saveChanges(List<TgtColumns> targetLists, String taskId, String status);
	
	public void saveResolvedTaskChanges(List<TgtColumns> targetLists, String taskId, String status);
	
	public void updateStatusToTempLock(String taskId);

	void updateTaskStatus(String taskId, String status);

}
