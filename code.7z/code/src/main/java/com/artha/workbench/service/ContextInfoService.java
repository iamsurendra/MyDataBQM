package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.models.userConfig.ContextInfo;

public interface ContextInfoService {

	public List<ContextInfo> getContexInfoList();

	public void createContextInfo(ContextInfo contexInfo);

	List<ContextInfo> findAllSchemaNames();

	public void update(ContextInfo contexInfo);

	public boolean duplicateContext(ContextInfo contextInfo);
	
	public ContextInfo DefaultSchema();
}
