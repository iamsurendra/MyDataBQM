package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.SourceToWebServiceMapping;
import com.artha.workbench.models.metastore.SourceToWebServiceMappingKey;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class SourceToWebServiceMappingDAOImpl extends BaseDAOImpl<SourceToWebServiceMapping, SourceToWebServiceMappingKey> implements SourceToWebServiceMappingDAO {

	public SourceToWebServiceMappingDAOImpl(){
		super(SourceToWebServiceMapping.class);
	}
	
	public List<SourceToWebServiceMapping> getsourceToWebServiceMappingListByReleaseNum (Integer releaseNum){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SourceToWebServiceMapping> query = cb.createQuery(SourceToWebServiceMapping.class);
		Root<SourceToWebServiceMapping> root = query.from(SourceToWebServiceMapping.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNum"), releaseNum));
		
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllSourceToWebServiceMappingReleaseIds(Integer selectedReleaseId) {
		TypedQuery<Integer> query = entityManager.createQuery("select releaseNum from SourceToWebServiceMapping where releaseNum !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
}
