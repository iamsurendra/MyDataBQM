package com.artha.workbench.models.datahub;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import com.artha.workbench.models.metastore.AbstractModel;

@Entity
@Table(name = "datahub.tasktype")
@Audited
public class TaskType extends AbstractModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "type_id")
	private Integer typeId;

	@Column(name = "label")
	private String label;

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

}
