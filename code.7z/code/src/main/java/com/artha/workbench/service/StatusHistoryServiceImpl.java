package com.artha.workbench.service;

import org.springframework.stereotype.Service;

@Service("statusHistoryService")
public class StatusHistoryServiceImpl implements StatusHistoryService{

}
