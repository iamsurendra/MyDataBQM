package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.models.datahub.Srccolumns;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.models.userConfig.FileTypeColumns;
import com.artha.workbench.models.userConfig.PartnerFileTypes;

public interface CreateTaskService {

	public Task createTask(String taskId, String taskName,List<FileTypeColumns> columns,List<Srccolumns> access, String taskIdSeq);	
	
	public List<PartnerFileTypes> findPartnerByUser();
	
	public List<PartnerFileTypes> findFileTypeByPartner(Long partnerID);
}
