package com.artha.workbench.to;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="validationRules")
@XmlAccessorType(XmlAccessType.FIELD)
public class ValidationRuleMainXmlTO {
	
	@XmlElement(name="entityFileValidationRuleDetails",type=ValidationRuleDetailsInfoTO.class)
	private List<ValidationRuleDetailsInfoTO> validationRulesXmlTOs = new ArrayList<ValidationRuleDetailsInfoTO>();

	public List<ValidationRuleDetailsInfoTO> getValidationRulesXmlTOs() {
		return validationRulesXmlTOs;
	}

	public void setValidationRulesXmlTOs(List<ValidationRuleDetailsInfoTO> validationRulesXmlTOs) {
		this.validationRulesXmlTOs = validationRulesXmlTOs;
	}

	
	
	
}
