package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileTypeWebServiceVw;
import com.artha.workbench.models.metastore.EntityFileTypeWebServiceVwKey;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class EntityFileTypeWebServiceVwDAOImpl extends BaseDAOImpl<EntityFileTypeWebServiceVw, EntityFileTypeWebServiceVwKey> implements EntityFileTypeWebServiceVwDAO{

	public EntityFileTypeWebServiceVwDAOImpl() {
		super(EntityFileTypeWebServiceVw.class);
	}
	
	@Override
	public List<EntityFileTypeWebServiceVw> getEntityFileTypeWebServiceVwListByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeWebServiceVw> query = cb.createQuery(EntityFileTypeWebServiceVw.class);
		Root<EntityFileTypeWebServiceVw> root = query.from(EntityFileTypeWebServiceVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}	

}
