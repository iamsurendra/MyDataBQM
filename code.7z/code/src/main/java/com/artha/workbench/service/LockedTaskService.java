package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.models.datahub.LockedTask;


public interface LockedTaskService {
	
	List<LockedTask> getLockedTasksList();

	void unlockEditLockTask(List<String> lockedTaskIdList);


	void unlockTempLockTasks(List<String> lockedTaskIdList);


}
