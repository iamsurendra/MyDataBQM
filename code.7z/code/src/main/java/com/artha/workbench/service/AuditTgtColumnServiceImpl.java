package com.artha.workbench.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.artha.workbench.dao.AuditTgtColumnDAO;
import com.artha.workbench.dao.TaskcolLayoutDAO;
import com.artha.workbench.models.core.AuditTgtColInfo_VW;
import com.artha.workbench.models.datahub.TaskcolLayout;
import com.artha.workbench.to.AuditTgtColumnTO;

@Service("auditTgtColumnService")
public class AuditTgtColumnServiceImpl implements AuditTgtColumnService {

	@Autowired
	AuditTgtColumnDAO auditTgtColumnDAO;

	@Autowired
	TaskcolLayoutDAO taskcolLayoutDAO;

	@Transactional
	@Override
	public List<AuditTgtColumnTO> getAuditTgtColumns(String taskId) {
		List<AuditTgtColumnTO> auditTaskList = new ArrayList<AuditTgtColumnTO>();
		List<AuditTgtColumnTO> auditTaskListSorted = new LinkedList<AuditTgtColumnTO>();
		List<AuditTgtColInfo_VW> auditTgtColInfo_VWList = auditTgtColumnDAO.getAuditTgtColumnList(taskId);

		Map<String, AuditTgtColumnTO> tgtColumnMap = new HashMap<String, AuditTgtColumnTO>();
		for (AuditTgtColInfo_VW tgtRev : auditTgtColInfo_VWList) {
			// TODO check for the first record what will happen
			if (tgtColumnMap.containsKey(tgtRev.getTgtcolId())) {
				AuditTgtColumnTO auditTgtColumnTO = tgtColumnMap.get(tgtRev.getTgtcolId());
				auditTgtColumnTO.setPresentValue(tgtRev.getModifiedvalue());
				// auditTaskList.add(auditTgtColumnTO);
				// isOnlyOneRecord = false;
				if (auditTaskList.contains(auditTgtColumnTO)) {
					auditTaskList.remove(auditTgtColumnTO);
				}
				auditTaskList.add(auditTgtColumnTO);
			} else {
				AuditTgtColumnTO auditTgtColumnTO = new AuditTgtColumnTO();
				auditTgtColumnTO.setDefColName(tgtRev.getDefColName());
				auditTgtColumnTO.setPreviousValue(tgtRev.getModifiedvalue());
				auditTgtColumnTO.setTgtcolId(tgtRev.getTgtcolId());
				auditTgtColumnTO.setTgtrecId(tgtRev.getTgtrecId());
				tgtColumnMap.put(tgtRev.getTgtcolId(), auditTgtColumnTO);
				auditTaskList.add(auditTgtColumnTO);
			}
		}
		/*
		 * if(isOnlyOneRecord) {
		 * 
		 * if(!auditTgtColInfo_VWList.isEmpty()) { //Need to fetch source record
		 * values as their previous values //When only one record is present in
		 * target valuec auditTaskList.addAll(tgtColumnMap.values()); } else{
		 * //Need to fetch source record values as their present values //TODO
		 * need confirmation if no records are present in target then what
		 * should we do }
		 * 
		 * }
		 */
		List<TaskcolLayout> taskcolLayoutList = taskcolLayoutDAO.getTaskcolLayoutData(taskId);
		if (taskcolLayoutList.isEmpty()) {
			auditTaskListSorted.addAll(auditTaskList);
			return auditTaskList;
		}
		for (TaskcolLayout taskcolLayout : taskcolLayoutList) {
			for (AuditTgtColumnTO srccolumn : auditTaskList) {
				if (taskcolLayout.getSchemaPk().equalsIgnoreCase(srccolumn.getDefColName())) {
					auditTaskListSorted.add(srccolumn);
					break;
				}
			}
		}

		return auditTaskListSorted;
	}
}
