package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.FileFormatDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.metastore.FileFormat;
import com.artha.workbench.models.metastore.FileFormatId;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("fileFormatService")
public class FileFormatServiceImpl implements FileFormatService {

	@Autowired
	FileFormatDAO fileFormatDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Transactional(readOnly = true)
	public List<FileFormat> getFileFormatList() {
		return fileFormatDAO.findAll();
	}
	
	
	@Transactional(readOnly = true)
	public List<FileFormat> getFileFormatListByReleaseNo(Integer releaseNo) {
		return fileFormatDAO.getFileFormatListByReleaseNo(releaseNo);
	}

	@Transactional
	public void create(FileFormat fileFormat) {
		fileFormatDAO.create(fileFormat);
	}
	
	public FileFormat getPreviousFileFormat(FileFormat fileFormat) throws IOException
	{
		FileFormatId fileFormatId = new FileFormatId();
		fileFormatId.setFileFormatID(fileFormat.getFileFormatID());
		String fileFormatIdJson = AppWebUtils.convertObjectToJson(fileFormatId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(fileFormat.getReleaseNo(), "FILEFORMAT", fileFormatIdJson);
		FileFormat previousFileFormat = new FileFormat();
		if(releaseArchive!=null){
		previousFileFormat = AppWebUtils.convertJsonToObject(FileFormat.class, releaseArchive.getRecData());
		}
		return previousFileFormat;
		
	}

	@Transactional
	public void update(FileFormat fileFormat,boolean isReleaseChanged) throws JsonProcessingException {
		FileFormat oldEntity = fileFormatDAO.findOne(fileFormat.getFileFormatID());
		checkForCyclicDependency(fileFormat);
		if(isReleaseChanged)
		{
		ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
		releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
		releaseArchiveKey.setReleaseId(fileFormat.getReleaseNo());
		releaseArchiveKey.setTableName("FILEFORMAT");
		FileFormatId fileFormatId = new FileFormatId();
		fileFormatId.setFileFormatID(oldEntity.getFileFormatID());
		releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(fileFormatId));
		ReleaseArchive releaseArchive =releaseArchiveDAO.findOne(releaseArchiveKey);
		if(releaseArchive!=null){
			releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
			releaseArchiveDAO.update(releaseArchive);
		}else{
			releaseArchive=new ReleaseArchive();
			releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
			releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
			releaseArchiveDAO.create(releaseArchive);
		}
		
		}
		fileFormatDAO.update(fileFormat);
	}
	
	
	private void checkForCyclicDependency(FileFormat fileFormat) throws JsonProcessingException
	{
		FileFormatId fileFormatId = new FileFormatId();
		fileFormatId.setFileFormatID(fileFormat.getFileFormatID());
		String jsonId = AppWebUtils.convertObjectToJson(fileFormatId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(fileFormat.getReleaseNo(), "FILEFORMAT", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	
	@Transactional
	public void saveFileFormat(List<FileFormat> fileFormats)
	{
		deleteFileFormatData();
		fileFormatDAO.saveFileFormat(fileFormats);
	}
	@Transactional
	public int getmaxfileFormatID()
	{
		return fileFormatDAO.getmaxfileFormatID();
	}
	@Transactional
	public HashMap<Integer,String> loadFileFormatId()
	{
		return fileFormatDAO.loadFileFormatId();	
	}
	
	@Override
	@Transactional(readOnly = true)
	public long getFileFormatDataCount(){
		return fileFormatDAO.count();
	}
	
	@Transactional
	public void deleteFileFormatData(){
		fileFormatDAO.deleteFileFormat();
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<Integer> getFileFormatReleaseNumbers(Set<Integer> fileFormatIds,Integer selectedReleaseNumber){
		return fileFormatDAO.getFileFormatReleaseNumbers(fileFormatIds, selectedReleaseNumber);
	}


	@Override
	@Transactional(readOnly = true)
	public List<Integer> getAllFileFormatReleaseIds(Integer selectedReleaseId) {
		return fileFormatDAO.getAllFileFormatReleaseIds(selectedReleaseId);
	}


	@Override
	@Transactional(readOnly = true)
	public List<FileFormat> getFileFormatsList(Set<Integer> fileFormatIds, Integer selectedReleaseNumber) {
		return fileFormatDAO.getFileFormatsList(fileFormatIds, selectedReleaseNumber);
	}
	
}
