package com.artha.workbench.service;

//excel

public interface DownloadService {
		
    public void downloadExcel(String filename,String versionid,String osname) ;
}