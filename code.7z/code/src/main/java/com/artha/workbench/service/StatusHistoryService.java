package com.artha.workbench.service;

public interface StatusHistoryService {

}
