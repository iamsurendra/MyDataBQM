package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.ValidationStep;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface ValidationStepService {

	public List<ValidationStep> getValidationStepList();

	public void create(ValidationStep validationStep);

	public void update(ValidationStep validationStep, boolean isReleaseChanged) throws JsonProcessingException;

	public HashMap<String, Integer> loadStepId();

	public HashMap<Integer, String> loadStepIdMap();

	public int getmaxStepID();

	public List<ValidationStep> getValidationStepListByReleaseNo(Integer releaseNo);

	public ValidationStep getPreviousValidationStep(ValidationStep validationStep) throws IOException;

	List<Integer> getValidationStepReleaseNumbers(Set<Integer> stepIds, Integer selectedReleaseNumber);

	List<Integer> getAllValidationStepReleaseIds(Integer selectedReleaseId);
	
	List<ValidationStep> getValidationStepList(Set<Integer> stepIds,Integer selectedReleaseNumber);
}
