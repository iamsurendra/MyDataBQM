package com.artha.workbench.models.userConfig;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the hssecurityaccess database table.
 * 
 */
@Entity
@Table(name ="userconfig.hssecurityaccess")
@NamedQuery(name="HsSecurityAccess.findAll", query="SELECT h FROM HsSecurityAccess h")
public class HsSecurityAccess implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="COL_NAME")
	private String colName;

	@Id
	@Column(name="FILE_NAME")
	private String fileName;

	@Id
	@Column(name="GROUP_ID")
	private int groupId;

	@Id
	@Column(name="PARTNER_NAME")
	private String partnerName;
	
	
	@Id
	@Column(name="EntityFileTypeID")
	private String entityFileTypeId;
	
	
	
	@Column(name="WRITE_MODE")
	private int writeMode;
	
	

	public HsSecurityAccess() {
	}

	
	
	public String getEntityFileTypeId() {
		return entityFileTypeId;
	}



	public void setEntityFileTypeId(String entityFileTypeId) {
		this.entityFileTypeId = entityFileTypeId;
	}



	public String getColName() {
		return this.colName;
	}

	public void setColName(String colName) {
		this.colName = colName;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getGroupId() {
		return this.groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public String getPartnerName() {
		return this.partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public int getWriteMode() {
		return this.writeMode;
	}

	public void setWriteMode(int writeMode) {
		this.writeMode = writeMode;
	}

}