package com.artha.workbench.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.FileTypeColumnsDAO;
import com.artha.workbench.dao.HssecurityroleDAO;
import com.artha.workbench.dao.PartnerFileTypesDAO;
import com.artha.workbench.dao.RoleprivilegesDAO;
import com.artha.workbench.dao.RolesDAO;
import com.artha.workbench.dao.UserRolesDAO;
import com.artha.workbench.models.userConfig.FileTypeColumns;
import com.artha.workbench.models.userConfig.Hssecurityrole;
import com.artha.workbench.models.userConfig.PartnerFileTypes;
import com.artha.workbench.models.userConfig.Roles;
import com.artha.workbench.models.userConfig.UserRoles;


@Service("userRolesService")
public class UserRolesServiceImpl implements UserRolesService {

	@Autowired
	UserRolesDAO userRolesDAO;

	@Autowired
	RolesDAO rolesDAO;

	@Autowired
	RoleprivilegesDAO roleprivilegesDAO;

	@Autowired
	HssecurityroleDAO hssecurityroleDAO;

	@Autowired
	FileTypeColumnsDAO fileTypeColumnsDAO;

	@Autowired
	PartnerFileTypesDAO partnerFileTypesDAO;

	@Transactional
	public void update(UserRoles userRoles) {
		userRolesDAO.update(userRoles);
	}

	@Transactional
	public List<UserRoles> getUserRoles(int loginId) {
		return userRolesDAO.getUserRoles(loginId);
	}

	@Transactional
	public List<UserRoles> getUserRolesDetails(int loginid) {
		return userRolesDAO.getUserRolesDetails(loginid);
	}

	@Transactional
	public List<Roles> getRolesList() {
		return rolesDAO.getAllRoles();
	}

	@Transactional
	public Roles saveUserRole(Roles roles) {
		return rolesDAO.create(roles);
	}
	
	@Transactional
	public void updateUserRole(Roles roles) {
		rolesDAO.update(roles);
	}
	

	@Transactional
	public void savePrivileges(Hssecurityrole hssecurityrole) {
		hssecurityroleDAO.create(hssecurityrole);
	}

	@Transactional
	public void submitUserRoles(List<Hssecurityrole> hssecurityrole,Long roleId) {
		List<Hssecurityrole> hssecurityroles = hssecurityroleDAO.findAllByRoleID(roleId);
		if(!hssecurityroles.isEmpty()){
			hssecurityroleDAO.deleteAll(hssecurityroles);	
		}
		hssecurityroleDAO.batchCreate(hssecurityrole, 50);
	}

	@Transactional
	public Roles findRoleById(Long roleId) {
		return rolesDAO.findOne(roleId);
	}

	@Transactional
	public List<Long> findPartnerByRoleID(Long roleId) {
		return hssecurityroleDAO.findPartnerByRoleID(roleId);
	}

	@Transactional
	public List<Long> findFileTypeByPartnerID(Long partnerID) {
		return hssecurityroleDAO.findFileTypeByPartnerID(partnerID);
	}
	
	@Transactional
	public List<Long> findFileTypeByPartnerIDRoleId(Long partnerID,Long roleId) {
		//TODO get confirmation whether we need to return file type or entity file type id
		List<Long> entityFileTypeId = hssecurityroleDAO.findFileTypeByPartnerIDRoleId(partnerID,roleId);
		if(entityFileTypeId==null ||entityFileTypeId.isEmpty())
			return new ArrayList<Long>();
		else
		//partnerFileTypesDAO.findFileTypebyPartnerIdFileId(partnerID, fileTypeId);
		return entityFileTypeId;
	}

	@Transactional
	public List<String> findFileTypebyPartnerName(String partnerName) {
		return partnerFileTypesDAO.findFileTypebyPartnerName(partnerName);
	}

	@Transactional
	public List<String> findColumnsByFileName(String fileName) {
		return fileTypeColumnsDAO.findColumnsByFileName(fileName);
	}

	@Transactional
	public List<PartnerFileTypes> findAllPartner() {
		return partnerFileTypesDAO.findAllPartner();
	}

	@Transactional
	public List<PartnerFileTypes> findAllFileTypes(Long partnerID) {
		return partnerFileTypesDAO.findAllFileTypes(partnerID);
	}
	

	@Transactional
	public List<PartnerFileTypes> findAllFileTypes(List<Long> ids) {
		return partnerFileTypesDAO.findAllFileTypes(ids);
	}

	@Transactional
	public PartnerFileTypes findPartnerById(Long id) {
		return partnerFileTypesDAO.findPartnerById(id);
	}

	@Transactional
	public List<FileTypeColumns> findColumnsByEntityFileTypeID(Long id) {
		return fileTypeColumnsDAO.findColumnsByEntityFileTypeID(id);
	}
	
	@Transactional
	public List<FileTypeColumns> findFileTypeColumnsByEntityFileTypeID(Long id){
		return fileTypeColumnsDAO.findFileTypeColumnsByEntityFileTypeID(id);
		
	}
	
	@Transactional
	public String findFileTypeAbbr(Long fileTypeId){
		if(null==fileTypeId)
			return null;
		return partnerFileTypesDAO.findFileTypeAbbr(fileTypeId);
	}

	public String findPartnerAbbr(Long entityId){
		if(null==entityId)
			return null;
		return partnerFileTypesDAO.findPartnerAbbr(entityId);
	}

	@Transactional
	public  List<Hssecurityrole> findColumnsByPartnerIdFileTypeID(Long partnerTypeId,Long entityFileTypeId,Long roleId) {
			//TODO get confiramtion whether we need to return file type or entity file type id
			//Long fileTypeId = partnerFileTypesDAO.findOne(entityFileTypeId).getFileTypeId();
		 List<Hssecurityrole> columnNames = hssecurityroleDAO.findColumnByPartnerIdFileTypeID(partnerTypeId,entityFileTypeId,roleId);
		String colValue="";
		 for(Hssecurityrole role : columnNames)
		 {
			 String readMode;
			 String writeMode;
			 if(role.isWriteMode())
			 {
				 readMode="true";
				 writeMode="true";
			 }else
			 {
				 readMode="true";
				 writeMode="false";
			 }
			 colValue = role.getFileId().toString().concat("|").concat(role.getId().getColName()).concat("|").concat(readMode).concat("|").concat(writeMode);
			 colValue = colValue.concat(",");
		 }
		 return columnNames;
	}

	@Transactional
	public PartnerFileTypes findFileTypeID(Long id) {
		return partnerFileTypesDAO.findOne(id);
	}
	
	@Transactional
	public boolean duplicateRoleName(String roleName){
		return rolesDAO.duplicateRoleName(roleName);
	}
	
	public List<Hssecurityrole> findAllByRoleID(Long roleId) {
		return hssecurityroleDAO.findAllByRoleID(roleId);
	}
	
	public List<PartnerFileTypes> partnerFileTypesList(){
		return partnerFileTypesDAO.findAll();
	}

	@Override
	public List<String> getColumnsByEntityFileTypeId(Long id) {
		return fileTypeColumnsDAO.getColumnsByEntityFileTypeId(id);
	}
	
	@Override
	@Transactional
	public void submitUserRoles(List<Hssecurityrole> hssecurityrole, List<Long> partnerIdsList,
			List<Long> fileTypeIdsList, Long roleId) {
		if(!partnerIdsList.isEmpty() && !fileTypeIdsList.isEmpty()){
			hssecurityroleDAO.deleteColumnsByPartnerIdFileTypeID(partnerIdsList, fileTypeIdsList, roleId);
		}
		hssecurityroleDAO.batchCreate(hssecurityrole, 50);
		Roles roles = rolesDAO.findOne(roleId);
		roles.setActive(true);
		rolesDAO.update(roles);
	}
	
	@Override
	public boolean userRolesExists(List<Long> partnerIdsList,List<Long> fileTypeIdsList, Long roleId){
		int count = hssecurityroleDAO.findColumnByPartnerIdFileTypeID(partnerIdsList, fileTypeIdsList, roleId);
		return count>0;
	}
	
	@Transactional
	public  List<Hssecurityrole> findHssecurityroleByPartnerIdRoleID(Long partnerTypeId,Long roleId) {
		return hssecurityroleDAO.findHssecurityroleByPartnerIdRoleID(partnerTypeId,roleId);
	}
	
	@Transactional
	public List<PartnerFileTypes> getPartnerFileTypesBypartnerId(Long partnerId, List<Long> entityTypeIds) {
		return partnerFileTypesDAO.getPartnerFileTypesBypartnerId(partnerId, entityTypeIds);
	}
}