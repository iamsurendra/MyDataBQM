package com.artha.workbench.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.config.AuditLogDetails;
import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.metastore.EntityFileRecColumnVw;
import com.artha.workbench.models.metastore.EntityFileTypeScheduleXrefVw;
import com.artha.workbench.models.metastore.EntityFileTypeXrefVw;
import com.artha.workbench.models.metastore.EntityFileValidationRuleVw;
import com.artha.workbench.models.metastore.EntityMaster;
import com.artha.workbench.models.metastore.EntityType;
import com.artha.workbench.models.metastore.FileFormat;
import com.artha.workbench.models.metastore.FileValStepXrefVw;
import com.artha.workbench.models.metastore.HSFileType;
import com.artha.workbench.models.metastore.HeaderFooterColsVw;
import com.artha.workbench.models.metastore.HeaderFooterVw;
import com.artha.workbench.models.metastore.RuleType;
import com.artha.workbench.models.metastore.SourceToTargetMappingVw;
import com.artha.workbench.models.metastore.ValidationStep;
import com.artha.workbench.models.userConfig.Groups;
import com.artha.workbench.models.userConfig.Roles;
import com.guvvala.framework.dao.BaseDAOImpl;
import com.guvvala.framework.util.DateUtils;



/**
 * 
 * @author Guvala
 *
 */
@Repository
public class AuditLogDetailsDAOImpl extends BaseDAOImpl<AuditLogDetails, Integer> implements AuditLogDetailsDAO {


	public AuditLogDetailsDAOImpl() {
		super(AuditLogDetails.class);
	}

	public List<AuditLogDetails> userlist(int loginid) {
		TypedQuery<AuditLogDetails> query = entityManager
				.createQuery("from AuditLogDetails where loginid = '" + loginid + "' order by modifieddate desc", AuditLogDetails.class);
		return query.getResultList();
	}
	public List<AuditLogDetails> adminlist(int loginid) {
		TypedQuery<AuditLogDetails> query = entityManager
				.createQuery("from AuditLogDetails where loginid = '" + loginid + "' or parentid = '" + loginid + "' order by modifieddate desc", AuditLogDetails.class);
		return query.getResultList();
	}

	public void saveAll(HttpServletRequest request, HttpSession httpsession, String tname, List<? extends AbstractModel> entities,
			List<? extends AbstractModel> entityTypes, String reviewflag, HashMap<Integer, String> logintypemap,int reviewlistcount) {

		DateFormat dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
		List<AbstractModel> DbentityTypelist = (List<AbstractModel>) request.getSession().getAttribute("DbentityTypelist");
		List<AbstractModel> Dbentitymasterlist = (List<AbstractModel>) request.getSession().getAttribute("Dbentitymasterlist");
		List<AbstractModel> Dbvalidationsteplist = (List<AbstractModel>) request.getSession().getAttribute("Dbvalidationsteplist");
		List<AbstractModel> DbruleTypelist = (List<AbstractModel>) request.getSession().getAttribute("DbruleTypelist");
		List<AbstractModel> DbhSFileTypelist = (List<AbstractModel>) request.getSession().getAttribute("DbhSFileTypelist");
		List<AbstractModel> DbfileFormatlist = (List<AbstractModel>) request.getSession().getAttribute("DbfileFormatlist");
		List<AbstractModel> DbentityFileTypeXreflist = (List<AbstractModel>) request.getSession().getAttribute("DbentityFileTypeXreflist");
		List<AbstractModel> DbheaderFooterColslist = (List<AbstractModel>) request.getSession().getAttribute("DbheaderFooterColslist");
		List<AbstractModel> DbheaderFooterList = (List<AbstractModel>) request.getSession().getAttribute("DbheaderFooterList");
		List<AbstractModel> DbsourceToTargetMappingList = (List<AbstractModel>) request.getSession().getAttribute("DbsourceToTargetMappingList");
		List<AbstractModel> DbentityFileValidationRule = (List<AbstractModel>) request.getSession().getAttribute("DbentityFileValidationRule");
		List<AbstractModel> DbfileValStepXref = (List<AbstractModel>) request.getSession().getAttribute("DbfileValStepXref");
		List<AbstractModel> DbentityFileTypeScheduleXref = (List<AbstractModel>) request.getSession().getAttribute("DbentityFileTypeScheduleXref");
		List<AbstractModel> DbentityFileRecColumnlist = (List<AbstractModel>) request.getSession().getAttribute("DbentityFileRecColumnlist");
		Long loginid = 0l;
		int logintypeid = 0;
		String rolename = "";
		if (httpsession.getAttribute("loginID") != null)
			loginid = (Long) httpsession.getAttribute("loginID");
		boolean isadmin = (boolean)httpsession.getAttribute("isadmin");
		boolean issuperadmin = (boolean)httpsession.getAttribute("issuperadmin");
		Long parentid =0l;
		if(!issuperadmin && !isadmin)
		{
			parentid =  (Long)httpsession.getAttribute("parentid");
		}
		if (httpsession.getAttribute("loginTypeid") != null)
			logintypeid = (Integer) httpsession.getAttribute("loginTypeid");
		// int maxid = 0;
		// maxid = d.getmaxauditid();
		// HashMap<Integer,String> logintypemap = new HashMap<Integer,String>();
		// logintypemap = saveOrUpdateEntitesService.loadlogintypeid();
		// logintypemap = roleTypeService.loadlogintypeid();
		if (logintypemap != null && logintypemap.containsKey(logintypeid))
			rolename = logintypemap.get(logintypeid);
		if (tname != null && tname.equals("EntityType")) {
			EntityType e = null;
			EntityType e1 = null;
			for (int i = 0; i < reviewlistcount; i++) {
				e = new EntityType();
				e1 = new EntityType();
				e = (EntityType) entityTypes.get(i);
				if(e.getDescription()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (EntityType) DbentityTypelist.get(i);
				} else {
					e1 = (EntityType) entities.get(i);
				}
				if (e1.getEntityTypeID() == null) {
					e1.setEntityTypeID(0);
				}
				if (e.getEntityTypeID() != null && !e.getEntityTypeID().equals(e1.getEntityTypeID())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					//// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EntityTypeID");
					auditlog.setOldvalue(e1.getEntityTypeID().toString());
					auditlog.setNewvalue(e.getEntityTypeID().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);

					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
					// create(auditlog);
				}
				if (e1.getDescription() == null) {
					e1.setDescription("");
				}
				if (e.getDescription() != null && !e.getDescription().equals(e1.getDescription())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Description");
					auditlog.setOldvalue(e1.getDescription());
					auditlog.setNewvalue(e.getDescription());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}
		}
		// File Format
		if (tname != null && tname.equals("FileFormat")) {
			FileFormat e = null;
			FileFormat e1 = null;
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new FileFormat();
				e1 = new FileFormat();
				e = (FileFormat) entityTypes.get(i);
				if(e.getFileFormat()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (FileFormat) DbfileFormatlist.get(i);
				} else {
					e1 = (FileFormat) entities.get(i);
				}
				if (e1.getFileFormat() == null) {
					e1.setFileFormat("");
				}
				if (e.getFileFormat() != null && !e.getFileFormat().equals(e1.getFileFormat())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FileFormat");
					auditlog.setOldvalue(e1.getFileFormat().toString());
					auditlog.setNewvalue(e.getFileFormat().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getDescription() == null) {
					e1.setDescription("");
				}
				if (e.getDescription() != null && !e.getDescription().equals(e1.getDescription())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Description");
					auditlog.setOldvalue(e1.getDescription());
					auditlog.setNewvalue(e.getDescription());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}

		}
		// ValidationStep
		else if (tname != null && tname.equals("ValidationStep")) {
			ValidationStep e = null;
			ValidationStep e1 = null;
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new ValidationStep();
				e1 = new ValidationStep();
				e = (ValidationStep) entityTypes.get(i);
				if(e.getStepName()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (ValidationStep) Dbvalidationsteplist.get(i);
				} else {
					e1 = (ValidationStep) entities.get(i);
				}
				if (e1.getStepName() == null) {
					e1.setStepName("");
				}
				if (e.getStepName() != null && !e.getStepName().equals(e1.getStepName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("StepName");
					auditlog.setOldvalue(e1.getStepName().toString());
					auditlog.setNewvalue(e.getStepName().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getStepDescription() == null) {
					e1.setStepDescription("");
				}
				if (e.getStepDescription() != null && !e.getStepDescription().equals(e1.getStepDescription())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Step Description");
					auditlog.setOldvalue(e1.getStepDescription());
					auditlog.setNewvalue(e.getStepDescription());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getJobName() == null) {
					e1.setJobName("");
				}
				if (e.getJobName() != null && !e.getJobName().equals(e1.getJobName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("JobName");
					auditlog.setOldvalue(e1.getJobName());
					auditlog.setNewvalue(e.getJobName());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if(e.getEffectiveDate()!=null && !"".equals(e.getEffectiveDate()))
					e.setEffectiveDtstr(DateUtils.convertDateFormat(e.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if(e1.getEffectiveDate()!=null && !"".equals(e1.getEffectiveDate()))
					e1.setEffectiveDtstr(DateUtils.convertDateFormat(e1.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if (e.getEffectiveDtstr() != null && !e.getEffectiveDtstr().equals(e1.getEffectiveDtstr())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EffectiveDt");
					auditlog.setOldvalue(e1.getEffectiveDate().toString());
					auditlog.setNewvalue(e.getEffectiveDate().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getActive() == null) {
					e1.setActive("");
				}
				if (e.getActive() != null && !e.getActive().equals(e1.getActive())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Active");
					auditlog.setOldvalue(e1.getActive());
					auditlog.setNewvalue(e.getActive());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}
		}
		// Rule Type
		if (tname != null && tname.equals("RuleType")) {
			RuleType e = null;
			RuleType e1 = null;
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new RuleType();
				e1 = new RuleType();
				e = (RuleType) entityTypes.get(i);
				if(e.getRuleType()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (RuleType) DbruleTypelist.get(i);
				} else {
					e1 = (RuleType) entities.get(i);
				}
				if (e1.getRuleType() == null) {
					e1.setRuleType("");
				}
				if (e.getRuleType() != null && !e.getRuleType().equals(e1.getRuleType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleType");
					auditlog.setOldvalue(e1.getRuleType().toString());
					auditlog.setNewvalue(e.getRuleType().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getRuleTypeDesc() == null) {
					e1.setRuleTypeDesc("");
				}
				if (e.getRuleTypeDesc() != null && !e.getRuleTypeDesc().equals(e1.getRuleTypeDesc())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleTypeDesc");
					auditlog.setOldvalue(e1.getRuleTypeDesc());
					auditlog.setNewvalue(e.getRuleTypeDesc());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}

		}
		// entity Master
		if (tname != null && tname.equals("EntityMaster")) {
			EntityMaster e = null;
			EntityMaster e1 = null;
			//System.out.println("**entityTypes--size**"+entityTypes.size());
			for (int i = 0; i < reviewlistcount; i++) {
				e = new EntityMaster();
				e1 = new EntityMaster();
				e = (EntityMaster) entityTypes.get(i);
				if(e.getEntityName()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (EntityMaster) Dbentitymasterlist.get(i);
				} else {
					e1 = (EntityMaster) entities.get(i);
				}
				if (e1.getEntityName() == null) {
					e1.setEntityName("");
				}
				if (e.getEntityName() != null && !e.getEntityName().equals(e1.getEntityName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EntityName");
					auditlog.setOldvalue(e1.getEntityName().toString());
					auditlog.setNewvalue(e.getEntityName().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getEntityNameAbbr() == null) {
					e1.setEntityNameAbbr("");
				}
				if (e.getEntityNameAbbr() != null && !e.getEntityNameAbbr().equals(e1.getEntityNameAbbr())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EntityNameAbbr");
					auditlog.setOldvalue(e1.getEntityNameAbbr());
					auditlog.setNewvalue(e.getEntityNameAbbr());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getEntityTypeID() == null) {
					e1.setEntityTypeID(0);
				}
				if (e.getEntityTypeID() != null && !e.getEntityTypeID().equals(e1.getEntityTypeID())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EntityTypeID");
					auditlog.setOldvalue(e1.getEntityTypeID().toString());
					auditlog.setNewvalue(e.getEntityTypeID().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getAddrLine1() == null) {
					e1.setAddrLine1("");
				}
				if (e.getAddrLine1() != null && !e.getAddrLine1().equals(e1.getAddrLine1())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("AddrLine1");
					auditlog.setOldvalue(e1.getAddrLine1().toString());
					auditlog.setNewvalue(e.getAddrLine1().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getAddrLine2() == null) {
					e1.setAddrLine2("");
				}
				if (e.getAddrLine2() != null && !e.getAddrLine2().equals(e1.getAddrLine2())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("AddrLine2");
					auditlog.setOldvalue(e1.getAddrLine2().toString());
					auditlog.setNewvalue(e.getAddrLine2().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getAddrLine3() == null) {
					e1.setAddrLine3("");
				}
				if (e.getAddrLine3() != null && !e.getAddrLine3().equals(e1.getAddrLine3())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("AddrLine3");
					auditlog.setOldvalue(e1.getAddrLine3().toString());
					auditlog.setNewvalue(e.getAddrLine3().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getCityName() == null) {
					e1.setCityName("");
				}
				if (e.getCityName() != null && !e.getCityName().equals(e1.getCityName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("CityName");
					auditlog.setOldvalue(e1.getCityName().toString());
					auditlog.setNewvalue(e.getCityName().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getStateCd() == null) {
					e1.setStateCd("");
				}
				if (e.getStateCd() != null && !e.getStateCd().equals(e1.getStateCd())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("StateCd");
					auditlog.setOldvalue(e1.getStateCd().toString());
					auditlog.setNewvalue(e.getStateCd().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getPostalCd() == null) {
					e1.setPostalCd("");
				}
				if (e.getPostalCd() != null && !e.getPostalCd().equals(e1.getPostalCd())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("PostalCd");
					auditlog.setOldvalue(e1.getPostalCd().toString());
					auditlog.setNewvalue(e.getPostalCd().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getPostalPlus() == null) {
					e1.setPostalPlus("");
				}
				if (e.getPostalPlus() != null && !e.getPostalPlus().equals(e1.getPostalPlus())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("PostalPlus");
					auditlog.setOldvalue(e1.getPostalPlus().toString());
					auditlog.setNewvalue(e.getPostalPlus().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getActive() == null) {
					e1.setActive("");
				}
				if (e.getActive() != null && !e.getActive().equals(e1.getActive())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Active");
					auditlog.setOldvalue(e1.getActive().toString());
					auditlog.setNewvalue(e.getActive().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if(e.getEffectiveDt()!=null && !"".equals(e.getEffectiveDt()))
					e.setEffectiveDtstr(DateUtils.convertDateFormat(e.getEffectiveDt(), DateUtils.INPUT_TABLEFORMAT));
				if(e1.getEffectiveDt()!=null && !"".equals(e1.getEffectiveDt()))
					e1.setEffectiveDtstr(DateUtils.convertDateFormat(e1.getEffectiveDt(), DateUtils.INPUT_TABLEFORMAT));
				if (e.getEffectiveDtstr() != null && !e.getEffectiveDtstr().equals(e1.getEffectiveDtstr())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EffectiveDt");
					auditlog.setOldvalue(e1.getEffectiveDtstr().toString());
					auditlog.setNewvalue(e.getEffectiveDtstr().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}
		}
		// FileValStepXref
		if (tname != null && tname.equals("FileValStepXref")) {
			FileValStepXrefVw e = null;
			FileValStepXrefVw e1 = null;
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new FileValStepXrefVw();
				e1 = new FileValStepXrefVw();
				e = (FileValStepXrefVw) entityTypes.get(i);
				if(e.getEntityName()==null){
					continue;
				}
				
					if (reviewflag != null && reviewflag.equals("true")) {
						e1 = (FileValStepXrefVw) DbfileValStepXref.get(i);
					} else {
						e1 = (FileValStepXrefVw) entities.get(i);
					}
					if (e1.getEntityName() == null) {
						e1.setEntityName("");
					}
					if (e1.getFileMask() != null) {
					if (e.getEntityName() != null && !e.getEntityName().equals(e1.getEntityName())) {
						AuditLogDetails auditlog = new AuditLogDetails();
						dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
						Date date = new Date();
						// auditlog.setAuditid(maxid+1);
						auditlog.setTablename(tname);
						auditlog.setUsername(rolename);
						auditlog.setChangetype("Update");
						auditlog.setChnagedfield("EntityName");
						auditlog.setOldvalue(e1.getEntityName().toString());
						auditlog.setNewvalue(e.getEntityName().toString());
						auditlog.setLoginid(loginid.intValue());
						auditlog.setUsername(rolename);
						auditlog.setRowno(i+1);
						if(!issuperadmin && !isadmin)
						{
							auditlog.setParentid(parentid);
						}
						try {
							auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
						} catch (ParseException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
						auditlog.setModifiedby((String) httpsession.getAttribute("username"));
						create(auditlog);
					}
					if (e1.getFileMask() == null) {
						e1.setFileMask("");
					}
					if (e.getFileMask() != null && !e.getFileMask().equals(e1.getFileMask())) {
						AuditLogDetails auditlog = new AuditLogDetails();
						dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
						Date date = new Date();
						// auditlog.setAuditid(maxid+1);
						auditlog.setTablename(tname);
						auditlog.setUsername(rolename);
						auditlog.setChangetype("Update");
						auditlog.setChnagedfield("FileMask");
						auditlog.setOldvalue(e1.getFileMask());
						auditlog.setNewvalue(e.getFileMask());
						auditlog.setLoginid(loginid.intValue());
						auditlog.setUsername(rolename);
						auditlog.setRowno(i+1);
						if(!issuperadmin && !isadmin)
						{
							auditlog.setParentid(parentid);
						}
						try {
							auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
						} catch (ParseException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
						auditlog.setModifiedby((String) httpsession.getAttribute("username"));
						create(auditlog);
					}
					if (e1.getFileType() == null) {
						e1.setFileType("");
					}
										if (e.getFileType() != null && !e.getFileType().equals(e1.getFileType())) {
						AuditLogDetails auditlog = new AuditLogDetails();
						dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
						Date date = new Date();
						// auditlog.setAuditid(maxid+1);
						auditlog.setTablename(tname);
						auditlog.setUsername(rolename);
						auditlog.setChangetype("Update");
						auditlog.setChnagedfield("HSFileType");
						auditlog.setOldvalue(e1.getFileType());
						auditlog.setNewvalue(e.getFileType());
						auditlog.setLoginid(loginid.intValue());
						auditlog.setUsername(rolename);
						auditlog.setRowno(i+1);
						if(!issuperadmin && !isadmin)
						{
							auditlog.setParentid(parentid);
						}
						try {
							auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
						} catch (ParseException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
						auditlog.setModifiedby((String) httpsession.getAttribute("username"));
						create(auditlog);
					}
					if (e1.getStepName() == null) {
						e1.setStepName("");
					}
					if (e.getStepName() != null && !e.getStepName().equals(e1.getStepName())) {
						AuditLogDetails auditlog = new AuditLogDetails();
						dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
						Date date = new Date();
						// auditlog.setAuditid(maxid+1);
						auditlog.setTablename(tname);
						auditlog.setUsername(rolename);
						auditlog.setChangetype("Update");
						auditlog.setChnagedfield("StepName");
						auditlog.setOldvalue(e1.getStepName());
						auditlog.setNewvalue(e.getStepName());
						auditlog.setLoginid(loginid.intValue());
						auditlog.setUsername(rolename);
						auditlog.setRowno(i+1);
						if(!issuperadmin && !isadmin)
						{
							auditlog.setParentid(parentid);
						}
						try {
							auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
						} catch (ParseException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
						auditlog.setModifiedby((String) httpsession.getAttribute("username"));
						create(auditlog);
					}
					if (e1.getStepOrder() == null) {
						e1.setStepOrder(0);
					}
					if (e.getStepOrder() != null && !e.getStepOrder().equals(e1.getStepOrder())) {
						AuditLogDetails auditlog = new AuditLogDetails();
						dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
						Date date = new Date();
						// auditlog.setAuditid(maxid+1);
						auditlog.setTablename(tname);
						auditlog.setUsername(rolename);
						auditlog.setChangetype("Update");
						auditlog.setChnagedfield("StepOrder");
						auditlog.setOldvalue(e1.getStepOrder().toString());
						auditlog.setNewvalue(e.getStepOrder().toString());
						auditlog.setLoginid(loginid.intValue());
						auditlog.setUsername(rolename);
						auditlog.setRowno(i+1);
						if(!issuperadmin && !isadmin)
						{
							auditlog.setParentid(parentid);
						}
						try {
							auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
						} catch (ParseException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
						auditlog.setModifiedby((String) httpsession.getAttribute("username"));
						create(auditlog);
					}
				}
			}
		}
		// HSFileType
		if (tname != null && tname.equals("HSFileType")) {
			HSFileType e = null;
			HSFileType e1 = null;
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new HSFileType();
				e1 = new HSFileType();
				e = (HSFileType) entityTypes.get(i);
				if(e.getHsFileType()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (HSFileType) DbhSFileTypelist.get(i);
				} else {
					e1 = (HSFileType) entities.get(i);
				}
				if (e1.getHsFileType() == null) {
					e1.setHsFileType("");
				}
				if (e.getHsFileType() != null && !e.getHsFileType().equals(e1.getHsFileType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename("HSFileType");
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("HSFileType");
					auditlog.setOldvalue(e1.getHsFileType().toString());
					auditlog.setNewvalue(e.getHsFileType().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getDescription() == null) {
					e1.setDescription("");
				}
				if (e.getDescription() != null && !e.getDescription().equals(e1.getDescription())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename("HSFileType");
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Description");
					auditlog.setOldvalue(e1.getDescription());
					auditlog.setNewvalue(e.getDescription());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}
		}
		// EntityFileRecColumn
		if (tname != null && tname.equals("EntityFileRecColumn")) {
			EntityFileRecColumnVw e = null;
			EntityFileRecColumnVw e1 = null;
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new EntityFileRecColumnVw();
				e1 = new EntityFileRecColumnVw();
				e = (EntityFileRecColumnVw) entityTypes.get(i);
				if(e.getFileMask()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (EntityFileRecColumnVw) DbentityFileRecColumnlist.get(i);
				} else {
					e1 = (EntityFileRecColumnVw) entities.get(i);
				}
				if (e1.getFileMask() == null) {
					e1.setFileMask("");
				}
				if (e.getFileMask() != null && !e.getFileMask().equals(e1.getFileMask())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FileMask");
					auditlog.setOldvalue(e1.getFileMask().toString());
					auditlog.setNewvalue(e.getFileMask().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getEntityName() == null) {
					e1.setEntityName("");
				}
				if (e.getEntityName() != null && !e.getEntityName().equals(e1.getEntityName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EntityName");
					auditlog.setOldvalue(e1.getEntityName());
					auditlog.setNewvalue(e.getEntityName());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getHSFileType() == null) {
					e1.setHSFileType("");
				}
				if (e.getHSFileType() != null && !e.getHSFileType().equals(e1.getHSFileType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("HsFileType");
					auditlog.setOldvalue(e1.getHSFileType());
					auditlog.setNewvalue(e.getHSFileType());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
					auditlog.setUsername(rolename);
				}
				if (e1.getColName() == null) {
					e1.setColName("");
				}
				if (e.getColName() != null && !e.getColName().equals(e1.getColName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColName");
					auditlog.setOldvalue(e1.getColName());
					auditlog.setNewvalue(e.getColName());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getDataType() == null) {
					e1.setDataType("");
				}
				if (e.getDataType() != null && !e.getDataType().equals(e1.getDataType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("DataType");
					auditlog.setOldvalue(e1.getDataType());
					auditlog.setNewvalue(e.getDataType());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getColLength() == null) {
					e1.setColLength(0);
				}
				if (e.getColLength() != null && !e.getColLength().equals(e1.getColLength())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColLength");
					auditlog.setOldvalue(e1.getColLength().toString());
					auditlog.setNewvalue(e.getColLength().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getStartPosition() == null) {
					e1.setStartPosition(0);
				}
				if (e.getStartPosition() != null && !e.getStartPosition().equals(e1.getStartPosition())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("StartPosition");
					auditlog.setOldvalue(e1.getStartPosition().toString());
					auditlog.setNewvalue(e.getStartPosition().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getColMask() == null) {
					e1.setColMask("");
				}
				if (e.getColMask() != null && !e.getColMask().equals(e1.getColMask())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColMask");
					auditlog.setOldvalue(e1.getColMask().toString());
					auditlog.setNewvalue(e.getColMask().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getAllowValue() == null) {
					e1.setAllowValue("");
				}
				if (e.getAllowValue() != null && !e.getAllowValue().equals(e1.getAllowValue())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("AllowNullValue");
					auditlog.setOldvalue(e1.getAllowValue().toString());
					auditlog.setNewvalue(e.getAllowValue().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getActive() == null) {
					e1.setActive("");
				}
				if (e.getActive() != null && !e.getActive().equals(e1.getActive())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Active");
					auditlog.setOldvalue(e1.getActive().toString());
					auditlog.setNewvalue(e.getActive().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if(e.getEffectiveDate()!=null && !"".equals(e.getEffectiveDate()))
					e.setEffectiveDtstr(DateUtils.convertDateFormat(e.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if(e1.getEffectiveDate()!=null && !"".equals(e1.getEffectiveDate()))
					e1.setEffectiveDtstr(DateUtils.convertDateFormat(e1.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if (e.getEffectiveDtstr() != null && !e.getEffectiveDtstr().equals(e1.getEffectiveDtstr())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EffectiveDate");
					auditlog.setOldvalue(e1.getEffectiveDtstr().toString());
					auditlog.setNewvalue(e.getEffectiveDtstr().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}
		}
		// EntityFileRecColumn
		if (tname != null && tname.equals("EntityFileTypeScheduleXref")) {
			EntityFileTypeScheduleXrefVw e = null;
			EntityFileTypeScheduleXrefVw e1 = null;
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new EntityFileTypeScheduleXrefVw();
				e1 = new EntityFileTypeScheduleXrefVw();
				e = (EntityFileTypeScheduleXrefVw) entityTypes.get(i);
				if(e.getEntityName()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (EntityFileTypeScheduleXrefVw) DbentityFileTypeScheduleXref.get(i);
				} else {
					e1 = (EntityFileTypeScheduleXrefVw) entities.get(i);
				}
				if (e1.getEntityName() == null) {
					e1.setEntityName("");
				}
				if (e.getEntityName() != null && !e.getEntityName().equals(e1.getEntityName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EntityName");
					auditlog.setOldvalue(e1.getEntityName().toString());
					auditlog.setNewvalue(e.getEntityName().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getHSFileType() == null) {
					e1.setHSFileType("");
				}
				if (e.getHSFileType() != null && !e.getHSFileType().equals(e1.getHSFileType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("HSFileType");
					auditlog.setOldvalue(e1.getHSFileType());
					auditlog.setNewvalue(e.getHSFileType());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getFileMask() == null) {
					e1.setFileMask("");
				}
				if (e.getFileMask() != null && !e.getFileMask().equals(e1.getFileMask())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FileMask");
					auditlog.setOldvalue(e1.getFileMask());
					auditlog.setNewvalue(e.getFileMask());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getScheduleFequencyType() == null) {
					e1.setScheduleFequencyType("");
				}
				if (e.getScheduleFequencyType() != null && !e.getScheduleFequencyType().equals(e1.getScheduleFequencyType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ScheduleFequencyType");
					auditlog.setOldvalue(e1.getScheduleFequencyType());
					auditlog.setNewvalue(e.getScheduleFequencyType());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getSchFrequencyValue() == null) {
					e1.setSchFrequencyValue(0);
				}
				if (e.getSchFrequencyValue() != null && !e.getSchFrequencyValue().equals(e1.getSchFrequencyValue())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("SchFrequencyValue");
					auditlog.setOldvalue(e1.getSchFrequencyValue().toString());
					auditlog.setNewvalue(e.getSchFrequencyValue().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getScheduleOffsetType() == null) {
					e1.setScheduleOffsetType("");
				}
				if (e.getScheduleOffsetType() != null && !e.getScheduleOffsetType().equals(e1.getScheduleOffsetType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ScheduleOffsetType");
					auditlog.setOldvalue(e1.getScheduleOffsetType().toString());
					auditlog.setNewvalue(e.getScheduleOffsetType().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getSchFrequencyValue() == null) {
					e1.setSchFrequencyValue(0);
				}
				if (e.getSchFrequencyValue() != null && !e.getSchFrequencyValue().equals(e1.getSchFrequencyValue())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("SchFrequencyValue");
					auditlog.setOldvalue(e1.getSchFrequencyValue().toString());
					auditlog.setNewvalue(e.getSchFrequencyValue().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getFileDirection() == null) {
					e1.setFileDirection("");
				}
				if (e.getFileDirection() != null && !e.getFileDirection().equals(e1.getFileDirection())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FileDirection");
					auditlog.setOldvalue(e1.getFileDirection().toString());
					auditlog.setNewvalue(e.getFileDirection().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getActive() == null) {
					e1.setActive("");
				}
				if (e.getActive() != null && !e.getActive().equals(e1.getActive())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Active");
					auditlog.setOldvalue(e1.getActive().toString());
					auditlog.setNewvalue(e.getActive().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}
		}
		// HeaderFooterCols
		if (tname != null && tname.equals("HeaderFooterCols")) {
			HeaderFooterColsVw e = null;
			HeaderFooterColsVw e1 = null;
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new HeaderFooterColsVw();
				e1 = new HeaderFooterColsVw();
				e = (HeaderFooterColsVw) entityTypes.get(i);
				if(e.getFileMask()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (HeaderFooterColsVw) DbheaderFooterColslist.get(i);
				} else {
					e1 = (HeaderFooterColsVw) entities.get(i);
				}
				if (e1.getFileMask() == null) {
					e1.setFileMask("");
				}
				if (e.getFileMask() != null && !e.getFileMask().equals(e1.getFileMask())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FileMask");
					auditlog.setOldvalue(e1.getFileMask().toString());
					auditlog.setNewvalue(e.getFileMask().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getEntityName() == null) {
					e1.setEntityName("");
				}
				if (e.getEntityName() != null && !e.getEntityName().equals(e1.getEntityName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EntityName");
					auditlog.setOldvalue(e1.getEntityName());
					auditlog.setNewvalue(e.getEntityName());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getHSFileType() == null) {
					e1.setHSFileType("");
				}
				if (e.getHSFileType() != null && !e.getHSFileType().equals(e1.getHSFileType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("HsFileType");
					auditlog.setOldvalue(e1.getHSFileType());
					auditlog.setNewvalue(e.getHSFileType());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getColumnName() == null) {
					e1.setColumnName("");
				}
				if (e.getColumnName() != null && !e.getColumnName().equals(e1.getColumnName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColumnName");
					auditlog.setOldvalue(e1.getColumnName());
					auditlog.setNewvalue(e.getColumnName());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getActive() == null) {
					e1.setActive("");
				}
				if (e.getActive() != null && !e.getActive().equals(e1.getActive())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Active");
					auditlog.setOldvalue(e1.getActive().toString());
					auditlog.setNewvalue(e.getActive().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if(e.getEffectiveDate()!=null && !"".equals(e.getEffectiveDate()))
					e.setEffectiveDtstr(DateUtils.convertDateFormat(e.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if(e1.getEffectiveDate()!=null && !"".equals(e1.getEffectiveDate()))
					e1.setEffectiveDtstr(DateUtils.convertDateFormat(e1.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if (e.getEffectiveDtstr() != null && !e.getEffectiveDtstr().equals(e1.getEffectiveDtstr())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EffectiveDate");
					auditlog.setOldvalue(e1.getEffectiveDtstr().toString());
					auditlog.setNewvalue(e.getEffectiveDtstr().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}
		}
		// HeaderFooter
		if (tname != null && tname.equals("HeaderFooter")) {
			HeaderFooterVw e = null;
			HeaderFooterVw e1 = null;
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new HeaderFooterVw();
				e1 = new HeaderFooterVw();
				e = (HeaderFooterVw) entityTypes.get(i);
				if(e.getHeaderFooterType()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (HeaderFooterVw) DbheaderFooterList.get(i);
				} else {
					e1 = (HeaderFooterVw) entities.get(i);
				}
				if (e1.getHeaderFooterType() == null) {
					e1.setHeaderFooterType("");
				}
				if (e.getHeaderFooterType() != null && !e.getHeaderFooterType().equals(e1.getHeaderFooterType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("HeaderFooterType");
					auditlog.setOldvalue(e1.getHeaderFooterType());
					auditlog.setNewvalue(e.getHeaderFooterType());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getFileRecNum() == null) {
					e1.setFileRecNum("");
				}
				if (e.getFileRecNum() != null && !e.getFileRecNum().equals(e1.getFileRecNum())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FileRecNum");
					auditlog.setOldvalue(e1.getFileRecNum().toString());
					auditlog.setNewvalue(e.getFileRecNum().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getColCnt() == null) {
					e1.setColCnt(0);
				}
				if (e.getColCnt() != null && !e.getColCnt().equals(e1.getColCnt())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColCnt");
					auditlog.setOldvalue(e1.getColCnt().toString());
					auditlog.setNewvalue(e.getColCnt().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if(e.getEffectiveDate()!=null && !"".equals(e.getEffectiveDate()))
					e.setEffectiveDatestr(DateUtils.convertDateFormat(e.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if(e1.getEffectiveDate()!=null && !"".equals(e1.getEffectiveDate()))
					e1.setEffectiveDatestr(DateUtils.convertDateFormat(e1.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if (e.getEffectiveDatestr() != null && !e.getEffectiveDatestr().equals(e1.getEffectiveDatestr())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EffectiveDate");
					auditlog.setOldvalue(e1.getEffectiveDatestr().toString());
					auditlog.setNewvalue(e.getEffectiveDatestr().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getColumnsWidth() == null) {
					e1.setColumnsWidth(0);
				}
				if (e.getColumnsWidth() != null && !e.getColumnsWidth().equals(e1.getColumnsWidth())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColumnsWidth");
					auditlog.setOldvalue(e1.getColumnsWidth().toString());
					auditlog.setNewvalue(e.getColumnsWidth().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getColumnsPattern() == null) {
					e1.setColumnsPattern("");
				}
				if (e.getColumnsPattern() != null && !e.getColumnsPattern().equals(e1.getColumnsPattern())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColumnsPattern");
					auditlog.setOldvalue(e1.getColumnsPattern().toString());
					auditlog.setNewvalue(e.getColumnsPattern().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}
		}
		// EntityFileValidationRule
		if (tname != null && tname.equals("EntityFileValidationRule")) {
			EntityFileValidationRuleVw e = null;
			EntityFileValidationRuleVw e1 = null;
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new EntityFileValidationRuleVw();
				e1 = new EntityFileValidationRuleVw();
				e = (EntityFileValidationRuleVw) entityTypes.get(i);
				if(e.getFileMask()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (EntityFileValidationRuleVw) DbentityFileValidationRule.get(i);
				} else {
					e1 = (EntityFileValidationRuleVw) entities.get(i);
				}
				if (e1.getRuleType() == null) {
					e1.setRuleType("");
				}

				if (e1.getFileMask() == null) {
					e1.setFileMask("");
				}
				if (e.getFileMask() != null && !e.getFileMask().equals(e1.getFileMask())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FileMask");
					auditlog.setOldvalue(e1.getFileMask().toString());
					auditlog.setNewvalue(e.getFileMask().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getEntityName() == null) {
					e1.setEntityName("");
				}
				if (e.getEntityName() != null && !e.getEntityName().equals(e1.getEntityName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EntityName");
					auditlog.setOldvalue(e1.getEntityName().toString());
					auditlog.setNewvalue(e.getEntityName().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}

				if (e1.getHSFileType() == null) {
					e1.setHSFileType("");
				}
				if (e.getHSFileType() != null && !e.getHSFileType().equals(e1.getHSFileType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FileMask");
					auditlog.setOldvalue(e1.getHSFileType().toString());
					auditlog.setNewvalue(e.getHSFileType().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getStepName() == null) {
					e1.setStepName("");
				}
				if (e.getStepName() != null && !e.getStepName().equals(e1.getStepName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("StepName");
					auditlog.setOldvalue(e1.getStepName().toString());
					auditlog.setNewvalue(e.getStepName().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getFailLevel() != null && !e.getFailLevel().equals(e1.getFailLevel())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FailLevel");
					auditlog.setOldvalue(e1.getFailLevel().toString());
					auditlog.setNewvalue(e.getFailLevel().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getActive() == null) {
					e1.setActive("");
				}
				if (e.getActive() != null && !e.getActive().equals(e1.getActive())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Active");
					auditlog.setOldvalue(e1.getActive().toString());
					auditlog.setNewvalue(e.getActive().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if(e.getEffectiveDate()!=null && !"".equals(e.getEffectiveDate()))
					e.setEffectiveDtstr(DateUtils.convertDateFormat(e.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if(e1.getEffectiveDate()!=null && !"".equals(e1.getEffectiveDate()))
					e1.setEffectiveDtstr(DateUtils.convertDateFormat(e1.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if (e.getEffectiveDtstr() != null && !e.getEffectiveDtstr().equals(e1.getEffectiveDtstr())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EffectiveDate");
					auditlog.setOldvalue(e1.getEffectiveDtstr().toString());
					auditlog.setNewvalue(e.getEffectiveDtstr().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleType() != null && !e.getRuleType().equals(e1.getRuleType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleType");
					auditlog.setOldvalue(e1.getRuleType().toString());
					auditlog.setNewvalue(e.getRuleType().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}

				if (e1.getRuleValue() == null) {
					e1.setRuleValue("");
				}
				if (e.getRuleValue() != null && !e.getRuleValue().equals(e1.getRuleValue())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleValue");
					auditlog.setOldvalue(e1.getRuleValue());
					auditlog.setNewvalue(e.getRuleValue());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleParam1() != null && !e.getRuleParam1().equals(e1.getRuleParam1())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleParam1");
					auditlog.setOldvalue(e1.getRuleParam1());
					auditlog.setNewvalue(e.getRuleParam1());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleParam2() != null && !e.getRuleParam2().equals(e1.getRuleParam2())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleParam2");
					auditlog.setOldvalue(e1.getRuleParam2());
					auditlog.setNewvalue(e.getRuleParam2());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleParam3() != null && !e.getRuleParam3().equals(e1.getRuleParam3())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleParam3");
					auditlog.setOldvalue(e1.getRuleParam3());
					auditlog.setNewvalue(e.getRuleParam3());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleParam4() != null && !e.getRuleParam4().equals(e1.getRuleParam4())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleParam4");
					auditlog.setOldvalue(e1.getRuleParam4());
					auditlog.setNewvalue(e.getRuleParam4());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleParam5() != null && !e.getRuleParam5().equals(e1.getRuleParam5())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleParam5");
					auditlog.setOldvalue(e1.getRuleParam5());
					auditlog.setNewvalue(e.getRuleParam5());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleParam6() != null && !e.getRuleParam6().equals(e1.getRuleParam6())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleParam6");
					auditlog.setOldvalue(e1.getRuleParam6());
					auditlog.setNewvalue(e.getRuleParam6());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleParam7() != null && !e.getRuleParam7().equals(e1.getRuleParam7())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleParam7");
					auditlog.setOldvalue(e1.getRuleParam7());
					auditlog.setNewvalue(e.getRuleParam7());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleParam8() != null && !e.getRuleParam8().equals(e1.getRuleParam8())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleParam8");
					auditlog.setOldvalue(e1.getRuleParam8());
					auditlog.setNewvalue(e.getRuleParam8());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleParam9() != null && !e.getRuleParam9().equals(e1.getRuleParam9())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleParam9");
					auditlog.setOldvalue(e1.getRuleParam9());
					auditlog.setNewvalue(e.getRuleParam9());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleParam10() != null && !e.getRuleParam10().equals(e1.getRuleParam10())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleParam10");
					auditlog.setOldvalue(e1.getRuleParam10());
					auditlog.setNewvalue(e.getRuleParam10());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleDesc() != null && !e.getRuleDesc().equals(e1.getRuleDesc())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleDesc");
					auditlog.setOldvalue(e1.getRuleDesc());
					auditlog.setNewvalue(e.getRuleDesc());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getRuleForTable() != null && !e.getRuleForTable().equals(e1.getRuleForTable())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RuleForTable");
					auditlog.setOldvalue(e1.getRuleForTable());
					auditlog.setNewvalue(e.getRuleForTable());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getComments() != null && !e.getComments().equals(e1.getComments())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Comments");
					auditlog.setOldvalue(e1.getComments());
					auditlog.setNewvalue(e.getComments());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getBaseColumn() != null && !e.getBaseColumn().equals(e1.getBaseColumn())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("BaseColumn");
					auditlog.setOldvalue(e1.getBaseColumn());
					auditlog.setNewvalue(e.getBaseColumn());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getBaseMessage() != null && !e.getBaseMessage().equals(e1.getBaseMessage())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("BaseMessage");
					auditlog.setOldvalue(e1.getBaseMessage());
					auditlog.setNewvalue(e.getBaseMessage());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getWhoMadeChange() != null && !e.getWhoMadeChange().equals(e1.getWhoMadeChange())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("WhomadeChange");
					auditlog.setOldvalue(e1.getWhoMadeChange());
					auditlog.setNewvalue(e.getWhoMadeChange());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e.getReasonForChange() != null && !e.getReasonForChange().equals(e1.getReasonForChange())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ReasonforChange");
					auditlog.setOldvalue(e1.getReasonForChange());
					auditlog.setNewvalue(e.getReasonForChange());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setUsername(rolename);
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}

			}
		}
		// SourceToTargetMapping
		if (tname != null && tname.equals("SourceToTargetMapping")) {
			SourceToTargetMappingVw e = null;
			SourceToTargetMappingVw e1 = null;

			for (int i = 0; i < entityTypes.size(); i++) {
				e = new SourceToTargetMappingVw();
				e1 = new SourceToTargetMappingVw();
				e = (SourceToTargetMappingVw) entityTypes.get(i);
				if(e.getInputFileMask()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (SourceToTargetMappingVw) DbsourceToTargetMappingList.get(i);
				} else {
					e1 = (SourceToTargetMappingVw) entities.get(i);
				}
				if (e1.getInputFileMask() == null) {
					e1.setInputFileMask("");
				}
				if (e.getInputFileMask() != null && !e.getInputFileMask().equals(e1.getInputFileMask())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("InputFileMask");
					auditlog.setOldvalue(e1.getInputFileMask().toString());
					auditlog.setNewvalue(e.getInputFileMask().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getEntityName() == null) {
					e1.setEntityName("");
				}
				if (e.getEntityName() != null && !e.getEntityName().equals(e1.getEntityName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EntityName");
					auditlog.setOldvalue(e1.getEntityName());
					auditlog.setNewvalue(e.getEntityName());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getHSFileType() == null) {
					e1.setHSFileType("");
				}
				if (e.getHSFileType() != null && !e.getHSFileType().equals(e1.getHSFileType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("HsFileType");
					auditlog.setOldvalue(e1.getHSFileType());
					auditlog.setNewvalue(e.getHSFileType());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getTargetEntityFileMask() == null) {
					e1.setTargetEntityFileMask("");
				}
				if (e.getTargetEntityFileMask() != null && !e.getTargetEntityFileMask().equals(e1.getTargetEntityFileMask())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("TargetEntityFileMask");
					auditlog.setOldvalue(e1.getTargetEntityFileMask());
					auditlog.setNewvalue(e.getTargetEntityFileMask());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getTargetEntityName() == null) {
					e1.setTargetEntityName("");
				}
				if (e.getTargetEntityName() != null && !e.getTargetEntityName().equals(e1.getTargetEntityName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("TargetEntityName");
					auditlog.setOldvalue(e1.getTargetEntityName().toString());
					auditlog.setNewvalue(e.getTargetEntityName().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getMapFunction() == null) {
					e1.setMapFunction("");
				}
				if (e.getMapFunction() != null && !e.getMapFunction().equals(e1.getMapFunction())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("MapFunction");
					auditlog.setOldvalue(e1.getMapFunction().toString());
					auditlog.setNewvalue(e.getMapFunction().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getActive() == null) {
					e1.setActive("");
				}
				if (e.getActive() != null && !e.getActive().equals(e1.getActive())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Active");
					auditlog.setOldvalue(e1.getActive().toString());
					auditlog.setNewvalue(e.getActive().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if(e.getEffectiveDate()!=null && !"".equals(e.getEffectiveDate()))
					e.setEffectiveDtstr(DateUtils.convertDateFormat(e.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if(e1.getEffectiveDate()!=null && !"".equals(e1.getEffectiveDate()))
					e1.setEffectiveDtstr(DateUtils.convertDateFormat(e1.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if (e.getEffectiveDtstr() != null && !e.getEffectiveDtstr().equals(e1.getEffectiveDtstr())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EffectiveDate");
					auditlog.setOldvalue(e1.getEffectiveDtstr().toString());
					auditlog.setNewvalue(e.getEffectiveDtstr().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getTargetColOrder() == null) {
					e1.setTargetColOrder(0);
				}
				if (e.getTargetColOrder() != null && !e.getTargetColOrder().equals(e1.getTargetColOrder())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("TargetColOrder");
					auditlog.setOldvalue(e1.getTargetColOrder().toString());
					auditlog.setNewvalue(e.getTargetColOrder().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}
		}
		// EntityFileTypeXref
		if (tname != null && tname.equals("EntityFileTypeXref")) {
			EntityFileTypeXrefVw e = null;
			EntityFileTypeXrefVw e1 = null;
			//System.out.println("entityTypes.size() ****"+entityTypes);
			for (int i = 0; i < entityTypes.size(); i++) {
				e = new EntityFileTypeXrefVw();
				e1 = new EntityFileTypeXrefVw();
				e = (EntityFileTypeXrefVw) entityTypes.get(i);
				if(e.getEntityName()==null){
					continue;
				}
				if (reviewflag != null && reviewflag.equals("true")) {
					e1 = (EntityFileTypeXrefVw) DbentityFileTypeXreflist.get(i);
				} else {
					e1 = (EntityFileTypeXrefVw) entities.get(i);
				}
				if (e1.getEntityName() == null) {
					e1.setEntityName("");
				}
				if (e.getEntityName() != null && !e.getEntityName().equals(e1.getEntityName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EntityName");
					auditlog.setOldvalue(e1.getEntityName().toString());
					auditlog.setNewvalue(e.getEntityName().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getHSFileType() == null) {
					e1.setHSFileType("");
				}
				if (e.getHSFileType() != null && !e.getHSFileType().equals(e1.getHSFileType())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("HsFileType");
					auditlog.setOldvalue(e1.getHSFileType());
					auditlog.setNewvalue(e.getHSFileType());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getFilePath() == null) {
					e1.setFilePath("");
				}
				if (e.getFilePath() != null && !e.getFilePath().equals(e1.getFilePath())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FilePath");
					auditlog.setOldvalue(e1.getFilePath());
					auditlog.setNewvalue(e.getFilePath());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getFileFormat() == null) {
					e1.setFileFormat("");
				}
				if (e.getFileFormat() != null && !e.getFileFormat().equals(e1.getFileFormat())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FileFormat");
					auditlog.setOldvalue(e1.getFileFormat());
					auditlog.setNewvalue(e.getFileFormat());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getFileMask() == null) {
					e1.setFileMask("");
				}
				if (e.getFileMask() != null && !e.getFileMask().equals(e1.getFileMask())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FileMask");
					auditlog.setOldvalue(e1.getFileMask().toString());
					auditlog.setNewvalue(e.getFileMask().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getRecDelimiter() == null) {
					e1.setRecDelimiter("");
				}
				if (e.getRecDelimiter() != null && !e.getRecDelimiter().equals(e1.getRecDelimiter())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("RecDelimiter");
					auditlog.setOldvalue(e1.getRecDelimiter().toString());
					auditlog.setNewvalue(e.getRecDelimiter().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getColumnsDelimiter() == null) {
					e1.setColumnsDelimiter("");
				}
				if (e.getColumnsDelimiter() != null && !e.getColumnsDelimiter().equals(e1.getColumnsDelimiter())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColumnsDelimiter");
					auditlog.setOldvalue(e1.getColumnsDelimiter().toString());
					auditlog.setNewvalue(e.getColumnsDelimiter().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getColumnsCount() == null) {
					e1.setColumnsCount(0);
				}
				if (e.getColumnsCount() != null && !e.getColumnsCount().equals(e1.getColumnsCount())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColumnsCount");
					auditlog.setOldvalue(e1.getColumnsCount().toString());
					auditlog.setNewvalue(e.getColumnsCount().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getMaxRecLen() == null) {
					e1.setMaxRecLen(0);
				}
				if (e.getMaxRecLen() != null && !e.getMaxRecLen().equals(e1.getMaxRecLen())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("MaxRecLen");
					auditlog.setOldvalue(e1.getMaxRecLen().toString());
					auditlog.setNewvalue(e.getMaxRecLen().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getAllowExtraColumns() == null) {
					e1.setAllowExtraColumns("");
				}
				if (e.getAllowExtraColumns() != null && !e.getAllowExtraColumns().equals(e1.getAllowExtraColumns())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("AllowExtraColumns");
					auditlog.setOldvalue(e1.getAllowExtraColumns().toString());
					auditlog.setNewvalue(e.getAllowExtraColumns().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getNotifyRetyCount() == null) {
					e1.setNotifyRetyCount(0);
				}
				if (e.getNotifyRetyCount() != null && !e.getNotifyRetyCount().equals(e1.getNotifyRetyCount())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("NotifyRetyCount");
					auditlog.setOldvalue(e1.getNotifyRetyCount().toString());
					auditlog.setNewvalue(e.getNotifyRetyCount().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getOutboundOrder() == null) {
					e1.setOutboundOrder(0);
				}
				if (e.getOutboundOrder() != null && !e.getOutboundOrder().equals(e1.getOutboundOrder())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("OutboundOrder");
					auditlog.setOldvalue(e1.getOutboundOrder().toString());
					auditlog.setNewvalue(e.getOutboundOrder().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getActive() == null) {
					e1.setActive("");
				}
				if (e.getActive() != null && !e.getActive().equals(e1.getActive())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("Active");
					auditlog.setOldvalue(e1.getActive().toString());
					auditlog.setNewvalue(e.getActive().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if(e.getEffectiveDate()!=null && !"".equals(e.getEffectiveDate()))
					e.setEffectiveDtstr(DateUtils.convertDateFormat(e.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if(e1.getEffectiveDate()!=null && !"".equals(e1.getEffectiveDate()))
					e1.setEffectiveDtstr(DateUtils.convertDateFormat(e1.getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				if (e.getEffectiveDtstr() != null && !e.getEffectiveDtstr().equals(e1.getEffectiveDtstr())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("EffectiveDate");
					auditlog.setOldvalue(e1.getEffectiveDtstr().toString());
					auditlog.setNewvalue(e.getEffectiveDtstr().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getColumnsWidth() == null) {
					e1.setColumnsWidth(0);
				}
				if (e.getColumnsWidth() != null && !e.getColumnsWidth().equals(e1.getColumnsWidth())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColumnsWidth");
					auditlog.setOldvalue(e1.getColumnsWidth().toString());
					auditlog.setNewvalue(e.getColumnsWidth().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getDupFileCheck() == null) {
					e1.setDupFileCheck("");
				}
				if (e.getDupFileCheck() != null && !e.getDupFileCheck().equals(e1.getDupFileCheck())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("DupFileCheck");
					auditlog.setOldvalue(e1.getDupFileCheck().toString());
					auditlog.setNewvalue(e.getDupFileCheck().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getColumnsPattern() == null) {
					e1.setColumnsPattern("");
				}
				if (e.getColumnsPattern() != null && !e.getColumnsPattern().equals(e1.getColumnsPattern())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("ColumnsPattern");
					auditlog.setOldvalue(e1.getColumnsPattern().toString());
					auditlog.setNewvalue(e.getColumnsPattern().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getNoDataRecordPattern() == null) {
					e1.setNoDataRecordPattern("");
				}
				if (e.getNoDataRecordPattern() != null && !e.getNoDataRecordPattern().equals(e1.getNoDataRecordPattern())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("NoDataRecordPattern");
					auditlog.setOldvalue(e1.getNoDataRecordPattern().toString());
					auditlog.setNewvalue(e.getNoDataRecordPattern().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getNoDataRecordPattern() == null) {
					e1.setNoDataRecordPattern("");
				}
				if (e.getNoDataRecordPattern() != null && !e.getNoDataRecordPattern().equals(e1.getNoDataRecordPattern())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("NoDataRecordPattern");
					auditlog.setOldvalue(e1.getNoDataRecordPattern().toString());
					auditlog.setNewvalue(e.getNoDataRecordPattern().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getNoRecordDelimiter() == null) {
					e1.setNoRecordDelimiter("");
				}
				if (e.getNoRecordDelimiter() != null && !e.getNoRecordDelimiter().equals(e1.getNoRecordDelimiter())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("NoRecordDelimiter");
					auditlog.setOldvalue(e1.getNoRecordDelimiter().toString());
					auditlog.setNewvalue(e.getNoRecordDelimiter().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getOutBoundFilter() == null) {
					e1.setOutBoundFilter("");
				}
				if (e.getOutBoundFilter() != null && !e.getOutBoundFilter().equals(e1.getOutBoundFilter())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("OutBoundFilter");
					auditlog.setOldvalue(e1.getOutBoundFilter().toString());
					auditlog.setNewvalue(e.getOutBoundFilter().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getSheetName() == null) {
					e1.setSheetName("");
				}
				if (e.getSheetName() != null && !e.getSheetName().equals(e1.getSheetName())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					// auditlog.setAuditid(maxid+1);
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("SheetName");
					auditlog.setOldvalue(e1.getSheetName().toString());
					auditlog.setNewvalue(e.getSheetName().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getIgnoreHeaderRowCount() == null) {
					e1.setIgnoreHeaderRowCount(0);
				}
				if (e.getIgnoreHeaderRowCount() != null && !e.getIgnoreHeaderRowCount().equals(e1.getIgnoreHeaderRowCount())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					// auditlog.setAuditid(maxid+1);
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("IgnoreHeaderRowCount");
					auditlog.setOldvalue(e1.getIgnoreHeaderRowCount().toString());
					auditlog.setNewvalue(e.getIgnoreHeaderRowCount().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getIgnoreFooterRowCount() == null) {
					e1.setIgnoreFooterRowCount(0);
				}
				if (e.getIgnoreFooterRowCount() != null && !e.getIgnoreFooterRowCount().equals(e1.getIgnoreFooterRowCount())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					// auditlog.setAuditid(maxid+1);
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("IgnoreFooterRowCount");
					auditlog.setOldvalue(e1.getIgnoreFooterRowCount().toString());
					auditlog.setNewvalue(e.getIgnoreFooterRowCount().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getFirstColumn() == null) {
					e1.setFirstColumn(0);
				}
				if (e.getFirstColumn() != null && !e.getFirstColumn().equals(e1.getFirstColumn())) {
					AuditLogDetails auditlog = new AuditLogDetails();

					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("FirstColumn");
					auditlog.setOldvalue(e1.getFirstColumn().toString());
					auditlog.setNewvalue(e.getFirstColumn().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
				if (e1.getLastColumn() == null) {
					e1.setLastColumn(0);
				}
				if (e.getLastColumn() != null && !e.getLastColumn().equals(e1.getLastColumn())) {
					AuditLogDetails auditlog = new AuditLogDetails();
					dateFormat = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
					Date date = new Date();
					// auditlog.setAuditid(maxid+1);
					auditlog.setTablename(tname);
					auditlog.setUsername(rolename);
					auditlog.setChangetype("Update");
					auditlog.setChnagedfield("LastColumn");
					auditlog.setOldvalue(e1.getLastColumn().toString());
					auditlog.setNewvalue(e.getLastColumn().toString());
					auditlog.setLoginid(loginid.intValue());
					auditlog.setRowno(i+1);
					if(!issuperadmin && !isadmin)
					{
						auditlog.setParentid(parentid);
					}
					try {
						auditlog.setModifieddate(dateFormat.parse(dateFormat.format(date)));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					auditlog.setModifiedby((String) httpsession.getAttribute("username"));
					create(auditlog);
				}
			}
		}
	}

	public void save(String tablename, HttpSession httpsession) {

		Long loginid = 0L;
		if (httpsession.getAttribute("loginID") != null)
			loginid = (Long) httpsession.getAttribute("loginID");
		Date date = new Date();
		AuditLogDetails auditlog = new AuditLogDetails();
		auditlog.setTablename(tablename);
		auditlog.setChangetype("Single Record Insert");
		auditlog.setChnagedfield("All Fields");
		auditlog.setOldvalue("N/A");
		auditlog.setNewvalue("N/A");
		auditlog.setLoginid(loginid.intValue());
		try {
			auditlog.setModifieddate(date);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (httpsession.getAttribute("username") != null)
			auditlog.setModifiedby((String) httpsession.getAttribute("username"));
		create(auditlog);
	}
	public void DownloadToAuditInfo(String tablename, HttpSession httpsession) {
		String username = "";
		if (httpsession.getAttribute("username") != null)
			username = (String) httpsession.getAttribute("username");
		Long loginid = 0L;
		if (httpsession.getAttribute("loginID") != null)
			loginid = (Long) httpsession.getAttribute("loginID");
		Date date = new Date();
		AuditLogDetails auditlog = new AuditLogDetails();
		auditlog.setTablename(tablename);
		auditlog.setUsername(username);
		auditlog.setChangetype("Download");
		auditlog.setChnagedfield("N/A");
		auditlog.setOldvalue("N/A");
		auditlog.setNewvalue("N/A");
		auditlog.setLoginid(loginid.intValue());
		try {
			auditlog.setModifieddate(date);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (httpsession.getAttribute("username") != null)
			auditlog.setModifiedby((String) httpsession.getAttribute("username"));
		create(auditlog);
	}
	public void uploadToAuditInfo(String tablename, HttpSession httpsession) {
		String username = "";
		if (httpsession.getAttribute("username") != null)
			username = (String) httpsession.getAttribute("username");
		Long loginid = 0L;
		if (httpsession.getAttribute("loginID") != null)
			loginid = (Long) httpsession.getAttribute("loginID");
		Date date = new Date();
		AuditLogDetails auditlog = new AuditLogDetails();
		auditlog.setTablename(tablename);
		auditlog.setUsername(username);
		auditlog.setChangetype("Upload");
		auditlog.setChnagedfield("N/A");
		auditlog.setOldvalue("N/A");
		auditlog.setNewvalue("N/A");
		auditlog.setLoginid(loginid.intValue());
		try {
			auditlog.setModifieddate(date);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (httpsession.getAttribute("username") != null)
			auditlog.setModifiedby((String) httpsession.getAttribute("username"));

		create(auditlog);
	}
	public void deleteAuditInfo(HttpSession httpsession) {
		String username = "";
		if (httpsession.getAttribute("username") != null)
			username = (String) httpsession.getAttribute("username");
		Long loginid = 0L;
		if (httpsession.getAttribute("loginID") != null)
			loginid = (Long) httpsession.getAttribute("loginID");
		Date date = new Date();
		AuditLogDetails auditlog = new AuditLogDetails();
		auditlog.setTablename("N/A");
		auditlog.setUsername(username);
		auditlog.setChangetype("Delete All Tables");
		auditlog.setChnagedfield("All Tables");
		auditlog.setOldvalue("N/A");
		auditlog.setNewvalue("N/A");
		auditlog.setLoginid(loginid.intValue());
		try {
			auditlog.setModifieddate(date);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (httpsession.getAttribute("username") != null)
			auditlog.setModifiedby((String) httpsession.getAttribute("username"));

		create(auditlog);
	}
	public void rolechangeAuditInfo(List<Roles> oldlist, List<Roles> changedlist,HttpSession httpsession) {
		String username = "";
		if (httpsession.getAttribute("username") != null)
			username = (String) httpsession.getAttribute("username");
		Long loginid = 0L;
		if (httpsession.getAttribute("loginID") != null)
			loginid = (Long) httpsession.getAttribute("loginID");
		boolean isadmin = (boolean)httpsession.getAttribute("isadmin");
		boolean issuperadmin = (boolean)httpsession.getAttribute("issuperadmin");
		Long parentid =0l;
		if(!issuperadmin && !isadmin)
		{
			parentid =  (Long)httpsession.getAttribute("parentid");
		}
		Roles e = null;
		Roles e1 = null;
		for (int i = 0; i < changedlist.size(); i++) {
			e = new Roles();
			e1 = new Roles();
			e = (Roles) changedlist.get(i);
			e1 = (Roles) oldlist.get(i);
			if (e.getRoleName() != null && !e.getRoleName().equals(e1.getRoleName())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				Date date = new Date();
				auditlog.setTablename("N/A");
				auditlog.setUsername(username);
				auditlog.setChangetype("Role Update");
				auditlog.setChnagedfield("N/A");
				auditlog.setOldvalue(e1.getRoleName().toString());
				auditlog.setNewvalue(e.getRoleName().toString());
				auditlog.setLoginid(loginid.intValue());
				auditlog.setRowno(i+1);
				if(!issuperadmin && !isadmin)
				{
					auditlog.setParentid(parentid);
				}
				try {
					auditlog.setModifieddate(date);
				} catch (Exception e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				auditlog.setModifiedby((String) httpsession.getAttribute("username"));
				create(auditlog);
			}
		}
	}
	public void groupchangeAuditInfo(List<Groups> oldlist, List<Groups> changedlist,HttpSession httpsession) {
		String username = "";
		if (httpsession.getAttribute("username") != null)
			username = (String) httpsession.getAttribute("username");
		Long loginid = 0L;
		if (httpsession.getAttribute("loginID") != null)
			loginid = (Long) httpsession.getAttribute("loginID");
		boolean isadmin = (boolean)httpsession.getAttribute("isadmin");
		boolean issuperadmin = (boolean)httpsession.getAttribute("issuperadmin");
		Long parentid =0l;
		if(!issuperadmin && !isadmin)
		{
			parentid =  (Long)httpsession.getAttribute("parentid");
		}
		Groups e = null;
		Groups e1 = null;
		for (int i = 0; i < changedlist.size(); i++) {
			e = new Groups();
			e1 = new Groups();
			e = (Groups) changedlist.get(i);
			e1 = (Groups) oldlist.get(i);
			if (e.getName() != null && !e.getName().equals(e1.getName())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				Date date = new Date();
				auditlog.setTablename("N/A");
				auditlog.setUsername(username);
				auditlog.setChangetype("Group Update");
				auditlog.setChnagedfield("N/A");
				auditlog.setOldvalue(e1.getName().toString());
				auditlog.setNewvalue(e.getName().toString());
				auditlog.setLoginid(loginid.intValue());
				auditlog.setRowno(i+1);
				if(!issuperadmin && !isadmin)
				{
					auditlog.setParentid(parentid);
				}
				try {
					auditlog.setModifieddate(date);
				} catch (Exception e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				auditlog.setModifiedby((String) httpsession.getAttribute("username"));
				create(auditlog);
			}
		}
	}
	 public List<AuditLogDetails> searchAll(String tablename,String changetype,String date,String modby)
	 {
		 String tallstr="";
		 String changypetstr="";
		 String modbystr="";
		 String modified_date="";
		 Date ModifiedDate=null;
		 List<AuditLogDetails> ret_auditLogDetails=new ArrayList<AuditLogDetails>();
		 
		 List<SimpleDateFormat> formaters = new ArrayList<SimpleDateFormat>();
			formaters.add(new SimpleDateFormat("yyyy-MM-dd"));
			formaters.add(new SimpleDateFormat("MM/dd/yyyy"));

			for (SimpleDateFormat pattern : formaters) {
			    try {
			        // Take a try
			    	
			    	ModifiedDate=(new Date(pattern.parse(date).getTime()));
			    	break;

			    } catch (ParseException pe) {
			        // Loop on
			    }
			}
		
		 if(ModifiedDate!=null){
			 List<List<AuditLogDetails>> all_list_audit=new ArrayList<List<AuditLogDetails>>();
			 List<AuditLogDetails> L_auditLogDetails=new ArrayList<AuditLogDetails>();
			 TypedQuery<AuditLogDetails> getM_DateQuery = entityManager.createQuery("from AuditLogDetails ", AuditLogDetails.class);
			 L_auditLogDetails=getM_DateQuery.getResultList();
			 for(AuditLogDetails auditLogDetails:L_auditLogDetails){
				 int counter=0;
				 if(!tablename.equalsIgnoreCase("All"))
				 {
					 tallstr = " where tablename ='" + tablename + "'";
					 counter++;
				 }
				 if(!changetype.equalsIgnoreCase("All"))
				 {
					 if(counter>0)
					 changypetstr = " and changetype ='" + changetype + "'";
					 else
						 changypetstr = " where changetype ='" + changetype + "'";
					 counter++;
					 }
				 if(!modby.equalsIgnoreCase("All"))
				 {
					 if(counter>0)
					 modbystr =  " and modifiedby ='" + modby + "'";
					 else
						 modbystr =  " where modifiedby ='" + modby + "'";
					 counter++;
				 }
				 Calendar cal = Calendar.getInstance(); 
				 Date m_d=null;
				 Date set_date=auditLogDetails.getModifieddate();
				cal.setTime(auditLogDetails.getModifieddate());
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
				m_d=cal.getTime();
				if(ModifiedDate.compareTo(m_d)==0){
					if(counter>0){
						modified_date=" and modifieddate='"+set_date+"'";
					}else{
					modified_date=" where modifieddate='"+set_date+"'";
					}
					TypedQuery<AuditLogDetails> query = entityManager.createQuery("from AuditLogDetails"+tallstr+changypetstr+modbystr+modified_date, AuditLogDetails.class);
			 		ret_auditLogDetails=query.getResultList();
			 		
			 		all_list_audit.add(ret_auditLogDetails);
				}
				
			 }
			 
			 Map<Date, AuditLogDetails> uniqdata=new HashMap<Date, AuditLogDetails>();
			 for(List<AuditLogDetails> lald: all_list_audit){
				 for(AuditLogDetails ald:lald){
					 uniqdata.put(ald.getModifieddate(), ald);
				 }
			 }
			 List<AuditLogDetails> m_ret_auditLogDetails=new ArrayList<AuditLogDetails>();
			 for(Date d:uniqdata.keySet()){
				 m_ret_auditLogDetails.add(uniqdata.get(d));
			 }
			 return m_ret_auditLogDetails;
		 }
		 else{
			 int counter=0;
			 if(!tablename.equalsIgnoreCase("All"))
			 {
				 tallstr = " where tablename ='" + tablename + "'";
				 counter++;
			 }
			 if(!changetype.equalsIgnoreCase("All"))
			 {
				 if(counter>0)
				 changypetstr = " and changetype ='" + changetype + "'";
				 else
					 changypetstr = " where changetype ='" + changetype + "'";
				 counter++;
				 }
			 if(!modby.equalsIgnoreCase("All"))
			 {
				 if(counter>0)
				 modbystr =  " and modifiedby ='" + modby + "'";
				 else
					 modbystr =  " where modifiedby ='" + modby + "'";
				 counter++;
			 }
			 TypedQuery<AuditLogDetails> query = entityManager.createQuery("from AuditLogDetails"+tallstr+changypetstr+modbystr, AuditLogDetails.class);
			 ret_auditLogDetails=query.getResultList();
		 }
		return ret_auditLogDetails;
		 
	 }
	 public List<AuditLogDetails> searchAllAdmin(Long loginid,String tablename,String changetype,String date,String modby)
	 {
		 String tallstr="";
		 String changypetstr="";
		 String modbystr="";
		 String modified_date="";
		 Date ModifiedDate=null;
		 List<AuditLogDetails> ret_auditLogDetails=new ArrayList<AuditLogDetails>();
		 
		 List<SimpleDateFormat> formaters = new ArrayList<SimpleDateFormat>();
			formaters.add(new SimpleDateFormat("yyyy-MM-dd"));
			formaters.add(new SimpleDateFormat("MM/dd/yyyy"));

			for (SimpleDateFormat pattern : formaters) {
			    try {
			        // Take a try
			    	
			    	ModifiedDate=(new Date(pattern.parse(date).getTime()));
			    	break;

			    } catch (ParseException pe) {
			        // Loop on
			    }
			}
		
		 if(ModifiedDate!=null){
			 List<List<AuditLogDetails>> all_list_audit=new ArrayList<List<AuditLogDetails>>();
			 List<AuditLogDetails> L_auditLogDetails=new ArrayList<AuditLogDetails>();
			 TypedQuery<AuditLogDetails> getM_DateQuery = entityManager.createQuery("from AuditLogDetails where (loginid = '" + loginid + "' or parentid = ')" + loginid + "'", AuditLogDetails.class);
			 L_auditLogDetails=getM_DateQuery.getResultList();
			 for(AuditLogDetails auditLogDetails:L_auditLogDetails){
				 int counter=0;
				 if(!tablename.equalsIgnoreCase("All"))
				 {
					 tallstr = " and tablename ='" + tablename + "'";
					 counter++;
				 }
				 if(!changetype.equalsIgnoreCase("All"))
				 {
					 if(counter>0)
					 changypetstr = " and changetype ='" + changetype + "'";
					 else
						 changypetstr = " and changetype ='" + changetype + "'";
					 counter++;
					 }
				 if(!modby.equalsIgnoreCase("All"))
				 {
					 if(counter>0)
					 modbystr =  " and modifiedby ='" + modby + "'";
					 else
						 modbystr =  " and modifiedby ='" + modby + "'";
					 counter++;
				 }
				 Calendar cal = Calendar.getInstance(); 
				 Date m_d=null;
				 Date set_date=auditLogDetails.getModifieddate();
				cal.setTime(auditLogDetails.getModifieddate());
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
				m_d=cal.getTime();
				if(ModifiedDate.compareTo(m_d)==0){
					if(counter>0){
						modified_date=" and modifieddate='"+set_date+"'";
					}else{
					modified_date=" and modifieddate='"+set_date+"'";
					}
					TypedQuery<AuditLogDetails> query = entityManager.createQuery("from AuditLogDetails where (loginid = '" + loginid + "' or parentid = ')" + loginid + "'"+tallstr+changypetstr+modbystr+modified_date, AuditLogDetails.class);
			 		ret_auditLogDetails=query.getResultList();
			 		
			 		all_list_audit.add(ret_auditLogDetails);
				}
				
			 }
			 
			 Map<Date, AuditLogDetails> uniqdata=new HashMap<Date, AuditLogDetails>();
			 for(List<AuditLogDetails> lald: all_list_audit){
				 for(AuditLogDetails ald:lald){
					 uniqdata.put(ald.getModifieddate(), ald);
				 }
			 }
			 List<AuditLogDetails> m_ret_auditLogDetails=new ArrayList<AuditLogDetails>();
			 for(Date d:uniqdata.keySet()){
				 m_ret_auditLogDetails.add(uniqdata.get(d));
			 }
			 return m_ret_auditLogDetails;
		 }
		 else{
			 int counter=0;
			 if(!tablename.equalsIgnoreCase("All"))
			 {
				 tallstr = " and tablename ='" + tablename + "'";
				 counter++;
			 }
			 if(!changetype.equalsIgnoreCase("All"))
			 {
				 if(counter>0)
				 changypetstr = " and changetype ='" + changetype + "'";
				 else
					 changypetstr = " and changetype ='" + changetype + "'";
				 counter++;
				 }
			 if(!modby.equalsIgnoreCase("All"))
			 {
				 if(counter>0)
				 modbystr =  " and modifiedby ='" + modby + "'";
				 else
					 modbystr =  " and  modifiedby ='" + modby + "'";
				 counter++;
			 }
			 TypedQuery<AuditLogDetails> query = entityManager.createQuery("from AuditLogDetails where (loginid = '" + loginid + "' or parentid = '" + loginid + "')"+tallstr+changypetstr+modbystr, AuditLogDetails.class);
			 ret_auditLogDetails=query.getResultList();
		 }
		return ret_auditLogDetails;
		 
	 }
}
