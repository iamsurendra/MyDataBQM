package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.RuleTypeDAO;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.models.metastore.RuleType;
import com.artha.workbench.models.metastore.RuleTypeId;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("ruleTypeService")
public class RuleTypeServiceImpl implements RuleTypeService {

	@Autowired
	RuleTypeDAO ruleTypeDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Transactional(readOnly = true)
	public List<RuleType> getRuleTypeList() {
		return ruleTypeDAO.findAll();
	}

	@Transactional
	public void create(RuleType ruleType) {
		ruleTypeDAO.create(ruleType);
	}

	@Transactional(readOnly = true)
	public List<RuleType> getRuleTypeListByReleaseNo(Integer releaseNo) {
		return ruleTypeDAO.getRuleTypeListByReleaseNo(releaseNo);
	}
	
	public RuleType getPreviousRuleType(RuleType ruleType) throws IOException
	{
		RuleTypeId ruleTypeId = new RuleTypeId();
		ruleTypeId.setRuleTypeID(ruleType.getRuleTypeID());
		String ruleTypeIdJson = AppWebUtils.convertObjectToJson(ruleTypeId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(ruleType.getReleaseNo(), "RULETYPE", ruleTypeIdJson);
		RuleType previousRuleType = new RuleType();
		if(releaseArchive!=null){
		previousRuleType = AppWebUtils.convertJsonToObject(RuleType.class, releaseArchive.getRecData());
		}
		return previousRuleType;
		
	}
	@Transactional
	public void update(RuleType ruleType, boolean isReleaseChanged) throws JsonProcessingException  {
		RuleType oldEntity = ruleTypeDAO.findOne(ruleType.getRuleTypeID());
		checkForCyclicDependency(ruleType);
		if (isReleaseChanged) {
			ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
			releaseArchiveKey.setReleaseId(ruleType.getReleaseNo());
			releaseArchiveKey.setTableName("RULETYPE");
			RuleTypeId ruleTypeId = new RuleTypeId();
			ruleTypeId.setRuleTypeID(oldEntity.getRuleTypeID());
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(ruleTypeId));
			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			checkForCyclicDependency(ruleType);
			if(releaseArchive!=null){
			releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
			releaseArchiveDAO.update(releaseArchive);
			}else{
				releaseArchive = new ReleaseArchive();
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchiveDAO.create(releaseArchive);
			}
		}
		ruleTypeDAO.update(ruleType);
	}
	private void checkForCyclicDependency(RuleType ruleType) throws JsonProcessingException	{
		RuleTypeId ruleTypeId = new RuleTypeId();
		ruleTypeId.setRuleTypeID(ruleType.getRuleTypeID());
		String jsonId = AppWebUtils.convertObjectToJson(ruleTypeId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(ruleType.getReleaseNo(), "RULETYPE", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
  	@Transactional
	 public void saveRuleType(List<RuleType> entitytypes) 
	 {
  		ruleTypeDAO.saveRuleType(entitytypes);
	 }
  	@Transactional
  	public int getmaxruleTypeID()
  	{
  		return ruleTypeDAO.getmaxruleTypeID();
  	}
  	@Transactional
  	 public HashMap<Integer,String> loadRuleTypeIdMap()
  	 {
  		return ruleTypeDAO.loadRuleTypeIdMap();
  	 }
  	
  	@Override
  	@Transactional(readOnly = true)
  	public List<Integer> getRuleTypeReleaseNumbers(Set<Integer> ruleTypeIds,Integer selectedReleaseNumber){
  		return ruleTypeDAO.getRuleTypeReleaseNumbers(ruleTypeIds, selectedReleaseNumber);
  	}
  	
	@Override
  	@Transactional(readOnly = true)
  	public List<Integer> getAllRuleTypeReleaseIds(Integer selectedReleaseId){
		return ruleTypeDAO.getAllRuleTypeReleaseIds(selectedReleaseId);
  	}

	@Override
	@Transactional(readOnly = true)
	public List<RuleType> getRuleTypeList(Set<Integer> ruleTypeIds, Integer selectedReleaseNumber) {
		return ruleTypeDAO.getRuleTypeList(ruleTypeIds, selectedReleaseNumber);
	}
}
