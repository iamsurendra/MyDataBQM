package com.artha.workbench.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.constant.WBConstants;
import com.artha.workbench.constant.Messages;
import com.artha.workbench.models.datahub.Srccolumns;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.models.userConfig.FileTypeColumns;
import com.artha.workbench.models.userConfig.PartnerFileTypes;
import com.artha.workbench.service.CreateTaskService;
import com.artha.workbench.service.TaskService;
import com.artha.workbench.service.UserRolesService;
import com.artha.workbench.service.UserService;
import com.artha.workbench.to.CreateTaskTo;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppUser;
import com.guvvala.framework.util.StringUtils;
import com.guvvala.framework.util.ThreadLocalUtil;

@RestController
@RequestMapping("/api/createtask")

public class CreateTaskController {
	@Autowired
	private CreateTaskService createTaskService;

	@Autowired
	private UserRolesService userRolesService;

	@Autowired
	private TaskService taskService;

	@Autowired
	private UserService userService;

	@RequestMapping(value = "/findPartnerByUser", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<PartnerFileTypes> findPartnerByUser() {
		return createTaskService.findPartnerByUser();
	}

	@RequestMapping(value = "/findFileTypeByPartner/{entityId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<PartnerFileTypes> findFileTypeByPartner(@PathVariable("entityId") Long entityId) {
		return createTaskService.findFileTypeByPartner(entityId);

	}

	// Get Access Columns based on EntityFileTypeId
	@RequestMapping(value = "/findFileTypeColumnsByEntityFileTypeID/{entityFileTypeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Srccolumns> findFileTypeColumnsByEntityFileTypeID(
			@PathVariable("entityFileTypeId") Integer entityFileTypeId) {
		return getAccessColumns(entityFileTypeId).getColumnaccess();
	}

	private CreateTaskTo getAccessColumns(Integer entityFileTypeId) {
		List<Srccolumns> srccols = new ArrayList<>();
		List<Srccolumns> noReadAccessSrcCols = new ArrayList<>();
		List<FileTypeColumns> columns = new ArrayList<>();
		List<String> taskAccessRights = new ArrayList<>();
		Map<String, Integer> colAccessRights = new LinkedHashMap<>();
		AppUser user = ThreadLocalUtil.getUser();
		columns.addAll(userRolesService.findFileTypeColumnsByEntityFileTypeID(entityFileTypeId.longValue()));
		FileTypeColumns fileTypeColumns = columns.get(0);
		String key = fileTypeColumns.getEntityNameAbbr().concat(WBConstants.UNDER_SCORE)
				.concat(fileTypeColumns.getHsFileType()).concat(WBConstants.UNDER_SCORE)
				.concat(fileTypeColumns.getEntityFileTypeId().toString());
		if (!user.isAdmin() || !user.isAdmin()) {
			taskAccessRights.addAll(userService.getTaskAccessRights(user.getGroupid()));
			colAccessRights.putAll(userService.getColAccessRights(user.getGroupid()));
		}
		if (user.isSadmin() || user.isAdmin() || taskAccessRights.contains(key)) {
			for (FileTypeColumns fileTypeCol : columns) {
				Srccolumns srcColumn = new Srccolumns();
				srcColumn.setCol_name(fileTypeCol.getColName());
				srcColumn.setColId(fileTypeCol.getColId());
				String column = key.concat(WBConstants.UNDER_SCORE).concat(srcColumn.getCol_name());
				Integer columnRights = colAccessRights.get(column);
				// If user has write access or user is admin or superadmin add
				// it to the main list
				if (user.isSadmin() || user.isAdmin() || (columnRights != null && columnRights == 1)) {
					srcColumn.setWriteMode(true);
					srccols.add(srcColumn);
				}
				// If user doesnt have read access add to noReadAccessSrcCols ,
				// will not show on UI , but will be added before creating task
				else if (columnRights == null) {
					noReadAccessSrcCols.add(srcColumn);
				}
				// If it has read access
				else if (columnRights != null && columnRights == 0) {
					srcColumn.setWriteMode(Boolean.FALSE);
					srccols.add(srcColumn);
				}
			}
			CreateTaskTo createTaskTo = new CreateTaskTo();
			createTaskTo.setColumnaccess(srccols);
			createTaskTo.setNoReadAccessSrcCols(noReadAccessSrcCols);
			return createTaskTo;
		} else {
			throw new AppException(Messages.TASK_CANNOT_BE_CREATED);
		}

	}

	// Create New Task
	@RequestMapping(value = "/createTask/{fileTypeId}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public CreateTaskTo createTask(@PathVariable("fileTypeId") Integer fileTypeId, @RequestBody List<Srccolumns> srccolumns) {
		Integer seqId = taskService.getTaskIdSeq();
		List<FileTypeColumns> fileTypeColumns = userRolesService
				.findFileTypeColumnsByEntityFileTypeID(fileTypeId.longValue());
		// 158
		String entityFileTypeId = fileTypeColumns.get(0).getEntityFileTypeId().toString();
		// 158_-158_8_0
		String taskIdSeq = entityFileTypeId.concat(WBConstants.UNDER_SCORE).concat(WBConstants.HYPHEN)
				.concat(entityFileTypeId).concat(WBConstants.UNDER_SCORE).concat(seqId.toString())
				.concat(WBConstants.UNDER_SCORE).concat(WBConstants.ZERO);

		// ENS_FTV_158_-158_8_0
		String taskId = fileTypeColumns.get(0).getEntityNameAbbr().concat(WBConstants.UNDER_SCORE)
				.concat(fileTypeColumns.get(0).getHsFileType()).concat(WBConstants.UNDER_SCORE).concat(taskIdSeq);
		 List<Srccolumns> noReadAccess= getAccessColumns(fileTypeId).getNoReadAccessSrcCols();
		ArrayList<Srccolumns> columnaccess = new ArrayList<Srccolumns>();
		columnaccess.addAll(getSrcColumns(srccolumns, entityFileTypeId, seqId));
		// adding columns for which there is no read access
		columnaccess.addAll(getSrcColumns(noReadAccess,entityFileTypeId, seqId));
		// get the 3rd occurance of _ from ENS_FTV_158_-158_8_0
		Integer prefixId = StringUtils.ordinalIndexOf(taskId, "_", 3) + 1;
		String prefixForColId = taskId.substring(prefixId);
		Task task =createTaskService.createTask(taskId, taskId, fileTypeColumns, columnaccess, prefixForColId);
         CreateTaskTo createTaskTo = new CreateTaskTo();
         createTaskTo.setData(task);
         createTaskTo.setColumnaccess(getSrcColumns(srccolumns, entityFileTypeId, seqId));
		return createTaskTo;
	}

	private List<Srccolumns> getSrcColumns(List<Srccolumns> srccolumns, String entityFileTypeId, Integer seqId) {
		String fileId = WBConstants.HYPHEN.concat(entityFileTypeId);
		String seqID = WBConstants.ZERO;
		String recType = WBConstants.D;
		for (Srccolumns col : srccolumns) {
			if (col.getCol_name().equals("RecID")) {
				col.setCol_value(seqId.toString());
			} else if (col.getCol_name().equals("FileID")) {
				col.setCol_value(fileId);
			} else if (col.getCol_name().equals("SeqID")) {
				col.setCol_value(seqID);
			} else if (col.getCol_name().equals("RecType")) {
				col.setCol_value(recType);
			}

		}
		return srccolumns;

	}
}
