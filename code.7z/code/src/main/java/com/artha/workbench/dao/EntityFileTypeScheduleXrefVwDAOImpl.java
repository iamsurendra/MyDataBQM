package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.EntityFileTypeScheduleXrefVw;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityFileTypeScheduleXrefVwDAOImpl extends
		BaseDAOImpl<EntityFileTypeScheduleXrefVw, Integer> implements
		EntityFileTypeScheduleXrefVwDAO {

	public EntityFileTypeScheduleXrefVwDAOImpl() {
		super(EntityFileTypeScheduleXrefVw.class);
	}
	
	
	@Transactional
	public List<EntityFileTypeScheduleXrefVw> getEntityFileTypeScheduleXrefByReleaseNo(Integer releaseNo)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeScheduleXrefVw> query = cb.createQuery(EntityFileTypeScheduleXrefVw.class);
		Root<EntityFileTypeScheduleXrefVw> root = query.from(EntityFileTypeScheduleXrefVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
}
