package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.SourceToWebServiceMapping;
import com.artha.workbench.models.metastore.SourceToWebServiceMappingKey;
import com.guvvala.framework.dao.BaseDAO;


public interface SourceToWebServiceMappingDAO extends BaseDAO<SourceToWebServiceMapping, SourceToWebServiceMappingKey>{
	
	public List<SourceToWebServiceMapping> getsourceToWebServiceMappingListByReleaseNum (Integer releaseNum);
	
	List<Integer> getAllSourceToWebServiceMappingReleaseIds(Integer selectedReleaseId);
}
