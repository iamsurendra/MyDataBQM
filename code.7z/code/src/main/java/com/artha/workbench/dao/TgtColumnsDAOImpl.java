package com.artha.workbench.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.StoredProcedureQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.datahub.TgtColumns;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class TgtColumnsDAOImpl extends BaseDAOImpl<TgtColumns, String> implements TgtColumnsDAO {

	public TgtColumnsDAOImpl() {
		super(TgtColumns.class);
	}

	public void updateTargetCol(List<TgtColumns> targetLists, int isModified) {
		/*for (TgtColumns target : targetLists) {
			TgtColumns tgtColumn = findOne(target.getTgtcolId());
			tgtColumn.setModifiedValue(target.getModifiedValue());
			tgtColumn.setIsModified(isModified);
			tgtColumn.setTgtcolTimeStamp(new Date());
			entityManager.merge(tgtColumn);
		}*/
	}

	public void updateWithProcedure(String json)
	{
		StoredProcedureQuery spQuery = entityManager.createNamedStoredProcedureQuery("SP_TGT_UPDATE");
		spQuery.setParameter("inputJson", json);
		spQuery.executeUpdate();
	}

	public void deleteAllTgtColumns(List<String> recIds) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<TgtColumns> query = cb.createQuery(TgtColumns.class);
		Root<TgtColumns> root = query.from(TgtColumns.class);
		query.where(root.get("tgtrecId").in(recIds));
		deleteAll(this.entityManager.createQuery(query).getResultList());
	}

}
