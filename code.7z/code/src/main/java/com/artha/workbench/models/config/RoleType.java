package com.artha.workbench.models.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.artha.workbench.models.metastore.AbstractModel;


@Entity
@Table(name = "roletype")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
public class RoleType extends AbstractModel {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "roletypeid", nullable = false)
	private Integer roletypeid;

	private String status;

	private String description;

	public Integer getRoletypeid() {
		return roletypeid;
	}

	public void setRoletypeid(Integer roletypeid) {
		this.roletypeid = roletypeid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
