package com.artha.workbench.service;

import java.io.IOException;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.AuditLogDetailsDAO;
import com.artha.workbench.dao.EntityMasterDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.config.AuditLogDetails;
import com.artha.workbench.models.metastore.EntityMaster;
import com.artha.workbench.models.metastore.EntityMasterId;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;
import com.guvvala.framework.util.ThreadLocalUtil;

@Service("entityMasterService")
public class EntityMasterServiceImpl implements EntityMasterService {

	@Autowired
	EntityMasterDAO entityMasterDAO;

	@Autowired
	AuditLogDetailsDAO auditLogDetailsDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Transactional(readOnly = true)
	public List<EntityMaster> getEntityMasterList() {
		return entityMasterDAO.findAll();
	}
	
	@Transactional(readOnly = true)
	@Override
	public List<EntityMaster> getEntityMasterListByReleaseNo(Integer releaseNo) {
		return entityMasterDAO.getEntityMasterListByReleaseNo(releaseNo);
	}

	@Transactional
	public void create(EntityMaster entityMaster) {
		entityMasterDAO.create(entityMaster);
	}

	@Transactional(readOnly = true)
	@Override
	public EntityMaster getPreviousEntityMaster(EntityMaster entityMaster) throws IOException
	{
		EntityMasterId entityMasterId = new EntityMasterId();
		entityMasterId.setEntityID(entityMaster.getEntityID());
		String entityMasterIdJson = AppWebUtils.convertObjectToJson(entityMasterId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(entityMaster.getReleaseNo(), "ENTITYMASTER", entityMasterIdJson);
		EntityMaster previousEntityMaster = new EntityMaster();
		if(releaseArchive!=null){
		previousEntityMaster = AppWebUtils.convertJsonToObject(EntityMaster.class, releaseArchive.getRecData());
		}
		return previousEntityMaster;
		
	}

	@Transactional
	public void update(EntityMaster entityMaster,boolean isReleaseChanged) throws JsonProcessingException {
			EntityMaster oldEntity = entityMasterDAO.findOne(entityMaster.getEntityID());
			checkForCyclicDependency(entityMaster);
			if(isReleaseChanged)
			{
			ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
			releaseArchiveKey.setReleaseId(entityMaster.getReleaseNo());
			releaseArchiveKey.setTableName("EntityMaster");
		
			EntityMasterId entityMasterId = new EntityMasterId();
			entityMasterId.setEntityID(oldEntity.getEntityID());
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityMasterId));
			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if(releaseArchive!=null){
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchiveDAO.update(releaseArchive);
			}else{
				releaseArchive=new ReleaseArchive();
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchiveDAO.update(releaseArchive);
			}
			}
		entityMasterDAO.update(entityMaster);
	}
	
	private void checkForCyclicDependency(EntityMaster entityMaster) throws JsonProcessingException	{

		EntityMasterId entityMasterId = new EntityMasterId();
		entityMasterId.setEntityID(entityMaster.getEntityID());
		String jsonId = AppWebUtils.convertObjectToJson(entityMasterId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(entityMaster.getReleaseNo(), "ENTITYMASTER", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	public void saveEntityMaster(List<EntityMaster> entitytypes) {
		entityMasterDAO.saveEntityMaster(entitytypes);
	}

	@Transactional
	public int getmaxEntitymster() {
		return entityMasterDAO.getmaxEntityMaster();
	}

	@Transactional
	public void createAudit(List<EntityMaster> Dbentitymasterlist, List<EntityMaster> entities,
			List<EntityMaster> entityTypes, String reviewflag) {
		String currentUser = ThreadLocalUtil.getUserName();
		String rolename = "";
		Integer loginid = null;

		EntityMaster e = null;
		EntityMaster e1 = null;
		for (int i = 0; i < entityTypes.size(); i++) {
			e = new EntityMaster();
			e1 = new EntityMaster();
			e = (EntityMaster) entityTypes.get(i);

			if (reviewflag != null && reviewflag.equals("true")) {
				e1 = (EntityMaster) Dbentitymasterlist.get(i);
			} else {
				e1 = (EntityMaster) entities.get(i);
			}
			if (e1.getEntityName() == null) {
				e1.setEntityName("");
			}
			if (e.getEntityName() != null && !e.getEntityName().equals(e1.getEntityName())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("EntityName");
				auditlog.setOldvalue(e1.getEntityName().toString());
				auditlog.setNewvalue(e.getEntityName().toString());
				auditlog.setLoginid(loginid);
				auditlog.setUsername(rolename);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e1.getEntityNameAbbr() == null) {
				e1.setEntityNameAbbr("");
			}
			if (e.getEntityNameAbbr() != null && !e.getEntityNameAbbr().equals(e1.getEntityNameAbbr())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("EntityNameAbbr");
				auditlog.setOldvalue(e1.getEntityNameAbbr());
				auditlog.setNewvalue(e.getEntityNameAbbr());
				auditlog.setLoginid(loginid);
				auditlog.setUsername(rolename);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e1.getEntityTypeID() == null) {
				e1.setEntityTypeID(0);
			}
			if (e.getEntityTypeID() != null && !e.getEntityTypeID().equals(e1.getEntityTypeID())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("EntityTypeID");
				auditlog.setOldvalue(e1.getEntityTypeID().toString());
				auditlog.setNewvalue(e.getEntityTypeID().toString());
				auditlog.setLoginid(loginid);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e1.getAddrLine1() == null) {
				e1.setAddrLine1("");
			}
			if (e.getAddrLine1() != null && !e.getAddrLine1().equals(e1.getAddrLine1())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("AddrLine1");
				auditlog.setOldvalue(e1.getAddrLine1().toString());
				auditlog.setNewvalue(e.getAddrLine1().toString());
				auditlog.setLoginid(loginid);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e1.getAddrLine2() == null) {
				e1.setAddrLine2("");
			}
			if (e.getAddrLine2() != null && !e.getAddrLine2().equals(e1.getAddrLine2())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("AddrLine2");
				auditlog.setOldvalue(e1.getAddrLine2().toString());
				auditlog.setNewvalue(e.getAddrLine2().toString());
				auditlog.setLoginid(loginid);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e1.getAddrLine3() == null) {
				e1.setAddrLine3("");
			}
			if (e.getAddrLine3() != null && !e.getAddrLine3().equals(e1.getAddrLine3())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("AddrLine3");
				auditlog.setOldvalue(e1.getAddrLine3().toString());
				auditlog.setNewvalue(e.getAddrLine3().toString());
				auditlog.setLoginid(loginid);
				auditlog.setUsername(rolename);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e1.getCityName() == null) {
				e1.setCityName("");
			}
			if (e.getCityName() != null && !e.getCityName().equals(e1.getCityName())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("CityName");
				auditlog.setOldvalue(e1.getCityName().toString());
				auditlog.setNewvalue(e.getCityName().toString());
				auditlog.setLoginid(loginid);
				auditlog.setUsername(rolename);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e1.getStateCd() == null) {
				e1.setStateCd("");
			}
			if (e.getStateCd() != null && !e.getStateCd().equals(e1.getStateCd())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("StateCd");
				auditlog.setOldvalue(e1.getStateCd().toString());
				auditlog.setNewvalue(e.getStateCd().toString());
				auditlog.setLoginid(loginid);
				auditlog.setUsername(rolename);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e1.getPostalCd() == null) {
				e1.setPostalCd("");
			}
			if (e.getPostalCd() != null && !e.getPostalCd().equals(e1.getPostalCd())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("PostalCd");
				auditlog.setOldvalue(e1.getPostalCd().toString());
				auditlog.setNewvalue(e.getPostalCd().toString());
				auditlog.setLoginid(loginid);
				auditlog.setUsername(rolename);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e1.getPostalPlus() == null) {
				e1.setPostalPlus("");
			}
			if (e.getPostalPlus() != null && !e.getPostalPlus().equals(e1.getPostalPlus())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("PostalPlus");
				auditlog.setOldvalue(e1.getPostalPlus().toString());
				auditlog.setNewvalue(e.getPostalPlus().toString());
				auditlog.setLoginid(loginid);
				auditlog.setUsername(rolename);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e1.getActive() == null) {
				e1.setActive("");
			}
			if (e.getActive() != null && !e.getActive().equals(e1.getActive())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("Active");
				auditlog.setOldvalue(e1.getActive().toString());
				auditlog.setNewvalue(e.getActive().toString());
				auditlog.setLoginid(loginid);
				auditlog.setUsername(rolename);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
			if (e.getEffectiveDt() != null && !e.getEffectiveDt().equals(e1.getEffectiveDt())) {
				AuditLogDetails auditlog = new AuditLogDetails();
				// auditlog.setAuditid(maxid+1);
				auditlog.setTablename("EntityMaster");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("EffectiveDt");
				auditlog.setOldvalue(e1.getEffectiveDt().toString());
				auditlog.setNewvalue(e.getEffectiveDt().toString());
				auditlog.setLoginid(loginid);
				auditlog.setUsername(rolename);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
			}
		}

	}
	@Transactional
	  public HashMap<String,Integer> loadSelectedEntityId(int  entityid)
	  {
		return entityMasterDAO.loadSelectedEntityId(entityid);
	  }

	@Transactional
	  public HashMap<String,Integer> loadEntityId()
	  {
		return entityMasterDAO.loadEntityId();
	  }
	@Transactional
	  public HashMap<Integer,String> loadEntityIdMap()
	  {
		return entityMasterDAO.loadEntityIdMap();
	  }
	
	@Override
	@Transactional(readOnly=true)
	public long getEntityMasterDataCount(){
		return entityMasterDAO.count();
	}
	@Override
	@Transactional(readOnly=true)
	public List<Integer> getEntityMasterReleaseNumbers(Set<Integer> entityIds,Integer selectedReleaseNumber){
		return entityMasterDAO.getEntityMasterReleaseNumbers(entityIds, selectedReleaseNumber);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Integer> getAllEntityMasterReleaseIds(Integer selectedReleaseId) {
		return entityMasterDAO.getAllEntityMasterReleaseIds(selectedReleaseId);
	}

	@Override
	@Transactional(readOnly=true)
	public List<EntityMaster> getEntityMastersList(Set<Integer> entityIds, Integer selectedReleaseNumber) {
		return entityMasterDAO.getEntityMastersList(entityIds, selectedReleaseNumber);
	}
}
