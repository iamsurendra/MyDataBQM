package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EntityFileTypeStepChunk;
import com.artha.workbench.models.metastore.EntityFileTypeStepChunkKey;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityFileTypeStepChunkDAO extends BaseDAO<EntityFileTypeStepChunk, EntityFileTypeStepChunkKey> {
	
	public List<EntityFileTypeStepChunk> getEntityFileTypeStepChunByReleaseNo(Integer releaseNo);
	
	public List<Integer> getAllEntityFileTypeStepChunkReleaseIds(Integer selectedReleaseId);

}
