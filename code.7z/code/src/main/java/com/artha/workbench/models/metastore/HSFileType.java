package com.artha.workbench.models.metastore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.ExcelHeader;

@Entity
@Table(name = "metastore.hsfiletype")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name="hsFileType")
public class HSFileType extends AbstractModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Column(name = "FileTypeID", nullable = false)
	@Id
	@NotNull
	@JsonProperty("FileTypeID")
	private Integer fileTypeID;
	
	@JsonProperty("HSFileType")
	private String hsFileType;
	
	@JsonProperty("Description")
	private String description;
	
	@Column(name = "ReleaseNum", nullable = false)
	@ExcelHeader(name="ReleaseNum")
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Column(name="HSFileTypeAbbr")
	@JsonProperty("HSFileTypeAbbr")
	private String hSFileTypeAbbr;

	@Transient
	@JsonIgnore
	private boolean addMode;
	



	public HSFileType(boolean addMode,Integer releaseNo) {
		this.addMode = addMode;
		this.releaseNo = releaseNo;
	}
	
	public HSFileType(){
		
	}

	// Getters and Setters.
	public Integer getFileTypeID() {
		return fileTypeID;
	}

	public void setFileTypeID(Integer fileTypeID) {
		this.fileTypeID = fileTypeID;
	}


	public String getHsFileType() {
		return hsFileType;
	}

	public void setHsFileType(String hsFileType) {
		this.hsFileType = hsFileType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
    @XmlTransient
	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}

	
	public String gethSFileTypeAbbr() {
		return hSFileTypeAbbr;
	}

	public void sethSFileTypeAbbr(String hSFileTypeAbbr) {
		this.hSFileTypeAbbr = hSFileTypeAbbr;
	}
	
	

}
