package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.FileFormat;
import com.guvvala.framework.dao.BaseDAO;


public interface FileFormatDAO extends BaseDAO<FileFormat, Integer> {
	public void saveFileFormat(List<FileFormat> entitytypes);

	public int getmaxfileFormatID();

	public HashMap<Integer, String> loadFileFormatId();

	public void deleteFileFormat();
	
	List<FileFormat> getFileFormatListByReleaseNo(Integer releaseNo);
	
	List<Integer> getFileFormatReleaseNumbers(Set<Integer> fileFormatIds,Integer selectedReleaseNumber);
	
	List<Integer> getAllFileFormatReleaseIds(Integer selectedReleaseId);
	
	List<FileFormat> getFileFormatsList(Set<Integer> fileFormatIds,Integer selectedReleaseNumber);
}
