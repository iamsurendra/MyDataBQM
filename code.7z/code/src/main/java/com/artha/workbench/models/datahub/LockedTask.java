package com.artha.workbench.models.datahub;

import java.io.Serializable;
import javax.persistence.*;

import com.guvvala.framework.util.DateUtils;

import java.util.Date;


/**
 * The persistent class for the locked_tasks database table.
 * 
 */
@Entity
@Table(name="datahub.locked_tasks")
@NamedQuery(name="LockedTask.findAll", query="SELECT l FROM LockedTask l")
public class LockedTask implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LockedTaskPK id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_on")
	private Date createdOn;

	public LockedTaskPK getId() {
		return id;
	}


	public void setId(LockedTaskPK id) {
		this.id = id;
	}

	@Column(name="lock_owned_by")
	private String lockOwnedBy;

	
	@Transient
	private String createdOnString;
	
	public LockedTask() {
	}


	public Date getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getLockOwnedBy() {
		return this.lockOwnedBy;
	}

	public void setLockOwnedBy(String lockOwnedBy) {
		this.lockOwnedBy = lockOwnedBy;
	}

	public String getCreatedOnString() {
		return createdOnString;
	}

	public void setCreatedOnString(String createdOnString) {
		this.createdOnString = createdOnString;
	}
	
	@PostLoad
	public void postLoad() {
		if(getCreatedOn()!=null)
		setCreatedOnString(DateUtils.convertDateFormat(getCreatedOn(), DateUtils.DISPLAY_DATE_TIME_FORMAT));
	}


}