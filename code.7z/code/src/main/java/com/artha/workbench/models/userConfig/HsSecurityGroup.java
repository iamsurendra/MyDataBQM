package com.artha.workbench.models.userConfig;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the hssecuritygroups database table.
 * 
 */
@Entity
@Table(name="userconfig.hssecuritygroups")
@NamedQuery(name="HsSecurityGroup.findAll", query="SELECT h FROM HsSecurityGroup h")
public class HsSecurityGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	@GeneratedValue
	private int id;

	private String access;

	private String col;

	@Column(name="FILE_NAME")
	private String fileName;

	@Column(name="GROUP_NAME")
	private String groupName;

	private String partner;

	@Column(name="ROLE_NAME")
	private String roleName;

	public HsSecurityGroup() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccess() {
		return this.access;
	}

	public void setAccess(String access) {
		this.access = access;
	}

	public String getCol() {
		return this.col;
	}

	public void setCol(String col) {
		this.col = col;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getGroupName() {
		return this.groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getPartner() {
		return this.partner;
	}

	public void setPartner(String partner) {
		this.partner = partner;
	}

	public String getRoleName() {
		return this.roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

}