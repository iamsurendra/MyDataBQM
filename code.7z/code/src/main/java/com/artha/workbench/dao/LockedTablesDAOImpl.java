package com.artha.workbench.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.core.LockedTables;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala 
 *
 */
@Repository
public class LockedTablesDAOImpl extends BaseDAOImpl<LockedTables, Integer> implements LockedTablesDAO {

	public LockedTablesDAOImpl() {
		super(LockedTables.class);
	}

}
