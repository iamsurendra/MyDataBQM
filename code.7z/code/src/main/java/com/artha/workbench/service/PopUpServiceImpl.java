package com.artha.workbench.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.TaskStatus;
import com.artha.workbench.constant.WBConstants;
import com.artha.workbench.dao.FileTypeColumnsDAO;
import com.artha.workbench.dao.LockedTaskDAO;
import com.artha.workbench.dao.SrccolumnsDAO;
import com.artha.workbench.dao.SrcrecordsDAO;
import com.artha.workbench.dao.StatusHistoryDAO;
import com.artha.workbench.dao.TaskDAO;
import com.artha.workbench.dao.TaskcolLayoutDAO;
import com.artha.workbench.dao.TgtColumnsDAO;
import com.artha.workbench.dao.TgtRecordsDAO;
import com.artha.workbench.models.datahub.SrcColumnErrorInfo;
import com.artha.workbench.models.datahub.StatusHistory;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.models.datahub.TgtColumns;
import com.artha.workbench.models.datahub.TgtRecords;
import com.artha.workbench.models.userConfig.FileTypeColumns;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.util.AppWebUtils;
import com.guvvala.framework.util.ThreadLocalUtil;

@Service
public class PopUpServiceImpl implements PopUpService {

	@Autowired
	SrcrecordsDAO srcrecordsDAO;

	@Autowired
	SrccolumnsDAO srccolumnsDAO;

	@Autowired
	LockedTaskDAO lockedTaskDAO;

	@Autowired
	TaskDAO taskDAO;

	@Autowired
	TgtRecordsDAO tgtRecordsDAO;

	@Autowired
	TgtColumnsDAO tgtColumnsDAO;

	@Autowired
	TaskcolLayoutDAO taskcolLayoutDAO;
	
	@Autowired
	FileTypeColumnsDAO fileTypeColumnsDAO;
	
	@Autowired
	StatusHistoryDAO statusHistoryDAO;

	@Transactional
	public LinkedList<SrcColumnErrorInfo> getPopuplist(String srcid, String tarrecid, Integer entityTypeId) {
		LinkedList<SrcColumnErrorInfo> srccolumnsList = new LinkedList<SrcColumnErrorInfo>();
		List<FileTypeColumns> fileTypeColumns = new ArrayList<>();
		if(entityTypeId!=null){
	    fileTypeColumns = fileTypeColumnsDAO.findColumnsByEntityFileTypeId(entityTypeId);
	    }
		List<SrcColumnErrorInfo> srccolumns = srccolumnsDAO.getPopuplist(srcid);
		if (fileTypeColumns.isEmpty()) {
			srccolumnsList.addAll(srccolumns);
			return srccolumnsList;
		}
		for (FileTypeColumns taskcolLayout : fileTypeColumns) {
			for (SrcColumnErrorInfo srccolumn : srccolumns) {
				if (taskcolLayout.getColName().equalsIgnoreCase(srccolumn.getColumnName())) {
					srccolumnsList.add(srccolumn);
					break;
				}
			}
		}

		return srccolumnsList;
	}

	@Transactional
	public List<TgtColumns> getTargetPopuplist(String srcid) {
		return srccolumnsDAO.getTargetPopuplist(srcid);
	}

	@Transactional
	public String getSrcrecid(String taskid) {
		return srcrecordsDAO.getSrcrecid(taskid);
	}

	@Transactional
	public String getTargetrecid(String taskid) {
		return srcrecordsDAO.getTargetrecid(taskid);
	}

	@Override
	@Transactional
	public void lockTask(String taskId, String userName, String lockType) {
		Task task = taskDAO.findOne(taskId);
		if (task != null && !task.getStatus().equalsIgnoreCase(TaskStatus.RESOLVED.value)
				&& !task.getStatus().equalsIgnoreCase(TaskStatus.LOCKED.value)) {
			// check if temporary lock is given , if it is already present then
			// do not lock else lock for both temporary and edit locks

			List<String> alreadyLocked = lockedTaskDAO.getLockedTasksList(taskId, lockType);
			if (null != alreadyLocked && alreadyLocked.size() > 0) {
				return;
			}
			lockedTaskDAO.createLock(taskId, userName, lockType);
		}

	}

	@Transactional
	public void updatePendingTasks(String taskid, String userName, String status) {
		taskDAO.updatePendingTasks(taskid, userName, TaskStatus.PENDING.value);
	}

	@Transactional
	public void updatetgtrecords(String taskid, String userName) {
		tgtRecordsDAO.updatetgtrecords(taskid, userName);
	}

	@Override
	@Transactional
	public void updateresolvedtask(String taskid, String userName) {
		taskDAO.updateresolvedtask(taskid, userName);
	}

	@Transactional
	public void updateTargetCol(List<TgtColumns> targetLists, int ismodified) {
		tgtColumnsDAO.updateTargetCol(targetLists, ismodified);
	}

	@Transactional
	public void saveChanges(List<TgtColumns> targetLists, String taskId, String status) {
		if (!status.equalsIgnoreCase("resolved")) {
			List<String> jsonList = new ArrayList<String>(); 
			String userName = ThreadLocalUtil.getUserName();
			Task task = taskDAO.findOne(taskId);
			task.setModified_by(userName);
			task.setOwner(userName);
			task.setModified_on(new Date());
			task.setStatus(status);
			task.setLast_upd_by(userName);
			jsonList.addAll(convertTaskToJson(Collections.singletonList(task)));
			TgtRecords tgtRecord = tgtRecordsDAO.getTgtRecordsObjByTaskId(taskId);
			tgtRecord.setResolvedBy(userName);
			tgtRecord.setResolvedOn(new Date());
			tgtRecord.setLast_upd_by(userName);
			jsonList.addAll(convertTgtRecordToJson(Collections.singletonList(tgtRecord)));
			//prepare json list for tgt columns
			jsonList.addAll(convertTgtColumnsToJson(targetLists));
			taskDAO.detach(task);
			tgtRecordsDAO.detach(tgtRecord);
			String result = StringUtils.join(jsonList, ",");
			result = "["+result+"]";
			//used for escaping the ' character
			result=result.replaceAll("'","''");
			tgtColumnsDAO.updateWithProcedure(result);
		}
		
	}
	
	private List<String> convertTaskToJson(List<Task> taskList)
	{
		List<String> jsonList = new ArrayList<String>(); 
		for(Task task : taskList)
		{
			try {
				String taskJson = AppWebUtils.convertObjectToJson(task);
				jsonList.add(taskJson);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jsonList;
	}
	
	private List<String> convertTgtRecordToJson(List<TgtRecords> tgtRecords){
		
		List<String> jsonList = new ArrayList<String>(); 
		for(TgtRecords tgtRecord : tgtRecords)
		{
		try {
			String tgtRecordJson = AppWebUtils.convertObjectToJson(tgtRecord);
			jsonList.add(tgtRecordJson);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		return jsonList;
		
	}
	private List<String> convertTgtColumnsToJson(List<TgtColumns> targetLists)
	{
		List<String> jsonList = new ArrayList<String>(); 
		String userName = ThreadLocalUtil.getUserName();
		//THis is kept because as of now we are recieving duplicate col ids , once talend job is fixed this shouldnt happen
		Set<String> tgtColumnIdSet = new HashSet<String>();
		for(TgtColumns tgtColumns:targetLists)
		{
			if(!tgtColumnIdSet.contains(tgtColumns.getTgtcolId()))
			{
				tgtColumnIdSet.add(tgtColumns.getTgtcolId());
			try {
				tgtColumns.setLast_upd_by(userName);
				String tgtColumnJson =	AppWebUtils.convertObjectToJson(tgtColumns);
				jsonList.add(tgtColumnJson);
				tgtColumnsDAO.detach(tgtColumns);
				
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
		return jsonList;
	}

	@Transactional
	public void saveResolvedTaskChanges(List<TgtColumns> targetLists, String taskId, String status) {
		if (!status.equalsIgnoreCase("resolved")) {
			List<String> jsonList = new ArrayList<String>(); 
			String userName = ThreadLocalUtil.getUserName();
			Task task = taskDAO.findOne(taskId);
			task.setModified_by(userName);
			task.setOwner(userName);
			task.setModified_on(new Date());
			task.setStatus(TaskStatus.RESOLVED.value);
			task.setLast_upd_by(userName);
			jsonList.addAll(convertTaskToJson(Collections.singletonList(task)));
			TgtRecords tgtRecord = tgtRecordsDAO.getTgtRecordsObjByTaskId(taskId);
			tgtRecord.setResolvedBy(userName);
			tgtRecord.setResolvedOn(new Date());
			tgtRecord.setLast_upd_by(userName);
			jsonList.addAll(convertTgtRecordToJson(Collections.singletonList(tgtRecord)));
			//taskDAO.updateresolvedtask(taskId, ThreadLocalUtil.getUserName());
			//tgtRecordsDAO.updatetgtrecords(taskId, ThreadLocalUtil.getUserName());
			jsonList.addAll(convertTgtColumnsToJson(targetLists));
			taskDAO.detach(task);
			tgtRecordsDAO.detach(tgtRecord);
			String result = StringUtils.join(jsonList, ",");
			result = "["+result+"]";
			//used for escaping the ' character
			result=result.replaceAll("'","''");
			tgtColumnsDAO.updateWithProcedure(result);
		}
		//tgtColumnsDAO.updateTargetCol(targetLists, 1);
	}

	@Transactional
	public void updateStatusToTempLock(String taskId){
		Task task = taskDAO.findOne(taskId);
		task.setStatus(TaskStatus.TEMP_LOCK.value);
	}

	@Transactional
	@Override
	public void updateTaskStatus(String taskId,String status){
		String[] taskArray =taskId.split(WBConstants.UNDER_SCORE);
		StatusHistory statusHistory = new StatusHistory(Long.valueOf(taskArray[0]), Long.valueOf(taskArray[1]),Long.valueOf(taskArray[2]), status, new Date());
		statusHistoryDAO.create(statusHistory);
	}
	

}
