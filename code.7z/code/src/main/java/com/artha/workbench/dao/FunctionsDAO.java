package com.artha.workbench.dao;

import com.artha.workbench.models.userConfig.Functions;
import com.guvvala.framework.dao.BaseDAO;

public interface FunctionsDAO extends BaseDAO<Functions, Long> {


}
