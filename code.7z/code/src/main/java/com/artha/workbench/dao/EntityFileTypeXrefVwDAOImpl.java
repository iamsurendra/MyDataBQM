package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileTypeXrefVw;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityFileTypeXrefVwDAOImpl extends
		BaseDAOImpl<EntityFileTypeXrefVw, Integer> implements
		EntityFileTypeXrefVwDAO {

	public EntityFileTypeXrefVwDAOImpl() {
		super(EntityFileTypeXrefVw.class);
	}
	

	public List<EntityFileTypeXrefVw> getEntityFileTypeXrefVwList(Integer releaseNo)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeXrefVw> query = cb.createQuery(EntityFileTypeXrefVw.class);
		Root<EntityFileTypeXrefVw> root = query.from(EntityFileTypeXrefVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}

}
