package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.SourceToTargetSplit;
import com.artha.workbench.models.metastore.SourceToTargetSplitKey;
import com.guvvala.framework.dao.BaseDAO;


public interface SourceToTargetSplitDAO extends BaseDAO<SourceToTargetSplit, SourceToTargetSplitKey> {

	List<SourceToTargetSplit> getSourceToTargetSplitListByReleaseNo(Integer releaseNo);
	
	List<Integer> getAllSourceToTargetSplitReleaseIds(Integer selectedReleaseId);
}
