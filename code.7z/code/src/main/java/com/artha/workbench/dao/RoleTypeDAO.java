package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;

import com.artha.workbench.models.config.RoleType;
import com.guvvala.framework.dao.BaseDAO;


public interface RoleTypeDAO extends BaseDAO<RoleType, Integer> {

	 public HashMap<Integer,String> loadlogintypeid() ;
	 public List< RoleType> getRoleDetails();
	 public int getMaxRoleid();
	 public String checkRoleExist(String lname);
}

