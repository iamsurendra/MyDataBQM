package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.GroupRoleFunctionsPK;
import com.artha.workbench.models.userConfig.GroupRoleFunctionsVW;
import com.guvvala.framework.dao.BaseDAO;

public interface GroupRoleFunctionsDAO extends BaseDAO<GroupRoleFunctionsVW, GroupRoleFunctionsPK> {

	public List<GroupRoleFunctionsVW> findbyGroupID(Integer groupId);

}
