package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.core.LockedTables;
import com.artha.workbench.models.metastore.EntityType;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EntityTypeService {

	public List<EntityType> getEntityTypeList();

	public void create(EntityType entityType);

	public void update(EntityType entityType, boolean isReleaseChanged) throws JsonProcessingException;

	public void saveEntityType(List<EntityType> entitytypes);

	public void createAudit(List<EntityType> DbentityTypelist, List<EntityType> entities, List<EntityType> entityTypes, String reviewflag);
	public int getmaxEntitytype();
	public HashMap<Integer,String> loadentityTypeid();
	public List<LockedTables> getLockedList();
	public void saveLockedTables(LockedTables lockedTables);
	
	public void removeLocks(LockedTables lockedTables);
	
	public long getEntityTypeDataCount();

	List<EntityType> getEntityTypeListByReleaseNo(Integer releaseNo);

	EntityType getPreviousEntityType(EntityType entityType) throws IOException;

	List<Integer> getEntityTypeReleaseNumbers(Set<Integer> entityTypeIds,Integer selectedReleaseNumber);
	
	List<Integer> getAllEntityTypeReleaseIds(Integer selectedReleaseId);
	
	List<EntityType> getEntityTypeList(Set<Integer> entityTypeIds,Integer selectedReleaseId);
	
}
