package com.artha.workbench.dao;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.datahub.TaskLayout;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * @author Guvala
 *
 */
@Repository
public class TaskLayoutDAOImpl extends BaseDAOImpl<TaskLayout, String> implements TaskLayoutDAO {

	public TaskLayoutDAOImpl() {
		super(TaskLayout.class);
	}

}
