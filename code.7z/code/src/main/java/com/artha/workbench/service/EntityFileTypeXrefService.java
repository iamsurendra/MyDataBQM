package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.EntityFileTypeXref;
import com.artha.workbench.models.metastore.EntityFileTypeXrefVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EntityFileTypeXrefService {
	
	public List<EntityFileTypeXref> getEntityFileTypeXrefList();
	public List<EntityFileTypeXrefVw> getEntityFileTypeXrefVwList();
	public void create(EntityFileTypeXrefVw entityFileTypeXrefVW);
	public void update(EntityFileTypeXrefVw entityFileTypeXrefVW,boolean isReleaseChanged) throws JsonProcessingException ;
	
	public HashMap<String,Integer> loadentityFileTypeID();
	
	public int getMaxEntityFileTypeID();
	public HashMap<Integer,String> loadEntityFileTypeID();
	public EntityFileTypeXref getEntityFileTypeXref(Integer entityFileTypeId);
	
	public EntityFileTypeXref findOne(Integer id);
	
	public long getEntityFileTypeXrefDataCount();
	
	public List<EntityFileTypeXrefVw> getEntityFileTypeXrefVwList(Integer releaseNo);
	
	public EntityFileTypeXrefVw getPreviousEntityFileTypeXrefVw(EntityFileTypeXrefVw entityFileTypeXrefVw) throws IOException;
	public List<EntityFileTypeXref> getEntityFileTypeXrefListByReleaseNo(Integer releaseNo);
	List<Integer> getEntityTypeXrefReleaseNumbers(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber);
	List<Integer> getAllEntityFileTypeXrefReleaseIds(Integer selectedReleaseId);
	List<EntityFileTypeXref> getEntityTypeXrefList(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber);
	public List<Integer> getpoolIds();

	
}
