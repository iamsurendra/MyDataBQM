package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.DateUtils;


@Entity
@Table(name = "metastore.entityfilereccol_V")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@IdClass(EntityFileReccolVwkey.class)
public class EntityFileRecColumnVw extends AbstractModel {


	private static final long serialVersionUID = 1L;
	
	

	//private Integer efrcid;
	@JsonProperty("FileMask")
	private String FileMask;
	
	@JsonProperty("EntityName")
	private String EntityName;
	
	@JsonProperty("HSFileType")
	private String HSFileType;
	
	
	@Id 
	@Column(name = "ColumnID", nullable = false)
	@JsonProperty("ColumnID")
	private Integer ColumnID;
	
	@JsonProperty("EntityFileTypeID")
	private Integer EntityFileTypeID;
	
	@JsonProperty("ColName")
	private String ColName;
	
	@JsonProperty("DataType")
	private String DataType;
	
	@JsonProperty("ColLength")
	private Integer ColLength;
	
	@JsonProperty("StartPosition")
	private Integer StartPosition;
	
	@JsonProperty("AllowValue")
	private String AllowValue;
	
	@JsonProperty("Active")
	private String Active;
	

	
	@Transient
	@JsonIgnore
	private String Comments;
	
	@Transient
	@JsonIgnore
	private String wmc;
	
	@Transient
	@JsonIgnore
	private String rfc;
	
	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date EffectiveDate;
	
	@JsonProperty("ColMask")
	private String ColMask;
	
	
	@Transient
	@JsonIgnore
	private String effectiveDtstr;
	
	@Transient
	@JsonIgnore
	private boolean addMode;
	
	@Column(name = "ReleaseNum")
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Column(name = "IncludeInRpt")
	@JsonProperty("IncludeInRpt")
	@Type(type = "boolean")
	private Boolean includeInRpt;
	
	@Transient
	private Character includeRpt;

	
	public EntityFileRecColumnVw() {
		
	}
	public EntityFileRecColumnVw(boolean addMode,Date effectiveDate,Integer releaseNo) {
		this.EffectiveDate = effectiveDate;
		this.addMode = addMode;
		this.releaseNo = releaseNo;
		convertEffectiveDate();

	}
	public boolean isAddMode() {
		return addMode;
	}
	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}
	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}
	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}
	public String getColMask() {
		return ColMask;
	}
	public void setColMask(String colMask) {
		ColMask = colMask;
	}
//	public Integer getId() {
//		return efrcid;
//	}
//	public void setId(Integer id) {
//		this.efrcid = id;
//	}
	public String getFileMask() {
		return FileMask;
	}
	public void setFileMask(String fileMask) {
		FileMask = fileMask;
	}
	public String getEntityName() {
		return EntityName;
	}
	public void setEntityName(String entityName) {
		EntityName = entityName;
	}
	public String getHSFileType() {
		return HSFileType;
	}
	public void setHSFileType(String hSFileType) {
		HSFileType = hSFileType;
	}
	public Integer getColumnID() {
		return ColumnID;
	}
	public void setColumnID(Integer columnID) {
		ColumnID = columnID;
	}
	public String getColName() {
		return ColName;
	}
	public void setColName(String colName) {
		ColName = colName;
	}
	public String getDataType() {
		return DataType;
	}
	public void setDataType(String dataType) {
		DataType = dataType;
	}
	public Integer getColLength() {
		return ColLength;
	}
	public void setColLength(Integer colLength) {
		ColLength = colLength;
	}
	public Integer getStartPosition() {
		return StartPosition;
	}
	public void setStartPosition(Integer startPosition) {
		StartPosition = startPosition;
	}
	
	
	public String getAllowValue() {
		return AllowValue;
	}
	public void setAllowValue(String allowValue) {
		AllowValue = allowValue;
	}
	public String getActive() {
		return Active;
	}
	public void setActive(String active) {
		Active = active;
	}
	public String getComments() {
		return Comments;
	}
	public void setComments(String comments) {
		Comments = comments;
	}
	public String getWmc() {
		return wmc;
	}
	public void setWmc(String wmc) {
		this.wmc = wmc;
	}
	public String getRfc() {
		return rfc;
	}
	public void setRfc(String rfc) {
		this.rfc = rfc;
	}
	public Date getEffectiveDate() {
		return EffectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		EffectiveDate = effectiveDate;
	}
	
	public Integer getEntityFileTypeID() {
		return EntityFileTypeID;
	}
	public void setEntityFileTypeID(Integer entityFileTypeID) {
		EntityFileTypeID = entityFileTypeID;
	}
	
	public Integer getReleaseNo() {
		return releaseNo;
	}
	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}

	
	public Boolean getIncludeInRpt() {
		return includeInRpt;
	}
	public void setIncludeInRpt(Boolean includeInRpt) {
		this.includeInRpt = includeInRpt;
	}
	
	
	public Character getIncludeRpt() {
		return includeRpt;
	}
	public void setIncludeRpt(Character includeRpt) {
		this.includeRpt = includeRpt;
	}
	@PostLoad
	public void postLoad(){
		convertEffectiveDate();
		convertIncludeInRpt();
	}
	private void convertIncludeInRpt() {
		if(getIncludeInRpt()== null){
			this.includeRpt = 'N';
		}else{
			if(getIncludeInRpt()== true){
				this.includeRpt = 'Y';
			}else{
				this.includeRpt = 'N';
			}
		}
		
		
		}
	public void convertEffectiveDate(){
		this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());	
	}

	

}
