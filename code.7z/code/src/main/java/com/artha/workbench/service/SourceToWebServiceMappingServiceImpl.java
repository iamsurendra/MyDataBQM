package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.SourceToWebServiceMappingDAO;
import com.artha.workbench.dao.SourceToWebServiceMappingVwDAO;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.models.metastore.SourceToWebServiceMapping;
import com.artha.workbench.models.metastore.SourceToWebServiceMappingKey;
import com.artha.workbench.models.metastore.SourceToWebServiceMappingVw;
import com.artha.workbench.models.metastore.SourceToWebServiceMappingVwKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("sourceToWebServiceMappingService")
public class SourceToWebServiceMappingServiceImpl implements SourceToWebServiceMappingService {

	@Autowired
	SourceToWebServiceMappingVwDAO sourceToWebServiceMappingVwDAO;

	@Autowired
	SourceToWebServiceMappingDAO sourceToWebServiceMappingDAO;

	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;


	@Transactional
	public List<SourceToWebServiceMappingVw> getSourceToWebServiceMappingVwList() {
		return sourceToWebServiceMappingVwDAO.findAll();
	}
	
	
	@Transactional
	public void create(SourceToWebServiceMappingVw sourceToWebServiceMappingVw) {
		SourceToWebServiceMapping sourceToWebServiceMapping = new SourceToWebServiceMapping();
		SourceToWebServiceMappingKey sourceToWebServiceMappingKey = new SourceToWebServiceMappingKey();
		sourceToWebServiceMappingKey.setSourceEntityFileTypeID(sourceToWebServiceMappingVw.getSourceEntityFileTypeID());
		sourceToWebServiceMappingKey.setWebServiceID(sourceToWebServiceMappingVw.getWebServiceID());
		sourceToWebServiceMappingKey.setTargetColumnID(sourceToWebServiceMappingVw.getTargetColumnID());
		sourceToWebServiceMapping.setSourceToWebServiceMappingKey(sourceToWebServiceMappingKey);
		loadSourceToWebServiceMapping(sourceToWebServiceMapping, sourceToWebServiceMappingVw);
		sourceToWebServiceMappingDAO.create(sourceToWebServiceMapping);

	}

	@Transactional
	public SourceToWebServiceMapping loadSourceToWebServiceMapping(SourceToWebServiceMapping sourceToWebServiceMapping,
			SourceToWebServiceMappingVw sourceToWebServiceMappingVw) {
		sourceToWebServiceMapping.setMapFunction(sourceToWebServiceMappingVw.getMapFunction());
		sourceToWebServiceMapping.setActive(sourceToWebServiceMappingVw.getActive());
		sourceToWebServiceMapping.setEffectiveDate(sourceToWebServiceMappingVw.getEffectiveDate());
		sourceToWebServiceMapping.setTargetColOrder(sourceToWebServiceMappingVw.getTargetColOrder());
		sourceToWebServiceMapping.setReleaseNum(sourceToWebServiceMappingVw.getReleaseNum());
		return sourceToWebServiceMapping;
	}

	@Transactional
	public void update(SourceToWebServiceMappingVw sourceToWebServiceMappingVw, boolean isReleaseChanged)
			throws JsonProcessingException {
		SourceToWebServiceMappingKey sourceToWebServiceMappingKey = new SourceToWebServiceMappingKey();
		sourceToWebServiceMappingKey.setSourceEntityFileTypeID(sourceToWebServiceMappingVw.getSourceEntityFileTypeID());
		sourceToWebServiceMappingKey.setWebServiceID(sourceToWebServiceMappingVw.getWebServiceID());
		sourceToWebServiceMappingKey.setTargetColumnID(sourceToWebServiceMappingVw.getTargetColumnID());
		checkForCyclicDependency(sourceToWebServiceMappingVw);
		SourceToWebServiceMapping sourceToWebServiceMapping = sourceToWebServiceMappingDAO
				.findOne(sourceToWebServiceMappingKey);

		if (isReleaseChanged) {
			SourceToWebServiceMappingVwKey sourceToWebServiceMappingVwKey = new SourceToWebServiceMappingVwKey();
			sourceToWebServiceMappingVwKey.setEntityName(sourceToWebServiceMappingVw.getEntityName());
			sourceToWebServiceMappingVwKey.sethSFileType(sourceToWebServiceMappingVw.getHsFileType());
			sourceToWebServiceMappingVwKey.setFileMask(sourceToWebServiceMappingVw.getFileMask());
			sourceToWebServiceMappingVwKey
					.setSourceEntityFileTypeID(sourceToWebServiceMappingVw.getSourceEntityFileTypeID());
			sourceToWebServiceMappingVwKey.setWebServiceID(sourceToWebServiceMappingVw.getWebServiceID());
			sourceToWebServiceMappingVwKey.setTargetColumnID(sourceToWebServiceMappingVw.getTargetColumnID());
			SourceToWebServiceMappingVw oldEntity = sourceToWebServiceMappingVwDAO
					.findOne(sourceToWebServiceMappingVwKey);
			if (oldEntity != null) {
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();

				releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNum());
				releaseArchiveKey.setReleaseId(sourceToWebServiceMappingVw.getReleaseNum());
				releaseArchiveKey.setTableName("SOURCETOWEBSERVICEMAPPING");
				releaseArchiveKey.setTableRecId(
						AppWebUtils.convertObjectToJson(sourceToWebServiceMapping.getSourceToWebServiceMappingKey()));
				ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
				if (releaseArchive != null) {
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToWebServiceMapping));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToWebServiceMappingVwKey));
					releaseArchiveDAO.update(releaseArchive);
				} else {
					releaseArchive = new ReleaseArchive();
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToWebServiceMapping));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToWebServiceMappingVwKey));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				}
			}

		}
		if (sourceToWebServiceMapping != null) {
			sourceToWebServiceMapping.setMapFunction(sourceToWebServiceMappingVw.getMapFunction());
			sourceToWebServiceMapping.setActive(sourceToWebServiceMappingVw.getActive());
			sourceToWebServiceMapping.setEffectiveDate(sourceToWebServiceMappingVw.getEffectiveDate());
			sourceToWebServiceMapping.setReleaseNum(sourceToWebServiceMappingVw.getReleaseNum());
			sourceToWebServiceMapping.setTargetColOrder(sourceToWebServiceMappingVw.getTargetColOrder());
			sourceToWebServiceMappingDAO.update(sourceToWebServiceMapping);

		}
	}

	private void checkForCyclicDependency(SourceToWebServiceMappingVw sourceToWebServiceMappingVw)
			throws JsonProcessingException {
		SourceToWebServiceMappingKey sourceToWebServiceMappingKey = new SourceToWebServiceMappingKey();
		sourceToWebServiceMappingKey.setSourceEntityFileTypeID(sourceToWebServiceMappingVw.getSourceEntityFileTypeID());
		sourceToWebServiceMappingKey.setTargetColumnID(sourceToWebServiceMappingVw.getTargetColumnID());
		sourceToWebServiceMappingKey.setWebServiceID(sourceToWebServiceMappingVw.getWebServiceID());
		String jsonId = AppWebUtils.convertObjectToJson(sourceToWebServiceMappingKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(
				sourceToWebServiceMappingVw.getReleaseNum(), "SOURCETOWEBSERVICEMAPPING", jsonId);
		if (releaseArchive != null) {
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	
	@Transactional
	public SourceToWebServiceMappingVw getPreviousSourceToWebServiceMappingVw(SourceToWebServiceMappingVw sourceToWebServiceMappingVw) throws IOException{
		
		SourceToWebServiceMappingKey sourceToWebServiceMappingKey = new SourceToWebServiceMappingKey();
		sourceToWebServiceMappingKey.setSourceEntityFileTypeID(sourceToWebServiceMappingVw.getSourceEntityFileTypeID());
		sourceToWebServiceMappingKey.setTargetColumnID(sourceToWebServiceMappingVw.getTargetColumnID());
		sourceToWebServiceMappingKey.setWebServiceID(sourceToWebServiceMappingVw.getWebServiceID());
		String sourceToWebServiceMappingVwJson = AppWebUtils.convertObjectToJson(sourceToWebServiceMappingKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(sourceToWebServiceMappingVw.getReleaseNum(), "SOURCETOWEBSERVICEMAPPING", sourceToWebServiceMappingVwJson);
		SourceToWebServiceMappingVw previousSourceToWebServiceMappingVw = new SourceToWebServiceMappingVw();
				if (releaseArchive != null) {
			previousSourceToWebServiceMappingVw = AppWebUtils.convertJsonToObject(SourceToWebServiceMappingVw.class, releaseArchive.getViewRecData());
					}
		return previousSourceToWebServiceMappingVw; 
	}
	
	@Transactional
	public List<SourceToWebServiceMappingVw> getsourceToWebServiceMappingVwListByReleaseNum (Integer releaseNum){
		return sourceToWebServiceMappingVwDAO.getsourceToWebServiceMappingVwListByReleaseNum(releaseNum);
	}


	public List<SourceToWebServiceMapping> getsourceToWebServiceMappingListByReleaseNum(Integer releaseNum) {
	
		return sourceToWebServiceMappingDAO.getsourceToWebServiceMappingListByReleaseNum(releaseNum);
	}
	
	@Transactional
	public SourceToWebServiceMapping getSourceToWebServiceMapping(SourceToWebServiceMappingVw sourceToWebServiceMappingVw) {
		SourceToWebServiceMappingKey sourceToWebServiceMappingKey = new SourceToWebServiceMappingKey();
		sourceToWebServiceMappingKey.setSourceEntityFileTypeID(sourceToWebServiceMappingVw.getSourceEntityFileTypeID());
		sourceToWebServiceMappingKey.setWebServiceID(sourceToWebServiceMappingVw.getWebServiceID());
		sourceToWebServiceMappingKey.setTargetColumnID(sourceToWebServiceMappingVw.getTargetColumnID());
		SourceToWebServiceMapping sourceToWebServiceMapping = sourceToWebServiceMappingDAO.findOne(sourceToWebServiceMappingKey);
		return sourceToWebServiceMapping;
	}
	
}

