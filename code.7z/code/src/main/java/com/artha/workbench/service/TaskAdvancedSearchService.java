package com.artha.workbench.service;

import java.util.List;

public interface TaskAdvancedSearchService {

	public List<String> findAllPartners();

	public List<String> findFileTypebyPartnerName(String partnerName);

	public List<String> findColumnsByFileName(String fileName);

}
