package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.SourceToTargetMapping;
import com.artha.workbench.models.metastore.SourceToTargetMappingVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface SourceToTargetMappingService {
	
	public List<SourceToTargetMapping> getSourceToTargetMappingList();
	public void create(SourceToTargetMappingVw sourceToTargetMappingVw);
	public void update(SourceToTargetMappingVw sourceToTargetMappingVw,boolean isReleaseChanged)throws JsonProcessingException;
	public List<SourceToTargetMappingVw> getSourceToTargetMappingVwList();
	public void saveSourceToTargetMappingS(List<SourceToTargetMapping> entitytypes);
	public List<SourceToTargetMapping> getSourceToTargetMappingTempList();
	public SourceToTargetMapping getSourceToTargetMapping(SourceToTargetMappingVw sourceToTargetMappingVw);
	
	public List<SourceToTargetMappingVw> getSourceToTargetMappingVwByReleaseNo(Integer releaseNo);
	
	public SourceToTargetMappingVw getPreviousSourceToTargetMappingVw(SourceToTargetMappingVw sourceToTargetMappingVw) throws IOException;
	
	public List<SourceToTargetMapping> getSourceToTargetMappingListByReleaseNo(Integer releaseNo);
	
	List<Integer> getAllSourceToTargetMappingReleaseIds(Integer selectedReleaseId);
}
