package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.metastore.EntityMaster;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityMasterDAOImpl extends BaseDAOImpl<EntityMaster, Integer> implements EntityMasterDAO {

	public EntityMasterDAOImpl() {
		super(EntityMaster.class);
	}

	public void saveEntityMaster(List<EntityMaster> entitytypes) {
		EntityMaster entityMaster = null;
		for (AbstractModel ref : entitytypes) {
			entityMaster = (EntityMaster) ref;
			create(entityMaster);
		}
	}

	public int getmaxEntityMaster() {
		int entityMasterId = 0;// changed 1 to 0 because to avoid data
								// constraint voilation Exception
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(entityID) from EntityMaster", Integer.class);
		if (query.getSingleResult() != null)
			entityMasterId = query.getSingleResult();
		return entityMasterId;
	}

	public HashMap<String, Integer> loadEntityId() {
		List<String> enamelist = null;
		List<Integer> eidlist = null;
		HashMap<String, Integer> hsmap = new HashMap<String, Integer>();
		TypedQuery<String> query = entityManager.createQuery("SELECT entityName from EntityMaster", String.class);
		TypedQuery<Integer> query1 = entityManager.createQuery("SELECT entityID from EntityMaster", Integer.class);
		enamelist = query.getResultList();
		eidlist = query1.getResultList();
		if (eidlist != null) {
			for (int i = 0; i < eidlist.size(); i++) {
				hsmap.put(enamelist.get(i), eidlist.get(i));
			}
		}
		return hsmap;
	}

	public HashMap<Integer, String> loadEntityIdMap() {
		HashMap<Integer, String> entityMap = new HashMap<Integer, String>();
		TypedQuery<Object[]> query = entityManager.createQuery("SELECT entityID,entityName from EntityMaster",
				Object[].class);
		List<Object[]> entityList = query.getResultList();
		for (Object[] array : entityList) {
			entityMap.put((Integer) array[0], (String) array[1]);
		}

		return entityMap;
	}

	public HashMap<String, Integer> loadSelectedEntityId(int entityid) {
		List<String> enamelist = null;
		List<Integer> eidlist = null;
		HashMap<String, Integer> hsmap = new HashMap<String, Integer>();
		TypedQuery<String> query = entityManager.createQuery(
				"SELECT em.entityName from EntityMaster em ,EntityFileTypeXref ef where em.entityID =ef.entityID and ef.entityFileTypeID ='"
						+ entityid + "'",
				String.class);
		TypedQuery<Integer> query1 = entityManager.createQuery(
				"SELECT em.entityID from EntityMaster em,EntityFileTypeXref ef where em.entityID =ef.entityID and ef.entityFileTypeID ='"
						+ entityid + "'",
				Integer.class);
		enamelist = query.getResultList();
		eidlist = query1.getResultList();
		if (eidlist != null) {
			for (int i = 0; i < eidlist.size(); i++) {
				hsmap.put(enamelist.get(i), eidlist.get(i));
			}
		}
		return hsmap;
	}

	public void deleteEntityMaster() {
		Query query = entityManager.createQuery("delete from EntityMaster");
		query.executeUpdate();
	}
	
	public List<EntityMaster> getEntityMasterListByReleaseNo(Integer releaseNo)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityMaster> query = cb.createQuery(EntityMaster.class);
		Root<EntityMaster> root = query.from(EntityMaster.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getEntityMasterReleaseNumbers(Set<Integer> entityIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<EntityMaster> root = query.from(EntityMaster.class);
		query.select(root.<Integer>get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("entityID")).value(entityIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}

	@Override
	public List<Integer> getAllEntityMasterReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from EntityMaster where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	
	@Override
	public List<EntityMaster> getEntityMastersList(Set<Integer> entityIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityMaster> query = cb.createQuery(EntityMaster.class);
		Root<EntityMaster> root = query.from(EntityMaster.class);
		query.select(root);
		query.where(cb.and(cb.in(root.get("entityID")).value(entityIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
}
