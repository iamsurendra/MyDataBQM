
package com.artha.workbench.models.datahub;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.Transient;

/**
 * @author Guvala
 *
 */
@Entity
@Table(name="datahub.srccolumnerrorInfo")
public class SrcColumnErrorInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
    @Column(name="ColId")
    private String columnId;
    
    @Column(name="SrcRecId")
    private String srcRecordId;
    
    @Column(name="ColName")
    private String columnName;
    
    @Column(name="ColValue")
    private String columnValue;
    
    @Column(name="ColType")
    private String columnType;
    
    @Column(name="ColIsKey")
    private Integer columnIsKey;
    
    @Column(name="ErrorValue")
    private String errorValue;
    
    @Transient
	private String task_Id;
    

    
    
	public String getTask_Id() {
		return task_Id;
	}

	public void setTask_Id(String task_Id) {
		this.task_Id = task_Id;
	}

	public String getColumnId() {
		return columnId;
	}

	public void setColumnId(String columnId) {
		this.columnId = columnId;
	}

	public String getSrcRecordId() {
		return srcRecordId;
	}

	public void setSrcRecordId(String srcRecordId) {
		this.srcRecordId = srcRecordId;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnValue() {
		return columnValue;
	}

	public void setColumnValue(String columnValue) {
		this.columnValue = columnValue;
	}

	public String getColumnType() {
		return columnType;
	}

	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

	public Integer getColumnIsKey() {
		return columnIsKey;
	}

	public void setColumnIsKey(Integer columnIsKey) {
		this.columnIsKey = columnIsKey;
	}

	public String getErrorValue() {
		return errorValue;
	}

	public void setErrorValue(String errorValue) {
		this.errorValue = errorValue;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((columnId == null) ? 0 : columnId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SrcColumnErrorInfo other = (SrcColumnErrorInfo) obj;
		if (columnId == null) {
			if (other.columnId != null)
				return false;
		} else if (!columnId.equals(other.columnId))
			return false;
		return true;
	}
    
        

}
