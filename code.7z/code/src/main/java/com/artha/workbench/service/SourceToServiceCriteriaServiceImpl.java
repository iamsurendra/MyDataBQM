package com.artha.workbench.service;


import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileTypeWebServiceDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.SourceToServiceCriteriaDAO;
import com.artha.workbench.dao.SourceToServiceCriteriaVwDAO;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.models.metastore.SourceToServiceCriteria;
import com.artha.workbench.models.metastore.SourceToServiceCriteriaKey;
import com.artha.workbench.models.metastore.SourceToServiceCriteriaVw;
import com.artha.workbench.models.metastore.SourceToServiceCriteriaVwKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("sourceToServiceCriteriaService")
public class SourceToServiceCriteriaServiceImpl implements SourceToServiceCriteriaService {

	@Autowired
	SourceToServiceCriteriaVwDAO sourceToServiceCriteriaVwDAO;
	
	@Autowired
	SourceToServiceCriteriaDAO sourceToServiceCriteriaDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;
	
	@Autowired
	EntityFileTypeWebServiceDAO entityFileTypeWebServiceDAO;
	
	
	
	@Transactional
	public List<SourceToServiceCriteriaVw> getSourceToServiceCriteriaVwList() {
		return sourceToServiceCriteriaVwDAO.findAll();
	}
	
	@Transactional
	public void create(SourceToServiceCriteriaVw sourceToServiceCriteriaVw) {
		SourceToServiceCriteria sourceToServiceCriteria = new SourceToServiceCriteria();
		SourceToServiceCriteriaKey sourceToServiceCriteriaKey = new SourceToServiceCriteriaKey();
		sourceToServiceCriteriaKey.setSourceEntityFileTypeID(sourceToServiceCriteriaVw.getSourceEntityFileTypeID());
		sourceToServiceCriteriaKey.setWebServiceID(sourceToServiceCriteriaVw.getWebServiceId());
		sourceToServiceCriteria.setSourceToServiceCriteriaKey(sourceToServiceCriteriaKey);
		loadSourceToServiceCriteria(sourceToServiceCriteria, sourceToServiceCriteriaVw);
		sourceToServiceCriteriaDAO.create(sourceToServiceCriteria);
	}
	@Transactional
	public SourceToServiceCriteria loadSourceToServiceCriteria(SourceToServiceCriteria sourceToServiceCriteria, SourceToServiceCriteriaVw sourceToServiceCriteriaVw) {
		sourceToServiceCriteria.setCriteria(sourceToServiceCriteriaVw.getCriteria());
		sourceToServiceCriteria.setActive(sourceToServiceCriteriaVw.getActive());
		sourceToServiceCriteria.setEffectiveDate(sourceToServiceCriteriaVw.getEffectiveDate());
		sourceToServiceCriteria.setReleaseNum(sourceToServiceCriteriaVw.getReleaseNum());
		sourceToServiceCriteria.setSeqOrder(sourceToServiceCriteriaVw.getSeqOrder());
	return 	sourceToServiceCriteria;

	}
	
	
	@Transactional
	public void update(SourceToServiceCriteriaVw sourceToServiceCriteriaVw, boolean isReleaseChanged) throws JsonProcessingException {
		SourceToServiceCriteriaKey sourceToServiceCriteriaKey = new SourceToServiceCriteriaKey();
		sourceToServiceCriteriaKey.setSourceEntityFileTypeID(sourceToServiceCriteriaVw.getSourceEntityFileTypeID());
		sourceToServiceCriteriaKey.setWebServiceID(sourceToServiceCriteriaVw.getWebServiceId());
		checkForCyclicDependency(sourceToServiceCriteriaVw);
		SourceToServiceCriteria sourceToServiceCriteria = sourceToServiceCriteriaDAO.findOne(sourceToServiceCriteriaKey);
		
		if (isReleaseChanged) {
			SourceToServiceCriteriaVwKey sourceToServiceCriteriaVwKey = new SourceToServiceCriteriaVwKey();
			sourceToServiceCriteriaVwKey.setSourceEntityFileTypeID(sourceToServiceCriteriaVw.getSourceEntityFileTypeID());
			sourceToServiceCriteriaVwKey.setEntityName(sourceToServiceCriteriaVw.getEntityName());
			sourceToServiceCriteriaVwKey.setFileMask(sourceToServiceCriteriaVw.getFileMask());
			sourceToServiceCriteriaVwKey.setHsFileType(sourceToServiceCriteriaVw.getHsFileType());
			sourceToServiceCriteriaVwKey.setWebServiceID(sourceToServiceCriteriaVw.getWebServiceId());
			SourceToServiceCriteriaVw oldEntity = sourceToServiceCriteriaVwDAO.findOne(sourceToServiceCriteriaVwKey);
			if(oldEntity!=null){
		    ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			
			releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNum());
			releaseArchiveKey.setReleaseId(sourceToServiceCriteriaVw.getReleaseNum());
			releaseArchiveKey.setTableName("SOURCETOSERVICECRITERIA");
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(sourceToServiceCriteria.getSourceToServiceCriteriaKey()));
			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if(releaseArchive!=null){
				releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToServiceCriteria));
				releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToServiceCriteriaVwKey));
				releaseArchiveDAO.update(releaseArchive);
			}else{
				releaseArchive = new ReleaseArchive();
				releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToServiceCriteria));
				releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToServiceCriteriaVwKey));
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchiveDAO.create(releaseArchive);
			}
			}
		}
		if (sourceToServiceCriteria != null) {
			sourceToServiceCriteria.setActive(sourceToServiceCriteriaVw.getActive());
			sourceToServiceCriteria.setEffectiveDate(sourceToServiceCriteriaVw.getEffectiveDate());
			sourceToServiceCriteria.setReleaseNum(sourceToServiceCriteriaVw.getReleaseNum());
			sourceToServiceCriteria.setCriteria(sourceToServiceCriteriaVw.getCriteria());
			sourceToServiceCriteria.setSeqOrder(sourceToServiceCriteriaVw.getSeqOrder());
			sourceToServiceCriteriaDAO.update(sourceToServiceCriteria);
		}
	}
	
	private void checkForCyclicDependency(SourceToServiceCriteriaVw sourceToServiceCriteriaVw) throws JsonProcessingException	{
		SourceToServiceCriteriaKey sourceToServiceCriteriaKey = new SourceToServiceCriteriaKey();
		sourceToServiceCriteriaKey.setSourceEntityFileTypeID(sourceToServiceCriteriaVw.getSourceEntityFileTypeID());
		sourceToServiceCriteriaKey.setWebServiceID(sourceToServiceCriteriaVw.getWebServiceId());
		String jsonId = AppWebUtils.convertObjectToJson(sourceToServiceCriteriaKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(sourceToServiceCriteriaVw.getReleaseNum(), "SOURCETOSERVICECRITERIA", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	@Transactional
	public SourceToServiceCriteriaVw getPreviousSourceToServiceCriteriaVw(SourceToServiceCriteriaVw sourceToServiceCriteriaVw) throws IOException {
		SourceToServiceCriteriaKey sourceToServiceCriteriaKey = new SourceToServiceCriteriaKey();
		sourceToServiceCriteriaKey.setWebServiceID(sourceToServiceCriteriaVw.getWebServiceId());
		sourceToServiceCriteriaKey.setSourceEntityFileTypeID(sourceToServiceCriteriaVw.getSourceEntityFileTypeID());
		String sourceToServiceCriteriaVwJson = AppWebUtils.convertObjectToJson(sourceToServiceCriteriaKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(sourceToServiceCriteriaVw.getReleaseNum(), "SOURCETOSERVICECRITERIA", sourceToServiceCriteriaVwJson);
		SourceToServiceCriteriaVw PreviousSourceToServiceCriteriaVw = new SourceToServiceCriteriaVw();
		if(releaseArchive!=null){
			PreviousSourceToServiceCriteriaVw = AppWebUtils.convertJsonToObject(SourceToServiceCriteriaVw.class, releaseArchive.getViewRecData());
		}
		return PreviousSourceToServiceCriteriaVw;
	}

	@Transactional
	public List<SourceToServiceCriteriaVw> getSourceToServiceCriteriaVwListByReleaseNo(Integer releaseNo) {
		return sourceToServiceCriteriaVwDAO.geSourceToServiceCriteriaListByReleaseNo(releaseNo);
	}
	
	
	@Transactional
	public List<SourceToServiceCriteria> getSourceToServiceCriteriaListByReleaseNo(Integer releaseNo) {
		return sourceToServiceCriteriaDAO.getSourceToServiceCriteriaListByReleaseNo(releaseNo);
	}
	
	@Transactional
	public SourceToServiceCriteria getSourceToServiceCriteria(SourceToServiceCriteriaVw sourceToServiceCriteriaVw) {
		SourceToServiceCriteriaKey sourceToServiceCriteriaKey = new SourceToServiceCriteriaKey();
		sourceToServiceCriteriaKey.setSourceEntityFileTypeID(sourceToServiceCriteriaVw.getSourceEntityFileTypeID());
		sourceToServiceCriteriaKey.setWebServiceID(sourceToServiceCriteriaVw.getWebServiceId());
		SourceToServiceCriteria sourceToServiceCriteria = sourceToServiceCriteriaDAO.findOne(sourceToServiceCriteriaKey);
		return sourceToServiceCriteria;
	}
}


