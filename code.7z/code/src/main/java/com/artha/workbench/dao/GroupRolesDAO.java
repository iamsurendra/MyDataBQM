package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.GroupRoles;
import com.guvvala.framework.dao.BaseDAO;

public interface GroupRolesDAO extends BaseDAO<GroupRoles, Long> {

	List<Integer> getGroupRoles(Integer groupId);
	
	List<GroupRoles> getGroupRolesList(Integer groupId);
}
