package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.RoleFunctions;
import com.artha.workbench.models.userConfig.RoleFunctionsPK;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */ 
@Repository
public class RoleFunctionsDAOImpl extends BaseDAOImpl<RoleFunctions, RoleFunctionsPK> implements RoleFunctionsDAO {

	public RoleFunctionsDAOImpl() {
		super(RoleFunctions.class);
	}
	
	

@Override
public List<RoleFunctions> getRoleFunctionsById(Integer roleId) {
	TypedQuery<RoleFunctions> query = entityManager.createQuery("from RoleFunctions where ROLE_ID = :roleID",
			RoleFunctions.class);
	query.setParameter("roleID", roleId);
	return query.getResultList();
}

public List<RoleFunctions> getRoleFunctionsById(List<Integer> roleIds) {
	CriteriaBuilder cb = entityManager.getCriteriaBuilder();
	CriteriaQuery<RoleFunctions> query = cb.createQuery(RoleFunctions.class);
	Root<RoleFunctions> root = query.from(RoleFunctions.class);
	query.where(root.get("id").get("roleID").in(roleIds));
	return this.entityManager.createQuery(query).getResultList();
}
}
