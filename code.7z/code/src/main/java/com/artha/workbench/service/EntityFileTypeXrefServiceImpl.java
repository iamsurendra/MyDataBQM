package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileRuleXrefDAO;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.EntityFileTypeXrefVwDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.ThreadPoolTypeDAO;
import com.artha.workbench.models.metastore.EntityFileTypeXref;
import com.artha.workbench.models.metastore.EntityFileTypeXrefId;
import com.artha.workbench.models.metastore.EntityFileTypeXrefVw;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;
import com.guvvala.framework.util.StringUtils;

@Service("entityFileTypeXrefService")
public class EntityFileTypeXrefServiceImpl implements EntityFileTypeXrefService {

	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefdbDAO;
	@Autowired
	EntityFileTypeXrefVwDAO entityFileTypeXrefVwDAO;

	@Autowired
	EntityMasterService entityMasterService;

	@Autowired
	FileTypeService fileTypeService;

	@Autowired
	FileFormatService fleFormatService;

	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Autowired
	ThreadPoolTypeDAO threadPoolTypeDAO;

	@Transactional(readOnly = true)
	public List<EntityFileTypeXref> getEntityFileTypeXrefList() {
		return entityFileTypeXrefdbDAO.findAll();
	}

	@Transactional(readOnly = true)
	@Override
	public List<EntityFileTypeXrefVw> getEntityFileTypeXrefVwList(Integer releaseNo) {
		return entityFileTypeXrefVwDAO.getEntityFileTypeXrefVwList(releaseNo);
	}

	@Transactional(readOnly = true)
	@Override
	public EntityFileTypeXrefVw getPreviousEntityFileTypeXrefVw(EntityFileTypeXrefVw entityFileTypeXrefVw)
			throws IOException {
		EntityFileTypeXrefId entityFileTypeXrefId = new EntityFileTypeXrefId();
		entityFileTypeXrefId.setEntityFileTypeID(entityFileTypeXrefVw.getEntityFileTypeID());
		String entityFileTypeXrefIdJson = AppWebUtils.convertObjectToJson(entityFileTypeXrefId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(entityFileTypeXrefVw.getReleaseNo(),
				"ENTITYFILETYPEXREF", entityFileTypeXrefIdJson);
		EntityFileTypeXrefVw previousEntityFileTypeXrefVw = new EntityFileTypeXrefVw();
		if (releaseArchive != null) {
			previousEntityFileTypeXrefVw = AppWebUtils.convertJsonToObject(EntityFileTypeXrefVw.class,
					releaseArchive.getViewRecData());
		}
		return previousEntityFileTypeXrefVw;

	}

	@Transactional
	public void create(EntityFileTypeXrefVw entityFileTypeXrefVW) {
		EntityFileTypeXref entityFileTypeXref = new EntityFileTypeXref();
		entityFileTypeXref.setEntityFileTypeID(getMaxEntityFileTypeID() + 1);
		loadEntityFileTypeXref(entityFileTypeXref, entityFileTypeXrefVW);
		entityFileTypeXrefdbDAO.create(entityFileTypeXref);
	}

	@Transactional
	public void update(EntityFileTypeXrefVw entityFileTypeXrefVW, boolean isReleaseChanged)
			throws JsonProcessingException {
		EntityFileTypeXref entityFileTypeXref = entityFileTypeXrefdbDAO
				.findOne(entityFileTypeXrefVW.getEntityFileTypeID());
		checkForCyclicDependency(entityFileTypeXrefVW);
		if (isReleaseChanged) {
			EntityFileTypeXrefVw oldViewEntity = entityFileTypeXrefVwDAO
					.findOne(entityFileTypeXrefVW.getEntityFileTypeID());
			if (oldViewEntity != null) {
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldViewEntity.getReleaseNo());
				releaseArchiveKey.setReleaseId(entityFileTypeXrefVW.getReleaseNo());
				releaseArchiveKey.setTableName("EntityFileTypeXref");
				EntityFileTypeXrefId entityFileTypeXrefId = new EntityFileTypeXrefId();
				entityFileTypeXrefId.setEntityFileTypeID(entityFileTypeXrefVW.getEntityFileTypeID());
				releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityFileTypeXrefId));
				ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
				if (releaseArchive != null) {
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldViewEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileTypeXref));
					releaseArchiveDAO.update(releaseArchive);
				} else {
					releaseArchive = new ReleaseArchive();
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldViewEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileTypeXref));
					releaseArchiveDAO.create(releaseArchive);
				}
			}
		}

		if (entityFileTypeXref != null) {
			loadEntityFileTypeXref(entityFileTypeXref, entityFileTypeXrefVW);
			entityFileTypeXrefdbDAO.update(entityFileTypeXref);
		}
	}

	private void checkForCyclicDependency(EntityFileTypeXrefVw entityFileTypeXrefVW) throws JsonProcessingException {

		EntityFileTypeXrefId entityFileTypeXrefId = new EntityFileTypeXrefId();
		entityFileTypeXrefId.setEntityFileTypeID(entityFileTypeXrefVW.getEntityFileTypeID());
		String jsonId = AppWebUtils.convertObjectToJson(entityFileTypeXrefId);
		ReleaseArchive releaseArchive = releaseArchiveDAO
				.getReleaseArchiveByArchiveId(entityFileTypeXrefVW.getReleaseNo(), "EntityFileTypeXref", jsonId);
		if (releaseArchive != null) {
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	@Transactional(readOnly = true)
	public List<EntityFileTypeXrefVw> getEntityFileTypeXrefVwList() {
		return entityFileTypeXrefVwDAO.findAll();
	}

	@Transactional
	public EntityFileTypeXref loadEntityFileTypeXref(EntityFileTypeXref entityFileTypeXref,
			EntityFileTypeXrefVw entityFileTypeXrefVW) {
		entityFileTypeXref.setEntityID(entityFileTypeXrefVW.getEntityID());
		entityFileTypeXref.setFileTypeID(entityFileTypeXrefVW.getFileTypeID());
		entityFileTypeXref.setFileFormatID(entityFileTypeXrefVW.getFileFormatID());
		entityFileTypeXref.setFilePath(entityFileTypeXrefVW.getFilePath());
		entityFileTypeXref.setFileMask(entityFileTypeXrefVW.getFileMask());
		entityFileTypeXref.setRecDelimiter(entityFileTypeXrefVW.getRecDelimiter());
		entityFileTypeXref.setColumnsDelimiter(entityFileTypeXrefVW.getColumnsDelimiter());
		entityFileTypeXref.setColumnsCount(entityFileTypeXrefVW.getColumnsCount());
		entityFileTypeXref.setMaxRecLen(entityFileTypeXrefVW.getMaxRecLen());
		entityFileTypeXref.setAllowExtraColumns(entityFileTypeXrefVW.getAllowExtraColumns());
		entityFileTypeXref.setNotifyRetyCount(entityFileTypeXrefVW.getNotifyRetyCount());
		entityFileTypeXref.setOutboundOrder(entityFileTypeXrefVW.getOutboundOrder() != null
				? entityFileTypeXrefVW.getOutboundOrder().toString() : null);
		entityFileTypeXref.setActive(entityFileTypeXrefVW.getActive());
		entityFileTypeXref.setEffectiveDate(entityFileTypeXrefVW.getEffectiveDate());
		entityFileTypeXref.setPoolID(entityFileTypeXrefVW.getPoolID());
		entityFileTypeXref.setColumnsWidth(entityFileTypeXrefVW.getColumnsWidth());
		if (StringUtils.isEmpty(entityFileTypeXrefVW.getDupFileCheck())) {
			entityFileTypeXref.setDupFileCheck("N");
		} else {
			entityFileTypeXref.setDupFileCheck(entityFileTypeXrefVW.getDupFileCheck());
		}
		entityFileTypeXref.setColumnsPattern(entityFileTypeXrefVW.getColumnsPattern());
		if (StringUtils.isEmpty(entityFileTypeXrefVW.getNoDataRecordPattern())) {
			entityFileTypeXref.setNoDataRecordPattern(":NoData:");
		} else {
			entityFileTypeXref.setNoDataRecordPattern(entityFileTypeXrefVW.getNoDataRecordPattern());
		}
		if (StringUtils.isEmpty(entityFileTypeXrefVW.getNoRecordDelimiter())) {
			entityFileTypeXref.setNoRecordDelimiter("N");
		} else {
			entityFileTypeXref.setNoRecordDelimiter(entityFileTypeXrefVW.getNoRecordDelimiter());
		}
		entityFileTypeXref.setOutBoundFilter(entityFileTypeXrefVW.getOutBoundFilter());
		entityFileTypeXref.setSheetName(entityFileTypeXrefVW.getSheetName());
		entityFileTypeXref.setIgnoreHeaderRowCount(entityFileTypeXrefVW.getIgnoreHeaderRowCount());
		entityFileTypeXref.setIgnoreFooterRowCount(entityFileTypeXrefVW.getIgnoreFooterRowCount());
		entityFileTypeXref.setFirstColumn(entityFileTypeXrefVW.getFirstColumn());
		entityFileTypeXref.setLastColumn(entityFileTypeXrefVW.getLastColumn());
		if (StringUtils.isEmpty(entityFileTypeXrefVW.getAllowBlankRows())) {
			entityFileTypeXref.setAllowBlankRows("N");
		} else {
			entityFileTypeXref.setAllowBlankRows(entityFileTypeXrefVW.getAllowBlankRows());
		}
		entityFileTypeXref.seteOFDelimiter(entityFileTypeXrefVW.geteOFDelimiter());
		entityFileTypeXref.setReleaseNo(entityFileTypeXrefVW.getReleaseNo());
		entityFileTypeXref.setXsd(entityFileTypeXrefVW.getXsd());
		entityFileTypeXref.setXmlLoop(entityFileTypeXrefVW.getXmlLoop());
		entityFileTypeXref.setPrettify(entityFileTypeXrefVW.getPrettify());

		return entityFileTypeXref;
	}

	@Transactional
	public HashMap<String, Integer> loadentityFileTypeID() {
		return entityFileTypeXrefdbDAO.loadentityFileTypeID();
	}

	@Transactional
	public HashMap<Integer, String> loadEntityFileTypeID() {
		return entityFileTypeXrefdbDAO.loadEntityFileTypeID();
	}

	@Transactional
	public int getMaxEntityFileTypeID() {
		return entityFileTypeXrefdbDAO.getMaxEntityFileTypeID();
	}

	@Transactional
	public EntityFileTypeXref getEntityFileTypeXref(Integer entityFileTypeId) {
		return entityFileTypeXrefdbDAO.findOne(entityFileTypeId);
	}

	@Transactional
	public List<EntityFileTypeXref> getEntityFileTypeXrefListByReleaseNo(Integer releaseNo) {
		return entityFileTypeXrefdbDAO.getEntityFileTypeXrefListByReleaseNo(releaseNo);
	}

	@Override
	public EntityFileTypeXref findOne(Integer id) {
		// TODO Auto-generated method stub
		return entityFileTypeXrefdbDAO.findOne(id);
	}

	@Override
	@Transactional(readOnly = true)
	public long getEntityFileTypeXrefDataCount() {
		return entityFileTypeXrefdbDAO.count();

	}

	@Transactional(readOnly = true)
	public List<Integer> getEntityTypeXrefReleaseNumbers(Set<Integer> entityFileTypeIds,
			Integer selectedReleaseNumber) {
		return entityFileTypeXrefdbDAO.getEntityTypeXrefReleaseNumbers(entityFileTypeIds, selectedReleaseNumber);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Integer> getAllEntityFileTypeXrefReleaseIds(Integer selectedReleaseId) {
		return entityFileTypeXrefdbDAO.getAllEntityFileTypeXrefReleaseIds(selectedReleaseId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<EntityFileTypeXref> getEntityTypeXrefList(Set<Integer> entityFileTypeIds,
			Integer selectedReleaseNumber) {
		return entityFileTypeXrefdbDAO.getEntityTypeXrefList(entityFileTypeIds, selectedReleaseNumber);
	}

	@Transactional
	public List<Integer> getpoolIds() {
		return threadPoolTypeDAO.getPoolIds();

	}

}
