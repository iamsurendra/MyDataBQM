package com.artha.workbench.models.userConfig;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.guvvala.framework.util.ThreadLocalUtil;

@Entity
@Table(name = "rolefunctions")

public class RoleFunctions implements Serializable {

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RoleFunctionsPK id;

	@Column(name = "WRITE_MODE")
	private Integer writeMode;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	@Column(name = "LAST_UPD_BY")
	private String updatedBy;

	@Column(name = "LAST_UPD_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedDate;

	public RoleFunctions() {
		super();
	}
	@Transient
	@Column(name = "ROLE_ID")
	private Integer ROLE_ID;
	
	@Transient
	@Column(name = "FUNCTION_ID")
	private Integer FUNCTION_ID;
	

	public Integer getFUNCTION_ID() {
		return FUNCTION_ID;
	}

	public void setFUNCTION_ID(Integer fUNCTION_ID) {
		FUNCTION_ID = fUNCTION_ID;
	}

	public Integer getROLE_ID() {
		return ROLE_ID;
	}

	public void setROLE_ID(Integer rOLE_ID) {
		ROLE_ID = rOLE_ID;
	}

	public RoleFunctions(Integer roleID, Integer functionID) {
		super();
		this.id = new RoleFunctionsPK(roleID, functionID);
	}

	public RoleFunctionsPK getId() {
		return id;
	}

	public void setId(RoleFunctionsPK id) {
		this.id = id;
	}

	public Integer getWriteMode() {
		return writeMode;
	}

	public void setWriteMode(Integer writeMode) {
		this.writeMode = writeMode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoleFunctions other = (RoleFunctions) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	@PrePersist
	public void prePresist() {
		setCreatedBy(ThreadLocalUtil.getUserName());
		setUpdatedBy(ThreadLocalUtil.getUserName());
		setCreatedDate(new Date());
		setUpdatedDate(new Date());
	}
}
