package com.artha.workbench.service;

import java.io.BufferedInputStream;
import java.util.List;

import org.springframework.stereotype.Service;

import com.artha.workbench.models.metastore.AbstractModel;

@Service("excelFileReaderService")
public class ExcelFileReaderService {
	
	public List<AbstractModel> readDataFromExcelFile(String fileIdentifier, BufferedInputStream fis) throws Exception{
		//TODO need to uncomment.
	/*	try {
		//Call the read method with the corresponding DAO  
			AbstractExcelFileDAO dao = ExcelFileDAOFactory.getExcelFileReaderDAO(fileIdentifier);
			
			if ( dao == null ) {
				
				throw new FileFormatNotSupportedException("The Excel File format is not yet supported for the table :" + fileIdentifier);
				
			} else {
				
				return dao.readDataFromExcelFile(fis);
			}
		} catch(FileDataException e){
			throw e;
		}*/
		return null;
	}

}