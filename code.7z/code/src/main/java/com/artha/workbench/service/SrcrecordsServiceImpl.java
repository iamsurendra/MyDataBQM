package com.artha.workbench.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.SrcrecordsDAO;

@Service("srcrecordsService")
public class SrcrecordsServiceImpl implements SrcrecordsService {

	@Autowired
	SrcrecordsDAO srcrecordsDAO;

	@Transactional
	public String getSrcrecid(String taskid) {
		return srcrecordsDAO.getSrcrecid(taskid);
	}
	
	
}