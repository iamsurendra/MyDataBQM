package com.artha.workbench.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class VersionServiceImpl implements VersionService {

	 public List<Integer> getEntityTypeVersionDetails(String osname) {		
			List<Integer> auditdet = new ArrayList<Integer>();
			File file = null;
			 file = new File("c:\\downloadfiles\\EntityType\\all\\");
			if (!file.exists()) {
				file.mkdirs();
			}
			int count = file.listFiles().length;
			   if(count>0)
			   {
		        for(int i=1;i<=count;i++)
		        {
		        	auditdet.add(i);
		        }
			   }
			    
	        
	        return auditdet;
	    }
	    public List<Integer> getefrcVlistDetails(String osname) {		
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	         file = new File("c:\\downloadfiles\\EntityFileRecColumn\\all\\");
			if (!file.exists()) {
				file.mkdirs();
			}
			int count = file.listFiles().length;
				if(count>0)
				{
		        for(int i=1;i<=count;i++)
		        {
		        	auditdet.add(i);
		        }
				}
	        return auditdet;
	    }
	    public List<Integer> geteftsxVlistDetails(String osname) {	
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	 file = new File("c:\\downloadfiles\\EntityFileTypeScheduleXref\\all\\");
			if (!file.exists()) {
				file.mkdirs();
			}
			int count = file.listFiles().length;
			if(count>0)
			{
	 	        for(int i=1;i<=count;i++)
	 	        {
	 	        	auditdet.add(i);
	 	        }
			}
	         return auditdet;
	    }
	    public List<Integer> geteftxVlistDetails(String osname) {		
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	 file = new File("c:\\downloadfiles\\EntityFileTypeXref\\all\\");
			if (!file.exists()) {
				file.mkdirs();
			}
			int count = file.listFiles().length;
			if(count>0)
			{
	  	        for(int i=1;i<=count;i++)
	  	        {
	  	        	auditdet.add(i);
	  	        }
			}
	          return auditdet;
	    }
	    public List<Integer> getemVlistDetails(String osname) {	
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	 file = new File("c:\\downloadfiles\\EntityMaster\\all\\");
			if (!file.exists()) {
				file.mkdirs();
			}
			int count = file.listFiles().length;
			if(count>0)
			{
	   	        for(int i=1;i<=count;i++)
	   	        {
	   	        	auditdet.add(i);
	   	        }
			}
	           return auditdet;
	    }
	    public List<Integer> getffVlistDetails(String osname) {	
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	  file = new File("c:\\downloadfiles\\FileFormat\\all\\");
				if (!file.exists()) {
					file.mkdirs();
				}
				int count = file.listFiles().length;
				if(count>0)
				   {
	    	        for(int i=1;i<=count;i++)
	    	        {
	    	        	auditdet.add(i);
	    	        }
				  }
	            return auditdet;
	    }
	    public List<Integer> getfvsxVlistDetails(String osname) {		
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	  file = new File("c:\\downloadfiles\\FileValStepXref\\all\\");
				if (!file.exists()) {
					file.mkdirs();
				}
				int count = file.listFiles().length;
				if(count>0)
				{
	 	        for(int i=1;i<=count;i++)
	 	        {
	 	        	auditdet.add(i);
	 	        }
				}
	         return auditdet;
	    }
	    public List<Integer> gethfVlistDetails(String osname) {		
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	  file = new File("c:\\downloadfiles\\HeaderFooter\\all\\");
				if (!file.exists()) {
					file.mkdirs();
				}
				int count = file.listFiles().length;
				if(count>0)
				{
	  	        for(int i=1;i<=count;i++)
	  	        {
	  	        	auditdet.add(i);
	  	        }
				}
	          return auditdet;
	    }
	    public List<Integer> gethfcVlistDetails(String osname) {	
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	  file = new File("c:\\downloadfiles\\HeaderFooterCols\\all\\");
	 		if (!file.exists()) {
	 			file.mkdirs();
	 		}
	 		int count = file.listFiles().length;
	 		if(count>0)
			{
	   	        for(int i=1;i<=count;i++)
	   	        {
	   	        	auditdet.add(i);
	   	        }
			}
	           return auditdet;
	    }
	    
	    public List<Integer> gethftVlistDetails(String osname) {		
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	  file = new File("c:\\downloadfiles\\HSFileType\\all\\");
	  		if (!file.exists()) {
	  			file.mkdirs();
	  		}
	  		int count = file.listFiles().length;
	  		if(count>0)
			{
	    	        for(int i=1;i<=count;i++)
	    	        {
	    	        	auditdet.add(i);
	    	        }
			}
	            return auditdet;
	    }
	    public List<Integer> getrtVlistDetails(String osname) {	
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	  file = new File("c:\\downloadfiles\\RuleType\\all\\");
	   		if (!file.exists()) {
	   			file.mkdirs();
	   		}
	   		int count = file.listFiles().length;
	   		if(count>0)
			{
	 	        for(int i=1;i<=count;i++)
	 	        {
	 	        	auditdet.add(i);
	 	        }
			}
	         return auditdet;
	    }
	    public List<Integer> getsttmVlistDetails(String osname) {	
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	  file = new File("c:\\downloadfiles\\SourceToTargetMapping\\all\\");
	    		if (!file.exists()) {
	    			file.mkdirs();
	    		}
	    		int count = file.listFiles().length;
	    		if(count>0)
				{
	  	        for(int i=1;i<=count;i++)
	  	        {
	  	        	auditdet.add(i);
	  	        }
				}
	          return auditdet;
	    }
	    public List<Integer> getvrVlistDetails(String osname) {	
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
	    	  file = new File("c:\\downloadfiles\\EntityFileValidationRule\\all\\");
	 		if (!file.exists()) {
	 			file.mkdirs();
	 		}
	 		int count = file.listFiles().length;
	 		if(count>0)
			{
	 		for(int i=1;i<=count;i++)
	   	        {
	   	        	auditdet.add(i);
	   	        }
			}
	           return auditdet;
	    }
	    public List<Integer> getvsVlistDetails(String osname) {		
	    	List<Integer> auditdet = new ArrayList<Integer>();
	    	File file = null;
				  file = new File("c:\\downloadfiles\\ValidationStep\\all\\");
				if (!file.exists()) {
					file.mkdirs();
				}
				int count = file.listFiles().length;
				if(count>0)
				{
	    	        for(int i=1;i<=count;i++)
	    	        {
	    	        	auditdet.add(i);
	    	        }
				}
	            return auditdet;
	    }
}
