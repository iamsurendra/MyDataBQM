package com.artha.workbench.models.datahub;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Guvvala
 *
 */
@Entity
@Table(name="datahub.StatusHistory")
public class StatusHistory implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="StatHistID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long statHistId;
	
	@Column(name="FileID")
	private Long fileId;
	
	@Column(name="RecordID")
	private Long recordId;
	
	@Column(name="Status")
	private String status;
	
	@Column(name="SeqID")
	private Long seqId;
	
	@Column(name="FailedRuleID")
	private Long failedRuleId;
	
	@Column(name = "EventMoment")
	private Date eventMoment;
	
	
	public StatusHistory(){
		
	}

	public StatusHistory(Long fileId, Long recordId,Long seqId,String status,Date eventMoment) {
		this.fileId = fileId;
		this.recordId = recordId;
		this.status = status;
		this.seqId = seqId;
		this.eventMoment = eventMoment;
	}

	public Long getStatHistId() {
		return statHistId;
	}

	public void setStatHistId(Long statHistId) {
		this.statHistId = statHistId;
	}

	public Long getFileId() {
		return fileId;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public Long getRecordId() {
		return recordId;
	}

	public void setRecordId(Long recordId) {
		this.recordId = recordId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getSeqId() {
		return seqId;
	}

	public void setSeqId(Long seqId) {
		this.seqId = seqId;
	}

	public Long getFailedRuleId() {
		return failedRuleId;
	}

	public void setFailedRuleId(Long failedRuleId) {
		this.failedRuleId = failedRuleId;
	}

	public Date getEventMoment() {
		return eventMoment;
	}

	public void setEventMoment(Date eventMoment) {
		this.eventMoment = eventMoment;
	}
	
	
	
	
}
	
	

