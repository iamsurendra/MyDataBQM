package com.artha.workbench.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.constant.TaskStatus;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.service.TaskService;
import com.artha.workbench.to.ChartQueryTO;
import com.guvvala.framework.util.ThreadLocalUtil;

@RestController
@RequestMapping("/api/home")
public class HomeController {

	@Autowired
	TaskService taskService;

	@RequestMapping(value = "/chart", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Long> loadChartInfo() {
		List<Task> taskList = new ArrayList<>();
		Map<String, Long> chartMap = new HashMap<>();
		if (ThreadLocalUtil.getUser().isSadmin() || ThreadLocalUtil.getUser().isAdmin()) {
			taskList = taskService.getTaskList();
		} else {
			taskList = taskService.getTaskByAccessRight(ThreadLocalUtil.getUser().getTaskAccessRights());
		}
		Long newtasklength = 0l;
		Long resolvedtasklength = 0l;
		Long pendinglength = 0l;
		Long lockedlength = 0l;
		for (Task task : taskList) {
			if (task.getStatus().equalsIgnoreCase(TaskStatus.NEW.value))
				newtasklength++;
			else if (task.getStatus().equalsIgnoreCase(TaskStatus.RESOLVED.value))
				resolvedtasklength++;
			else if (task.getStatus().equalsIgnoreCase(TaskStatus.PENDING.value))
				pendinglength++;
			else if (task.getStatus().equalsIgnoreCase(TaskStatus.LOCKED.value))
				lockedlength++;
		}
		chartMap.put("New", newtasklength);
		chartMap.put("Resolved", resolvedtasklength);
		chartMap.put("Pending", pendinglength);
		chartMap.put("Locked", lockedlength);
		return chartMap;
	}

	// reports
	@RequestMapping(value = "/reportCharts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ChartQueryTO> getDashboardCountForAdmin() {
		return taskService.getDashboardCountForAdmin();

	}
}
