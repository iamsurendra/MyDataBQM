package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.TableList;
import com.guvvala.framework.dao.BaseDAO;


public interface TableListDAO extends BaseDAO<TableList, Integer> {
	public List<TableList> getTablelist(String statusFlag);
	public List<TableList> getUploadList() ;
	public String getDescription(String tablename);
}
