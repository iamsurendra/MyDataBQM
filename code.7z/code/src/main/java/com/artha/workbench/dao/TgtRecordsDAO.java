package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.datahub.TgtRecords;
import com.guvvala.framework.dao.BaseDAO;

public interface TgtRecordsDAO extends BaseDAO<TgtRecords, String> {

	public void updatetgtrecords(String taskid,String userName);

	public List<String> findTgtRecordsByTaskId(List<String> taskIds);

	public void deleteAllTgtRecords(List<String> taskIds);

	public void removeResolvedStatus(String taskId);
	
	TgtRecords getTgtRecordsObjByTaskId(String taskid);

}
