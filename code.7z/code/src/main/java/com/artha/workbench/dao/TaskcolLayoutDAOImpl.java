package com.artha.workbench.dao;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.datahub.TaskcolLayout;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * @author Guvala
 *
 */
@Repository
public class TaskcolLayoutDAOImpl extends BaseDAOImpl<TaskcolLayout, String> implements TaskcolLayoutDAO {

	public TaskcolLayoutDAOImpl() {
		super(TaskcolLayout.class);
	}
	
	public List<TaskcolLayout> getTaskcolLayoutData(String tarrecid) {
		List<TaskcolLayout> taskColLayoutList = new LinkedList<TaskcolLayout>();
		Query query = entityManager.createQuery("select col from TaskcolLayout col, TaskLayout lay "+
          "where col.layoutId=lay.layoutId and lay.taskId = :tarRecId order by col.sequenceNo ASC");
		query.setParameter("tarRecId", tarrecid);
		
		taskColLayoutList = (List<TaskcolLayout>)query.getResultList();
		return taskColLayoutList;
	}

}
