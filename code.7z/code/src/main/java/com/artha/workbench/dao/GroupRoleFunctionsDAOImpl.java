package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.GroupRoleFunctionsPK;
import com.artha.workbench.models.userConfig.GroupRoleFunctionsVW;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class GroupRoleFunctionsDAOImpl extends BaseDAOImpl<GroupRoleFunctionsVW, GroupRoleFunctionsPK>
		implements GroupRoleFunctionsDAO {

	public GroupRoleFunctionsDAOImpl() {
		super(GroupRoleFunctionsVW.class);
	}

	public List<GroupRoleFunctionsVW> findbyGroupID(Integer groupId) {
		TypedQuery<GroupRoleFunctionsVW> query = entityManager
				.createQuery("from GroupRoleFunctionsVW where id.groupID=" + groupId, GroupRoleFunctionsVW.class);
		return query.getResultList();
	}

}
