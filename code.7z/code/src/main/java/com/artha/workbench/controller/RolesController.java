package com.artha.workbench.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.models.userConfig.FileTypeColumns;
import com.artha.workbench.models.userConfig.Hssecurityrole;
import com.artha.workbench.models.userConfig.HssecurityrolePK;
import com.artha.workbench.models.userConfig.PartnerFileTypes;
import com.artha.workbench.models.userConfig.Roles;
import com.artha.workbench.service.UserRolesService;
import com.artha.workbench.to.PartnerFileTypeColumnsTO;
import com.artha.workbench.to.RoleSummaryTO;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.ThreadLocalUtil;

@RestController
@RequestMapping("/api/roles")

public class RolesController {
	@Autowired
	private UserRolesService userRolesService;

	@RequestMapping(value = "/getAllRoles", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Roles> getAllRoles() {
		return userRolesService.getRolesList();
	}

	@RequestMapping(value = "/saveRole", method = RequestMethod.POST)
	public Roles saveUserRole(@RequestBody Roles role) {
		if (userRolesService.duplicateRoleName(role.getRoleName())) {
			throw new AppException(MessagesEnum.DUPLICATEROLENAME, role.getRoleName());
		} else {
			return userRolesService.saveUserRole(role);
		}
	}

	@RequestMapping(value = "/getPartners", method = RequestMethod.GET)
	public Map<String, List<PartnerFileTypes>> getPartners(@RequestParam("roleId") Long roleId) {
		Map<String, List<PartnerFileTypes>> partnersMap = new HashMap<>();
		List<PartnerFileTypes> allPartners = userRolesService.findAllPartner();
		List<PartnerFileTypes> selectedPartnersList = new ArrayList<>();
		List<Long> selPartnerIdList = userRolesService.findPartnerByRoleID(roleId);
		for (Long parnerId : selPartnerIdList) {
			for (PartnerFileTypes partnerFileType : allPartners) {
				if (parnerId.equals(partnerFileType.getEntityId())) {
					selectedPartnersList.add(partnerFileType);
					break;
				}
			}
		}
		sortSelectedPartners(selectedPartnersList);
		partnersMap.put("partnersList", allPartners);
		partnersMap.put("selectedPartnersList", selectedPartnersList);
		return partnersMap;
	}

	@RequestMapping(value = "/getSelectedFileTypes/{roleId}", method = RequestMethod.POST)
	public Map<Long, List<PartnerFileTypes>> getSelectedFileTypes(@PathVariable("roleId") Long roleId,
			@RequestBody List<Long> partnerIds) {
		Map<Long, List<PartnerFileTypes>> partnerFileTypesMap = new HashMap<>();
		for (Long partnerId : partnerIds) {
			List<PartnerFileTypes> selectedFileTypeList = new ArrayList<>();
			List<PartnerFileTypes> partnerFileTypeList = userRolesService.findAllFileTypes(partnerId);
			List<Long> selectedDBFileTypes = userRolesService.findFileTypeByPartnerIDRoleId(partnerId, roleId);
			if (!selectedDBFileTypes.isEmpty()) {
				for (Long fileTypeId : selectedDBFileTypes) {
					for (PartnerFileTypes fileType : partnerFileTypeList) {
						if (fileTypeId.equals(fileType.getEntityFileTypeId())) {
							selectedFileTypeList.add(fileType);
							break;
						}
					}
				}
			}
			partnerFileTypesMap.put(partnerId, selectedFileTypeList);
		}
		return partnerFileTypesMap;
	}

	@RequestMapping(value = "/getAllFileTypes", method = RequestMethod.GET)
	public List<PartnerFileTypes> getFileTypesByPartnerId(@RequestParam("partnerId") Long partnerId) {
		return userRolesService.findAllFileTypes(partnerId);
	}

	@RequestMapping(value = "/getPFColumns", method = RequestMethod.GET)
	public List<FileTypeColumns> getPFColumns(@RequestParam("roleId") Long roleId,
			@RequestParam("partnerFileTypeId") String partnerFileTypeId) {
		String[] pfIdArray = partnerFileTypeId.split("-");
		List<FileTypeColumns> fileTypeColumns = userRolesService
				.findColumnsByEntityFileTypeID(Long.parseLong(pfIdArray[1]));
		List<Hssecurityrole> hssRolesDB = new ArrayList<Hssecurityrole>();
		Roles role = userRolesService.findRoleById(roleId);
		if (role.isActive()) {
			hssRolesDB = userRolesService.findColumnsByPartnerIdFileTypeID(Long.parseLong(pfIdArray[0]),
					Long.parseLong(pfIdArray[1]), roleId);
		}
		if (!hssRolesDB.isEmpty()) {
			for (Hssecurityrole hsRole : hssRolesDB) {
				for (FileTypeColumns ftColumn : fileTypeColumns) {
					if (hsRole.getId().getColName().equalsIgnoreCase(ftColumn.getColName())) {
						ftColumn.setWriteMode(hsRole.isWriteMode());
						ftColumn.setReadMode(Boolean.TRUE);
						break;
					}
				}
			}
		}
		return fileTypeColumns;
	}

	/**
	 * To sort selected partners
	 */
	public void sortSelectedPartners(List<PartnerFileTypes> selectedPartnersList) {
		Collections.sort(selectedPartnersList, new Comparator<PartnerFileTypes>() {
			@Override
			public int compare(PartnerFileTypes p1, PartnerFileTypes p2) {
				return p1.getEntityName().compareToIgnoreCase(p2.getEntityName());
			}
		});
	}

	@RequestMapping(value = "/submitPFColumns/{roleId}", method = RequestMethod.POST)
	public void saveDate(@PathVariable("roleId") Long roleId,
			@RequestBody Map<String, List<FileTypeColumns>> pfColumnsMap) {
		List<Long> updPartnerIdsList = new ArrayList<>();
		List<Long> updFileTypeIdsList = new ArrayList<>();

		List<Long> partnerIdsList = new ArrayList<>();
		List<Long> fileTypeIdsList = new ArrayList<>();

		List<Hssecurityrole> hssRoles = new ArrayList<>();
		for (String pFTid : pfColumnsMap.keySet()) {
			String[] pftIds = pFTid.split("-");
			partnerIdsList.add(new Long(pftIds[0]));
			fileTypeIdsList.add(new Long(pftIds[1]));
			// TODO need to add set i
			if (pftIds.length == 3 && pftIds[1].equals("UPDATED")
					&& (pfColumnsMap.get(pFTid) == null || pfColumnsMap.get(pFTid).isEmpty())) {
				updPartnerIdsList.add(new Long(pftIds[0]));
				updFileTypeIdsList.add(new Long(pftIds[1]));
			}
			for (FileTypeColumns fileTypeColumn : pfColumnsMap.get(pFTid)) {
				updPartnerIdsList.add(new Long(pftIds[0]));
				updFileTypeIdsList.add(new Long(pftIds[1]));
				if (fileTypeColumn.isReadMode() || fileTypeColumn.isWriteMode()) {
					HssecurityrolePK id = new HssecurityrolePK();
					id.setRoleId(roleId);
					id.setColName(fileTypeColumn.getColName());
					id.setEntityFileTypeId(Long.parseLong(pftIds[1]));
					Hssecurityrole hss = new Hssecurityrole();
					hss.setId(id);
					hss.setWriteMode(fileTypeColumn.isWriteMode());
					hss.setFileId(fileTypeColumn.getFileTypeId());
					hss.setPartnerId(Long.parseLong(pftIds[0]));
					hss.setCreationDate(new Timestamp(new Date().getTime()));
					hss.setLastUpdatedDate(new Timestamp(new Date().getTime()));
					hss.setCreatedBy(ThreadLocalUtil.getUserName());
					hss.setLastUpdatedBy(ThreadLocalUtil.getUserName());
					hssRoles.add(hss);
				}
			}
		}
		if (!userRolesService.userRolesExists(partnerIdsList, fileTypeIdsList, roleId) && hssRoles.isEmpty()) {
			throw new AppException(MessagesEnum.ATLEAST_ONE_COLUMN_REQUIRED);
		}
		userRolesService.submitUserRoles(hssRoles, updPartnerIdsList, updFileTypeIdsList, roleId);
	}

	@RequestMapping(value = "/getPartnerIdsForRole/{roleId}", method = RequestMethod.GET)
	public List<Long> getPartnerIdsForRole(@PathVariable("roleId") Long roleId) {
		List<Long> selectedPartnerIdList = userRolesService.findPartnerByRoleID(roleId);
		return selectedPartnerIdList;
	}

	@RequestMapping(value = "/getRoleSummaryFileTypeAndColumns", method = RequestMethod.GET)
	public RoleSummaryTO getRoleSummaryFileTypeAndColumns(@RequestParam("roleId") Long roleId,
			@RequestParam("partnerId") Long partnerId) {
		RoleSummaryTO roleSummaryTo = new RoleSummaryTO();
		List<Hssecurityrole> hssecurityrolesList = userRolesService.findHssecurityroleByPartnerIdRoleID(partnerId,
				roleId);
		List<Long> selectedDBFileTypes = userRolesService.findFileTypeByPartnerIDRoleId(partnerId, roleId);
		List<PartnerFileTypes> partnerFileTypesList = userRolesService.getPartnerFileTypesBypartnerId(partnerId,
				selectedDBFileTypes);
		Map<String, List<PartnerFileTypeColumnsTO>> fileTypeColumns = new HashMap<>();
		List<String> fileTyesList = new ArrayList<>();
		for (PartnerFileTypes partnerFileType : partnerFileTypesList) {
			roleSummaryTo.setPartnerName(partnerFileType.getEntityName());
			List<PartnerFileTypeColumnsTO> partnerFileTypeColumnsTOList = new ArrayList<>();
			String fileTypeName = partnerFileType.getDescription() + "-" + partnerFileType.getShortDescription();
			List<String> entityFileTypeColumns = userRolesService
					.getColumnsByEntityFileTypeId(partnerFileType.getEntityFileTypeId());
			for (String column : entityFileTypeColumns) {
				PartnerFileTypeColumnsTO partnerFileTypeColumnsTO = new PartnerFileTypeColumnsTO();
				partnerFileTypeColumnsTO.setColName(column);
				partnerFileTypeColumnsTO.setWriteMode(null);
				for (Hssecurityrole hssecurityrole : hssecurityrolesList) {
					if (hssecurityrole.getId().getEntityFileTypeId().equals(partnerFileType.getEntityFileTypeId())
							&& hssecurityrole.getId().getColName().equals(column)) {
						partnerFileTypeColumnsTO.setWriteMode(hssecurityrole.isWriteMode());
						break;
					}
				}
				partnerFileTypeColumnsTOList.add(partnerFileTypeColumnsTO);

			}
			fileTypeColumns.put(fileTypeName, partnerFileTypeColumnsTOList);
			fileTyesList.add(fileTypeName);
		}
		roleSummaryTo.setFileTypes(fileTyesList);
		roleSummaryTo.setFileTypeColumns(fileTypeColumns);
		return roleSummaryTo;
	}

}
