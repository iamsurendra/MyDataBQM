package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.SourceToTargetSplitVw;
import com.artha.workbench.models.metastore.SourceToTargetSplitVwKey;
import com.guvvala.framework.dao.BaseDAO;

public interface SourceToTargetSplitVwDAO extends BaseDAO<SourceToTargetSplitVw, SourceToTargetSplitVwKey> {

	public List<SourceToTargetSplitVw> getSourceToTargetSplitListByReleaseNo(Integer releaseNo);
}
