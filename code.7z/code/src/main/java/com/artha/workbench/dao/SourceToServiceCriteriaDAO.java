package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.SourceToServiceCriteria;
import com.artha.workbench.models.metastore.SourceToServiceCriteriaKey;
import com.guvvala.framework.dao.BaseDAO;

public interface SourceToServiceCriteriaDAO  extends BaseDAO<SourceToServiceCriteria, SourceToServiceCriteriaKey> {
	
	public List<SourceToServiceCriteria> getSourceToServiceCriteriaListByReleaseNo(Integer releaseNo);
	
	List<Integer> getAllSourceToServiceCriteriaReleaseIds(Integer selectedReleaseId);

}
