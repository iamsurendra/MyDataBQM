package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.WebServiceRecColumn;
import com.artha.workbench.models.metastore.WebServiceRecColumnVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface WebServiceRecColumnService {
	List<WebServiceRecColumn> getWebServiceRecColumn();

	List<WebServiceRecColumnVw> getWebServiceRecColumnVw();

	void createWebServiceRec(WebServiceRecColumnVw webServiceRecColumnVw);

	public void updateWebServiceRecColumn(WebServiceRecColumnVw webServiceRecColumnVw, boolean isReleaseChanged)
			throws JsonProcessingException;

	public List<WebServiceRecColumnVw> getWebServiceRecColumnVwListByReleaseNo(Integer releaseNo);

	public List<WebServiceRecColumn> getWebServiceRecColumnListByReleaseNo(Integer releaseNo);

	public WebServiceRecColumnVw getPreviousWebServiceRecColsVw(WebServiceRecColumnVw webServiceRecColumnVw)
			throws IOException;

	public List<WebServiceRecColumn> getWebServiceRecColumnList(Set<Integer> webServiceIds, Set<Integer> colIds,
			Integer selectedReleaseNumber);

	public WebServiceRecColumn getWebServiceRecColumn(WebServiceRecColumnVw webServiceRecColumnVw);
	
	List<Integer> getWebServiceIds();
	
	List<Integer> getTargetColumnIds(Integer webServiceId);
	
	WebServiceRecColumn getWebServiceRecColumn(Integer webServiceId,Integer columnId);

}
