package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.datahub.TaskcolLayout;
import com.guvvala.framework.dao.BaseDAO;

/**
 * @author Guvala
 *
 */
public interface TaskcolLayoutDAO extends BaseDAO<TaskcolLayout, String> {
	List<TaskcolLayout> getTaskcolLayoutData(String tarrecid);

}
