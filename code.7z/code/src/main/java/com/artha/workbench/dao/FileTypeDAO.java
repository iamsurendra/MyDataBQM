package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.HSFileType;
import com.guvvala.framework.dao.BaseDAO;

public interface FileTypeDAO extends BaseDAO<HSFileType, Integer> {
	 public void saveHSFileType(List<HSFileType> entitytypes);
	 public int getmaxhsFileType();
	 public HashMap<String,Integer> loadFiletypeId();
	 public void deleteHsFiletype();
	 public HashMap<String,Integer> loadSelectedFiletypeId(int entityid);
	 public HashMap<Integer,String> loadFiletypeIdMap();
	 public List<HSFileType> getFileTypeListByReleaseNo(Integer releaseNo);
	 public List<Integer> getFileTypeReleaseNumbers(Set<Integer> fileTypeIds,Integer selectedReleaseNumber);
	 List<Integer> getAllFileTypeReleaseIds(Integer selectedReleaseId);
	 List<HSFileType> getFileTypesList(Set<Integer> fileTypeIds, Integer selectedReleaseNumber) ;
}
