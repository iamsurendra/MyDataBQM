package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlRootElement;

import com.artha.workbench.models.metastore.AbstractModel;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "metastore.ThreadThreadPoolXref")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@JsonRootName("threadThreadPoolXref")
@XmlRootElement(name = "threadThreadPoolXref")

public class ThreadThreadPoolXref extends AbstractModel {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonProperty("Key")
	private ThreadThreadPoolXrefKey threadThreadPoolXrefKey;

	@Column(name = "Thread", insertable = false, updatable = false)
	@JsonIgnore
	private Integer thread;

	@Column(name = "PoolID", insertable = false, updatable = false)
	@JsonIgnore
	private Integer poolid;

	@JsonProperty("EffectiveDate")
	@Column(name = "EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date effectiveDate;

	@JsonProperty("Active")
	@Column(name = "Active")
	private String active;

	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;

	@Transient
	@JsonIgnore
	private String effectiveDtstr;

	@Transient
	@JsonIgnore
	private boolean addMode;

	
	public ThreadThreadPoolXref() {

	}

	public ThreadThreadPoolXref(boolean addMode, Date effectiveDate, Integer releaseNo) {
		this.addMode = addMode;
		this.releaseNo = releaseNo;
		this.effectiveDate = effectiveDate;
		convertEffectiveDate();
	}
	// getters and setters

	public ThreadThreadPoolXrefKey getThreadThreadPoolXrefKey() {
		return threadThreadPoolXrefKey;
	}

	public void setThreadThreadPoolXrefKey(ThreadThreadPoolXrefKey threadThreadPoolXrefKey) {
		this.threadThreadPoolXrefKey = threadThreadPoolXrefKey;
	}


	public Integer getThread() {
		return thread;
	}

	public void setThread(Integer thread) {
		this.thread = thread;
	}

	public Integer getPoolid() {
		return poolid;
	}

	public void setPoolid(Integer poolid) {
		this.poolid = poolid;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}

	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}

	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}

	@PostLoad
	public void postLoad() {
		convertEffectiveDate();
	}

	public void convertEffectiveDate() {
		this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());
	}

}
