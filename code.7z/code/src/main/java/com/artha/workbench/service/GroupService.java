package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.models.userConfig.GroupRoleFunctionsVW;
import com.artha.workbench.models.userConfig.Groups;

public interface GroupService {

	public List<GroupRoleFunctionsVW> findbyGroupID(Integer groupId);
	
	public List<Groups> getGroupsList();
	
	public Groups saveGroup(Groups groups);
	
	List<Integer> getGroupRoles(Integer groupId);
	
	void updateGroupRoles(List<Integer> roleIds, Integer groupid);
	
	void deleteGroup(Integer groupId);
	
	public Boolean groupNameExists(String groupName);



	

}
