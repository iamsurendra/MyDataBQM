package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.core.AuditTgtColInfo_VW;
import com.artha.workbench.models.datahub.Srccolumns;

public interface AuditTgtColumnDAO {
	
	List<AuditTgtColInfo_VW> getAuditTgtColumnList(String taskId);
	
	List<Srccolumns> getSourceValues(String taskId);

}
