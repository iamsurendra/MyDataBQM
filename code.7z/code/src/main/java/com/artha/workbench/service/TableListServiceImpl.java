package com.artha.workbench.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.TableListDAO;
import com.artha.workbench.models.userConfig.TableList;


@Service("tableListService")
public class TableListServiceImpl implements TablesListService {

	@Autowired
	TableListDAO tableListDAO;

	@Transactional
	public List<TableList> getTablelist(String statusFlag) {
		return tableListDAO.getTablelist(statusFlag);
	}

	@Transactional
	public List<TableList> getUploadList() {
		return tableListDAO.getUploadList();
	}
	
	@Transactional
	public void update(TableList tableList) {
		tableListDAO.update(tableList);
	}
	
	
	public String getDescription(String tablename){
		return tableListDAO.getDescription(tablename);
	}
}