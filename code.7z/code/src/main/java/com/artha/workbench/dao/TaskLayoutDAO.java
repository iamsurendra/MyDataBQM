package com.artha.workbench.dao;

import com.artha.workbench.models.datahub.TaskLayout;
import com.guvvala.framework.dao.BaseDAO;

/**
 * @author Guvala
 *
 */
public interface TaskLayoutDAO extends BaseDAO<TaskLayout, String> {

}
