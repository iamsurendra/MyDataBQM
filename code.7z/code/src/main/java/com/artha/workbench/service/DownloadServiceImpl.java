package com.artha.workbench.service;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.artha.workbench.dao.EntityFileRecColumnVwDAO;
import com.artha.workbench.dao.EntityFileTypeScheduleXrefVwDAO;
import com.artha.workbench.dao.EntityFileTypeXrefVwDAO;
import com.artha.workbench.dao.EntityFileValidationRuleVwDAO;
import com.artha.workbench.dao.EntityMasterDAO;
import com.artha.workbench.dao.EntityTypeDAO;
import com.artha.workbench.dao.FileFormatDAO;
import com.artha.workbench.dao.FileTypeDAO;
import com.artha.workbench.dao.FileValStepXrefVwDAO;
import com.artha.workbench.dao.HeaderFooterColsVwDAO;
import com.artha.workbench.dao.HeaderFooterVwDAO;
import com.artha.workbench.dao.RuleTypeDAO;
import com.artha.workbench.dao.SourceToTargetMappingVwDAO;
import com.artha.workbench.dao.ValidationStepDAO;
import com.artha.workbench.models.metastore.EntityFileRecColumnKey;
import com.artha.workbench.models.metastore.EntityFileRecColumnVw;
import com.artha.workbench.models.metastore.EntityFileTypeScheduleXrefVw;
import com.artha.workbench.models.metastore.EntityFileTypeXrefVw;
import com.artha.workbench.models.metastore.EntityFileValidationRuleVw;
import com.artha.workbench.models.metastore.EntityMaster;
import com.artha.workbench.models.metastore.EntityType;
import com.artha.workbench.models.metastore.FileFormat;
import com.artha.workbench.models.metastore.FileValStepXrefVw;
import com.artha.workbench.models.metastore.HSFileType;
import com.artha.workbench.models.metastore.HeaderFooterColsVw;
import com.artha.workbench.models.metastore.HeaderFooterVw;
import com.artha.workbench.models.metastore.RuleType;
import com.artha.workbench.models.metastore.SourceToTargetMappingVw;
import com.artha.workbench.models.metastore.ValidationStep;
import com.guvvala.framework.util.DateUtils;

@Service("downloadService")
public class DownloadServiceImpl implements DownloadService {


	
	@Autowired
	RuleTypeDAO ruleTypeDAO;
	
	@Autowired
	EntityMasterDAO entityMasterDAO;
	
	@Autowired
	ValidationStepDAO validationStepDAO;
	
	@Autowired
	EntityTypeDAO entityTypeDAO;
	
	@Autowired
	FileValStepXrefVwDAO fileValStepXrefVwDAO;
	
	@Autowired
	FileTypeDAO fileTypeDAO;
	
	@Autowired
	EntityFileTypeXrefVwDAO entityFileTypeXrefVwDAO;
	
	@Autowired
	EntityFileRecColumnVwDAO entityFileRecColumnVwDAO;
	
	@Autowired
	EntityFileTypeScheduleXrefVwDAO entityFileTypeScheduleXrefVwDAO;
	
	@Autowired
	HeaderFooterColsVwDAO headerFooterColsVwDAO;

	@Autowired
	HeaderFooterVwDAO headerFooterVwDAO;
	
	@Autowired
	EntityFileValidationRuleVwDAO entityFileValidationRuleVwDAO;
	
	@Autowired
	SourceToTargetMappingVwDAO sourceToTargetMappingVwDAO;
	
	@Autowired
	FileFormatDAO fileFormatDAO;
	
	
	 public void downloadExcel(String filename,String versionid,String osname)
	    {
	    	int rownum = 0;
	    	XSSFSheet firstSheet;
			Collection<File> files;
			//HSSFWorkbook workbook;
			XSSFWorkbook workbook ;
			File exactFile;

			//workbook = new HSSFWorkbook();
			 workbook = new XSSFWorkbook();
			
			firstSheet = workbook.createSheet("Sheet1");
			Row headerRow = firstSheet.createRow(rownum);
			headerRow.setHeightInPoints(40);
			List<String> header = new ArrayList<String>();
			List<List> recordToAdd = new ArrayList<List>();
	//entity type
			if(filename!=null && filename.equals("EntityType"))
			{ 
			//Session session = sessionFactory.getCurrentSession();
	        List<EntityType> auditdet = null;
	        //auditdet = (List<EntityType>)session.createQuery("from EntityType").list();
	        auditdet = entityTypeDAO.findAll();
			header.add("EntityTypeID");
			header.add("Description");
			recordToAdd.add(header);
			//recordToAdd.add(auditdet);
			
			EntityType et =null;
			for (int j = 0; j < recordToAdd.size(); j++) {
				Row row = firstSheet.createRow(rownum);
				
				List<String> l2= recordToAdd.get(j);
				
				for(int k=0; k<l2.size(); k++)
					{
						Cell cell = row.createCell(k);
						cell.setCellValue(l2.get(k));
					}
				rownum++;
				
			}
			for (int k = 0; k < auditdet.size(); k++) {
				Row row = firstSheet.createRow(rownum);
				et= new EntityType();
				et = auditdet.get(k);
						Cell cell = row.createCell(0);
						if(et.getEntityTypeID()!=null)
						cell.setCellValue(et.getEntityTypeID());
						 cell = row.createCell(1);
						 if(et.getDescription()!=null)
						cell.setCellValue(et.getDescription());
				rownum++;
			 }
			}
			//FileFormat
			else if(filename!=null && filename.equals("FileFormat"))
			{
			//Session session = sessionFactory.getCurrentSession();
	        List<FileFormat> fileformat = null;
	       // fileformat = (List<FileFormat>)session.createQuery("from FileFormat").list();
	        fileformat = fileFormatDAO.findAll();
			header.add("File Format ID");
			header.add("File Format");
			header.add("Description");
			
			recordToAdd.add(header);
			//recordToAdd.add(auditdet);
			
			FileFormat ff =null;
			for (int j = 0; j < recordToAdd.size(); j++) {
				Row row = firstSheet.createRow(rownum);
				
				List<String> l2= recordToAdd.get(j);
				
				for(int k=0; k<l2.size(); k++)
					{
						Cell cell = row.createCell(k);
						cell.setCellValue(l2.get(k));
					}
				rownum++;
			}
			for (int k = 0; k < fileformat.size(); k++) {
				Row row = firstSheet.createRow(rownum);
				ff= new FileFormat();
				ff = fileformat.get(k);
				Cell cell = row.createCell(0);
				 if(ff.getFileFormatID()!=null)
				cell.setCellValue(ff.getFileFormatID());
				cell = row.createCell(1);
				 if(ff.getFileFormat()!=null)
				cell.setCellValue(ff.getFileFormat());
				cell = row.createCell(2);
				 if(ff.getDescription()!=null)
				cell.setCellValue(ff.getDescription());
				
				rownum++;
			 }
			}
			//EntityFileRecColumn
					else if(filename!=null && filename.equals("EntityFileRecColumn"))
					{
			        List<EntityFileRecColumnVw> entityFileRecColumn = null;
			        entityFileRecColumn = entityFileRecColumnVwDAO.findAll();
			        for(int i=0;i<entityFileRecColumn.size();i++)
					{
			        	if(entityFileRecColumn.get(i).getEffectiveDate()!=null && !entityFileRecColumn.get(i).getEffectiveDate().equals(""))
			        	entityFileRecColumn.get(i).setEffectiveDtstr(DateUtils.convertDateFormat(entityFileRecColumn.get(i).getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
					}
			        EntityFileRecColumnKey entityFileRecColumnKey;		
			  
			        header.add("FileMask");
	        		header.add("EntityName");
	        		header.add("HSFileType");
	        		header.add("ColumnID");
					header.add("Column Name");
					header.add("DataType");
					header.add("Column Length");
					header.add("Start Position ");
					header.add("Column Mask");
					header.add("Allow Null Value");
					header.add("Active");
					header.add("Effective Date");
					header.add("Comments");
					header.add(" Who made Change");
					header.add(" Reason for Change");
					recordToAdd.add(header);
					//recordToAdd.add(auditdet);
					
					EntityFileRecColumnVw efrc =null;
					for (int j = 0; j < recordToAdd.size(); j++) {
						Row row = firstSheet.createRow(rownum);
						
						List<String> l2= recordToAdd.get(j);
						
						for(int k=0; k<l2.size(); k++)
							{
								Cell cell = row.createCell(k);
								cell.setCellValue(l2.get(k));
							}
						rownum++;
					}
					for (int k = 0; k < entityFileRecColumn.size(); k++) {
						Row row = firstSheet.createRow(rownum);
						efrc= new EntityFileRecColumnVw();
						efrc = entityFileRecColumn.get(k);
						Cell cell = row.createCell(0);
						if(efrc.getFileMask()!=null)
						cell.setCellValue(efrc.getFileMask());
						 cell = row.createCell(1);
						 if(efrc.getEntityName()!=null)
						cell.setCellValue(efrc.getEntityName());
						 cell = row.createCell(2);
						 if(efrc.getHSFileType()!=null)
						cell.setCellValue(efrc.getHSFileType());
						 cell = row.createCell(3);
						 if(efrc.getColumnID()!=null)
						cell.setCellValue(efrc.getColumnID());
						 cell = row.createCell(4);
						 if(efrc.getColName()!=null)
						cell.setCellValue(efrc.getColName());
						cell = row.createCell(5);
						if(efrc.getDataType()!=null)
						cell.setCellValue(efrc.getDataType());
						cell = row.createCell(6);
						if(efrc.getColLength()!=null)
						cell.setCellValue(efrc.getColLength());
						cell = row.createCell(7);
						if(efrc.getStartPosition()!=null)
						cell.setCellValue(efrc.getStartPosition());
						else
							cell.setCellValue("");
						cell = row.createCell(8);
						if(efrc.getColMask()!=null)
						cell.setCellValue(efrc.getColMask());
						else
							cell.setCellValue("");
						cell = row.createCell(9);
						if(efrc.getAllowValue()!=null)
						cell.setCellValue(efrc.getAllowValue());
						cell = row.createCell(10);
						if(efrc.getActive()!=null)
						cell.setCellValue(efrc.getActive());
						cell = row.createCell(11);
						if(efrc.getEffectiveDate()!=null)
						cell.setCellValue(efrc.getEffectiveDtstr());
						cell = row.createCell(12);
						if(efrc.getComments()!=null)
						cell.setCellValue(efrc.getComments());
						cell = row.createCell(13);
						if(efrc.getWmc()!=null)
						cell.setCellValue(efrc.getWmc());
						cell = row.createCell(14);
						if(efrc.getRfc()!=null)
						cell.setCellValue(efrc.getRfc());
						rownum++;
					 }
					}
			//EntityFileTypeScheduleXref
				else if(filename!=null && filename.equals("EntityFileTypeScheduleXref"))
					{
			        List<EntityFileTypeScheduleXrefVw> entityFileTypeScheduleXrefList = null;
			        entityFileTypeScheduleXrefList = entityFileTypeScheduleXrefVwDAO.findAll(); 
					header.add("Entity FileTypeSchedID");
					header.add("Entity Name");
					header.add("HS FileType");
					header.add("File Mask");
					header.add("Schedule FequencyType");
					header.add("Sch Frequency Value");
					header.add("Schedule Offset Type");
					header.add("Schedule OffsetValue");
					header.add("File Direction ");
					header.add("Active");
					header.add("Comments");
					
					recordToAdd.add(header);
					//recordToAdd.add(auditdet);
					
					EntityFileTypeScheduleXrefVw entityFileTypeScheduleXref =null;
					for (int j = 0; j < recordToAdd.size(); j++) {
						Row row = firstSheet.createRow(rownum);
						
						List<String> l2= recordToAdd.get(j);
						
						for(int k=0; k<l2.size(); k++)
							{
								Cell cell = row.createCell(k);
								cell.setCellValue(l2.get(k));
							}
						rownum++;
					}
					for (int k = 0; k < entityFileTypeScheduleXrefList.size(); k++) {
						Row row = firstSheet.createRow(rownum);
						entityFileTypeScheduleXref= new EntityFileTypeScheduleXrefVw();
						entityFileTypeScheduleXref = entityFileTypeScheduleXrefList.get(k);
						Cell cell = row.createCell(0);
						if(entityFileTypeScheduleXref.getEntityFileTypeSchedID()!=null)
						cell.setCellValue(entityFileTypeScheduleXref.getEntityFileTypeSchedID());
						cell = row.createCell(1);
						if(entityFileTypeScheduleXref.getEntityName()!=null)
						cell.setCellValue(entityFileTypeScheduleXref.getEntityName());
						cell = row.createCell(2);
						if(entityFileTypeScheduleXref.getHSFileType()!=null)
						cell.setCellValue(entityFileTypeScheduleXref.getHSFileType());
						cell = row.createCell(3);
						if(entityFileTypeScheduleXref.getFileMask()!=null)
						cell.setCellValue(entityFileTypeScheduleXref.getFileMask());
						cell = row.createCell(4);
						if(entityFileTypeScheduleXref.getScheduleFequencyType()!=null)
						cell.setCellValue(entityFileTypeScheduleXref.getScheduleFequencyType());
						cell = row.createCell(5);
						if(entityFileTypeScheduleXref.getSchFrequencyValue()!=null)
						cell.setCellValue(entityFileTypeScheduleXref.getSchFrequencyValue());
						 cell = row.createCell(6);
						 if(entityFileTypeScheduleXref.getScheduleOffsetType()!=null)
						cell.setCellValue(entityFileTypeScheduleXref.getScheduleOffsetType());
						cell = row.createCell(7);
						if(entityFileTypeScheduleXref.getScheduleOffsetValue()!=null)
						cell.setCellValue(entityFileTypeScheduleXref.getScheduleOffsetValue());
						cell = row.createCell(8);
						if(entityFileTypeScheduleXref.getFileDirection()!=null)
						cell.setCellValue(entityFileTypeScheduleXref.getFileDirection());
						cell = row.createCell(9);
						if(entityFileTypeScheduleXref.getActive()!=null)
						cell.setCellValue(entityFileTypeScheduleXref.getActive());
						
						
						
						rownum++;
					 }
					}
			//EntityFileTypeXref
				else if(filename!=null && filename.equals("EntityFileTypeXref"))
				{
		        List<EntityFileTypeXrefVw> entityFileTypeXrefList = null;
		        entityFileTypeXrefList = entityFileTypeXrefVwDAO.findAll(); 
		        for(int i=0;i<entityFileTypeXrefList.size();i++)
				{
		        	if(entityFileTypeXrefList.get(i).getEffectiveDate()!=null &&!entityFileTypeXrefList.get(i).getEffectiveDate().equals(""))
		        	entityFileTypeXrefList.get(i).setEffectiveDtstr(DateUtils.convertDateFormat(entityFileTypeXrefList.get(i).getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				}
				header.add("Entity FileType ID");
				header.add("Entity Name");
				header.add("HS FileType");
				header.add("File Format");
				header.add("File Path");
				header.add("File Mask");
				header.add("Rec Delimiter");
				header.add("Columns Delimiter");
				header.add("Columns Count");
				header.add("Max RecLen");
				header.add("Allow Extra Columns");
				header.add("Notify RetyCount");
				header.add("Outbound Order");
				header.add("Active");
				header.add("Effective Date");
				header.add("Columns Width");
				header.add("DupFile Check");
				header.add("Columns Pattern");
				header.add("No Data Record Pattern");
				header.add("No Record Delimiter");
				header.add("OutBound Filter");
				header.add("Ignore Header RowCount");
				header.add("Ignore Footer RowCount");
				header.add("First Column");
				header.add("LastColumn");
				header.add("AllowBlankRows");
				header.add("EOFDelimiter");
				header.add("Comments");
				recordToAdd.add(header);
				//recordToAdd.add(auditdet);
				
				EntityFileTypeXrefVw eftx =null;
				for (int j = 0; j < recordToAdd.size(); j++) {
					Row row = firstSheet.createRow(rownum);
					
					List<String> l2= recordToAdd.get(j);
					
					for(int k=0; k<l2.size(); k++)
						{
							Cell cell = row.createCell(k);
							cell.setCellValue(l2.get(k));
						}
					rownum++;
				}
				for (int k = 0; k < entityFileTypeXrefList.size(); k++) {
					Row row = firstSheet.createRow(rownum);
					eftx= new EntityFileTypeXrefVw();
					eftx = entityFileTypeXrefList.get(k);
					Cell cell = row.createCell(0);
					if(eftx.getEntityFileTypeID()!=null)
					cell.setCellValue(eftx.getEntityFileTypeID());
					cell = row.createCell(1);
					if(eftx.getEntityName()!=null)
					cell.setCellValue(eftx.getEntityName());
					cell = row.createCell(2);
					if(eftx.getHSFileType()!=null)
					cell.setCellValue(eftx.getHSFileType());
					cell = row.createCell(3);
					if(eftx.getFileFormat()!=null)
					cell.setCellValue(eftx.getFileFormat());
					cell = row.createCell(4);
					
					if(eftx.getFilePath()!=null)
					cell.setCellValue(eftx.getFilePath());
					cell = row.createCell(5);
					if(eftx.getFileMask()!=null)
					cell.setCellValue(eftx.getFileMask());
					cell = row.createCell(6);
					if(eftx.getRecDelimiter()!=null)
					cell.setCellValue(eftx.getRecDelimiter());
					cell = row.createCell(7);
					if(eftx.getColumnsDelimiter()!=null)
					cell.setCellValue(eftx.getColumnsDelimiter());
					cell = row.createCell(8);
					if(eftx.getColumnsCount()!=null)
					cell.setCellValue(eftx.getColumnsCount());
					cell = row.createCell(9);
					if(eftx.getMaxRecLen()!=null)
					cell.setCellValue(eftx.getMaxRecLen());
					else
						cell.setCellValue("");
					cell = row.createCell(10);
					if(eftx.getAllowExtraColumns()!=null)
					cell.setCellValue(eftx.getAllowExtraColumns());
					cell = row.createCell(11);
					if(eftx.getNotifyRetyCount()!=null)
					cell.setCellValue(eftx.getNotifyRetyCount());
					cell = row.createCell(12);
					if(eftx.getOutboundOrder()!=null)
					cell.setCellValue(eftx.getOutboundOrder());
					else
						cell.setCellValue("");
					cell = row.createCell(13);
					if(eftx.getActive()!=null)
					cell.setCellValue(eftx.getActive());
					cell = row.createCell(14);
					if(eftx.getEffectiveDate()!=null)
					cell.setCellValue(eftx.getEffectiveDtstr());
					cell = row.createCell(15);
					if(eftx.getColumnsWidth()!=null)
					cell.setCellValue(eftx.getColumnsWidth());
					else
						cell.setCellValue("");
					cell = row.createCell(16);
					if(eftx.getDupFileCheck()!=null)
					cell.setCellValue(eftx.getDupFileCheck());
					cell = row.createCell(17);
					if(eftx.getColumnsPattern()!=null)
					cell.setCellValue(eftx.getColumnsPattern());
					cell = row.createCell(18);
					if(eftx.getNoDataRecordPattern()!=null)
					cell.setCellValue(eftx.getNoDataRecordPattern());
					cell = row.createCell(19);
					if(eftx.getRecDelimiter()!=null)
					cell.setCellValue(eftx.getRecDelimiter());
					cell = row.createCell(20);
					if(eftx.getOutBoundFilter()!=null)
					cell.setCellValue(eftx.getOutBoundFilter());
					cell = row.createCell(21);
					if(eftx.getIgnoreHeaderRowCount()!=null)
					cell.setCellValue(eftx.getIgnoreHeaderRowCount());
					cell = row.createCell(22);
					if(eftx.getIgnoreFooterRowCount()!=null)
					cell.setCellValue(eftx.getIgnoreFooterRowCount());
					cell = row.createCell(23);
					if(eftx.getFirstColumn()!=null)
					cell.setCellValue(eftx.getFirstColumn());
					cell = row.createCell(24);
					if(eftx.getLastColumn()!=null)
					cell.setCellValue(eftx.getLastColumn());
					cell = row.createCell(25);
					if(eftx.getAllowBlankRows()!=null)
					cell.setCellValue(eftx.getAllowBlankRows());
					cell = row.createCell(26);
					if(eftx.geteOFDelimiter()!=null)
					cell.setCellValue(eftx.geteOFDelimiter());
					cell = row.createCell(27);
					if(eftx.getComments()!=null)
					cell.setCellValue(eftx.getComments());
					rownum++;
				 }
				}
			//EntityMaster
				else if(filename!=null && filename.equals("EntityMaster"))
				{
		        List<EntityMaster> entityMasterList = null;
		        entityMasterList = entityMasterDAO.findAll();
		        for(int i=0;i<entityMasterList.size();i++)
				{
		        	if(entityMasterList.get(i).getEffectiveDt()!=null && !entityMasterList.get(i).getEffectiveDt().equals(""))
		        	entityMasterList.get(i).setEffectiveDtstr(DateUtils.convertDateFormat(entityMasterList.get(i).getEffectiveDt(), DateUtils.INPUT_TABLEFORMAT));
				}
				header.add("Entity ID");
				header.add("Entity Name");
				header.add("Entity Name Abbr");
				header.add("Entity TypeID");
				header.add("AddrLine1");
				header.add("AddrLine2");
				header.add("AddrLine3");
				header.add("City Name");
				header.add("StateCd ");
				header.add("PostalCd");
				header.add("Postal Plus");
				header.add("Active");
				header.add("Effective Date");
				
				recordToAdd.add(header);
				//recordToAdd.add(auditdet);
				
				EntityMaster entityMaster =null;
				for (int j = 0; j < recordToAdd.size(); j++) {
					Row row = firstSheet.createRow(rownum);
					
					List<String> l2= recordToAdd.get(j);
					
					for(int k=0; k<l2.size(); k++)
						{
							Cell cell = row.createCell(k);
							cell.setCellValue(l2.get(k));
						}
					rownum++;
				}
				for (int k = 0; k < entityMasterList.size(); k++) {
					Row row = firstSheet.createRow(rownum);
					entityMaster= new EntityMaster();
					entityMaster = entityMasterList.get(k);
					Cell cell = row.createCell(0);
					if(entityMaster.getEntityID()!=null)
					cell.setCellValue(entityMaster.getEntityID());
					cell = row.createCell(1);
					if(entityMaster.getEntityName()!=null)
					cell.setCellValue(entityMaster.getEntityName());
					cell = row.createCell(2);
					if(entityMaster.getEntityNameAbbr()!=null)
					cell.setCellValue(entityMaster.getEntityNameAbbr());
					cell = row.createCell(3);
					if(entityMaster.getEntityTypeID()!=null)
					cell.setCellValue(entityMaster.getEntityTypeID());
					cell = row.createCell(4);
					if(entityMaster.getAddrLine1()!=null)
					cell.setCellValue(entityMaster.getAddrLine1());
					cell = row.createCell(5);
					if(entityMaster.getAddrLine2()!=null)
					cell.setCellValue(entityMaster.getAddrLine2());
					cell = row.createCell(6);
					if(entityMaster.getAddrLine3()!=null)
					cell.setCellValue(entityMaster.getAddrLine3());
					cell = row.createCell(7);
					if(entityMaster.getCityName()!=null)
					cell.setCellValue(entityMaster.getCityName());
					cell = row.createCell(8);
					if(entityMaster.getStateCd()!=null)
					cell.setCellValue(entityMaster.getStateCd());
					cell = row.createCell(9);
					if(entityMaster.getPostalCd()!=null)
					cell.setCellValue(entityMaster.getPostalCd());
					cell = row.createCell(10);
					if(entityMaster.getPostalPlus()!=null)
					cell.setCellValue(entityMaster.getPostalPlus());
					cell = row.createCell(11);
					if(entityMaster.getActive()!=null)
					cell.setCellValue(entityMaster.getActive());
					cell = row.createCell(12);
					if(entityMaster.getEffectiveDt()!=null)
					cell.setCellValue(entityMaster.getEffectiveDtstr());
					
					rownum++;
				 }
				}
			//FileValStepXref
				else if(filename!=null && filename.equals("FileValStepXref"))
				{
		        List<FileValStepXrefVw> fileValStepXrefList = null;
		       fileValStepXrefList = fileValStepXrefVwDAO.findAll();
				header.add("Entity Name ");
				header.add("File Type");
				header.add("File Mask ");
				header.add("Step Name");
				header.add("Step Order");
				
				recordToAdd.add(header);
				//recordToAdd.add(auditdet);
				
				FileValStepXrefVw fileValStepXref =null;
				for (int j = 0; j < recordToAdd.size(); j++) {
					Row row = firstSheet.createRow(rownum);
					
					List<String> l2= recordToAdd.get(j);
					
					for(int k=0; k<l2.size(); k++)
						{
							Cell cell = row.createCell(k);
							cell.setCellValue(l2.get(k));
						}
					rownum++;
				}
				for (int k = 0; k < fileValStepXrefList.size(); k++) {
					Row row = firstSheet.createRow(rownum);
					fileValStepXref= new FileValStepXrefVw();
					fileValStepXref = fileValStepXrefList.get(k);
					Cell cell = row.createCell(0);
					if(fileValStepXref.getEntityName()!=null)
					cell.setCellValue(fileValStepXref.getEntityName());
					cell = row.createCell(1);
					if(fileValStepXref.getFileType()!=null)
					cell.setCellValue(fileValStepXref.getFileType());
					cell = row.createCell(2);
					if(fileValStepXref.getFileMask()!=null)
					cell.setCellValue(fileValStepXref.getFileMask());
					cell = row.createCell(3);
					if(fileValStepXref.getStepName()!=null)
					cell.setCellValue(fileValStepXref.getStepName());
					cell = row.createCell(4);
					if(fileValStepXref.getStepOrder()!=null)
					cell.setCellValue(fileValStepXref.getStepOrder());
					
					rownum++;
				 }
				}
			//HeaderFooter
				else if(filename!=null && filename.equals("HeaderFooter"))
				{
		        List<HeaderFooterVw> headerFooterList = null;
		        headerFooterList = headerFooterVwDAO.findAll();
		        for(int i=0;i<headerFooterList.size();i++)
				{
					if(headerFooterList.get(i).getEffectiveDate()!=null && !headerFooterList.get(i).getEffectiveDate().equals(""))
		        	headerFooterList.get(i).setEffectiveDatestr(DateUtils.convertDateFormat(headerFooterList.get(i).getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				}
				header.add("File Mask");
				header.add("Rec Type");
				header.add("Seq Num");
				header.add("Entity Name");
				header.add("HS FileType");
				header.add("HeaderFooter Type");
				header.add("File RecNum");
				header.add("Col Cnt");
				header.add("Active ");
				header.add("Effective Date");
				header.add("Columns Width");
				header.add("Columns Pattern");
				
				recordToAdd.add(header);
				//recordToAdd.add(auditdet);
				
				HeaderFooterVw headerFooter =null;
				for (int j = 0; j < recordToAdd.size(); j++) {
					Row row = firstSheet.createRow(rownum);
					
					List<String> l2= recordToAdd.get(j);
					
					for(int k=0; k<l2.size(); k++)
						{
							Cell cell = row.createCell(k);
							cell.setCellValue(l2.get(k));
						}
					rownum++;
				}
				for (int k = 0; k < headerFooterList.size(); k++) {
					Row row = firstSheet.createRow(rownum);
					headerFooter= new HeaderFooterVw();
					headerFooter = headerFooterList.get(k);
					Cell cell = row.createCell(0);
					if(headerFooter.getFileMask()!=null)
					cell.setCellValue(headerFooter.getFileMask());
					cell = row.createCell(1);
					if(headerFooter.getRecType()!=null)
					cell.setCellValue(headerFooter.getRecType());
					cell = row.createCell(2);
					if(headerFooter.getSeqNum()!=null)
					cell.setCellValue(headerFooter.getSeqNum());
					cell = row.createCell(3);
					if(headerFooter.getEntityName()!=null)
					cell.setCellValue(headerFooter.getEntityName());
					cell = row.createCell(4);
					if(headerFooter.getHSFileType()!=null)
						cell.setCellValue(headerFooter.getHSFileType());
					cell = row.createCell(5);
					if(headerFooter.getHeaderFooterType()!=null)
					cell.setCellValue(headerFooter.getHeaderFooterType());
					cell = row.createCell(6);
					if(headerFooter.getFileRecNum()!=null)
					cell.setCellValue(headerFooter.getFileRecNum());
					cell = row.createCell(7);
					if(headerFooter.getColCnt()!=null)
					cell.setCellValue(headerFooter.getColCnt());
					cell = row.createCell(8);
					if(headerFooter.getActive()!=null)
					cell.setCellValue(headerFooter.getActive());
					cell = row.createCell(9);
					if(headerFooter.getEffectiveDate()!=null)
					cell.setCellValue(headerFooter.getEffectiveDatestr());
					cell = row.createCell(10);
					if(headerFooter.getColumnsWidth()!=null)
					cell.setCellValue(headerFooter.getColumnsWidth());
					cell = row.createCell(11);
					if(headerFooter.getColumnsPattern()!=null)
					cell.setCellValue(headerFooter.getColumnsPattern());
					
					rownum++;
				 }
				}
			//HeaderFooterCols
				else if(filename!=null && filename.equals("HeaderFooterCols"))
				{
		        List<HeaderFooterColsVw> headerFooterColsList = null;
		        headerFooterColsList = headerFooterColsVwDAO.findAll();
		        for(int i=0;i<headerFooterColsList.size();i++)
				{
		        	if(headerFooterColsList.get(i).getEffectiveDate()!=null && !headerFooterColsList.get(i).getEffectiveDate().equals(""))
		        	headerFooterColsList.get(i).setEffectiveDtstr(DateUtils.convertDateFormat(headerFooterColsList.get(i).getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				}
				header.add("File Mask");
				header.add("Entity Name");
				header.add("HS File Type ");
				header.add("Rec Type");
				header.add("Seq Num");
				header.add("Column ID");
				header.add("Column Name");
				header.add("Active");
				header.add("Effective Date");
				
				recordToAdd.add(header);
				//recordToAdd.add(auditdet);
				
				HeaderFooterColsVw headerFooterCols =null;
				for (int j = 0; j < recordToAdd.size(); j++) {
					Row row = firstSheet.createRow(rownum);
					
					List<String> l2= recordToAdd.get(j);
					
					for(int k=0; k<l2.size(); k++)
						{
							Cell cell = row.createCell(k);
							cell.setCellValue(l2.get(k));
						}
					rownum++;
				}
				for (int k = 0; k < headerFooterColsList.size(); k++) {
					Row row = firstSheet.createRow(rownum);
					headerFooterCols= new HeaderFooterColsVw();
					headerFooterCols = headerFooterColsList.get(k);
					Cell cell = row.createCell(0);
					if(headerFooterCols.getFileMask()!=null)
					cell.setCellValue(headerFooterCols.getFileMask());
					cell = row.createCell(1);
					if(headerFooterCols.getEntityName()!=null)
					cell.setCellValue(headerFooterCols.getEntityName());
					cell = row.createCell(2);
					if(headerFooterCols.getHSFileType()!=null)
					cell.setCellValue(headerFooterCols.getHSFileType());
					cell = row.createCell(3);
					if(headerFooterCols.getRecType()!=null)
					cell.setCellValue(headerFooterCols.getRecType());
					cell = row.createCell(4);
					if(headerFooterCols.getSeqNum()!=null)
					cell.setCellValue(headerFooterCols.getSeqNum());
					cell = row.createCell(5);
					if(headerFooterCols.getColumnID()!=null)
					cell.setCellValue(headerFooterCols.getColumnID());
					cell = row.createCell(6);
					if(headerFooterCols.getColumnName()!=null)
					cell.setCellValue(headerFooterCols.getColumnName());
					cell = row.createCell(7);
					if(headerFooterCols.getActive()!=null)
					cell.setCellValue(headerFooterCols.getActive());
					cell = row.createCell(8);
					if(headerFooterCols.getEffectiveDate()!=null)
					cell.setCellValue(headerFooterCols.getEffectiveDtstr());
					cell = row.createCell(9);
					if(headerFooterCols.getComments()!=null)
					cell.setCellValue(headerFooterCols.getComments());
					
					rownum++;
				 }
				}
			//HSFileType
				else if(filename!=null && filename.equals("HSFileType"))
				{
		        List<HSFileType> hSFileTypeList = null;
		        hSFileTypeList = fileTypeDAO.findAll();
				header.add("File Type ID");
				header.add("HS FileType");
				header.add("Description");
				
				recordToAdd.add(header);
				//recordToAdd.add(auditdet);
				
				HSFileType hSFileType =null;
				for (int j = 0; j < recordToAdd.size(); j++) {
					Row row = firstSheet.createRow(rownum);
					
					List<String> l2= recordToAdd.get(j);
					
					for(int k=0; k<l2.size(); k++)
						{
							Cell cell = row.createCell(k);
							cell.setCellValue(l2.get(k));
						}
					rownum++;
				}
				for (int k = 0; k < hSFileTypeList.size(); k++) {
					Row row = firstSheet.createRow(rownum);
					hSFileType= new HSFileType();
					hSFileType = hSFileTypeList.get(k);
					Cell cell = row.createCell(0);
					if(hSFileType.getFileTypeID()!=null)
					cell.setCellValue(hSFileType.getFileTypeID());
					cell = row.createCell(1);
					if(hSFileType.getHsFileType()!=null)
					cell.setCellValue(hSFileType.getHsFileType());
					cell = row.createCell(2);
					if(hSFileType.getDescription()!=null)
					cell.setCellValue(hSFileType.getDescription());
					
					rownum++;
				 }
				}
			//RuleType
				else if(filename!=null && filename.equals("RuleType"))
				{
		        List<RuleType> ruleTypeList = null;
		        ruleTypeList = ruleTypeDAO.findAll();
				header.add("Rule Type ID");
				header.add("Rule Type");
				header.add("Rule Type Description");
				
				recordToAdd.add(header);
				//recordToAdd.add(auditdet);
				
				RuleType ruleType =null;
				for (int j = 0; j < recordToAdd.size(); j++) {
					Row row = firstSheet.createRow(rownum);
					
					List<String> l2= recordToAdd.get(j);
					
					for(int k=0; k<l2.size(); k++)
						{
							Cell cell = row.createCell(k);
							cell.setCellValue(l2.get(k));
						}
					rownum++;
				}
				for (int k = 0; k < ruleTypeList.size(); k++) {
					Row row = firstSheet.createRow(rownum);
					ruleType= new RuleType();
					ruleType = ruleTypeList.get(k);
					Cell cell = row.createCell(0);
					cell.setCellValue(ruleType.getRuleTypeID());
					cell = row.createCell(1);
					if(ruleType.getRuleType()!= null)
					cell.setCellValue(ruleType.getRuleType());
					cell = row.createCell(2);
					if(ruleType.getRuleTypeDesc()!= null)
					cell.setCellValue(ruleType.getRuleTypeDesc());
					
					rownum++;
				 }
				}
			//SourceToTargetMapping
				else if(filename!=null && filename.equals("SourceToTargetMapping"))
				{
		        List<SourceToTargetMappingVw> sourceToTargetMappingList = null;
		        sourceToTargetMappingList = sourceToTargetMappingVwDAO.findAll();
		        for(int i=0;i<sourceToTargetMappingList.size();i++)
				{
		        	if(sourceToTargetMappingList.get(i).getEffectiveDate()!=null &&!sourceToTargetMappingList.get(i).getEffectiveDate().equals(""))
		        	sourceToTargetMappingList.get(i).setEffectiveDtstr(DateUtils.convertDateFormat(sourceToTargetMappingList.get(i).getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				}
				header.add("inputFileMask");
				header.add("Entity Name");
				header.add("Hs File Type");
				header.add("Target Entity FileMask");
				header.add("Target Entity Name");
				header.add("Column ID");
				header.add("Map Function");
				header.add("Active");
				header.add("Effective Date");
				header.add("Target ColOrder");
				header.add("Comments");
				
				recordToAdd.add(header);
				//recordToAdd.add(auditdet);
				
				SourceToTargetMappingVw sourceToTargetMapping =null;
				for (int j = 0; j < recordToAdd.size(); j++) {
					Row row = firstSheet.createRow(rownum);
					
					List<String> l2= recordToAdd.get(j);
					
					for(int k=0; k<l2.size(); k++)
						{
							Cell cell = row.createCell(k);
							cell.setCellValue(l2.get(k));
						}
					rownum++;
				}
				for (int k = 0; k < sourceToTargetMappingList.size(); k++) {
					Row row = firstSheet.createRow(rownum);
					sourceToTargetMapping= new SourceToTargetMappingVw();
					sourceToTargetMapping = sourceToTargetMappingList.get(k);
					Cell cell = row.createCell(0);
					if(sourceToTargetMapping.getInputFileMask()!=null)
					cell.setCellValue(sourceToTargetMapping.getInputFileMask());
					cell = row.createCell(1);
					if(sourceToTargetMapping.getEntityName()!=null)
					cell.setCellValue(sourceToTargetMapping.getEntityName());
					cell = row.createCell(2);
					if(sourceToTargetMapping.getHSFileType()!=null)
					cell.setCellValue(sourceToTargetMapping.getHSFileType());
					cell = row.createCell(3);
					if(sourceToTargetMapping.getTargetEntityFileMask()!=null)
					cell.setCellValue(sourceToTargetMapping.getTargetEntityFileMask());
					cell = row.createCell(4);
					if(sourceToTargetMapping.getTargetEntityName()!=null)
					cell.setCellValue(sourceToTargetMapping.getTargetEntityName());
					cell = row.createCell(5);
					if(sourceToTargetMapping.getColumnID()!=null)
					cell.setCellValue(sourceToTargetMapping.getColumnID());
					cell = row.createCell(6);
					if(sourceToTargetMapping.getMapFunction()!=null)
					cell.setCellValue(sourceToTargetMapping.getMapFunction());
					cell = row.createCell(7);
					if(sourceToTargetMapping.getActive()!=null)
					cell.setCellValue(sourceToTargetMapping.getActive());
					cell = row.createCell(8);
					if(sourceToTargetMapping.getEffectiveDtstr()!=null)
					cell.setCellValue(sourceToTargetMapping.getEffectiveDtstr());
					cell = row.createCell(9);
					if(sourceToTargetMapping.getTargetColOrder()!=null)
					cell.setCellValue(sourceToTargetMapping.getTargetColOrder());
					cell = row.createCell(10);
					if(sourceToTargetMapping.getComments()!=null)
					cell.setCellValue(sourceToTargetMapping.getComments());
					rownum++;
				 }
				}
			//entityFileValidationRule
				else if(filename!=null && filename.equals("EntityFileValidationRule"))
				{
		        List<EntityFileValidationRuleVw> EntityFileValidationRuleList = null;
		        EntityFileValidationRuleList = entityFileValidationRuleVwDAO.findAll();
		        for(int i=0;i<EntityFileValidationRuleList.size();i++)
				{
		        	if(EntityFileValidationRuleList.get(i).getEffectiveDate()!=null && !EntityFileValidationRuleList.get(i).getEffectiveDate().equals(""))
		        	EntityFileValidationRuleList.get(i).setEffectiveDtstr(DateUtils.convertDateFormat(EntityFileValidationRuleList.get(i).getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				}
				header.add("File Mask");
				header.add("Entity Name");
				header.add("HS File Type");
				header.add("Step Name");
				header.add("Fail Level");
				header.add("Active");
				header.add("Effective Date");
				header.add("Rule Type");
				header.add("Raw Rule");
				header.add("RuleParam1");
				header.add("RuleParam2");
				header.add("RuleParam3");
				header.add("RuleParam4");
				header.add("RuleParam5");
				header.add("RuleParam6");
				header.add("RuleParam7");
				header.add("RuleParam8");
				header.add("RuleParam9");
				header.add("RuleParam10");
				header.add("RuleValue");
				header.add("Base Column");
				header.add("Base Message");
				header.add("Who made Change");
				header.add("Reason For Change");
				
				recordToAdd.add(header);
				//recordToAdd.add(auditdet);
				
				EntityFileValidationRuleVw entityFileValidationRule =null;
				for (int j = 0; j < recordToAdd.size(); j++) {
					Row row = firstSheet.createRow(rownum);
					
					List<String> l2= recordToAdd.get(j);
					
					for(int k=0; k<l2.size(); k++)
						{
							Cell cell = row.createCell(k);
							cell.setCellValue(l2.get(k));
						}
					rownum++;
				}
				for (int k = 0; k < EntityFileValidationRuleList.size(); k++) {
					Row row = firstSheet.createRow(rownum);
					entityFileValidationRule= new EntityFileValidationRuleVw();
					entityFileValidationRule = EntityFileValidationRuleList.get(k);
					Cell cell = row.createCell(0);
					cell = row.createCell(1);
						if(entityFileValidationRule.getFileMask()!=null)
					cell.setCellValue(entityFileValidationRule.getFileMask());
					cell = row.createCell(2);
					if(entityFileValidationRule.getEntityName()!=null)
					cell.setCellValue(entityFileValidationRule.getEntityName());
					cell = row.createCell(3);
					if(entityFileValidationRule.getHSFileType()!=null)
					cell.setCellValue(entityFileValidationRule.getHSFileType());
					cell = row.createCell(4);
					if(entityFileValidationRule.getStepName()!=null)
					cell.setCellValue(entityFileValidationRule.getStepName());
					cell = row.createCell(5);
					if(entityFileValidationRule.getFailLevel()!=null)
					cell.setCellValue(entityFileValidationRule.getFailLevel());
					cell = row.createCell(6);
					if(entityFileValidationRule.getActive()!=null)
				cell.setCellValue(entityFileValidationRule.getActive());
					cell = row.createCell(7);
					if(entityFileValidationRule.getEffectiveDate()!=null)
					cell.setCellValue(entityFileValidationRule.getEffectiveDtstr());
					cell = row.createCell(8);
					if(entityFileValidationRule.getRuleType()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleType());
					cell = row.createCell(9);
					if(entityFileValidationRule.getRawRule()!=null)
					cell.setCellValue(entityFileValidationRule.getRawRule());
					cell = row.createCell(10);
					if(entityFileValidationRule.getRuleParam1()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleParam1());
					cell = row.createCell(11);
					if(entityFileValidationRule.getRuleParam2()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleParam2());
					cell = row.createCell(12);
					if(entityFileValidationRule.getRuleParam3()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleParam3());
					cell = row.createCell(13);
					if(entityFileValidationRule.getRuleParam4()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleParam4());
					cell = row.createCell(14);
					if(entityFileValidationRule.getRuleParam5()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleParam5());
					cell = row.createCell(15);
					if(entityFileValidationRule.getRuleParam6()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleParam6());
					cell = row.createCell(16);
					if(entityFileValidationRule.getRuleParam7()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleParam7());
					cell = row.createCell(17);
					if(entityFileValidationRule.getRuleParam8()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleParam8());
					cell = row.createCell(18);
					if(entityFileValidationRule.getRuleParam9()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleParam9());
					cell = row.createCell(19);
					if(entityFileValidationRule.getRuleParam10()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleParam10());
					cell = row.createCell(20);
					if(entityFileValidationRule.getRuleValue()!=null)
					cell.setCellValue(entityFileValidationRule.getRuleValue());
					cell = row.createCell(21);
					if(entityFileValidationRule.getBaseColumn()!=null)
					cell.setCellValue(entityFileValidationRule.getBaseColumn());
					cell = row.createCell(22);
					if(entityFileValidationRule.getWhoMadeChange()!=null)
					cell.setCellValue(entityFileValidationRule.getWhoMadeChange());
					cell = row.createCell(23);
					if(entityFileValidationRule.getReasonForChange()!=null)
					cell.setCellValue(entityFileValidationRule.getReasonForChange());
					
					rownum++;
				 }
				}
			//ValidationStep
				else if(filename!=null && filename.equals("ValidationStep"))
				{
		        List<ValidationStep> validationStepList = null;
		        validationStepList = validationStepDAO.findAll();
		        for(int i=0;i<validationStepList.size();i++)
				{
		        	if(validationStepList.get(i).getEffectiveDate()!=null && !"".equals(validationStepList.get(i).getEffectiveDate()))
		        	validationStepList.get(i).setEffectiveDtstr(DateUtils.convertDateFormat(validationStepList.get(i).getEffectiveDate(), DateUtils.INPUT_TABLEFORMAT));
				}
				header.add("Step ID");
				header.add("Step Name");
				header.add("Step Description");
				header.add("Job Name");
				header.add("Active");
				header.add("Effective Date");
				
				recordToAdd.add(header);
				//recordToAdd.add(auditdet);
				
				ValidationStep validationStep =null;
				for (int j = 0; j < recordToAdd.size(); j++) {
					Row row = firstSheet.createRow(rownum);
					
					List<String> l2= recordToAdd.get(j);
					
					for(int k=0; k<l2.size(); k++)
						{
							Cell cell = row.createCell(k);
							cell.setCellValue(l2.get(k));
						}
					rownum++;
				}
				for (int k = 0; k < validationStepList.size(); k++) {
					Row row = firstSheet.createRow(rownum);
					validationStep= new ValidationStep();
					validationStep = validationStepList.get(k);
					Cell cell = row.createCell(0);
					if(validationStep.getStepID()!=null)
					cell.setCellValue(validationStep.getStepID());
					cell = row.createCell(1);
					if(validationStep.getStepName()!=null)
					cell.setCellValue(validationStep.getStepName());
					cell = row.createCell(2);
					if(validationStep.getStepDescription()!=null)
					cell.setCellValue(validationStep.getStepDescription());
					cell = row.createCell(3);
					if(validationStep.getJobName()!=null)
					cell.setCellValue(validationStep.getJobName());
					cell = row.createCell(4);
					if(validationStep.getActive()!=null)
					cell.setCellValue(validationStep.getActive());
					cell = row.createCell(5);
					if(validationStep.getEffectiveDtstr()!=null)
					cell.setCellValue(validationStep.getEffectiveDtstr());
					rownum++;
				 }
				}
			FileOutputStream fos = null;
			try {
				File file = null;
				 file = new File("c:\\downloadfiles\\"+filename+"\\all\\");
				if (!file.exists()) {
					file.mkdirs();
				}
				int count = file.listFiles().length;
				count++;
				if(versionid!=null && versionid.equalsIgnoreCase("dbversion"))
				{
					File f1 = null;
					 f1 = new File("c:\\downloadfiles\\"+filename+"\\latest");
					if (!f1.exists()) {
						f1.mkdirs();
					}
				 fos=new FileOutputStream(new File("c:\\downloadfiles\\"+filename+"\\latest\\"+filename+versionid+".xls"));
				}
				else if(versionid!=null && versionid.equalsIgnoreCase("backupversion"))
				{
					File f1 = null;
					 f1 = new File("c:\\downloadfiles\\"+filename+"\\backup");
					if (!f1.exists()) {
						f1.mkdirs();
					}
				 fos=new FileOutputStream(new File("c:\\downloadfiles\\"+filename+"\\backup\\"+filename+versionid+".xls"));
				}
				else
				{
					fos=new FileOutputStream(new File("c:\\downloadfiles\\"+filename+"\\all\\"+filename+count+".xls"));
				}
				XSSFCellStyle hsfstyle=workbook.createCellStyle();
				hsfstyle.setBorderBottom((short) 1);
				hsfstyle.setFillBackgroundColor((short)245);
				workbook.write(fos);
			} catch (Exception e) {
				e.printStackTrace();
			}
	      
	    }    
}