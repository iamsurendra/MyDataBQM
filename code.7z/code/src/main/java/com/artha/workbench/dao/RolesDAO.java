package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.Roles;
import com.guvvala.framework.dao.BaseDAO;

public interface RolesDAO extends BaseDAO<Roles, Long> {

	public boolean duplicateRoleName(String roleName);

	List<Roles> getAllRoles();

}
