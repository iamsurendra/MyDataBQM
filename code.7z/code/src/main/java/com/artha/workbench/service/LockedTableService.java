package com.artha.workbench.service;

public interface LockedTableService {
	
	public void createLockedTables(Integer tableId,Long userId,String tableName);
	
	public boolean lockedByOtherUser(Integer tableId, Long userId);
	
	public void unlockTable(Integer tableId);

}
