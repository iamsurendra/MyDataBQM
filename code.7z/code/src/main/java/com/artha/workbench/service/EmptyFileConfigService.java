package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.EmptyFileConfig;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EmptyFileConfigService {

	public List<EmptyFileConfig> getEmptyFileConfigList();

	public void update(EmptyFileConfig emptyFileConfig, boolean isReleaseChanged) throws JsonProcessingException;

	public int getmaxEmptyFileConfig();

	public void create(EmptyFileConfig emptyFileConfig);

	public void saveEmptyFileConfig(List<EmptyFileConfig> emptyFileConfig);
	
	List<Integer> loadentityFileTypeid();
	
	 List<Integer> getEntityFileTypeSchedIds();
	 
	 public List<EmptyFileConfig> getEmptyFileConfigByReleaseNo(Integer releaseNo);
	 
	 public EmptyFileConfig getPreviousEmptyFileConfig(EmptyFileConfig emptyFileConfig)throws IOException ;

}
