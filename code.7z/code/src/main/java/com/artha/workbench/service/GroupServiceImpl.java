package com.artha.workbench.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.GroupRoleFunctionsDAO;
import com.artha.workbench.dao.GroupRolesDAO;
import com.artha.workbench.dao.GroupsDAO;
import com.artha.workbench.dao.UserDAO;
import com.artha.workbench.models.userConfig.GroupRoleFunctionsVW;
import com.artha.workbench.models.userConfig.GroupRoles;
import com.artha.workbench.models.userConfig.Groups;
import com.artha.workbench.models.userConfig.User;


@Service("groupService")
public class GroupServiceImpl implements GroupService {

	@Autowired
	GroupRoleFunctionsDAO groupRoleFunctionsDAO;

	@Autowired
	GroupsDAO groupsDAO;

	@Autowired
	GroupRolesDAO groupRolesDAO;

	@Autowired
	UserDAO userDAO;

	@Transactional(readOnly = true)
	public List<GroupRoleFunctionsVW> findbyGroupID(Integer groupId) {
		return groupRoleFunctionsDAO.findbyGroupID(groupId);
	}

	@Transactional(readOnly = true)
	public List<Groups> getGroupsList() {
		return groupsDAO.getAllGroups();
	}

	@Transactional
	public Groups saveGroup(Groups groups) {
		return groupsDAO.create(groups);
	}

	@Transactional
	public List<Integer> getGroupRoles(Integer groupId) {
		return groupRolesDAO.getGroupRoles(groupId);
	}

	@Transactional
	public void updateGroupRoles(List<Integer> roleIds, Integer groupid) {
		List<GroupRoles> groupRoles = groupRolesDAO.getGroupRolesList(groupid);
		for (GroupRoles groupRole : groupRoles) {
			if (!roleIds.contains(groupRole.getRoleid())) {
				groupRolesDAO.delete(groupRole);
			}
		}
		for (Integer roleId : roleIds) {
			boolean newRole = true;
			for (GroupRoles groupRole : groupRoles) {
				if (groupRole.getRoleid().equals(roleId)) {
					newRole = false;
					break;
				}
			}
			if (newRole) {
				GroupRoles gr = new GroupRoles();
				gr.setGroupid(groupid);
				gr.setRoleid(roleId);
				groupRolesDAO.create(gr);
			}
		}
	}

	@Transactional
	public void deleteGroup(Integer groupId) {
		List<GroupRoles> groupRoles = groupRolesDAO.getGroupRolesList(groupId);
		for (GroupRoles groupRole : groupRoles) {
			groupRolesDAO.delete(groupRole);
		}
		List<User> users = userDAO.getUsersList(groupId);
		for (User user : users) {
			user.setGroupid(null);
			userDAO.update(user);
		}
		Groups delGroupEntity = groupsDAO.findOne(groupId);
		groupsDAO.delete(delGroupEntity);
	}

	@Transactional
	public Boolean groupNameExists(String groupName) {
		return groupsDAO.groupNameExists(groupName);
	}

}