package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.WebServiceRecColumnVw;
import com.artha.workbench.models.metastore.WebServiceRecColumnVwKey;
import com.guvvala.framework.dao.BaseDAO;

public interface WebServiceRecColumnVwDAO extends BaseDAO<WebServiceRecColumnVw,WebServiceRecColumnVwKey >{

	public List<WebServiceRecColumnVw> getWebServiceRecColumnListByReleaseNo(Integer releaseNo);
}
