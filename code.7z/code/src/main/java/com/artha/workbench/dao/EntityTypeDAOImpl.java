package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.EntityType;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityTypeDAOImpl extends BaseDAOImpl<EntityType, Integer> implements EntityTypeDAO {

	public EntityTypeDAOImpl() {
		super(EntityType.class);
	}

	public void saveEntityType(List<EntityType> entitytypes) {
		batchCreate(entitytypes, 50);

	}

	public int getmaxEntitytype() {
		int loginid = 0;
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(entityTypeID) from EntityType",
				Integer.class);
		if (query.getSingleResult() != null)
			loginid = query.getSingleResult();
		return loginid;
	}

	@Transactional
	public HashMap<Integer, String> loadentityTypeid() {
		HashMap<Integer, String> entityTypeMap = new HashMap<Integer, String>();
		TypedQuery<Object[]> query = entityManager.createQuery("SELECT entityTypeID,description from EntityType",
				Object[].class);
		List<Object[]> list = query.getResultList();
		if (!list.isEmpty()) {
			for (Object[] object : list) {
				entityTypeMap.put((Integer) object[0], (String) object[1]);
			}
		}
		return entityTypeMap;
	}

	@Transactional
	public void deleteEntityType() {
		Query query = entityManager.createQuery("delete from EntityType");
		query.executeUpdate();
	}
	
	
	@Transactional
	public List<EntityType> getEntityTypeListByReleaseNo(Integer releaseNo)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityType> query = cb.createQuery(EntityType.class);
		Root<EntityType> root = query.from(EntityType.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getEntityTypeReleaseNumbers(Set<Integer> entityTypeIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<EntityType> root = query.from(EntityType.class);
		query.select(root.<Integer>get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("entityTypeID")).value(entityTypeIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllEntityTypeReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from EntityType where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	
	@Transactional
	public List<EntityType> getEntityTypeList(Set<Integer> entityTypeIds,Integer selectedReleaseId)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityType> query = cb.createQuery(EntityType.class);
		Root<EntityType> root = query.from(EntityType.class);
		query.select(root);
		query.where(cb.and(cb.in(root.get("entityTypeID")).value(entityTypeIds)),cb.notEqual(root.get("releaseNo"), selectedReleaseId));
		return this.entityManager.createQuery(query).getResultList();
	}
	
}
