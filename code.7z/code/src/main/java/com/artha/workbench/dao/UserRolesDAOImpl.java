package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.UserRoles;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class UserRolesDAOImpl extends BaseDAOImpl<UserRoles, Integer> implements UserRolesDAO {

	public UserRolesDAOImpl() {
		super(UserRoles.class);
	}

	public List<UserRoles> getUserRoles(int loginId) {
		TypedQuery<UserRoles> query = entityManager.createQuery("from UserRoles where status ='Y' ", UserRoles.class);
		return query.getResultList();
	}

	public List<UserRoles> getUserRolesDetails(int loginid) {
		TypedQuery<UserRoles> query = entityManager.createQuery("from UserRoles where roletypeid = '" + loginid + "' ",
				UserRoles.class);
		return query.getResultList();
	}

}
