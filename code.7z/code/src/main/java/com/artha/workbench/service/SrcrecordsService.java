package com.artha.workbench.service;

public interface SrcrecordsService {

	 public String getSrcrecid(String taskid) ;
	 
	 
}
