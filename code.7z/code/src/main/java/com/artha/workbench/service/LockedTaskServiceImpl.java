package com.artha.workbench.service;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.TaskStatus;
import com.artha.workbench.dao.LockedTaskDAO;
import com.artha.workbench.dao.TaskDAO;
import com.artha.workbench.dao.TgtColumnsDAO;
import com.artha.workbench.models.datahub.LockedTask;
import com.artha.workbench.models.datahub.SrcColumnErrorInfo;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.models.datahub.TgtColumns;

@Service("lockedTaskService")
public class LockedTaskServiceImpl implements LockedTaskService {

	@Autowired
	LockedTaskDAO lockedTaskDAO;

	@Autowired
	TaskDAO taskDAO;

	@Autowired
	PopUpService popUpService;

	@Autowired
	TgtColumnsDAO tgtColumnsDAO;

	@Override
	public List<LockedTask> getLockedTasksList() {
		return lockedTaskDAO.findAll();
	}

	@Transactional
	@Override
	public void unlockTempLockTasks(List<String> lockedTaskIdList) {
		for (String taskId : lockedTaskIdList) {
			lockedTaskDAO.unlockSelected(taskId, TaskStatus.TEMP_LOCK.value);
			/*Task task = taskDAO.findOne(taskId);
			if (task != null && !task.getStatus().equalsIgnoreCase(TaskStatus.RESOLVED.value) && !task.getStatus().equalsIgnoreCase(TaskStatus.LOCKED.value)) {
					List<Integer> revIds = taskDAO.getLockedTaskRevisionIds(taskId);
						String status = taskDAO.getPreviousTaskStatus(revIds, taskId);
						task.setStatus(status == null ? TaskStatus.NEW.value : status);
					taskDAO.update(task);

					
				}*/
		}
	}

	@Transactional
	@Override
	public void unlockEditLockTask(List<String> lockedTaskIdList) {
		Map<String, List<TgtColumns>> targetLists = new LinkedHashMap<String, List<TgtColumns>>();
		for (String taskId : lockedTaskIdList) {
			lockedTaskDAO.unlockSelected(taskId, TaskStatus.TEMP_LOCK.value);
			/*Task task = taskDAO.findOne(taskId);
					LinkedList<SrcColumnErrorInfo> popUpList = new LinkedList<SrcColumnErrorInfo>();
					List<TgtColumns> popUpTargetList = new LinkedList<TgtColumns>();
					String srcrecid = popUpService.getSrcrecid(taskId);
					String tarrecid = popUpService.getTargetrecid(taskId);
					popUpList = popUpService.getPopuplist(srcrecid, taskId,null);
					List<TgtColumns> popUpTargets = popUpService.getTargetPopuplist(tarrecid);
					for (SrcColumnErrorInfo srccolumn : popUpList) {
						for (TgtColumns tgtColumn : popUpTargets) {
							if (srccolumn.getColumnName().equalsIgnoreCase(tgtColumn.getDefColName())) {
								//TODO need to confirm the code with previous.
								tgtColumn.setDefColValue(srccolumn.getColumnValue());
								popUpTargetList.add(tgtColumn);
								break;
							}
						}
					}
					task.setStatus(TaskStatus.NEW.value);
					taskDAO.update(task);*/
					lockedTaskDAO.unlockSelected(taskId, TaskStatus.LOCKED.value);
					//targetLists.put(taskId, popUpTargetList);

		}

		/*if (targetLists != null && !targetLists.isEmpty()) {
			for(String taskId : targetLists.keySet()){
			tgtColumnsDAO.updateTargetCol(targetLists.get(taskId), 1);
			}
		}*/
	}

}
