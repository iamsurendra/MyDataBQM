package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.artha.workbench.models.metastore.AbstractModel;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "metastore.EntityFileTypeStepChunk")
@JsonRootName("entityFileTypeStepChunk")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name = "entityFileTypeStepChunk")
public class EntityFileTypeStepChunk extends AbstractModel {

	private static final long serialVersionUID = 1L;
	@EmbeddedId
	@JsonProperty("Key")
	private EntityFileTypeStepChunkKey entityFileTypeStepChunkKey;


	@JsonIgnore
	@Column(name = "EntityFileTypeID", insertable = false, updatable = false)
	private Integer entityFileTypeID;

	
	@JsonIgnore
	@Column(name = "StepID", insertable = false, updatable = false)
	private Integer stepID;

	@JsonProperty("ChunkNTile")
	@Column(name = "ChunkNTile")
	private String chunkNTile;

	@JsonProperty("ChunkOver")
	@Column(name = "ChunkOver")
	private String chunkOver;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("EffectiveDate")
	@Column(name = "EffectiveDate")
	private Date effectiveDate;

	@JsonProperty("Active")
	@Column(name = "Active")
	private String active;

	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;

	@Transient
	@JsonIgnore
	private String effectiveDtstr;

	@Transient
	@JsonIgnore
	private boolean addMode;

	public EntityFileTypeStepChunk(boolean addMode, Date effectiveDate, Integer releaseNo) {
		this.addMode = addMode;
		this.effectiveDate = effectiveDate;
		this.releaseNo = releaseNo;
		convertEffectiveDate();
	}

	public EntityFileTypeStepChunk() {

	}

	// getters and setters

	public EntityFileTypeStepChunkKey getEntityFileTypeStepChunkKey() {
		return entityFileTypeStepChunkKey;
	}

	public void setEntityFileTypeStepChunkKey(EntityFileTypeStepChunkKey entityFileTypeStepChunkKey) {
		this.entityFileTypeStepChunkKey = entityFileTypeStepChunkKey;
	}

	public Integer getEntityFileTypeID() {
		return entityFileTypeID;
	}

	public void setEntityFileTypeID(Integer entityFileTypeID) {
		this.entityFileTypeID = entityFileTypeID;
	}

	public Integer getStepID() {
		return stepID;
	}

	public void setStepID(Integer stepID) {
		this.stepID = stepID;
	}

	public String getChunkNTile() {
		return chunkNTile;
	}

	public void setChunkNTile(String chunkNTile) {
		this.chunkNTile = chunkNTile;
	}

	public String getChunkOver() {
		return chunkOver;
	}

	public void setChunkOver(String chunkOver) {
		this.chunkOver = chunkOver;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}


	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}

	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}

	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}
	@XmlTransient
	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	@PostLoad
	public void postLoad() {
		convertEffectiveDate();
	}

	public void convertEffectiveDate() {
		this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((entityFileTypeStepChunkKey == null) ? 0 : entityFileTypeStepChunkKey.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EntityFileTypeStepChunk other = (EntityFileTypeStepChunk) obj;
		if (entityFileTypeStepChunkKey == null) {
			if (other.entityFileTypeStepChunkKey != null)
				return false;
		} else if (!entityFileTypeStepChunkKey.equals(other.entityFileTypeStepChunkKey))
			return false;
		return true;
	}

}
