package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileRecColumn;
import com.artha.workbench.models.metastore.EntityFileRecColumnKey;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityFileRecColumnDAOImpl extends BaseDAOImpl<EntityFileRecColumn, EntityFileRecColumnKey>
		implements EntityFileRecColumnDAO {

	public EntityFileRecColumnDAOImpl() {
		super(EntityFileRecColumn.class);
	}

	public void saveEntityFileRecColumn(List<EntityFileRecColumn> entitytypes) {
		batchCreate(entitytypes, 50);
	}

	public void deleteEntityFileReccol() {
		Query query = entityManager.createQuery("delete from EntityFileRecColumn");
		query.executeUpdate();
	}

	public List<EntityFileRecColumn> getEntityFileRecColumnListByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileRecColumn> query = cb.createQuery(EntityFileRecColumn.class);
		Root<EntityFileRecColumn> root = query.from(EntityFileRecColumn.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();

	}

	@Override
	public List<Integer> getEntityFileRecRelNumbersByTypeIds(Set<Integer> entityTypeIds,
			Integer selectedReleaseNumber) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<EntityFileRecColumn> root = query.from(EntityFileRecColumn.class);
		query.select(root.<Integer> get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("EntityFileTypeID")).value(entityTypeIds),
				cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));
		return this.entityManager.createQuery(query).getResultList();
	}

	@Override
	public List<Integer> getEntityFileRecRelNumbersByColIds(Set<Integer> colIds, Integer selectedReleaseNumber) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<EntityFileRecColumn> root = query.from(EntityFileRecColumn.class);
		query.select(root.<Integer> get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("ColumnID")).value(colIds),
				cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllEntityFileRecColumnReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from EntityFileRecColumn where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	
	@Override
	public List<EntityFileRecColumn> getEntityFileRecList(Set<Integer> entityTypeIds,Set<Integer> colIds,Integer selectedReleaseNumber) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileRecColumn> query = cb.createQuery(EntityFileRecColumn.class);
		Root<EntityFileRecColumn> root = query.from(EntityFileRecColumn.class);
		query.select(root).distinct(true);
		query.where(cb.and(cb.in(root.get("entityFileTypeID")).value(entityTypeIds),cb.in(root.get("columnID")).value(colIds),
				cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));
		return this.entityManager.createQuery(query).getResultList();
	}


}
