package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.models.datahub.SrcColumnErrorInfo;

public interface SrccolumnsService {

	public List<SrcColumnErrorInfo> getPopuplist(String srcid);
}
