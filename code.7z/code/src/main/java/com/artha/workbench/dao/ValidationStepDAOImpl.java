package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.ValidationStep;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class ValidationStepDAOImpl extends BaseDAOImpl<ValidationStep, Integer> implements ValidationStepDAO {

	public ValidationStepDAOImpl() {
		super(ValidationStep.class);
	}

	public void savevalidationStep(List<ValidationStep> entitytypes) {
		batchCreate(entitytypes, 50);
	}

	public int getmaxStepID() {
		int maxid = 0;// changed 1 to 0 because to avoid data constraint
						// voilation Exception
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(stepID) from ValidationStep", Integer.class);
		if (query.getSingleResult() != null)
			maxid = query.getSingleResult();
		return maxid;
	}

	public HashMap<String, Integer> loadStepId() {
		List<String> fileflist = null;
		List<Integer> ffidlist = null;
		HashMap<String, Integer> ffmap = new HashMap<String, Integer>();
		TypedQuery<String> query = entityManager.createQuery("SELECT stepName from ValidationStep", String.class);
		TypedQuery<Integer> query1 = entityManager.createQuery("SELECT stepID from ValidationStep", Integer.class);
		fileflist = query.getResultList();
		ffidlist = query1.getResultList();
		if (ffidlist != null) {
			for (int i = 0; i < ffidlist.size(); i++) {
				ffmap.put(fileflist.get(i), ffidlist.get(i));
			}
		}
		return ffmap;
	}

	public HashMap<Integer, String> loadStepIdMap() {

		HashMap<Integer, String> stepIdMap = new HashMap<Integer, String>();
		TypedQuery<Object[]> query = entityManager.createQuery("SELECT stepID,stepName from ValidationStep",
				Object[].class);
		List<Object[]> stepIdNames = query.getResultList();
		for (Object[] object : stepIdNames) {
			stepIdMap.put((Integer) object[0], (String) object[1]);
		}
		return stepIdMap;
	}

	public void deleteValidationstep() {
		Query query = entityManager.createQuery("delete from ValidationStep");
		query.executeUpdate();
	}
	
	public List<ValidationStep> getValidationStepListByReleaseNo(Integer releaseNo){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<ValidationStep> query = cb.createQuery(ValidationStep.class);
		Root<ValidationStep> root = query.from(ValidationStep.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}

	@Override
	public List<Integer> getValidationStepReleaseNumbers(Set<Integer> stepIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<ValidationStep> root = query.from(ValidationStep.class);
		query.select(root.<Integer>get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("stepID")).value(stepIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllValidationStepReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from ValidationStep where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	
	@Override
	public List<ValidationStep> getValidationStepList(Set<Integer> stepIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<ValidationStep> query = cb.createQuery(ValidationStep.class);
		Root<ValidationStep> root = query.from(ValidationStep.class);
		query.select(root).distinct(true);
		query.where(cb.and(cb.in(root.get("stepID")).value(stepIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
		
	}
		@Transactional
		public List<Integer>loadeStepIds() {
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaQuery<Integer> criteriaQuery = criteriaBuilder.createQuery(Integer.class);
			Root<ValidationStep> makeRoot = criteriaQuery.from(ValidationStep.class);
			criteriaQuery.multiselect(makeRoot.get("stepID")).distinct(true);
			return entityManager.createQuery(criteriaQuery).getResultList();
			}
	
}
