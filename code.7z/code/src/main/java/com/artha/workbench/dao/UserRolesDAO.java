package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.UserRoles;
import com.guvvala.framework.dao.BaseDAO;

public interface UserRolesDAO extends BaseDAO<UserRoles, Integer> {
	public List<UserRoles> getUserRoles(int loginId);

	public List<UserRoles> getUserRolesDetails(int loginid);
}
