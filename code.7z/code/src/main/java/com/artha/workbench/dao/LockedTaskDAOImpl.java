package com.artha.workbench.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.constant.TaskStatus;
import com.artha.workbench.models.datahub.LockedTask;
import com.artha.workbench.models.datahub.LockedTaskPK;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class LockedTaskDAOImpl extends BaseDAOImpl<LockedTask, LockedTaskPK> implements LockedTaskDAO {

	public LockedTaskDAOImpl() {
		super(LockedTask.class);
	}

	public void createLock(String taskId, String userName,String lockType) {
		LockedTask lockedTask = new LockedTask();
		lockedTask.setCreatedOn(new Date());
		lockedTask.setLockOwnedBy(userName);
		LockedTaskPK lockedTaskPK = new LockedTaskPK();
		lockedTaskPK.setTaskId(taskId);
		lockedTaskPK.setLockType(lockType);
		lockedTask.setId(lockedTaskPK);
		create(lockedTask);
	}

	public void deleteLock(String taskId) {
		LockedTaskPK lockedTaskPK = new LockedTaskPK();
		lockedTaskPK.setTaskId(taskId);
		lockedTaskPK.setLockType(TaskStatus.TEMP_LOCK.value);
		LockedTask task = findOne(lockedTaskPK);
		delete(task);
	}

	public List<String> getLockedTasksList(String userName) {
		List<String> taskdet = new ArrayList<String>();
		TypedQuery<String> query = entityManager
				.createQuery("select id.taskId from LockedTask where lockOwnedBy != " + userName + "'", String.class);
		taskdet = query.getResultList();
		return taskdet;
	}

	@Override
	public List<String> getLockedTasksList(String taskId,String lockType) {
		List<String> taskdet = new ArrayList<String>();
		TypedQuery<String> query = entityManager
				.createQuery("select id.taskId from LockedTask where id.lockType = :lockType and id.taskId=:taskId", String.class);
		query.setParameter("lockType", lockType);
		query.setParameter("taskId", taskId);
		taskdet = query.getResultList();
		return taskdet;
	}
	
	public void deleteAlltasks(List<String> taskIds) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<LockedTask> query = cb.createQuery(LockedTask.class);
		Root<LockedTask> root = query.from(LockedTask.class);
		query.where(root.get("id").get("taskId").in(taskIds));
		deleteAll(this.entityManager.createQuery(query).getResultList());
	}

	public void removeLockedTasks(String taskid, String username) {
		Query query = entityManager.createQuery(
				"delete from LockedTask where id.taskId = '" + taskid + "' and lockOwnedBy = '" + username + "'");
		query.executeUpdate();
	}

	public void unlockSelected(String taskid,String lockType) {
		Query query = entityManager.createQuery("delete from LockedTask where id.taskId = :taskId and id.lockType = :lockType ");
		query.setParameter("taskId", taskid);
		query.setParameter("lockType", lockType);
		query.executeUpdate();
	}
	
	
}
