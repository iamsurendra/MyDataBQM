package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.EntityFileTypeQueries;
import com.artha.workbench.models.metastore.EntityFileTypeQueriesVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EntityFileTypeQueriesService {
	
	public List<EntityFileTypeQueries> getEntityFileTypeQueriesList();

	public List<EntityFileTypeQueriesVw> getEntityFileTypeQueriesVwList();
	
	public void create(EntityFileTypeQueriesVw entityFileTypeQueriesVw);
	
	public void update(EntityFileTypeQueriesVw entityFileTypeQueriesVw,boolean isReleaseChanged)throws JsonProcessingException;
	
	public List<EntityFileTypeQueriesVw> getEntityFileTypeQueriesVwListByReleaseNo(Integer releaseNo);
	
	public EntityFileTypeQueriesVw getPreviousEntityFileTypeQueriesVw(EntityFileTypeQueriesVw entityFileTypeQueriesVw) throws IOException;
	
	public List<EntityFileTypeQueries> getEntityFileTypeQueriesListByReleaseNo(Integer releaseNo);
	
	public EntityFileTypeQueries getEntityFileTypeQueries(EntityFileTypeQueriesVw entityFileTypeQueriesVw);
}
