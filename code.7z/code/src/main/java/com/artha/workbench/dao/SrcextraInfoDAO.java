package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.datahub.SrcextraInfo;
import com.guvvala.framework.dao.BaseDAO;

/**
 * @author Guvala
 *
 */
public interface SrcextraInfoDAO extends BaseDAO<SrcextraInfo, String> {
	
	public void deleteAllSrcextraInfo(List<String> srcRecordIds);

}
