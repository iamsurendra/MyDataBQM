package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileRuleParam;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityFileRuleParamDAOImpl extends BaseDAOImpl<EntityFileRuleParam, Integer>
		implements EntityFileRuleParamDAO {

	public EntityFileRuleParamDAOImpl() {
		super(EntityFileRuleParam.class);
	}

	public void saveEntityFileRuleParam(List<EntityFileRuleParam> entitytypes) {
		batchCreate(entitytypes, 50);

	}
	
	public List<EntityFileRuleParam> getEntityFileRuleParamList(Integer xrefId){
		TypedQuery<EntityFileRuleParam> query = entityManager.createQuery("from EntityFileRuleParam where EntityFileRuleId = :param1",EntityFileRuleParam.class);
		query.setParameter("param1", xrefId);
		return query.getResultList();
		
	}
	
	public List<EntityFileRuleParam> getEntityFileRuleParamList(List<Integer> xrefIds){
		TypedQuery<EntityFileRuleParam> query = entityManager.createQuery("from EntityFileRuleParam where EntityFileRuleId in(:param1)",EntityFileRuleParam.class);
		query.setParameter("param1", xrefIds);
		return query.getResultList();
		
	}

}
