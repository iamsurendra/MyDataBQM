package com.artha.workbench.models.core;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PostLoad;
import javax.persistence.Transient;


/**
 * The persistent class for the audittaskinfo database table.
 * 
 */

@NamedQuery(name="FetchAuditTaskByRights", query="SELECT audittask FROM audittaskinfo audittask where audittask.taskId like ?1 order by revId desc")
public class AuditTaskInfo_VW implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LAST_UPD_BY")
	private String lastUpdBy;

	@Column(name="LAST_UPD_DT")
	private Timestamp lastUpdDt;

	private String owner;
	
	@Id
	@Column(name="REV_ID")
	private int revId;

	private String status;

	@Column(name="task_id")
	private String taskId;

	@Column(name="task_name")
	private String taskName;
	
	@Column(name="revision_type")
	private int revisionType;
	
	@Transient
	private String revisionTypeString;

	public AuditTaskInfo_VW() {
	}

	public String getLastUpdBy() {
		return this.lastUpdBy;
	}

	public void setLastUpdBy(String lastUpdBy) {
		this.lastUpdBy = lastUpdBy;
	}

	public Timestamp getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Timestamp lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getOwner() {
		return this.owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public int getRevId() {
		return this.revId;
	}

	public void setRevId(int revId) {
		this.revId = revId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTaskId() {
		return this.taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return this.taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	
	

	public int getRevisionType() {
		return revisionType;
	}

	public void setRevisionType(int revisionType) {
		this.revisionType = revisionType;
	}

	public String getRevisionTypeString() {
		return revisionTypeString;
	}

	public void setRevisionTypeString(String revisionTypeString) {
		this.revisionTypeString = revisionTypeString;
	}

	@PostLoad
	public void convertRevisionType()
	{
		if(revisionType==2)
		{
			revisionTypeString = "Deleted";
		}
	}
}