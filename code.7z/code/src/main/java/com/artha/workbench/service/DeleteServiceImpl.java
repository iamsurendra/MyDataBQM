package com.artha.workbench.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.EntityFileRecColumnDAO;
import com.artha.workbench.dao.EntityFileTypeScheduleXrefDAO;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.EntityFileValidationRuleDAO;
import com.artha.workbench.dao.EntityMasterDAO;
import com.artha.workbench.dao.EntityTypeDAO;
import com.artha.workbench.dao.FileFormatDAO;
import com.artha.workbench.dao.FileTypeDAO;
import com.artha.workbench.dao.FileValStepXrefDAO;
import com.artha.workbench.dao.HeaderFooterColsDAO;
import com.artha.workbench.dao.HeaderFooterDAO;
import com.artha.workbench.dao.RuleTypeDAO;
import com.artha.workbench.dao.SourceToTargetMappingDAO;
import com.artha.workbench.dao.ValidationStepDAO;

@Service("deleteService")
public class DeleteServiceImpl implements DeleteService {

	@Autowired
	RuleTypeDAO ruleTypeDAO;

	@Autowired
	EntityMasterDAO entityMasterDAO;

	@Autowired
	ValidationStepDAO validationStepDAO;

	@Autowired
	EntityTypeDAO entityTypeDAO;

	@Autowired
	FileValStepXrefDAO fileValStepXrefDAO;

	@Autowired
	FileTypeDAO fileTypeDAO;

	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefDAO;

	@Autowired
	EntityFileRecColumnDAO entityFileRecColumnDAO;

	@Autowired
	EntityFileTypeScheduleXrefDAO entityFileTypeScheduleXrefDAO;

	@Autowired
	HeaderFooterColsDAO headerFooterColsDAO;

	@Autowired
	HeaderFooterDAO headerFooterDAO;

	@Autowired
	EntityFileValidationRuleDAO entityFileValidationRuleDAO;

	@Autowired
	SourceToTargetMappingDAO sourceToTargetMappingDAO;

	@Autowired
	FileFormatDAO fileFormatDAO;

	@Transactional
	public void  deleteTableData(String fileIdentifier) {

		if (fileIdentifier.equalsIgnoreCase("EntityMaster")) {
			entityMasterDAO.deleteEntityMaster();
		} else if (fileIdentifier.equalsIgnoreCase("ValidationStep")) {
			validationStepDAO.deleteValidationstep();
		}
		else if (fileIdentifier.equalsIgnoreCase("EntityType")) {
			entityTypeDAO.deleteEntityType();
		}
		else if (fileIdentifier.equalsIgnoreCase("FileValStepXref")) {
			fileValStepXrefDAO.deleteFileValStepXref();
		}
		else if (fileIdentifier.equalsIgnoreCase("HSFileType")) {
			fileTypeDAO.deleteHsFiletype();
		}
		else if (fileIdentifier.equalsIgnoreCase("FileFormat")) {
			fileFormatDAO.deleteFileFormat();
		}
		else if (fileIdentifier.equalsIgnoreCase("RuleType")) {
			ruleTypeDAO.deleteRuleType();
		}
		else if (fileIdentifier.equalsIgnoreCase("EntityFileTypeXref")) {
			entityFileTypeXrefDAO.deleteEntityFileTypeXref();
		}
		else if (fileIdentifier.equalsIgnoreCase("EntityFileRecColumn")) {
			entityFileRecColumnDAO.deleteEntityFileReccol();
		}
		else if (fileIdentifier.equalsIgnoreCase("EntityFileTypeScheduleXref")) {
			entityFileTypeScheduleXrefDAO.deleteEntityFileTypeScheduleXref();
		}
		else if (fileIdentifier.equalsIgnoreCase("HeaderFooterCols")) {

			headerFooterColsDAO.deleteHeaderFooterCol();

		}
		else if (fileIdentifier.equalsIgnoreCase("HeaderFooter")) {

			headerFooterDAO.deleteHeaderFooter();
		}
		else if (fileIdentifier.equalsIgnoreCase("EntityFileValidationRule")) {

			entityFileValidationRuleDAO.deleteValidationRuleDB();
			entityFileValidationRuleDAO.deleteEntityFileRuleXref();
			entityFileValidationRuleDAO.deleteValidationRule();
			entityFileValidationRuleDAO.deleteEntityFileRuleParam();
		}
		else if (fileIdentifier.equalsIgnoreCase("SourceToTargetMapping")) {
			sourceToTargetMappingDAO.deleteSourcetotargetMapping();

		}
	}
	@Transactional
	public void  deleteAllTableData() {
		entityFileTypeScheduleXrefDAO.deleteEntityFileTypeScheduleXref();	
		headerFooterColsDAO.deleteHeaderFooterCol();					
		headerFooterDAO.deleteHeaderFooter();					
		sourceToTargetMappingDAO.deleteSourcetotargetMapping();
		entityFileRecColumnDAO.deleteEntityFileReccol();
		entityFileValidationRuleDAO.deleteEntityFileRuleXref();
		entityFileTypeXrefDAO.deleteEntityFileTypeXref();
		entityMasterDAO.deleteEntityMaster();
		entityTypeDAO.deleteEntityType();
		fileFormatDAO.deleteFileFormat();
		fileTypeDAO.deleteHsFiletype();
		entityFileValidationRuleDAO.deleteValidationRuleDB();
		entityFileValidationRuleDAO.deleteValidationRule();
		fileValStepXrefDAO.deleteFileValStepXref();
		validationStepDAO.deleteValidationstep();
		entityFileValidationRuleDAO.deleteEntityFileRuleParam();
		ruleTypeDAO.deleteRuleType();

	}
}
