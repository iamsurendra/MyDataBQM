package com.artha.workbench.models.datahub;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.artha.workbench.models.metastore.AbstractModel;

@Entity
@Table(name = "datahub.tasklinelayout")
public class TaskLineLayout extends AbstractModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "line_layout_id")
	private String lineLayoutId;

	@Column(name = "layout_id")
	private String layoutId;

	@Column(name = "srcrec_name")
	private String srcreName;

	@Column(name = "sequence_no")
	private Integer sequenceNo;

	public String getLineLayoutId() {
		return lineLayoutId;
	}

	public void setLineLayoutId(String lineLayoutId) {
		this.lineLayoutId = lineLayoutId;
	}

	public String getLayoutId() {
		return layoutId;
	}

	public void setLayoutId(String layoutId) {
		this.layoutId = layoutId;
	}

	public String getSrcreName() {
		return srcreName;
	}

	public void setSrcreName(String srcreName) {
		this.srcreName = srcreName;
	}

	public Integer getSequenceNo() {
		return sequenceNo;
	}

	public void setSequenceNo(Integer sequenceNo) {
		this.sequenceNo = sequenceNo;
	}

}
