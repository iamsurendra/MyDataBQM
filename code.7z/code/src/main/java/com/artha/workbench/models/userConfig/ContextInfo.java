package com.artha.workbench.models.userConfig;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.artha.workbench.models.metastore.AbstractModel;

@Entity
@Table(name = "contextInfo")
public class ContextInfo extends AbstractModel {

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "schema_name")
	private String schemaName;

	@Column(name = "ip")
	private String ip;

	@Column(name = "driver", nullable = false)
	private String driver;

	@Column(name = "username", nullable = false)
	private String userName;

	@Column(name = "password", nullable = false)
	private String password;

	@Column(name = "portno", nullable = false)
	private String portNo;

	@Column(name = "default_db", nullable = false)
	@Type(type = "boolean")
	private boolean defaultDb;

	@Transient
	private boolean addMode;

	public ContextInfo() {

	}

	public ContextInfo(boolean addMode) {
		this.addMode = addMode;
	}

	public ContextInfo(Long id, String schemaName, String ip) {
		this.id = id;
		this.schemaName = schemaName;
		this.ip = ip;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPortNo() {
		return portNo;
	}

	public void setPortNo(String portNo) {
		this.portNo = portNo;
	}

	public boolean isDefaultDb() {
		return defaultDb;
	}

	public void setDefaultDb(boolean defaultDb) {
		this.defaultDb = defaultDb;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ContextInfo other = (ContextInfo) obj;
		if (id != other.id)
			return false;
		return true;
	}

	// getters && setters

}
