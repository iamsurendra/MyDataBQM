package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.HeaderFooterColVwKey;
import com.artha.workbench.models.metastore.HeaderFooterColsVw;
import com.guvvala.framework.dao.BaseDAO;


public interface HeaderFooterColsVwDAO extends BaseDAO<HeaderFooterColsVw,HeaderFooterColVwKey> {
	
	public List<HeaderFooterColsVw> getHeaderFooterColsVwListByReleaseNo(Integer releaseNo);
}
