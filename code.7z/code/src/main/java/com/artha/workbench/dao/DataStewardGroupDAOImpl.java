package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.DataStewardGroups;
import com.artha.workbench.models.metastore.DataStewardGroupsKey;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class DataStewardGroupDAOImpl extends BaseDAOImpl<DataStewardGroups,DataStewardGroupsKey>implements DataStewardGroupDAO{

	public DataStewardGroupDAOImpl() {
		super(DataStewardGroups.class);
		// TODO Auto-generated constructor stub
	}
	
	
	public void saveDataStewardGroups(List<DataStewardGroups> dataStewardGroups) {
		batchCreate(dataStewardGroups, 50);

	}
	
	@Transactional
	public void deleteDataStewardGroups() {
		Query query = entityManager.createQuery("delete from datastewardgroups");
		query.executeUpdate();
	}
	
	
	@Override
	public List<DataStewardGroups> getDataStewardGroupsByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<DataStewardGroups> query = cb.createQuery(DataStewardGroups.class);
		Root<DataStewardGroups> root = query.from(DataStewardGroups.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}	
	
	
	
	@Override
	public List<Integer> getAllDatastewardgroupsReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from DataStewardGroups where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}

	
	
	
}
