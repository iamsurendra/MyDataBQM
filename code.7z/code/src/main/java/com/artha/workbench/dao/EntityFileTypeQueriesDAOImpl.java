package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileTypeQueries;
import com.artha.workbench.models.metastore.EntityFileTypeQueriesKey;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class EntityFileTypeQueriesDAOImpl extends BaseDAOImpl<EntityFileTypeQueries, EntityFileTypeQueriesKey> implements EntityFileTypeQueriesDAO{

	public EntityFileTypeQueriesDAOImpl() {
		super(EntityFileTypeQueries.class);
	
	}

	@Override
	public List<EntityFileTypeQueries> getEntityFileTypeQueriesListByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeQueries> query = cb.createQuery(EntityFileTypeQueries.class);
		Root<EntityFileTypeQueries> root = query.from(EntityFileTypeQueries.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllEntityFileTypeQueriesReleaseIds(Integer selectedReleaseId) {
		TypedQuery<Integer> query = entityManager.createQuery("select releaseNo from EntityFileTypeQueries where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}

}
