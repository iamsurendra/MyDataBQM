package com.artha.workbench.models.metastore;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class HeaderFooterColVwKey implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("FileMask")
	private String FileMask;
	
	@JsonProperty("EntityName")
	private String EntityName;
	
	@JsonProperty("HSFileType")
	private String HSFileType;
	
	@JsonProperty("RecType")
	private String RecType;
	
	@JsonProperty("SeqNum")
	private int SeqNum;
	
	@JsonProperty("ColumnID")
	private int ColumnID;
	
	
	public String getFileMask() {
		return FileMask;
	}
	public void setFileMask(String fileMask) {
		FileMask = fileMask;
	}
	public String getEntityName() {
		return EntityName;
	}
	public void setEntityName(String entityName) {
		EntityName = entityName;
	}
	public String getHSFileType() {
		return HSFileType;
	}
	public void setHSFileType(String hSFileType) {
		HSFileType = hSFileType;
	}
	public String getRecType() {
		return RecType;
	}
	public void setRecType(String recType) {
		RecType = recType;
	}
	public int getSeqNum() {
		return SeqNum;
	}
	public void setSeqNum(int seqNum) {
		SeqNum = seqNum;
	}
	public int getColumnID() {
		return ColumnID;
	}
	public void setColumnID(int columnID) {
		ColumnID = columnID;
	}
	
	
}
