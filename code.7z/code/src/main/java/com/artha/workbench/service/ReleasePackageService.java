package com.artha.workbench.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.artha.workbench.models.metastore.ReleasePackages;
import com.artha.workbench.to.ReleasePackageInfoTO;
import com.artha.workbench.to.ValidationRuleDetailsInfoTO;


public interface ReleasePackageService {

	List<ReleasePackages> fetchReleasePackages();

	 ReleasePackages createReleasePackage(String releasePackageId);
	 ReleasePackages findReleasePackage(Integer releasePackageId);
	 ReleasePackages freezeReleasePackages(Integer releasePackageNo);
	 List<Integer> getArchiveReleaseIds(Integer releaseId);
	 Set<Integer> getArchiveReleaseInfo(Integer releaseId,String tableName,Set<String> primaryKeys);
	 ReleasePackages createReleasePackage(Integer releasePackageId,String releasePackageName);
	 void saveRelaseInfo(ReleasePackageInfoTO releasePackageInfo);
	 Long getReleasePackageListCount(Set<String> releaseNames);
	 List<?>  getReleaseArchiveRecordData(Integer releaseId,String tableName);
	 List<?> getReleaseArchiveViewRecordData(Integer releaseId, String tableName);
	 Set<Integer> getArchiveTableReleaseInfo(Integer releaseId,String tableName,Set<String> primaryKeys);
	 void loadValidationRuleReleaseData(Integer releaseId,List<ValidationRuleDetailsInfoTO> validationRuleDetailsInfoTOs) throws Exception;
	 
	 ReleasePackages getReleasePackageList(Integer releaseId,String releaseName);
	 
	 Set<Integer> getAllReleaseLogicalDependencies(Integer selectedReleasePackageId);
	 Set<Integer> getBaseReleases(String parametars);
	 Map<String,Integer> getBaseReleasesAndPksMap(String parametars);
	 List<String> getTablesListInArchiveByReleaseNo(Integer releaseId);
}
