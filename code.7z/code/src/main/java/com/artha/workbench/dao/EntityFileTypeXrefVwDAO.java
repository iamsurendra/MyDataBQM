package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EntityFileTypeXrefVw;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityFileTypeXrefVwDAO extends BaseDAO<EntityFileTypeXrefVw, Integer> {
	
	List<EntityFileTypeXrefVw> getEntityFileTypeXrefVwList(Integer releaseNo);
}
