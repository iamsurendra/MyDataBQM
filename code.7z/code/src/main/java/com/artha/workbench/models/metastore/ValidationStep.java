
package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.ExcelHeader;

@Entity
@Table(name = "metastore.ValidationStep")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name="validationStep")
public class ValidationStep extends AbstractModel {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "StepID", nullable = false)
	@NotNull
	@JsonProperty("StepID")
	private Integer stepID;
	
	@JsonProperty("StepName")
	private String stepName;
	
	@JsonProperty("StepDescription")
	private String stepDescription;
	
	@JsonProperty("JobName")
	private String jobName;
	
	@JsonProperty("Active")
	private String active;
	
	@JsonProperty("Effectivedate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date effectiveDate;
	
	@Transient
	@JsonIgnore
	private String effectiveDtstr;
	
	@Column(name = "ReleaseNum", nullable = false)
	@ExcelHeader(name="ReleaseNum")
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Transient
	@JsonIgnore
	private boolean addMode;

	public ValidationStep(boolean addMode,Date effectiveDate,Integer releaseNo) {
		this.addMode = addMode;
		this.releaseNo = releaseNo;
		this.effectiveDate = effectiveDate;
	}

	public ValidationStep() {

	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@XmlTransient
	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}

	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}

	public Integer getStepID() {
		return stepID;
	}

	public void setStepID(Integer stepID) {
		this.stepID = stepID;
	}

	public String getStepName() {
		return stepName;
	}

	public void setStepName(String stepName) {
		this.stepName = stepName;
	}

	public String getStepDescription() {
		return stepDescription;
	}

	public void setStepDescription(String stepDescription) {
		this.stepDescription = stepDescription;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	@XmlTransient
	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	@PostLoad
	public void postLoad() {
		convertEffectiveDate();
	}

	public void convertEffectiveDate() {
		this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());
	}

	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}
	
}
