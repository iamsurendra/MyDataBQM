package com.artha.workbench.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.datahub.SrcColumnErrorInfo;
import com.artha.workbench.models.datahub.Srccolumns;
import com.artha.workbench.models.datahub.TgtColumns;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class SrccolumnsDAOImpl extends BaseDAOImpl<Srccolumns, Integer> implements SrccolumnsDAO {

	public SrccolumnsDAOImpl() {
		super(Srccolumns.class);
	}

	public List<SrcColumnErrorInfo> getPopuplist(String srcid) {
		//TODO need to include the srcextrainfo column values in the join query
		List<SrcColumnErrorInfo> taskdet = new ArrayList<SrcColumnErrorInfo>();
		TypedQuery<SrcColumnErrorInfo> query = entityManager.createQuery("from SrcColumnErrorInfo where srcRecordId = '" + srcid + "'",
				SrcColumnErrorInfo.class);
		if (query.getResultList() != null)
			taskdet = query.getResultList();
		return taskdet;
	}

	public List<TgtColumns> getTargetPopuplist(String tarid) {
		List<TgtColumns> taskdet = new ArrayList<TgtColumns>();
		TypedQuery<TgtColumns> query = entityManager.createQuery("from TgtColumns where tgtrecId = '" + tarid + "'",
				TgtColumns.class);
		if (query.getResultList() != null)
			taskdet = query.getResultList();
		return taskdet;
	}

	public void deleteAllSrcColumns(List<String> srcRecId) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Srccolumns> query = cb.createQuery(Srccolumns.class);
		Root<Srccolumns> root = query.from(Srccolumns.class);
		query.where(root.get("srcrec_id").in(srcRecId));
		deleteAll(this.entityManager.createQuery(query).getResultList());
	}

}
