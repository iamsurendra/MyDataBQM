package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "metastore.headerfootercol_v")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@IdClass(HeaderFooterColVwKey.class)
public class HeaderFooterColsVw extends AbstractModel {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "EntityFileTypeID")
	@JsonProperty("EntityFileTypeID")
	private Integer entityFileTypeId;
	
	@Column(name = "FileMask", nullable = false)
	@JsonProperty("FileMask")
	private String FileMask;
	
	@JsonProperty("EntityName")
	private String EntityName;
	
	@JsonProperty("HSFileType")
	private String HSFileType;
	
	@JsonProperty("RecType")
	private String RecType;
	
	@JsonProperty("SeqNum")
	private Integer SeqNum;
	
	@JsonProperty("ColumnID")
	private Integer ColumnID;
	
	@JsonProperty("ColumnName")
	private String ColumnName;
	
	@JsonProperty("Active")
	private String Active;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@JsonProperty("EffectiveDate")
	private Date EffectiveDate;
	
	
	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Transient
	@JsonIgnore
	private String Comments;
	
	
	@Transient
	@JsonIgnore
	private String effectiveDtstr;
	
	
	@Transient
	@JsonIgnore
	private boolean addMode;

	public HeaderFooterColsVw(boolean addMode,Date effctiveDate,Integer releaseNo) {
		this.addMode = addMode;
		this.EffectiveDate = effctiveDate;
		this.releaseNo = releaseNo;
		convertEffectiveDate();
	}

	public HeaderFooterColsVw() {

	}

	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}

	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}

	public String getFileMask() {
		return FileMask;
	}

	public void setFileMask(String fileMask) {
		FileMask = fileMask;
	}

	public String getEntityName() {
		return EntityName;
	}

	public void setEntityName(String entityName) {
		EntityName = entityName;
	}

	public String getHSFileType() {
		return HSFileType;
	}

	public void setHSFileType(String hSFileType) {
		HSFileType = hSFileType;
	}

	public String getRecType() {
		return RecType;
	}

	public void setRecType(String recType) {
		RecType = recType;
	}

	public Integer getSeqNum() {
		return SeqNum;
	}

	public void setSeqNum(Integer seqNum) {
		SeqNum = seqNum;
	}

	public Integer getColumnID() {
		return ColumnID;
	}

	public void setColumnID(Integer columnID) {
		ColumnID = columnID;
	}

	public String getColumnName() {
		return ColumnName;
	}

	public void setColumnName(String columnName) {
		ColumnName = columnName;
	}

	public String getActive() {
		return Active;
	}

	public void setActive(String active) {
		Active = active;
	}

	public Date getEffectiveDate() {
		return EffectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		EffectiveDate = effectiveDate;
	}

	public String getComments() {
		return Comments;
	}

	public void setComments(String comments) {
		Comments = comments;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public Integer getEntityFileTypeId() {
		return entityFileTypeId;
	}

	public void setEntityFileTypeId(Integer entityFileTypeId) {
		this.entityFileTypeId = entityFileTypeId;
	}
	
	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}

	@PostLoad
	public void postLoad(){
		convertEffectiveDate();
	}
	public void convertEffectiveDate(){
		this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());	
	}

}
