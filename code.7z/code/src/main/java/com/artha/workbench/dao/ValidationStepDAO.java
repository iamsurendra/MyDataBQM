package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.ValidationStep;
import com.guvvala.framework.dao.BaseDAO;

public interface ValidationStepDAO extends BaseDAO<ValidationStep, Integer> {

	public void savevalidationStep(List<ValidationStep> entitytypes);

	public int getmaxStepID();

	public void deleteValidationstep();

	public HashMap<String, Integer> loadStepId();

	HashMap<Integer, String> loadStepIdMap();

	public List<ValidationStep> getValidationStepListByReleaseNo(Integer releaseNo);

	List<Integer> getValidationStepReleaseNumbers(Set<Integer> stepIds, Integer selectedReleaseNumber);

	List<Integer> getAllValidationStepReleaseIds(Integer selectedReleaseId);
	
	List<ValidationStep> getValidationStepList(Set<Integer> stepIds,Integer selectedReleaseNumber);
	
	public List<Integer>loadeStepIds();
}
