package com.artha.workbench.models.userConfig;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name = "userconfig.userPreference")
public class UserPreference implements Serializable {

	/**
	 * serial version Id
	 */
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private UserPreferencePK userPreferencePK;
	
	@Column(name="USER_ID", insertable = false, updatable = false)
	private Long userId;
	
	@Column(name="PREFERENCE", insertable = false, updatable = false)
	private String preference;
	
	@Column(name="VALUE")
	private String value;
	

	@Transient
	private String valueInMinutes;
	

	//Getters & Setters


	
	public UserPreference() {
		
	}
	

	
	


	public void setUserPreferencePK(UserPreferencePK userPreferencePK) {
		this.userPreferencePK = userPreferencePK;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}


	public Long getUserId() {
		return userId;
	}


	public void setUserId(Long userId) {
		this.userId = userId;
	}


	public String getPreference() {
		return preference;
	}


	public void setPreference(String preference) {
		this.preference = preference;
	}


	public UserPreferencePK getUserPreferencePK() {
		return userPreferencePK;
	}
	

	public String getValueInMinutes() {
		return valueInMinutes;
	}

	public void setValueInMinutes(String valueInMinutes) {
		this.valueInMinutes = valueInMinutes;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userPreferencePK == null) ? 0 : userPreferencePK.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserPreference other = (UserPreference) obj;
		if (userPreferencePK == null) {
			if (other.userPreferencePK != null)
				return false;
		} else if (!userPreferencePK.equals(other.userPreferencePK))
			return false;
		return true;
	}


	@PostLoad
	public void postLoad() {
		if(getPreference().equalsIgnoreCase("timeout"))
		{
			// Converting milliseconds into minutes
			long value = Long.parseLong(getValue())/60000;
			this.valueInMinutes= String.valueOf(value);
			
		}
		
	}


	
}
