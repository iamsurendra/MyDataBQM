package com.artha.workbench.to;

public class PartnerFileTypeColumnsTO {
	
	private String colName;
	private Boolean writeMode;
	
	
	
	public PartnerFileTypeColumnsTO() {
	}
	
	public PartnerFileTypeColumnsTO(String colName, Boolean writeMode) {
		this.colName = colName;
		this.writeMode = writeMode;
	}
	public String getColName() {
		return colName;
	}
	public void setColName(String colName) {
		this.colName = colName;
	}

	public Boolean getWriteMode() {
		return writeMode;
	}

	public void setWriteMode(Boolean writeMode) {
		this.writeMode = writeMode;
	}

	
	
}
