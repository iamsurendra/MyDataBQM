package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.SourceToTargetSplitDAO;
import com.artha.workbench.dao.SourceToTargetSplitVwDAO;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.models.metastore.SourceToTargetSplit;
import com.artha.workbench.models.metastore.SourceToTargetSplitKey;
import com.artha.workbench.models.metastore.SourceToTargetSplitVw;
import com.artha.workbench.models.metastore.SourceToTargetSplitVwKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("sourceToTargetSplitService")
public class SourceToTargetSplitServiceImpl implements SourceToTargetSplitService {
	
	@Autowired
	SourceToTargetSplitVwDAO sourceToTargetSplitVwDAO;
	
	@Autowired
	SourceToTargetSplitDAO sourceToTargetSplitDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Transactional
	public List<SourceToTargetSplitVw> getSourceToTargetSplitVwList()
	{
		return sourceToTargetSplitVwDAO.findAll();
	}
	
	@Transactional
	public void create(SourceToTargetSplitVw sourceToTargetSplitVw) {
		SourceToTargetSplit sourceToTargetSplit = new SourceToTargetSplit();
		SourceToTargetSplitKey sourceToTargetSplitKey = new SourceToTargetSplitKey();
		sourceToTargetSplitKey.setSourceEntityFileTypeID(sourceToTargetSplitVw.getSourceEntityFileTypeID());
		sourceToTargetSplitKey.setTargetEntityFileTypeID(sourceToTargetSplitVw.getTargetEntityFileTypeID());
		sourceToTargetSplit.setSourceToTargetSplitKey(sourceToTargetSplitKey);
		loadSourceToTargetSplit(sourceToTargetSplit, sourceToTargetSplitVw);
		sourceToTargetSplitDAO.create(sourceToTargetSplit);
	}
	
	@Transactional
	public SourceToTargetSplit loadSourceToTargetSplit(SourceToTargetSplit sourceToTargetSplit, SourceToTargetSplitVw sourceToTargetSplitVw) {
		sourceToTargetSplit.setSplitCriteria(sourceToTargetSplitVw.getSplitCriteria());
		sourceToTargetSplit.setActive(sourceToTargetSplitVw.getActive());
		sourceToTargetSplit.setEffectiveDate(sourceToTargetSplitVw.getEffectiveDate());
		sourceToTargetSplit.setReleaseNo(sourceToTargetSplitVw.getReleaseNum());
	return 	sourceToTargetSplit;
    }
	
	@Transactional
	public void update(SourceToTargetSplitVw sourceToTargetSplitVw, boolean isReleaseChanged) throws JsonProcessingException {
		SourceToTargetSplitKey sourceToTargetSplitKey = new SourceToTargetSplitKey();
		sourceToTargetSplitKey.setSourceEntityFileTypeID(sourceToTargetSplitVw.getSourceEntityFileTypeID());
		sourceToTargetSplitKey.setTargetEntityFileTypeID(sourceToTargetSplitVw.getTargetEntityFileTypeID());
		checkForCyclicDependency(sourceToTargetSplitVw);
		SourceToTargetSplit sourceToTargetSplit = sourceToTargetSplitDAO.findOne(sourceToTargetSplitKey);
		
		if (isReleaseChanged) {
			SourceToTargetSplitVwKey sourceToTargetSplitVwKey = new SourceToTargetSplitVwKey();
			sourceToTargetSplitVwKey.setSourceEntityFileTypeID(sourceToTargetSplitVw.getSourceEntityFileTypeID());
			sourceToTargetSplitVwKey.setSourceEntityName(sourceToTargetSplitVw.getSourceEntityName());
			sourceToTargetSplitVwKey.setSourceFileMask(sourceToTargetSplitVw.getSourceFileMask());
			sourceToTargetSplitVwKey.setSourceHsFileType(sourceToTargetSplitVw.getSourceHsFileType());
			sourceToTargetSplitVwKey.setTargetEntityFileTypeID(sourceToTargetSplitVw.getTargetEntityFileTypeID());
			sourceToTargetSplitVwKey.setTargetEntityName(sourceToTargetSplitVw.getTargetEntityName());
			sourceToTargetSplitVwKey.setTargetFileMask(sourceToTargetSplitVw.getTargetFileMask());
			sourceToTargetSplitVwKey.setTargetHsFileType(sourceToTargetSplitVw.getTargetHsFileType());
			SourceToTargetSplitVw oldEntity = sourceToTargetSplitVwDAO.findOne(sourceToTargetSplitVwKey);
			if(oldEntity!=null){
		    ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			
			releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNum());
			releaseArchiveKey.setReleaseId(sourceToTargetSplitVw.getReleaseNum());
			releaseArchiveKey.setTableName("SOURCETOTARGETSPLIT");
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(sourceToTargetSplit.getSourceToTargetSplitKey()));
			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if(releaseArchive!=null){
				releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToTargetSplit));
				releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToTargetSplitVwKey));
				releaseArchiveDAO.update(releaseArchive);
			}else{
				releaseArchive = new ReleaseArchive();
				releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToTargetSplit));
				releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToTargetSplitVwKey));
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchiveDAO.create(releaseArchive);
			}
			}
		}
		if (sourceToTargetSplit != null) {
			sourceToTargetSplit.setActive(sourceToTargetSplitVw.getActive());
			sourceToTargetSplit.setEffectiveDate(sourceToTargetSplitVw.getEffectiveDate());
			sourceToTargetSplit.setReleaseNo(sourceToTargetSplitVw.getReleaseNum());
			sourceToTargetSplit.setSplitCriteria(sourceToTargetSplitVw.getSplitCriteria());
			sourceToTargetSplitDAO.update(sourceToTargetSplit);
		}
	}
	
	private void checkForCyclicDependency(SourceToTargetSplitVw sourceToTargetSplitVw) throws JsonProcessingException	{
		SourceToTargetSplitKey sourceToTargetSplitKey = new SourceToTargetSplitKey();
		sourceToTargetSplitKey.setSourceEntityFileTypeID(sourceToTargetSplitVw.getSourceEntityFileTypeID());
		sourceToTargetSplitKey.setTargetEntityFileTypeID(sourceToTargetSplitVw.getTargetEntityFileTypeID());
		String jsonId = AppWebUtils.convertObjectToJson(sourceToTargetSplitKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(sourceToTargetSplitVw.getReleaseNum(), "SOURCETOTARGETSPLIT", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	
	@Transactional
	public List<SourceToTargetSplitVw> getSourceToTargetSplitVwListByReleaseNo(Integer releaseNo) {
		return sourceToTargetSplitVwDAO.getSourceToTargetSplitListByReleaseNo(releaseNo);
	}
	
	@Transactional
	public List<SourceToTargetSplit> getSourceToTargetSplitListByReleaseNo(Integer releaseNo) {
		return sourceToTargetSplitDAO.getSourceToTargetSplitListByReleaseNo(releaseNo);
	}
	
	@Transactional
	public SourceToTargetSplitVw getPreviousSourceToTargetSplitVw(SourceToTargetSplitVw sourceToTargetSplitVw) throws IOException {
		SourceToTargetSplitKey sourceToTargetSplitKey = new SourceToTargetSplitKey();
		sourceToTargetSplitKey.setSourceEntityFileTypeID(sourceToTargetSplitVw.getSourceEntityFileTypeID());
		sourceToTargetSplitKey.setTargetEntityFileTypeID(sourceToTargetSplitVw.getTargetEntityFileTypeID());
		String sourceToTargetSplitVwJson = AppWebUtils.convertObjectToJson(sourceToTargetSplitKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(sourceToTargetSplitVw.getReleaseNum(), "SOURCETOTARGETSPLIT", sourceToTargetSplitVwJson);
		SourceToTargetSplitVw previousSourceToTargetSplitVw = new SourceToTargetSplitVw();
		if(releaseArchive!=null){
			previousSourceToTargetSplitVw = AppWebUtils.convertJsonToObject(SourceToTargetSplitVw.class, releaseArchive.getViewRecData());
		}
		return previousSourceToTargetSplitVw;
	}
	
	@Transactional
	public SourceToTargetSplit getSourceToTargetSplit(SourceToTargetSplitVw sourceToTargetSplitVw) {
		SourceToTargetSplitKey sourceToTargetSplitKey = new SourceToTargetSplitKey();
		sourceToTargetSplitKey.setSourceEntityFileTypeID(sourceToTargetSplitVw.getSourceEntityFileTypeID());
		sourceToTargetSplitKey.setTargetEntityFileTypeID(sourceToTargetSplitVw.getTargetEntityFileTypeID());
		SourceToTargetSplit sourceToTargetSplit = sourceToTargetSplitDAO.findOne(sourceToTargetSplitKey);
		return sourceToTargetSplit;
	}
}
