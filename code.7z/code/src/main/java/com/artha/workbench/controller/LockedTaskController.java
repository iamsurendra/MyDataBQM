package com.artha.workbench.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.models.datahub.LockedTask;
import com.artha.workbench.service.LockedTaskService;

@RestController
@RequestMapping("/api/lockedTask")

public class LockedTaskController {

	@Autowired
	LockedTaskService lockedTaskService;

	@RequestMapping(value = "/getLockedTasksList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<LockedTask> getLockedTasksList() {
		return lockedTaskService.getLockedTasksList();
	}

	@RequestMapping(value = "/unlockListOfTasks", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void unlockEditLockTask(@RequestBody List<String> lockedTaskIdList) {
		lockedTaskService.unlockEditLockTask(lockedTaskIdList);
	}

}
