package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EntityFileTypeScheduleXref;
import com.artha.workbench.to.FileMaskTO;
import com.guvvala.framework.dao.BaseDAO;

public interface EntityFileTypeScheduleXrefDAO extends BaseDAO<EntityFileTypeScheduleXref, Integer> {
	public void saveEntityFileTypeScheduleXref(List<EntityFileTypeScheduleXref> entitytypes);

	public void deleteEntityFileTypeScheduleXref();

	public int getMaxEntitySchedID();

	public List<FileMaskTO> loadFileMaskTO();

	public List<FileMaskTO> searchFileMaskTO(String fileMask, String description);

	public List<EntityFileTypeScheduleXref> getEntityFileTypeScheduleXrefList(Integer releaseNO);

	List<Integer> getAllEntityFileTypeSchXrefReleaseIds(Integer selectedReleaseId);

	public List<Integer> getEntityFileTypeSchedIds();

}
