package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.SavedQuery;
import com.guvvala.framework.dao.BaseDAO;

public interface SavedQueryDAO extends BaseDAO<SavedQuery, Integer>{

	public List<SavedQuery> getSavedQueryData(String createdBy);
	public SavedQuery getSavedQueryInfo(String queryName);
	
}
