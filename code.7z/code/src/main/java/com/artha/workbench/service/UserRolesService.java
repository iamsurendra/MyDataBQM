package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.models.userConfig.FileTypeColumns;
import com.artha.workbench.models.userConfig.Hssecurityrole;
import com.artha.workbench.models.userConfig.PartnerFileTypes;
import com.artha.workbench.models.userConfig.Roles;
import com.artha.workbench.models.userConfig.UserRoles;

public interface UserRolesService {
	public void update(UserRoles userRoles);

	public List<UserRoles> getUserRoles(int loginId);

	public List<UserRoles> getUserRolesDetails(int loginid);

	public List<Roles> getRolesList();

	public Roles saveUserRole(Roles roles);

	public void savePrivileges(Hssecurityrole hssecurityrole);

	public Roles findRoleById(Long roleId);

	public List<Long> findPartnerByRoleID(Long roleId);

	public List<Long> findFileTypeByPartnerID(Long partnerID);

	public List<PartnerFileTypes> findAllPartner();

	public List<PartnerFileTypes> findAllFileTypes(Long partnerID);

	public List<PartnerFileTypes> findAllFileTypes(List<Long> ids);

	public PartnerFileTypes findPartnerById(Long id);

	public List<FileTypeColumns> findColumnsByEntityFileTypeID(Long id);
	
	public List<FileTypeColumns> findFileTypeColumnsByEntityFileTypeID(Long id);
	
	public PartnerFileTypes findFileTypeID(Long id);
	
	public void submitUserRoles(List<Hssecurityrole> hssecurityrole,Long roleId);
	
	public boolean duplicateRoleName(String roleName);

	public List<Long> findFileTypeByPartnerIDRoleId(Long partnerCD, Long id);
	
	List<Hssecurityrole> findColumnsByPartnerIdFileTypeID(Long partnerTypeId,Long fileTypeid,Long roleId);
	
	void updateUserRole(Roles roles);
	
	String findFileTypeAbbr(Long fileTypeId);

	String findPartnerAbbr(Long entityId);
	
	List<Hssecurityrole> findAllByRoleID(Long roleId);
	
	List<PartnerFileTypes> partnerFileTypesList();
	
	List<String> getColumnsByEntityFileTypeId(Long id);

	void submitUserRoles(List<Hssecurityrole> hssecurityrole, List<Long> partnerIdsList, List<Long> fileTypeIdsList,
			Long roleId);

	boolean userRolesExists(List<Long> partnerIdsList, List<Long> fileTypeIdsList, Long roleId);
	
	List<Hssecurityrole> findHssecurityroleByPartnerIdRoleID(Long partnerTypeId,Long roleId);
	
	List<PartnerFileTypes> getPartnerFileTypesBypartnerId(Long partnerId, List<Long> entityTypeIds);



}
