package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.SourceToTargetMapping;
import com.artha.workbench.models.metastore.SourceToTargetMappingKey;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class SourceToTargetMappingDAOImpl extends BaseDAOImpl<SourceToTargetMapping, SourceToTargetMappingKey> implements SourceToTargetMappingDAO {

	public SourceToTargetMappingDAOImpl() {
		super(SourceToTargetMapping.class);
	}
	public void saveSourceToTargetMappingS(List<SourceToTargetMapping> entitytypes)
	{
		batchCreate(entitytypes, 50);
	}

	public void deleteSourcetotargetMapping() {
		Query query = entityManager.createQuery("delete from SourceToTargetMapping");
		query.executeUpdate();
	}
	
	@Transactional
	public List<SourceToTargetMapping> getSourceToTargetMappingListByReleaseNo(Integer releaseNo)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SourceToTargetMapping> query = cb.createQuery(SourceToTargetMapping.class);
		Root<SourceToTargetMapping> root = query.from(SourceToTargetMapping.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllSourceToTargetMappingReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from SourceToTargetMapping where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
}
