package com.artha.workbench.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.beanParams.TaskBeanParam;
import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.constant.TaskStatus;
import com.artha.workbench.constant.WBConstants;
import com.artha.workbench.models.datahub.SrcColumnErrorInfo;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.models.datahub.TgtColumns;
import com.artha.workbench.models.userConfig.FileTypeColumns;
import com.artha.workbench.models.userConfig.PartnerFileTypes;
import com.artha.workbench.service.LockedTaskService;
import com.artha.workbench.service.PopUpService;
import com.artha.workbench.service.TaskService;
import com.artha.workbench.service.TaskTypeService;
import com.artha.workbench.service.UserRolesService;
import com.artha.workbench.service.UserService;
import com.artha.workbench.to.TaskEditTO;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.filter.BaseFilter;
import com.guvvala.framework.filter.DateFilter;
import com.guvvala.framework.filter.FilterUtils;
import com.guvvala.framework.filter.StringFilter;
import com.guvvala.framework.util.AppUser;
import com.guvvala.framework.util.ThreadLocalUtil;

@RestController
@RequestMapping("/api/workbench")
public class WorkbenchController {

	@Autowired
	TaskService taskService;

	@Autowired
	TaskTypeService taskTypeService;

	@Autowired
	UserService userService;

	@Autowired
	UserRolesService userRolesService;

	@Autowired
	private PopUpService popUpService;

	@Autowired
	private LockedTaskService lockTaskService;

	private static final String PATTERN = "^[a-zA-Z0-9]+_+[a-zA-Z]+_+.*$";

	@RequestMapping(value = "/getAllTaskList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Task> getAllTaskList() {
		List<Task> taskList = new ArrayList<>();
		if (ThreadLocalUtil.getUser().isSadmin() || ThreadLocalUtil.getUser().isAdmin()) {
			taskList = taskService.getTaskList();
		} else {
			taskList = taskService.getTaskByAccessRight(ThreadLocalUtil.getUser().getTaskAccessRights());
		}
		Map<Integer, String> taskTypeMap = taskTypeService.loadtaskType();
		for (Task task : taskList) {
			task.setTypeStr(taskTypeMap.get(task.getType_id()));
		}
		return taskList;
	}

	@RequestMapping(value = "/deleteSelectedTasks", method = RequestMethod.POST)
	public void deleteSelectedTasks(@RequestBody List<String> taskIdList) {
		for (String taskId : taskIdList) {
			Task task = taskService.findOne(taskId);
			if (TaskStatus.RESOLVED.value.equalsIgnoreCase(task.getStatus())
					|| TaskStatus.LOCKED.value.equalsIgnoreCase(task.getStatus())) {
				throw new AppException(MessagesEnum.RESOLVED_OR_LOCKED_TASKS_CANT_BE_DELETED);
			}
		}
		taskService.delete(taskIdList);
	}

	@RequestMapping(value = "/changeStatus/{selectedStatus}", method = RequestMethod.POST)
	public void changeStatus(@PathVariable("selectedStatus") String selectedStatus,
			@RequestBody List<String> taskIdList) {
		List<String> tempLockList = new ArrayList<String>();
		List<String> resolveList = new ArrayList<String>();
		for (String taskId : taskIdList) {
			Task task = taskService.findOne(taskId);
			if (task.getStatus().equalsIgnoreCase(TaskStatus.TEMP_LOCK.value)) {
				tempLockList.add(task.getTask_id());
			}
			if (task.getStatus().equalsIgnoreCase(TaskStatus.RESOLVED.value)) {
				resolveList.add(task.getTask_id());
			}
		}
		boolean lockedByOtherUsers = taskService.findLockedTaskByOtherUser(tempLockList,
				ThreadLocalUtil.getUser().getUserName());
		if (lockedByOtherUsers) {
			throw new AppException(MessagesEnum.TASK_LOCKED_OTHER_USER);
		}
		taskService.changeStatus(taskIdList, selectedStatus, ThreadLocalUtil.getUser().getUserName(), resolveList);
	}

	@RequestMapping(value = "/taskSearch", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Task> normalSearch(@RequestBody TaskBeanParam taskBeanParam) {
		AppUser user = ThreadLocalUtil.getUser();
		if (taskBeanParam.isNormalSearch()) {
			Set<BaseFilter> normalSearchFilters = taskService.getNormalSearchFilters(taskBeanParam);
			boolean adminFlag = user.isSadmin() || user.isAdmin();
			return taskService.getNorSearchlist(normalSearchFilters, adminFlag,
					userService.getTaskAccessRights(user.getGroupid()));
		} else if (taskBeanParam.isAdvSearch()) {

			String partnertAbbr = userRolesService.findPartnerAbbr(taskBeanParam.getSelectedPartner());
			String fileTypeAbbr = userRolesService.findFileTypeAbbr(taskBeanParam.getSelectedFileType());
			String entityFileTypeId = null;
			if (taskBeanParam.getSelectedFileType() != null) {
				entityFileTypeId = taskBeanParam.getSelectedFileType().toString();
			}
			if (!taskBeanParam.atleastOneEntered()) {
				throw new AppException(MessagesEnum.ADV_SEARCH_EMPTY_MSG);
			} else if (!taskBeanParam.allColumnInfoEntered()) {
				throw new AppException(MessagesEnum.ADV_SEARCH_EMPTY_MSG);
			}

			if (user.isSadmin() || user.isAdmin()) {
				return taskService.getSearchlist(taskBeanParam, partnertAbbr, fileTypeAbbr, entityFileTypeId);
			} else {
				return taskService.getNormaluserSearchlist(taskBeanParam, partnertAbbr, fileTypeAbbr, entityFileTypeId,
						user.getTaskAccessRights());
			}

		} else {

			List<Task> taskList = new ArrayList<>();
			if (ThreadLocalUtil.getUser().isSadmin() || ThreadLocalUtil.getUser().isAdmin()) {
				taskList = taskService.getTaskList();
			} else {
				taskList = taskService.getTaskByAccessRight(ThreadLocalUtil.getUser().getTaskAccessRights());
			}
			Map<Integer, String> taskTypeMap = taskTypeService.loadtaskType();
			for (Task task : taskList) {
				task.setTypeStr(taskTypeMap.get(task.getType_id()));
			}
			return taskList;
		}

	}

	@RequestMapping(value = "/customStringOperators", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Collection<String> getStringFilterOperators() {
		return FilterUtils.getStringFilterOperators();
	}

	@RequestMapping(value = "/customDateOperators", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Collection<String> getCustomDateFilterOperators() {
		return FilterUtils.getCustomDateFilterOperators();
	}

	@RequestMapping(value = "/findAllPartner", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<PartnerFileTypes> findAllPartner() {
		return userRolesService.findAllPartner();
	}

	@RequestMapping(value = "/findAllFileTypesByPartnerId/{partnerID}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<PartnerFileTypes> findAllFileTypes(@PathVariable("partnerID") Long partnerID) {
		return userRolesService.findAllFileTypes(partnerID);
	}

	@RequestMapping(value = "/fileTypeColumnsByFileTypeId/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FileTypeColumns> findColumnsByEntityFileTypeID(@PathVariable("Id") Long id) {
		return userRolesService.findColumnsByEntityFileTypeID(id);
	}

	@RequestMapping(value = "/validatePopUpNavigation", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void validatePopUp(@RequestBody Map<String, Object> taskDetails) {
		List<String> taskIds = (List<String>) taskDetails.get("selectedTaskIds");
		boolean isNavigation = (boolean) taskDetails.get("isNavigation");
		boolean isMultiEdit = (boolean) taskDetails.get("isMultiEdit");
		List<String> tempLocktaskIdList = new ArrayList<>();

		AppUser user = ThreadLocalUtil.getUser();
		List<Task> selectedTaskList = taskService.getAllTasks(taskIds);
		for (Task task : selectedTaskList) {
			if ((user.isSadmin() || user.isAdmin()) && isNavigation && !validateTaskId(task.getTask_id())) {
				throw new AppException(MessagesEnum.INVALID_TASK_ID_PATTERN);
			}
			if (task.getStatus().equalsIgnoreCase(TaskStatus.TEMP_LOCK.value)) {
				tempLocktaskIdList.add(task.getTask_id());
			}
			if (!isNavigation) {
				if (task.getStatus().equalsIgnoreCase(TaskStatus.LOCKED.value)) {
					throw new AppException(MessagesEnum.TASK_LOCKED_CANNOT_NAVIGATE);
				}
				if (task.getStatus().equalsIgnoreCase(TaskStatus.RESOLVED.value)) {
					throw new AppException(MessagesEnum.TASK_RESOLVED_CANNOT_NAVIGATE);
				}
			}
		}
		// check if temporary lock is available
		if (taskService.findLockedTaskByOtherUser(tempLocktaskIdList, ThreadLocalUtil.getUserName())) {
			throw new AppException(MessagesEnum.TASK_LOCKED_OTHER_USER);
		}
	}

	@RequestMapping(value = "/getPopUpDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public TaskEditTO getPopUpDetails(@RequestBody Map<String, Object> taskDetails) {
		String currentTaskId = (String) taskDetails.get("currentTaskId");
		String previousTaskId = (String) taskDetails.get("previousTaskId");
		boolean isSingleEdit = (boolean) taskDetails.get("isSingleEdit");
		TaskEditTO to = new TaskEditTO();
		AppUser user = ThreadLocalUtil.getUser();
		List<Task> selectedTaskList = new ArrayList<Task>();
		if (user.isSadmin() || user.isAdmin()) {
			selectedTaskList = taskService.getAllTasks(Arrays.asList(currentTaskId));
		} else {
			selectedTaskList = taskService.getAllTasksByAccessRight(Arrays.asList(currentTaskId),
					user.getTaskAccessRights());
		}
		to.setTaskName(selectedTaskList.get(0).getTask_name());
		List<TgtColumns> popUpTargetList = new LinkedList<TgtColumns>();
		LinkedList<SrcColumnErrorInfo> srcColumnErrInfoList = new LinkedList<SrcColumnErrorInfo>();
		String srcrecid = popUpService.getSrcrecid(currentTaskId);
		String tarrecid = popUpService.getTargetrecid(currentTaskId);

		// -158
		String taskID[] = currentTaskId.split("_");
		// 158
		String entityType = taskID[2].replace("-", "");
		Integer entityTypeId = Integer.parseInt(entityType);
		srcColumnErrInfoList = popUpService.getPopuplist(srcrecid, currentTaskId, entityTypeId);
		List<TgtColumns> popUpTargets = popUpService.getTargetPopuplist(tarrecid);
		List<TgtColumns> newTgtColumns = new LinkedList<>();
		String taskStatus = selectedTaskList.get(0).getStatus();
		to.setTaskStatus(taskStatus);
		for (SrcColumnErrorInfo srccolumn : srcColumnErrInfoList) {
			if (TaskStatus.NEW.value.equals(taskStatus)) {
				TgtColumns newTgtColumn = new TgtColumns();
				newTgtColumn.setDefColName(srccolumn.getColumnName());
				newTgtColumn.setSourceValue(srccolumn.getColumnValue());
				newTgtColumn.setErrorValue(srccolumn.getErrorValue());
				newTgtColumn.setUpdated(true);
				newTgtColumns.add(newTgtColumn);
			} else {
				for (TgtColumns tgtColumn : popUpTargets) {
					if (srccolumn.getColumnName().equalsIgnoreCase(tgtColumn.getDefColName())) {
						// If modified value is other than source value then
						// we populate that as old value
						if (tgtColumn.getDefColValue() != null && !tgtColumn.getDefColValue().isEmpty()) {
							tgtColumn.setOldValue(tgtColumn.getDefColValue());
						} else {
							tgtColumn.setOldValue(srccolumn.getColumnValue());
							tgtColumn.setUpdated(true);
						}
						tgtColumn.setSourceValue(srccolumn.getColumnValue());
						tgtColumn.setErrorValue(srccolumn.getErrorValue());
						popUpTargetList.add(tgtColumn);
						break;
					}
				}
			}
		}
		if (TaskStatus.NEW.value.equals(taskStatus)) {
			popUpTargetList = newTgtColumns;
		}
		// TODO need to check the userId for insertion into locking
		// tables
		popUpService.lockTask(currentTaskId, ThreadLocalUtil.getUserName(), TaskStatus.TEMP_LOCK.value);
		List<TgtColumns> normalUsertgtList = new LinkedList<TgtColumns>();
		if (!(user.isSadmin() || user.isAdmin())) {
			// Get the partner_filetype from taskId, start for security
			// AEP_PFP_123444
			String taskKey = getKeyforTaskId(currentTaskId);
			for (TgtColumns tgtColumn : popUpTargetList) {
				// append the task Id key along with column name
				String key = taskKey.concat("_").concat(tgtColumn.getDefColName());
				if (user.getColAccessRights().containsKey(key)) {
					tgtColumn.setWriteMode(user.getColAccessRights().get(key));
					if (tgtColumn.getWriteMode() == 1) {
						to.setSaveDisabled(false);
					}
					if (tgtColumn.getWriteMode() == 1 || tgtColumn.getWriteMode() == 0) {
						normalUsertgtList.add(tgtColumn);
					}
					// If modified value is null or empty then we
					// populate old value as source value
					if (!TaskStatus.NEW.value.equals(taskStatus)) {
						if (tgtColumn.getDefColValue() == null || tgtColumn.getDefColValue().isEmpty()) {
							if (isSingleEdit) {
								String status = selectedTaskList.get(0).getStatus();
								if (!TaskStatus.RESOLVED.value.equalsIgnoreCase(status)) {
									if (TaskStatus.TEMP_LOCK.value.equalsIgnoreCase(status)) {
										if (!taskService.findLockedTaskByOtherUser(Arrays.asList(currentTaskId),
												ThreadLocalUtil.getUserName())) {
											tgtColumn.setDefColValue(tgtColumn.getOldValue());
										}
									} else {
										tgtColumn.setDefColValue(tgtColumn.getOldValue());
									}
								}
							} else {
								tgtColumn.setDefColValue(tgtColumn.getOldValue());
							}
						}
					}
				}
			}
		} else {
			for (TgtColumns tgtColumn : popUpTargetList) {
				// set write mode for the superadmin
				tgtColumn.setWriteMode(1);
				if (!TaskStatus.NEW.value.equals(taskStatus)) {
					if (tgtColumn.getDefColValue() == null || tgtColumn.getDefColValue().isEmpty()) {
						if (isSingleEdit) {
							String status = selectedTaskList.get(0).getStatus();
							if (!TaskStatus.RESOLVED.value.equalsIgnoreCase(status)) {
								if (TaskStatus.TEMP_LOCK.value.equalsIgnoreCase(status)) {
									if (!taskService.findLockedTaskByOtherUser(Arrays.asList(currentTaskId),
											ThreadLocalUtil.getUserName())) {
										tgtColumn.setDefColValue(tgtColumn.getOldValue());
									}
								} else {
									tgtColumn.setDefColValue(tgtColumn.getOldValue());
								}
							}
						} else {
							tgtColumn.setDefColValue(tgtColumn.getOldValue());
						}
					}
				}
				to.setSaveDisabled(false);
			}
		}
		if (!(user.isSadmin() || user.isAdmin())) {
			popUpTargetList = normalUsertgtList;
		}
		to.setTargetList(popUpTargetList);
			if (selectedTaskList.get(0).getTask_id().trim().equals(currentTaskId.trim())) {
				// To check templocked by other user for single edit
				if (isSingleEdit) {
					if (TaskStatus.TEMP_LOCK.value.equalsIgnoreCase(taskStatus)) {
						if (taskService.findLockedTaskByOtherUser(Arrays.asList(currentTaskId),
								ThreadLocalUtil.getUserName())) {
							to.setTaskLockedByOtherUser(true);
						}
					}
				}
		}
		if (taskStatus.equalsIgnoreCase(TaskStatus.RESOLVED.value) || taskStatus.equalsIgnoreCase(TaskStatus.LOCKED.value)
				|| to.isTaskLockedByOtherUser()) {
			to.setSaveDisabled(true);
		}

		return to;
	}

	private String getKeyforTaskId(String tempTaskId) {
		// TODO need to convert to string buffer
		// PartnerName_FileName_EntityFileTypeId
		String key = new String();
		String[] parts = tempTaskId.split("_");
		String[] firstThreeEntries = Arrays.copyOf(parts, 3);
		boolean firstTime = true;
		for (String entry : firstThreeEntries) {
			if (firstTime) {
				key = key.concat(entry);
				firstTime = false;
			} else {
				key = key.concat("_");
				key = key.concat(entry);
			}
		}

		return key;
	}

	/**
	 * Validation for TaskId
	 * 
	 */
	public boolean validateTaskId(String s) {
		return s.matches(PATTERN);
	}
	

}
