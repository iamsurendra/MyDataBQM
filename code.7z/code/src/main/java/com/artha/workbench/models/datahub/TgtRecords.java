package com.artha.workbench.models.datahub;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.NamedQuery;
import org.hibernate.envers.Audited;

import com.guvvala.framework.util.DateUtils;
import com.artha.workbench.models.metastore.AbstractModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Entity
@Table(name = "datahub.tgtrecords")
@Audited
@NamedQuery(name = "findTgtRecordByTaskId", query = "from TgtRecords tgtRecord where tgtRecord.taskId = :taskId")
@JsonPropertyOrder({"tableName","revRequired","tgtrecId","resolvedBy","resolvedOn","Revision_Type","LAST_UPD_BY"})
public class TgtRecords extends AbstractModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "tgtrec_id")
	@JsonProperty("tgtrec_id")
	private String tgtrecId;

	@Column(name = "task_id")
	@JsonIgnore
	private String taskId;

	@Column(name = "resolved_by")
	@JsonProperty("resolved_by")
	private String resolvedBy;

	@Column(name = "resolved_on")
	@Temporal(TemporalType.TIMESTAMP)
	@JsonProperty("resolved_on")
	private Date resolvedOn;
	
	@Transient
	private String tableName="tgtrecords";
	
	@Transient
	private String revRequired="true";
	
	@Transient
	@JsonProperty("Revision_Type")
	private String revision_type="1";
	
	@Transient
	@JsonProperty("LAST_UPD_BY")
	private String last_upd_by;

	public String getTgtrecId() {
		return tgtrecId;
	}

	public void setTgtrecId(String tgtrecId) {
		this.tgtrecId = tgtrecId;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getResolvedBy() {
		return resolvedBy;
	}

	public void setResolvedBy(String resolvedBy) {
		this.resolvedBy = resolvedBy;
	}

	public String getResolvedOn() {
		return DateUtils.convertDateFormat(resolvedOn, DateUtils.DATE_TIME_FORMAT_MM_DD_YYYY_HH_MM_SS);
	}

	public void setResolvedOn(Date resolvedOn) {
		this.resolvedOn = resolvedOn;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}


	public String getRevision_type() {
		return revision_type;
	}

	public void setRevision_type(String revision_type) {
		this.revision_type = revision_type;
	}

	public String getRevRequired() {
		return revRequired;
	}

	public void setRevRequired(String revRequired) {
		this.revRequired = revRequired;
	}

	public String getLast_upd_by() {
		return last_upd_by;
	}

	public void setLast_upd_by(String last_upd_by) {
		this.last_upd_by = last_upd_by;
	}

}
