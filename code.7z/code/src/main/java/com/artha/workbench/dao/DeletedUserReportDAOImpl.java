package com.artha.workbench.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.artha.workbench.models.userConfig.User;
import com.artha.workbench.to.DeletedUserTO;
@Repository
public class DeletedUserReportDAOImpl extends BaseDAOImpl<User, Integer> implements DeletedUserReportDAO {

	public DeletedUserReportDAOImpl() {
		super(User.class);
	}

	@Override
	public List<DeletedUserTO> fetchDeletedUserList() {
		List<DeletedUserTO> delUserList = new ArrayList<DeletedUserTO>();
		Query query = entityManager
				.createNativeQuery("select USERS_rev.USER_NAME,USERS_rev.FIRST_NAME,USERS_rev.LAST_NAME,USERS_rev.EMAIL,USERS_rev.ADMIN,USERS_rev.SUPER_ADMIN,revisionhistory.LAST_UPD_DT,revisionhistory.LAST_UPD_BY from USERS_rev , revisionhistory where revisionhistory.REV_ID= USERS_rev.REV_ID and USERS_rev.REVISION_TYPE=2");
		
		List<Object[]> results = query.getResultList();
		for (Object[] values : results)
		{
			DeletedUserTO delUser= new DeletedUserTO();
			delUser.setUserName((String)values[0]);
			//TODO set values
			delUserList.add(delUser);
		}
		return delUserList;
	}

}
