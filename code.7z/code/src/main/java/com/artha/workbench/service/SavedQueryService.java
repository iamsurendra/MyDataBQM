package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.models.userConfig.SavedQuery;


public interface SavedQueryService {

	public List<SavedQuery> getSavedQueryData(String createdBy);
	
	public List<SavedQuery> getAllSavedQuerys();

	public void saveSearchCriteria(String queryName, String json);

	public SavedQuery getSavedQueryInfo(String queryName);
	
	public void deleteSavedQuery(Integer SavedQueryId);

}
