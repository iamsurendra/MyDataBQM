package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.SourceToWebServiceMapping;
import com.artha.workbench.models.metastore.SourceToWebServiceMappingVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface SourceToWebServiceMappingService {

	List<SourceToWebServiceMappingVw> getSourceToWebServiceMappingVwList();
	void create(SourceToWebServiceMappingVw sourceToWebServiceMappingVw);
	void update(SourceToWebServiceMappingVw sourceToWebServiceMappingVw,boolean isReleaseChanged)throws JsonProcessingException;
	public List<SourceToWebServiceMappingVw> getsourceToWebServiceMappingVwListByReleaseNum (Integer releaseNum);
	public List<SourceToWebServiceMapping> getsourceToWebServiceMappingListByReleaseNum (Integer releaseNum);
	public SourceToWebServiceMappingVw getPreviousSourceToWebServiceMappingVw(SourceToWebServiceMappingVw sourceToWebServiceMappingVw) throws IOException;
	public SourceToWebServiceMapping getSourceToWebServiceMapping(SourceToWebServiceMappingVw sourceToWebServiceMappingVw);
}
