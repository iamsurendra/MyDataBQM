package com.artha.workbench.dao;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.artha.workbench.models.userConfig.ChartQuery;
import com.artha.workbench.to.ChartQueryTO;

public interface ChartQueryDAO extends BaseDAO<ChartQuery, Integer> {

	List<ChartQueryTO> executeQueries();
}
