package com.artha.workbench.models.datahub;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class LockedTaskPK implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name="task_id")
	private String taskId;
	

	@Column(name="LOCK_TYPE")
	private String lockType;


	public String getTaskId() {
		return taskId;
	}


	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}


	public String getLockType() {
		return lockType;
	}


	public void setLockType(String lockType) {
		this.lockType = lockType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((taskId == null) ? 0 : taskId.hashCode());
		result = prime * result + ((lockType == null) ? 0 : lockType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LockedTaskPK other = (LockedTaskPK) obj;
		if (taskId == null) {
			if (other.taskId != null)
				return false;
		} else if (!taskId.equals(other.taskId))
			return false;
		if (lockType == null) {
			if (other.lockType != null)
				return false;
		} else if (!lockType.equals(other.lockType))
			return false;
		return true;
	}


}
