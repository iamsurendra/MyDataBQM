package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.DataStewardGroupDAO;
import com.artha.workbench.dao.LockedTablesDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.metastore.DataStewardGroups;
import com.artha.workbench.models.metastore.DataStewardGroupsKey;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("dataStewardGroupService")
public class DataStewardGroupServiceImpl implements DataStewardGroupService {
	
	@Autowired
	DataStewardGroupDAO dataStewardGroupDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;
	
	@Autowired
	LockedTablesDAO lockedTablesDAO;
	
	
	@Transactional(readOnly = true)
	public List<DataStewardGroups> getDataStewardGroupList() {
		return dataStewardGroupDAO.findAll();
	}
	
	@Transactional
	public void create(DataStewardGroups dataStewardGroups) {
		DataStewardGroupsKey keyObj = new DataStewardGroupsKey();
		keyObj.setGroupName(dataStewardGroups.getGroupName());
		keyObj.setUserName(dataStewardGroups.getUserName());
		dataStewardGroups.setDataStewardGroupsKey(keyObj);
		dataStewardGroupDAO.create(dataStewardGroups);
	}
	
	
	
	@Transactional
	@Override
	public void update(DataStewardGroups dataStewardGroups, boolean isReleaseChanged) throws JsonProcessingException {
		DataStewardGroupsKey dataStewadgroupPK = new DataStewardGroupsKey();
		dataStewadgroupPK.setGroupName(dataStewardGroups.getGroupName());
		dataStewadgroupPK.setUserName(dataStewardGroups.getUserName());
		DataStewardGroups olddataSteward = dataStewardGroupDAO.findOne(dataStewadgroupPK);
		checkForCyclicDependency(dataStewardGroups);
		if (isReleaseChanged) {
			ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			releaseArchiveKey.setArchivedReleaseId(olddataSteward.getReleaseNo());
			releaseArchiveKey.setReleaseId(dataStewardGroups.getReleaseNo());
			releaseArchiveKey.setTableName("DATASTEWARDGROUPS");
			DataStewardGroupsKey dataStewardGroupsId = new DataStewardGroupsKey();
			dataStewardGroupsId.setGroupName(dataStewardGroups.getGroupName());
			dataStewardGroupsId.setUserName(dataStewardGroups.getUserName());
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(dataStewardGroupsId));

			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if (releaseArchive != null) {
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(olddataSteward));
				releaseArchiveDAO.update(releaseArchive);
			} else {
				releaseArchive = new ReleaseArchive();
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(olddataSteward));
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchiveDAO.create(releaseArchive);
			}
		}
		dataStewardGroupDAO.update(dataStewardGroups);
	}
	
	private void checkForCyclicDependency(DataStewardGroups dataStewardGroups) throws JsonProcessingException {
		DataStewardGroupsKey dataStewardGroupsId = new DataStewardGroupsKey();
		dataStewardGroupsId.setGroupName(dataStewardGroups.getGroupName());
		dataStewardGroupsId.setUserName(dataStewardGroups.getUserName());
		String jsonId = AppWebUtils.convertObjectToJson(dataStewardGroupsId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(dataStewardGroups.getReleaseNo(),
				"DATASTEWARDGROUPS", jsonId);
		if (releaseArchive != null) {
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	
	
	@Transactional
	public void saveDataStewardGroups(List<DataStewardGroups> dataStewardGroups) {
		dataStewardGroupDAO.deleteDataStewardGroups();
		dataStewardGroupDAO.saveDataStewardGroups(dataStewardGroups);;
	}
	
	
	@Transactional
	public List<DataStewardGroups> getDataStewardGroupsByReleaseNo(Integer releaseNo) {
		return dataStewardGroupDAO.getDataStewardGroupsByReleaseNo(releaseNo);
	}
	
	
	@Override
	@Transactional
	public DataStewardGroups getPreviousDataStewardGroups(DataStewardGroups dataStewardGroups)throws IOException {
		DataStewardGroupsKey dataStewardGroupsKey = new DataStewardGroupsKey();
		dataStewardGroupsKey.setUserName(dataStewardGroups.getUserName());
		dataStewardGroupsKey.setGroupName(dataStewardGroups.getGroupName());
		String dataStewardGroupsJson = AppWebUtils.convertObjectToJson(dataStewardGroupsKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(dataStewardGroups.getReleaseNo(), "DATASTEWARDGROUPS", dataStewardGroupsJson);
		DataStewardGroups previousDataStewardGroups = new DataStewardGroups();
		if(releaseArchive!=null){
			previousDataStewardGroups = AppWebUtils.convertJsonToObject(DataStewardGroups.class, releaseArchive.getRecData());
		}
		return previousDataStewardGroups;
	}
	
	@Transactional
	public DataStewardGroups getDataStewardGroupsCheckDuplicate(
			DataStewardGroups dataStewardGroups) {
		DataStewardGroupsKey dataStewardGroupsKey = new DataStewardGroupsKey();
		dataStewardGroupsKey.setUserName(dataStewardGroups.getUserName());
		dataStewardGroupsKey.setGroupName(dataStewardGroups.getGroupName());
		DataStewardGroups dataStewardGroups1 = dataStewardGroupDAO
				.findOne(dataStewardGroupsKey);
		return dataStewardGroups1;
	}
	
	

}
