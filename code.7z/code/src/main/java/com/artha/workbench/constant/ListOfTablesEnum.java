package com.artha.workbench.constant;

import java.util.HashMap;
import java.util.Map;

public enum ListOfTablesEnum {
	ENTITY_TYPE("Entity Type","entityType"),
	FILE_FORMAT("File Format","fileFormat"),
	HS_FILE_TYPE("HS FileType","hsFileType"),
	ENTITY_MASTER("Entity Master","entityMaster"),
	ENTITY_FILE_TYPE_XREF("Entity FileType Xref","entityFileTypeXref"),
	ENTITY_FILE_REC_COLUMN("Entity FileRecColumn","entityFileRecColumn"),
	SOURCE_TO_TARGET_MAPPING("Source To Target Mapping","sourceToTargetMapping"),
	ENTITY_FILE_TYPE_SCHEDULE_XREF("Entity FileType Schedule Xref","entityFileTypeScheduleXref"),
	HEADER_FOOTER("Header Footer","headerFooter"),
	HEADER_FOOTER_COLS("Header Footer Cols","headerFooterCols"),
	RULE_TYPE("Rule Type","ruleType"),
	VALIDATION_STEP("Validation Step","validationStep"),
	ENTITY_FILE_VALIDATION_RULE("Entity File Validation Rule","entityFileValidationRule"),
	FILE_VAL_STEP_XREF("File ValStep Xref","fileValStepXref"),
	ENTITY_FILE_TYPE_WEB_SERVICE("Entity File Type Web Service","entityFileTypeWebService"),
	WEB_SERVICE_REC_COLUMN("Web Service Rec Column","webServiceRecColumn"),
	SOURCE_TO_WEB_SERVICE_MAPPING("Source To Web Service Mapping","sourceToWebServiceMapping"),
	SOURCE_TO_TARGET_SPLIT("Source To Target Split","sourceToTargetSplit"),
	SOURCE_TO_SERVICE_CRITERIA("Source To Service Criteria","sourceToServiceCriteria"),
	ENTITY_FILE_TYPE_QUERIES("Entity File Type Queries","entityFileTypeQueries"),
	DATA_STEWARD_GROUPS("Data Steward Groups","dataStewardGroups"),
	THREAD_POOL_TYPE("Thread Pool Type","threadPoolType"),
	ENTITY_FILE_TYPE_STEP_CHUNK("Entity File Type Step Chunk","entityFileTypeStepChunk"),
	THREAD_THREAD_POOL_XREF("Thread Thread Pool Xref","threadThreadPoolXref"),
	EMPTY_FILE_CONFIG("Empty File Config","emptyFileConfig");
	
	public final String name;
	public final String value;
	public static final Map<String,String> listOfTablesMap = new HashMap<>();
	
	private ListOfTablesEnum(final String name,final String value) {
		this.name = name;
		this.value = value;
	}
	
	static {
		for (ListOfTablesEnum constant : ListOfTablesEnum.class.getEnumConstants()) {
			listOfTablesMap.put(constant.name, constant.value);
		}
	}

}
