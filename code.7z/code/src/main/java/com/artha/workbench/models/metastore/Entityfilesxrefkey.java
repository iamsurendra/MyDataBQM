package com.artha.workbench.models.metastore;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Entityfilesxrefkey implements Serializable{

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	     @JsonProperty("EntityFileTypeSchedID")
		private int entityFileTypeSchedID;
	     
	    @JsonProperty("EntityFileTypeID")
	   private int entityFileTypeID;
}
