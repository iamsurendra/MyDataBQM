package com.artha.workbench.to;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.artha.workbench.models.metastore.EntityFileRuleParam;
import com.artha.workbench.models.metastore.EntityFileRuleXref;
import com.artha.workbench.models.metastore.EntityFileValidationRule;
import com.artha.workbench.models.metastore.EntityFileValidationRuleVw;
import com.fasterxml.jackson.annotation.JsonProperty;

@XmlRootElement(name="validationRules")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder={"entityFileValidationRuleList","entityFileValidationRules","entityFileRuleXrefs","entityFileRuleParams"})
public class ValidationRulesInfoTO {
	
	@XmlElementWrapper(name="entityFileValidationRuleVwList")
	@XmlElement(name="entityFileValidationRuleVw",type=EntityFileValidationRuleVw.class)
	@JsonProperty("EntityFileValidationRuledb")
	private List<EntityFileValidationRuleVw> entityFileValidationRuleList = new ArrayList<EntityFileValidationRuleVw>();
	
	
	@XmlElementWrapper(name="entityFileValidationRules")
	@XmlElement(name="entityFileValidationRule",type=EntityFileValidationRule.class)
	@JsonProperty("ValidationRules")
	private List<EntityFileValidationRule> entityFileValidationRules = new ArrayList<>();
	
	
	@XmlElementWrapper(name="entityFileRuleXrefs")
	@XmlElement(name="entityFileRuleXref",type=EntityFileRuleXref.class)
	@JsonProperty("EntityFileRuleXref")
	private List<EntityFileRuleXref> entityFileRuleXrefs = new ArrayList<>();
	
	
	@XmlElementWrapper(name="entityFileRuleParams")
	@XmlElement(name="entityFileRuleParam",type=EntityFileRuleParam.class)
	@JsonProperty("EntityFileRuleParam")
	private List<EntityFileRuleParam> entityFileRuleParams = new ArrayList<>();
	
	
	

	public List<EntityFileValidationRuleVw> getEntityFileValidationRuleList() {
		return entityFileValidationRuleList;
	}

	public void setEntityFileValidationRuleList(List<EntityFileValidationRuleVw> entityFileValidationRuleList) {
		this.entityFileValidationRuleList = entityFileValidationRuleList;
	}

	public List<EntityFileValidationRule> getEntityFileValidationRules() {
		return entityFileValidationRules;
	}

	public void setEntityFileValidationRules(List<EntityFileValidationRule> entityFileValidationRules) {
		this.entityFileValidationRules = entityFileValidationRules;
	}

	public List<EntityFileRuleXref> getEntityFileRuleXrefs() {
		return entityFileRuleXrefs;
	}

	public void setEntityFileRuleXrefs(List<EntityFileRuleXref> entityFileRuleXrefs) {
		this.entityFileRuleXrefs = entityFileRuleXrefs;
	}

	public List<EntityFileRuleParam> getEntityFileRuleParams() {
		return entityFileRuleParams;
	}

	public void setEntityFileRuleParams(List<EntityFileRuleParam> entityFileRuleParams) {
		this.entityFileRuleParams = entityFileRuleParams;
	}
	
	
	
	
	

}
