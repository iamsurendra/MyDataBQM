package com.artha.workbench.models.userConfig;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RoleFunctionsPK implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "ROLE_ID")
	private Integer roleID;

	@Column(name = "FUNCTION_ID")
	private Integer functionID;

	public RoleFunctionsPK(Integer roleID, Integer functionID) {
		super();
		this.roleID = roleID;
		this.functionID = functionID;
	}

	public RoleFunctionsPK() {
		super();
	}

	public Integer getRoleID() {
		return roleID;
	}

	public void setRoleID(Integer roleID) {
		this.roleID = roleID;
	}

	public Integer getFunctionID() {
		return functionID;
	}

	public void setFunctionID(Integer functionID) {
		this.functionID = functionID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((functionID == null) ? 0 : functionID.hashCode());
		result = prime * result + ((roleID == null) ? 0 : roleID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoleFunctionsPK other = (RoleFunctionsPK) obj;
		if (functionID == null) {
			if (other.functionID != null)
				return false;
		} else if (!functionID.equals(other.functionID))
			return false;
		if (roleID == null) {
			if (other.roleID != null)
				return false;
		} else if (!roleID.equals(other.roleID))
			return false;
		return true;
	}

}
