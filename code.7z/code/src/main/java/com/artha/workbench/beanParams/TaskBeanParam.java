package com.artha.workbench.beanParams;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.artha.workbench.to.AdvSearchColumnsTO;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.guvvala.framework.util.StringUtils;

@JsonRootName("taskBeanParam")
public class TaskBeanParam {

	public static final String TASK_BEAN_PARAM = "TASK_BEAN_PARAM";

	private String createdBy;
	private String createdByOperator;
	private String selectedStatus;
	private String taskValue;
	private String taskOperator;
	private Date createdOn;
	private String createdOnOperator;
	private Date modifiedOn;
	private String modifiedOnOperator;
	private String modifiedBy;
	private String modifiedByOperator;
	private String selectedOwner;
	private String ownerOperator;
	private String statusOperator;
	private String taskIdValue;
	private String taskIdOperator;
	private Long selectedPartner;
	private Long selectedFileType;
	private String errorKey;
	private String errorKeyOperator;
	private String errorValue;
	private String errorValueOperator;

	private boolean showAdvSearch;
	private boolean advSearch;
	private boolean normalSearch;
	private List<AdvSearchColumnsTO> columns = new ArrayList<>();

	private int pageNo;
	private int noOfRows = 10;

	// Normal Search parameters;
	//@JsonIgnore
	private String colType;
	//@JsonIgnore
	private String condition;
	//@JsonIgnore
	private String colValue;
	//@JsonIgnore
	private Date dateValue;

	/**
	 * To check at least one search option selected/entered.
	 * 
	 * @return
	 */
	public boolean atleastOneEntered() {
		if (StringUtils.isEmpty(createdBy) && StringUtils.isEmpty(selectedStatus) && StringUtils.isEmpty(errorKey)
				&& StringUtils.isEmpty(errorValue) && createdOn == null
				&& (StringUtils.isEmpty(taskValue) || StringUtils.isEmpty(taskOperator))
				&& (StringUtils.isEmpty(taskIdValue) || StringUtils.isEmpty(taskIdOperator))
				&& StringUtils.isEmpty(modifiedBy) && StringUtils.isEmpty(selectedOwner) && modifiedOn == null
				&& (selectedPartner == null || selectedPartner == 0)
				&& (selectedFileType == null || selectedFileType == 0)) {
			return false;
		}
		return true;
	}

	/**
	 * To check proper column info entered to search
	 */
	public boolean allColumnInfoEntered() {
		for (AdvSearchColumnsTO col : columns) {
			if (!StringUtils.isEmpty(col.getName()) && StringUtils.isEmpty(col.getOperator())) {
				return false;
			}
		}
		return true;
	}

	/**
	 * To reset normal search fields.
	 */
	public void resetNormalSearch() {
		colType = null;
		condition = null;
		colValue = null;
		dateValue = null;
		setNormalSearch(false);
	}

	/**
	 * Getters and setters
	 * 
	 * @return
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getSelectedStatus() {
		return selectedStatus;
	}

	public void setSelectedStatus(String selectedStatus) {
		this.selectedStatus = selectedStatus;
	}

	public String getTaskValue() {
		return taskValue;
	}

	public void setTaskValue(String taskValue) {
		this.taskValue = taskValue;
	}

	public String getTaskOperator() {
		return taskOperator;
	}

	public void setTaskOperator(String taskOperator) {
		this.taskOperator = taskOperator;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Long getSelectedPartner() {
		return selectedPartner;
	}

	public void setSelectedPartner(Long selectedPartner) {
		this.selectedPartner = selectedPartner;
	}

	public Long getSelectedFileType() {
		return selectedFileType;
	}

	public void setSelectedFileType(Long selectedFileType) {
		this.selectedFileType = selectedFileType;
	}

	public List<AdvSearchColumnsTO> getColumns() {
		return columns;
	}

	public void setColumns(List<AdvSearchColumnsTO> columns) {
		this.columns = columns;
	}

	public boolean isShowAdvSearch() {
		return showAdvSearch;
	}

	public void setShowAdvSearch(boolean showAdvSearch) {
		this.showAdvSearch = showAdvSearch;
	}

	public String getColType() {
		return colType;
	}

	public void setColType(String colType) {
		this.colType = colType;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getColValue() {
		return colValue;
	}

	public void setColValue(String colValue) {
		this.colValue = colValue;
	}

	public Date getDateValue() {
		return dateValue;
	}

	public void setDateValue(Date dateValue) {
		this.dateValue = dateValue;
	}

	public boolean isAdvSearch() {
		return advSearch;
	}

	public void setAdvSearch(boolean advSearch) {
		this.advSearch = advSearch;
	}

	public boolean isNormalSearch() {
		return normalSearch;
	}

	public void setNormalSearch(boolean normalSearch) {
		this.normalSearch = normalSearch;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getNoOfRows() {
		return noOfRows;
	}

	public void setNoOfRows(int noOfRows) {
		this.noOfRows = noOfRows;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getSelectedOwner() {
		return selectedOwner;
	}

	public void setSelectedOwner(String selectedOwner) {
		this.selectedOwner = selectedOwner;
	}

	public String getTaskIdValue() {
		return taskIdValue;
	}

	public void setTaskIdValue(String taskIdValue) {
		this.taskIdValue = taskIdValue;
	}

	public String getTaskIdOperator() {
		return taskIdOperator;
	}

	public void setTaskIdOperator(String taskIdOperator) {
		this.taskIdOperator = taskIdOperator;
	}

	public String getCreatedByOperator() {
		return createdByOperator;
	}

	public void setCreatedByOperator(String createdByOperator) {
		this.createdByOperator = createdByOperator;
	}

	public String getModifiedByOperator() {
		return modifiedByOperator;
	}

	public void setModifiedByOperator(String modifiedByOperator) {
		this.modifiedByOperator = modifiedByOperator;
	}

	public String getOwnerOperator() {
		return ownerOperator;
	}

	public void setOwnerOperator(String ownerOperator) {
		this.ownerOperator = ownerOperator;
	}

	public String getStatusOperator() {
		return statusOperator;
	}

	public void setStatusOperator(String statusOperator) {
		this.statusOperator = statusOperator;
	}

	public String getCreatedOnOperator() {
		return createdOnOperator;
	}

	public void setCreatedOnOperator(String createdOnOperator) {
		this.createdOnOperator = createdOnOperator;
	}

	public String getModifiedOnOperator() {
		return modifiedOnOperator;
	}

	public void setModifiedOnOperator(String modifiedOnOperator) {
		this.modifiedOnOperator = modifiedOnOperator;
	}

	public String getErrorKey() {
		return errorKey;
	}

	public void setErrorKey(String errorKey) {
		this.errorKey = errorKey;
	}

	public String getErrorKeyOperator() {
		return errorKeyOperator;
	}

	public void setErrorKeyOperator(String errorKeyOperator) {
		this.errorKeyOperator = errorKeyOperator;
	}

	public String getErrorValue() {
		return errorValue;
	}

	public void setErrorValue(String errorValue) {
		this.errorValue = errorValue;
	}

	public String getErrorValueOperator() {
		return errorValueOperator;
	}

	public void setErrorValueOperator(String errorValueOperator) {
		this.errorValueOperator = errorValueOperator;
	}

}
