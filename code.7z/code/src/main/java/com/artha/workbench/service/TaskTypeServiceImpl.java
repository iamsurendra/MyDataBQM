package com.artha.workbench.service;

import java.util.HashMap;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.artha.workbench.dao.TaskTypeDAO;


@Service
public class TaskTypeServiceImpl implements TaskTypeService {

	@Autowired
	TaskTypeDAO taskTypeDAO;

	@Transactional
	public HashMap<Integer, String> loadtaskType() {
		return taskTypeDAO.loadtaskType();
	}

}