package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.metastore.EntityFileRuleParam;
import com.artha.workbench.models.metastore.EntityFileRuleXref;
import com.artha.workbench.models.metastore.EntityFileValidationRule;
import com.artha.workbench.models.metastore.EntityFileValidationRuleVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EntityFileValidationRuleService {

	public List<EntityFileValidationRule> getEntityFileValidationRuleList();

	public void create(EntityFileValidationRule entityFileValidationRule);

	public void update(EntityFileValidationRule entityFileValidationRule);

	public List<EntityFileValidationRuleVw> getEntityFileValidationRuleVwList();

	public List<EntityFileValidationRule> getEntityfileValruleList(List<AbstractModel> entitytypes, String deleteflag);

	public void saveEntityFileValidationRule(List<EntityFileValidationRule> entitytypes);

	public void saveEntityFileValidationRuleVw(List<EntityFileValidationRuleVw> entitytypes);

	public List<EntityFileRuleXref> getEntityFileRuleXrefList(List<AbstractModel> entitytypes, String deleteflag,
			List<EntityFileValidationRule> efrclocallist, String editFlag);

	public void saveEntityFileRuleXref(List<EntityFileRuleXref> entitytypes);

	public List<EntityFileRuleParam> getEntityFileRuleParamList(List<AbstractModel> entitytypes, String deleteflag,
			List<EntityFileRuleXref> efrxlist);

	public void saveEntityFileRuleParam(List<EntityFileRuleParam> entitytypes);

	public void updateEntityFileRuleXref(EntityFileRuleXref entityFileRuleXref);

	public void createEntityFileRuleXref(EntityFileRuleXref entityFileRuleXref);

	public void updateEntityFileRuleParam(EntityFileRuleParam entityFileRuleParam);

	public void createEntityFileRuleParam(EntityFileRuleParam entityFileRuleParam);

	public int getmaxEfvrid();

	public void updateEntityFileValidationRuleVw(List<EntityFileValidationRuleVw> entitytypes);

	public void performDBupdates(EntityFileValidationRuleVw efvrDB, boolean isReleaseChanged)
			throws JsonProcessingException;

	public List<EntityFileValidationRuleVw> getEntityFileValRuleVwListByReleaseNo(Integer releaseNo);

	public EntityFileValidationRuleVw getPreviousEntityFileValidationRuleVw(
			EntityFileValidationRuleVw entityFileValidationRuleVw) throws IOException;

	List<EntityFileRuleParam> getEntityFileRuleParamList(List<Integer> xrefIds);

	List<EntityFileRuleXref> getEntityFileRuleXrefsById(List<Integer> entityfileRuleIds);

	List<EntityFileValidationRule> getEntityFileValidationRulesById(List<Integer> ruleIds);

	List<Integer> getAllEntityFileValRuleReleaseIds(Integer selectedReleaseId);
	
	List<EntityFileRuleParam> getEntityFileRuleParamList(Integer xrefIds);
	
	EntityFileRuleXref getEntityFileRuleXrefsById(Integer entityfileRuleId);
	
	EntityFileValidationRule getEntityFileValidationRulesById(Integer ruleId);

}
