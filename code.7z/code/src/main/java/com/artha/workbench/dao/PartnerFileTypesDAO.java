package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.PartnerFileTypes;
import com.guvvala.framework.dao.BaseDAO;

public interface PartnerFileTypesDAO extends BaseDAO<PartnerFileTypes, Long> {

	public List<String> findFileTypebyPartnerName(String partnerName);

	public List<String> findAllPartnerCodes();

	public List<PartnerFileTypes> findAllPartner();

	public List<PartnerFileTypes> findAllFileTypes(Long partnerID);

	public List<PartnerFileTypes> findAllFileTypes(List<Long> ids);

	public PartnerFileTypes findPartnerById(Long id);
	
	List<Long> findFileTypebyPartnerIdFileId(Long partnerId , List<Long> fileTypeId) ;
	
	public List<PartnerFileTypes> findAllPartner(List<Long> entityId);
	
	String findFileTypeAbbr(Long fileTypeId);
	
	String findPartnerAbbr(Long entityId);
	
	public List<PartnerFileTypes> findFileTypeByPartner(Long partnerID,List<Long> entityTypeIds);
	
	List<PartnerFileTypes> getPartnerFileTypesBypartnerId(Long partnerId, List<Long> entityTypeIds);
}