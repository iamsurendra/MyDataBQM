package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;


@Entity
@Table(name = "metastore.EntityFileRuleXref")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name="entityFileRuleXref")

public class EntityFileRuleXref extends AbstractModel {


	private static final long serialVersionUID = 1L;
	
	
	
	@Id
	@Column(name = "EntityfileRuleId", nullable = false)
	@JsonProperty("EntityfileRuleId")
	private Integer entityfileRuleId;
	
	@JsonProperty("EntityFileTypeID")
	private Integer entityFileTypeID;
	
	@JsonProperty("StepID")
	private Integer stepID;
	
	@JsonProperty("RuleID")
	private Integer ruleID;
	
	@JsonProperty("FailLevel")
	private String failLevel;
	
	@JsonProperty("Active")
	private String active;
	
	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date effectiveDate;
	
	@JsonProperty("BaseMessage")
	private String baseMessage;
	
	@JsonProperty("BaseColumn")
	private String baseColumn;
	
	@JsonProperty("ParamHash")
	private String paramHash;
	
	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	
	
	public Integer getReleaseNo() {
		return releaseNo;
	}
	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}
	public Integer getEntityfileRuleId() {
		return entityfileRuleId;
	}
	public void setEntityfileRuleId(Integer entityfileRuleId) {
		this.entityfileRuleId = entityfileRuleId;
	}
	public Integer getEntityFileTypeID() {
		return entityFileTypeID;
	}
	public void setEntityFileTypeID(Integer entityFileTypeID) {
		this.entityFileTypeID = entityFileTypeID;
	}
	public Integer getStepID() {
		return stepID;
	}
	public void setStepID(Integer stepID) {
		this.stepID = stepID;
	}
	public Integer getRuleId() {
		return ruleID;
	}
	public void setRuleId(Integer ruleId) {
		ruleID = ruleId;
	}
	public String getFailLevel() {
		return failLevel;
	}
	public void setFailLevel(String failLevel) {
		this.failLevel = failLevel;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getParamHash() {
		return paramHash;
	}
	public void setParamHash(String paramHash) {
		this.paramHash = paramHash;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getBaseMessage() {
		return baseMessage;
	}
	public void setBaseMessage(String baseMessage) {
		this.baseMessage = baseMessage;
	}
	public String getBaseColumn() {
		return baseColumn;
	}
	public void setBaseColumn(String baseColumn) {
		this.baseColumn = baseColumn;
	}
	
		

}
