package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;




@Entity
@Table(name = "metastore.EntityFileTypeXref")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name="entityFileTypeXref")
public class EntityFileTypeXref extends AbstractModel{

	private static final long serialVersionUID = 1L;
	
		@Id
		@Column(name = "EntityFileTypeID", nullable = false)	
		@NotNull
		@JsonProperty("EntityFileTypeID")
		private Integer entityFileTypeID;
		
		@JsonProperty("EntityID")
		private Integer entityID;
		
		@JsonProperty("FileTypeID")
		private Integer fileTypeID;
		
		@JsonProperty("FileFormatID")
		private Integer fileFormatID;
		
		@JsonProperty("FilePath")
		private String filePath;
		
		@JsonProperty("FileMask")
		private String fileMask;
		
		@JsonProperty("RecDelimiter")
		private String recDelimiter;
		
		@JsonProperty("ColumnsDelimiter")
		private String columnsDelimiter;
		
		@JsonProperty("ColumnsCount")
		private Integer columnsCount;
		
		@JsonProperty("MaxRecLen")
		private Integer maxRecLen;
		
		@JsonProperty("AllowExtraColumns")
		private String allowExtraColumns;
		
		@JsonProperty("NotifyRetyCount")
		private Integer notifyRetyCount;
		
		@JsonProperty("OutboundOrder")
		private String outboundOrder;
		
		@JsonProperty("Active")
		private String active;
		
		@JsonProperty("EffectiveDate")
		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
		private Date effectiveDate;
		
		@JsonProperty("ColumnsWidth")
		private Integer columnsWidth;
		
		@JsonProperty("DupFileCheck")
		private String dupFileCheck;
		
		@JsonProperty("ColumnsPattern")
		private String columnsPattern;
		
		@JsonProperty("NoDataRecordPattern")
		private String noDataRecordPattern;
		
		@JsonProperty("NoRecordDelimiter")
		private String noRecordDelimiter;
		
		@JsonProperty("OutBoundFilter")
		private String outBoundFilter;
		
		@JsonProperty("SheetName")
		private String sheetName;
		
		@JsonProperty("IgnoreHeaderRowCount")
		private Integer ignoreHeaderRowCount;
		
		@JsonProperty("IgnoreFooterRowCount")
		private Integer ignoreFooterRowCount;
		
		@JsonProperty("FirstColumn")
		private Integer firstColumn;
		
		@JsonProperty("LastColumn")
		private Integer lastColumn;
		
		@JsonProperty("AllowBlankRows")
		private String allowBlankRows;
		
		@JsonProperty("EOFDelimiter")
		private String eOFDelimiter;
		
		@JsonProperty("ShortDescription")
		private String shortDescription;
		
		@Column(name = "ReleaseNum", nullable = false)
		@JsonProperty("ReleaseNum")
		private Integer releaseNo;
		
		@JsonProperty("XSD")
		private String xsd;
		
		@JsonProperty("XMLLOOP")
		private String xmlLoop;
		
		@JsonProperty("Prettify")
		private String prettify;
		
		@Transient
		@JsonProperty("PoolID")
		private Integer poolID;
		
/*        Following fields will be transient
		They are present in the excel but not in the database
		These columns are used to perform the look ups for the corresponding DB fields*/
		
		
		
		public String geteOFDelimiter() {
			return eOFDelimiter;
		}
		public String getAllowBlankRows() {
			return allowBlankRows;
		}
		public void setAllowBlankRows(String allowBlankRows) {
			this.allowBlankRows = allowBlankRows;
		}
		public void seteOFDelimiter(String eOFDelimiter) {
			this.eOFDelimiter = eOFDelimiter;
		}
		public Integer getEntityFileTypeID() {
			return entityFileTypeID;
		}
		public void setEntityFileTypeID(Integer entityFileTypeID) {
			this.entityFileTypeID = entityFileTypeID;
		}
		public Integer getEntityID() {
			return entityID;
		}
		public void setEntityID(Integer entityID) {
			this.entityID = entityID;
		}
		public Integer getFileTypeID() {
			return fileTypeID;
		}
		public void setFileTypeID(Integer fileTypeID) {
			this.fileTypeID = fileTypeID;
		}
		public Integer getFileFormatID() {
			return fileFormatID;
		}
		public void setFileFormatID(Integer fileFormatID) {
			this.fileFormatID = fileFormatID;
		}
		public String getFilePath() {
			return filePath;
		}
		public void setFilePath(String filePath) {
			this.filePath = filePath;
		}
		public String getFileMask() {
			return fileMask;
		}
		public void setFileMask(String fileMask) {
			this.fileMask = fileMask;
		}
		public String getRecDelimiter() {
			return recDelimiter;
		}
		public void setRecDelimiter(String recDelimiter) {
			this.recDelimiter = recDelimiter;
		}
		public String getColumnsDelimiter() {
			return columnsDelimiter;
		}
		public void setColumnsDelimiter(String columnsDelimiter) {
			this.columnsDelimiter = columnsDelimiter;
		}
		public Integer getColumnsCount() {
			return columnsCount;
		}
		public void setColumnsCount(Integer columnsCount) {
			this.columnsCount = columnsCount;
		}
		public Integer getMaxRecLen() {
			return maxRecLen;
		}
		public void setMaxRecLen(Integer maxRecLen) {
			this.maxRecLen = maxRecLen;
		}
		public String getAllowExtraColumns() {
			return allowExtraColumns;
		}
		public void setAllowExtraColumns(String allowExtraColumns) {
			this.allowExtraColumns = allowExtraColumns;
		}
		public Integer getNotifyRetyCount() {
			return notifyRetyCount;
		}
		public void setNotifyRetyCount(Integer notifyRetyCount) {
			this.notifyRetyCount = notifyRetyCount;
		}
		public String getOutboundOrder() {
			return outboundOrder;
		}
		public void setOutboundOrder(String outboundOrder) {
			this.outboundOrder = outboundOrder;
		}
		public String getActive() {
			return active;
		}
		public void setActive(String active) {
			this.active = active;
		}
		public Date getEffectiveDate() {
			return effectiveDate;
		}
		public void setEffectiveDate(Date effectiveDate) {
			this.effectiveDate = effectiveDate;
		}
		public Integer getColumnsWidth() {
			return columnsWidth;
		}
		public void setColumnsWidth(Integer columnsWidth) {
			this.columnsWidth = columnsWidth;
		}
		public String getDupFileCheck() {
			return dupFileCheck;
		}
		public void setDupFileCheck(String dupFileCheck) {
			this.dupFileCheck = dupFileCheck;
		}
		public String getColumnsPattern() {
			return columnsPattern;
		}
		public void setColumnsPattern(String columnsPattern) {
			this.columnsPattern = columnsPattern;
		}
		public String getNoDataRecordPattern() {
			return noDataRecordPattern;
		}
		public void setNoDataRecordPattern(String noDataRecordPattern) {
			this.noDataRecordPattern = noDataRecordPattern;
		}
		public String getNoRecordDelimiter() {
			return noRecordDelimiter;
		}
		public void setNoRecordDelimiter(String noRecordDelimiter) {
			this.noRecordDelimiter = noRecordDelimiter;
		}
		public String getOutBoundFilter() {
			return outBoundFilter;
		}
		public void setOutBoundFilter(String outBoundFilter) {
			this.outBoundFilter = outBoundFilter;
		}
		public String getSheetName() {
			return sheetName;
		}
		public void setSheetName(String sheetName) {
			this.sheetName = sheetName;
		}
		public Integer getIgnoreHeaderRowCount() {
			return ignoreHeaderRowCount;
		}
		public void setIgnoreHeaderRowCount(Integer ignoreHeaderRowCount) {
			this.ignoreHeaderRowCount = ignoreHeaderRowCount;
		}
		public Integer getIgnoreFooterRowCount() {
			return ignoreFooterRowCount;
		}
		public void setIgnoreFooterRowCount(Integer ignoreFooterRowCount) {
			this.ignoreFooterRowCount = ignoreFooterRowCount;
		}
		public Integer getFirstColumn() {
			return firstColumn;
		}
		public void setFirstColumn(Integer firstColumn) {
			this.firstColumn = firstColumn;
		}
		public Integer getLastColumn() {
			return lastColumn;
		}
		public void setLastColumn(Integer lastColumn) {
			this.lastColumn = lastColumn;
		}
	
		public String getShortDescription() {
			return shortDescription;
		}
		public void setShortDescription(String shortDescription) {
			this.shortDescription = shortDescription;
		}
		public Integer getReleaseNo() {
			return releaseNo;
		}
		public void setReleaseNo(Integer releaseNo) {
			this.releaseNo = releaseNo;
		}
		public String getXsd() {
			return xsd;
		}
		public void setXsd(String xsd) {
			this.xsd = xsd;
		}
		public String getXmlLoop() {
			return xmlLoop;
		}
		public void setXmlLoop(String xmlLoop) {
			this.xmlLoop = xmlLoop;
		}
		public String getPrettify() {
			return prettify;
		}
		public void setPrettify(String prettify) {
			this.prettify = prettify;
			
		}
		public Integer getPoolID() {
			return poolID;
		}
		public void setPoolID(Integer poolID) {
			this.poolID = poolID;
		}
		
		
		
		
}
