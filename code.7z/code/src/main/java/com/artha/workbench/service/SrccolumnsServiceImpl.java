package com.artha.workbench.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.SrccolumnsDAO;
import com.artha.workbench.models.datahub.SrcColumnErrorInfo;

@Service
public class SrccolumnsServiceImpl implements SrccolumnsService {

	@Autowired
	SrccolumnsDAO srccolumnsDAO;

	@Transactional
	public List<SrcColumnErrorInfo> getPopuplist(String srcid) {
		return srccolumnsDAO.getPopuplist(srcid);

	}
}