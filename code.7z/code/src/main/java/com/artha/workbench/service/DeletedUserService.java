package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.to.DeletedUserTO;

public interface DeletedUserService {

	List<DeletedUserTO> fetchDeletedUserList();

}
