package com.artha.workbench.constant;

/**
 * 
 * @author GuvalaL1
 *
 */
public enum TaskStatus {
	NEW("new"), RESOLVED("resolved"), PENDING("pending"), LOCKED("locked"), TEMP_LOCK("tempLock"),DELETE("delete");

	public final String value;

	private TaskStatus(String value) {
		this.value = value;
	}

}
