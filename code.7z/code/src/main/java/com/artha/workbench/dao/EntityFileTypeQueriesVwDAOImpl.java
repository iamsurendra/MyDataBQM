package com.artha.workbench.dao;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileTypeQueriesVw;
import com.artha.workbench.models.metastore.EntityFileTypeQueriesVwKey;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class EntityFileTypeQueriesVwDAOImpl extends BaseDAOImpl<EntityFileTypeQueriesVw, EntityFileTypeQueriesVwKey> implements EntityFileTypeQueriesVwDAO{

	public EntityFileTypeQueriesVwDAOImpl() {
		super(EntityFileTypeQueriesVw.class);
	}

	@Override
	public List<EntityFileTypeQueriesVw> getEntityFileTypeQueriesVwListByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeQueriesVw> query = cb.createQuery(EntityFileTypeQueriesVw.class);
		Root<EntityFileTypeQueriesVw> root = query.from(EntityFileTypeQueriesVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}	

}
