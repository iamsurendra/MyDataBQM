package com.artha.workbench.models.datahub;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.artha.workbench.models.metastore.AbstractModel;

@Entity
@Table(name = "datahub.taskcollayout")
public class TaskcolLayout extends AbstractModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "col_layout_id")
	private String colLayoutId;

	@Column(name = "layout_id")
	private String layoutId;

	@Column(name = "schema_pk")
	private String schemaPk;

	@Column(name = "sequence_no")
	private Integer sequenceNo;

	public String getColLayoutId() {
		return colLayoutId;
	}

	public void setColLayoutId(String colLayoutId) {
		this.colLayoutId = colLayoutId;
	}

	public String getLayoutId() {
		return layoutId;
	}

	public void setLayoutId(String layoutId) {
		this.layoutId = layoutId;
	}

	public String getSchemaPk() {
		return schemaPk;
	}

	public void setSchemaPk(String schemaPk) {
		this.schemaPk = schemaPk;
	}

	public Integer getSequenceNo() {
		return sequenceNo;
	}

	public void setSequenceNo(Integer sequenceNo) {
		this.sequenceNo = sequenceNo;
	}

}
