package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EntityFileTypeQueries;
import com.artha.workbench.models.metastore.EntityFileTypeQueriesKey;
import com.guvvala.framework.dao.BaseDAO;

public interface EntityFileTypeQueriesDAO extends BaseDAO<EntityFileTypeQueries, EntityFileTypeQueriesKey> {
	
	public List<EntityFileTypeQueries> getEntityFileTypeQueriesListByReleaseNo(Integer releaseNo);
	
	List<Integer> getAllEntityFileTypeQueriesReleaseIds(Integer selectedReleaseId);

}
