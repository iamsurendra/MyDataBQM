package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EntityFileRuleXref;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityFileRuleXrefDAO extends BaseDAO<EntityFileRuleXref,Integer> {
	
	 public int getMaxEntityfileruleid();
	 public void saveEntityFileRuleXref(List<EntityFileRuleXref> entitytypes);
	 
	 List<EntityFileRuleXref> getEntityFileRuleXrefsById(List<Integer> entityfileRuleIds);
}
