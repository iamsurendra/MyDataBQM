package com.artha.workbench.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class ReleaseArchiveDAOImpl extends BaseDAOImpl<ReleaseArchive, ReleaseArchiveKey> implements ReleaseArchiveDAO {

	public ReleaseArchiveDAOImpl() {
		super(ReleaseArchive.class);
	}

	public ReleaseArchive getReleaseArchive(Integer releaseId, String tableName, String tableRecId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ReleaseArchive> cQuery = builder.createQuery(ReleaseArchive.class);
		Root<ReleaseArchive> root = cQuery.from(ReleaseArchive.class);
		cQuery.select(root);
		cQuery.where(builder.equal(root.get("releaseArchiveKey").get("releaseId"), releaseId), builder.equal(root.get("releaseArchiveKey").get("tableName"), tableName),
				builder.equal(root.get("releaseArchiveKey").get("tableRecId"), tableRecId));
		return findSingle(cQuery);
	}
	
	public ReleaseArchive getReleaseArchiveByArchiveId(Integer releaseId, String tableName, String tableRecId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ReleaseArchive> cQuery = builder.createQuery(ReleaseArchive.class);
		Root<ReleaseArchive> root = cQuery.from(ReleaseArchive.class);
		cQuery.select(root);
		cQuery.where(builder.equal(root.get("releaseArchiveKey").get("archivedReleaseId"), releaseId), builder.equal(root.get("releaseArchiveKey").get("tableName"), tableName),
				builder.equal(root.get("releaseArchiveKey").get("tableRecId"), tableRecId));
		return findSingle(cQuery);
	}
	
	public ReleaseArchive getReleaseArchiveByViewPK(Integer releaseId, String tableName, String viewRecId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ReleaseArchive> cQuery = builder.createQuery(ReleaseArchive.class);
		Root<ReleaseArchive> root = cQuery.from(ReleaseArchive.class);
		cQuery.select(root);
		cQuery.where(builder.equal(root.get("releaseArchiveKey").get("releaseId"), releaseId), builder.equal(root.get("releaseArchiveKey").get("tableName"), tableName),
				builder.equal(root.get("tablePkRecID"), viewRecId));
		return findSingle(cQuery);
	}
	
	@Override
	public List<Integer> getArchiveReleaseIds(Integer releaseId){
		CriteriaBuilder cb= entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<ReleaseArchive> root = query.from(ReleaseArchive.class);
		query.select(root.get("releaseArchiveKey").<Integer>get("archivedReleaseId")).distinct(true);
		query.where(cb.equal(root.get("releaseArchiveKey").<Integer>get("releaseId"), releaseId));
		return entityManager.createQuery(query).getResultList();
	}
	@Override
	public List<Integer> getArchiveReleaseInfo(Integer releaseId,String tableName,List<String> primaryKeys){
		CriteriaBuilder cb= entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<ReleaseArchive> root = query.from(ReleaseArchive.class);
		query.select(root.get("releaseArchiveKey").<Integer>get("archivedReleaseId")).distinct(true);
		query.where(cb.and(cb.equal(root.get("releaseArchiveKey").<Integer>get("releaseId"), releaseId)
				,cb.equal(root.get("releaseArchiveKey").get("tableName"), tableName)
				,cb.in(root.get("releaseArchiveKey").get("tableRecId")).value(primaryKeys)));
		return entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getArchiveTableReleaseInfo(Integer releaseId,String tableName,List<String> primaryKeys){
		CriteriaBuilder cb= entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<ReleaseArchive> root = query.from(ReleaseArchive.class);
		query.select(root.get("releaseArchiveKey").<Integer>get("archivedReleaseId")).distinct(true);
		query.where(cb.and(cb.equal(root.get("releaseArchiveKey").<Integer>get("releaseId"), releaseId)
				,cb.equal(root.get("releaseArchiveKey").get("tableName"), tableName)
				,cb.in(root.get("tablePkRecID")).value(primaryKeys)));
		return entityManager.createQuery(query).getResultList();
	}
	
	public List<String> getReleaseArchiveRecData(Integer releaseId, String tableName) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> cQuery = builder.createQuery(String.class);
		Root<ReleaseArchive> root = cQuery.from(ReleaseArchive.class);
		cQuery.select(root.<String>get("recData"));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.equal(root.get("releaseArchiveKey").get("tableName"), tableName));
		if(releaseId!=null){
			predicates.add(builder.equal(root.get("releaseArchiveKey").get("archivedReleaseId"), releaseId));
		}
	    cQuery.where(predicates.toArray(new Predicate[]{}));
		return entityManager.createQuery(cQuery).getResultList();
	}
	
	public List<String> getReleaseArchiveViewRecData(Integer releaseId, String tableName) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> cQuery = builder.createQuery(String.class);
		Root<ReleaseArchive> root = cQuery.from(ReleaseArchive.class);
		cQuery.select(root.<String>get("viewRecData"));
		cQuery.where(builder.equal(root.get("releaseArchiveKey").get("archivedReleaseId"), releaseId), builder.equal(root.get("releaseArchiveKey").get("tableName"), tableName));
		return entityManager.createQuery(cQuery).getResultList();
	}
	
	public Set<Integer> getBaseReleases(String parametars){
		Query query = entityManager.createNativeQuery("select * from metastore.BaseDependentRelease(:param1)");
		query.setParameter("param1", parametars);
		List<Object[]> results = query.getResultList();
		Set<Integer> baseReleases = new HashSet<>();
		for(Object[] object : results){
			baseReleases.add((Integer) object[5]);
		}
		return baseReleases;
	}
	
	public Map<String,Integer> getBaseReleasesAndPksMap(String parametars){
		Query query = entityManager.createNativeQuery("select * from metastore.BaseDependentRelease(:param1)");
		query.setParameter("param1", parametars);
		List<Object[]> results = query.getResultList();
		Map<String,Integer> baseReleasesAndPksMap = new HashMap<>();
		for(Object[] object : results){
			baseReleasesAndPksMap.put((String)object[3],(Integer) object[5]);
		}
		return baseReleasesAndPksMap;
	}
	
	public List<String> getTablesListInArchiveByReleaseNo(Integer releaseId)
	{
		Query query = entityManager.createNativeQuery("select distinct(tablename) from metastore.ReleaseArchive where ReleaseID = ?1");
		query.setParameter(1, releaseId);
		return query.getResultList();
		
		/*CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> cQuery = builder.createQuery(String.class);
		Root<ReleaseArchive> root = cQuery.from(ReleaseArchive.class);
		cQuery.select(root.<String>get("releaseArchiveKey").get("tableName"));
		List<Predicate> predicates = new ArrayList<>();
		if(releaseId!=null){
			predicates.add(builder.equal(root.get("releaseArchiveKey").get("archivedReleaseId"), releaseId));
		}
	    cQuery.where(predicates.toArray(new Predicate[]{}));
		return entityManager.createQuery(cQuery).getResultList();*/
	}
}
