package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.Groups;
import com.guvvala.framework.dao.BaseDAO;

public interface GroupsDAO extends BaseDAO<Groups, Integer> {

	String getGroupName(Integer groupID);
	
 public	Boolean groupNameExists(String groupName);

	List<Groups> getAllGroups();
}
