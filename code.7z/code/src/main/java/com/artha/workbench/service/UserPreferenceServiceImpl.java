package com.artha.workbench.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.UserPreferenceDAO;
import com.artha.workbench.models.userConfig.UserPreference;
import com.artha.workbench.models.userConfig.UserPreferencePK;
import com.guvvala.framework.util.ThreadLocalUtil;

@Service("userPreferenceService")
public class UserPreferenceServiceImpl implements UserPreferenceService {
	
	@Autowired
	UserPreferenceDAO userPreferenceDAO;
		
	@Transactional
	public void saveUserPreferences(UserPreference timeOutPreference,UserPreference pollIntervalPreference){
		//TODO need to refactor complete method
		Long userId =	ThreadLocalUtil.getUserId();
		
		// converting minutes into milliseconds
		long value = Long.parseLong(timeOutPreference.getValueInMinutes())*60000;
		String valueInMil = String.valueOf(value);
		UserPreferencePK timeOutPreferencePK = new UserPreferencePK();
		timeOutPreferencePK.setUserId(userId);
		timeOutPreferencePK.setPreference("TimeOut");
		UserPreference DBTimeOutPreference = userPreferenceDAO.findOne(timeOutPreferencePK);
		if(DBTimeOutPreference!=null){
			DBTimeOutPreference.setValue(valueInMil);
			userPreferenceDAO.update(DBTimeOutPreference);
		}else{
			DBTimeOutPreference = new UserPreference();
			DBTimeOutPreference.setValue(valueInMil);
			DBTimeOutPreference.setUserPreferencePK(timeOutPreferencePK);
			userPreferenceDAO.create(DBTimeOutPreference);
		}
		UserPreference dbPollIntevalPreference = userPreferenceDAO.findOne(pollIntervalPreference.getUserPreferencePK());
		if(dbPollIntevalPreference!=null)
		{
			dbPollIntevalPreference.setValue(pollIntervalPreference.getValue());
			userPreferenceDAO.update(dbPollIntevalPreference);
		}
		else
		{
			dbPollIntevalPreference = new UserPreference();
			dbPollIntevalPreference.setValue(pollIntervalPreference.getValue());
			dbPollIntevalPreference.setUserPreferencePK(pollIntervalPreference.getUserPreferencePK());
			userPreferenceDAO.create(dbPollIntevalPreference);
		}
	}
	
	@Transactional
	 public UserPreference validateDuplicateUserPreference(UserPreferencePK userPreferencePK){
	  return userPreferenceDAO.findOne(userPreferencePK);
	 }
	
	@Transactional
	public List<UserPreference> getUserPreferenceByUserId(Long userId) {
		return userPreferenceDAO.getUserPreferenceByUserId(userId);
	}
}
