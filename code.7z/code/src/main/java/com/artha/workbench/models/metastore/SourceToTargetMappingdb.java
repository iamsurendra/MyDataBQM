package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.artha.workbench.models.metastore.AbstractModel;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;


@Entity
@Table(name = "metastore.sourcetotargetmapping_v")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
public class SourceToTargetMappingdb extends AbstractModel {
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue
	@Column(name = "InputFileMask", nullable = false)
	@JsonProperty("InputFileMask")
	private String InputFileMask;
	
	@JsonProperty("EntityName")
	private String EntityName;
	
	@JsonProperty("HSFileType")
	private String HSFileType;
	
	@JsonProperty("TargetEntityFileMask")
	private String TargetEntityFileMask;
	
	@JsonProperty("TargetEntityName")
	private String TargetEntityName;
	
	@JsonProperty("ColumnID")
	private Integer ColumnID;
	
	@JsonProperty("MapFunction")
	private String MapFunction;
	
	@JsonProperty("Active")
	private String Active;
	
	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date EffectiveDate;
	
	@JsonProperty("TargetColOrder")
	private Integer TargetColOrder;
	
	@Transient
	@JsonIgnore
	private String Comments;
	
	@Transient
	@JsonIgnore
	private String effectiveDtstr;
	
	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}
	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}
	
	public String getInputFileMask() {
		return InputFileMask;
	}
	
	public void setInputFileMask(String inputFileMask) {
		InputFileMask = inputFileMask;
	}
	
	public String getEntityName() {
		return EntityName;
	}
	
	public void setEntityName(String entityName) {
		EntityName = entityName;
	}
	
	public String getHSFileType() {
		return HSFileType;
	}
	
	public void setHSFileType(String hSFileType) {
		HSFileType = hSFileType;
	}
	
	public String getTargetEntityFileMask() {
		return TargetEntityFileMask;
	}
	
	public void setTargetEntityFileMask(String targetEntityFileMask) {
		TargetEntityFileMask = targetEntityFileMask;
	}
	
	public String getTargetEntityName() {
		return TargetEntityName;
	}
	
	public void setTargetEntityName(String targetEntityName) {
		TargetEntityName = targetEntityName;
	}
	
	public Integer getColumnID() {
		return ColumnID;
	}
	
	public void setColumnID(Integer columnID) {
		ColumnID = columnID;
	}
	
	public String getMapFunction() {
		return MapFunction;
	}
	
	public void setMapFunction(String mapFunction) {
		MapFunction = mapFunction;
	}
	
	public String getActive() {
		return Active;
	}
	
	public void setActive(String active) {
		Active = active;
	}
	
	public Date getEffectiveDate() {
		return EffectiveDate;
	}
	
	public void setEffectiveDate(Date effectiveDate) {
		EffectiveDate = effectiveDate;
	}
	
	public Integer getTargetColOrder() {
		return TargetColOrder;
	}
	
	public void setTargetColOrder(Integer targetColOrder) {
		TargetColOrder = targetColOrder;
	}
	
	public String getComments() {
		return Comments;
	}
	
	public void setComments(String comments) {
		Comments = comments;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
