package com.artha.workbench.dao;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.PagePreference;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class PagePreferenceDAOImpl extends BaseDAOImpl<PagePreference, Integer> implements PagePreferenceDAO {

	public PagePreferenceDAOImpl() {
		super(PagePreference.class);

	}

	public PagePreference findPagePreference(Long userId, String pageName) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<PagePreference> cQuery = builder.createQuery(PagePreference.class);
		Root<PagePreference> root = cQuery.from(PagePreference.class);
		cQuery.select(root);
		cQuery.where(builder.equal(root.get("userId"), userId), builder.equal(root.get("name"), pageName));
		return findSingle(cQuery);
	}

}
