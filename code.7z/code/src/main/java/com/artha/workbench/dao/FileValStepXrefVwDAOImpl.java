package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.FileValStepVwkey;
import com.artha.workbench.models.metastore.FileValStepXrefVw;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class FileValStepXrefVwDAOImpl extends
		BaseDAOImpl<FileValStepXrefVw, FileValStepVwkey> implements
		FileValStepXrefVwDAO {

	public FileValStepXrefVwDAOImpl() {
		super(FileValStepXrefVw.class);
	}
	
	public List<FileValStepXrefVw> getFileValStepXrefVwListByReleaseNo(Integer releaseNo){
			CriteriaBuilder cb = entityManager.getCriteriaBuilder();
			CriteriaQuery<FileValStepXrefVw> query = cb.createQuery(FileValStepXrefVw.class);
			Root<FileValStepXrefVw> root = query.from(FileValStepXrefVw.class);
			query.select(root);
			query.where(cb.equal(root.get("releaseNo"), releaseNo));
			return this.entityManager.createQuery(query).getResultList();
		}
	
}
