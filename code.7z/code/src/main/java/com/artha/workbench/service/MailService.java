package com.artha.workbench.service;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.stereotype.Component;

@Component
public interface MailService {
	public void sendMail(String password, String loginname, String email,String fname) throws AddressException, MessagingException;

	public void sendMailToUser(String password, String loginname, String email,String fname)
			throws AddressException, MessagingException;

	public void sendEmail(String message, String subject, String mailTo);
}
