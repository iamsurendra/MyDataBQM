package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.ThreadThreadPoolXref;
import com.artha.workbench.models.metastore.ThreadThreadPoolXrefKey;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class ThreadThreadPoolXrefDAOImpl extends BaseDAOImpl<ThreadThreadPoolXref,ThreadThreadPoolXrefKey >implements ThreadThreadPoolXrefDAO {

	public ThreadThreadPoolXrefDAOImpl() {
		super(ThreadThreadPoolXref.class);
		// TODO Auto-generated constructor stub
	}
	public void saveThreadThreadPoolXref(List<ThreadThreadPoolXref> threadThreadPoolXref) {
		batchCreate(threadThreadPoolXref, 50);

	}
	
	@Transactional
	public void deleteThreadThreadPoolXref() {
		Query query = entityManager.createQuery("delete from ThreadThreadPoolXref");
		query.executeUpdate();
	}
	
	
	@Override
	public List<ThreadThreadPoolXref> getThreadThreadPoolXrefByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<ThreadThreadPoolXref> query = cb.createQuery(ThreadThreadPoolXref.class);
		Root<ThreadThreadPoolXref> root = query.from(ThreadThreadPoolXref.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}	
	
	
	@Override
	public List<Integer> getAllThreadThreadPoolXrefReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from ThreadThreadPoolXref where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	

	
}
