package com.artha.workbench.to;

import java.util.List;
import java.util.Map;

public class RoleSummaryTO {
	
	private String partnerName;
	
	private Map<String,List<PartnerFileTypeColumnsTO>>  fileTypeColumns;
	
	private List<String> fileTypes;

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public Map<String, List<PartnerFileTypeColumnsTO>> getFileTypeColumns() {
		return fileTypeColumns;
	}

	public void setFileTypeColumns(Map<String, List<PartnerFileTypeColumnsTO>> fileTypeColumns) {
		this.fileTypeColumns = fileTypeColumns;
	}

	public List<String> getFileTypes() {
		return fileTypes;
	}

	public void setFileTypes(List<String> fileTypes) {
		this.fileTypes = fileTypes;
	}

}
