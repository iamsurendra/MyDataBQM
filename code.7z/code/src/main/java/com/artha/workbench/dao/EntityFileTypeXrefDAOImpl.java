package com.artha.workbench.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.EntityFileTypeXref;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityFileTypeXrefDAOImpl extends BaseDAOImpl<EntityFileTypeXref, Integer> implements EntityFileTypeXrefDAO {

	public EntityFileTypeXrefDAOImpl() {
		super(EntityFileTypeXref.class);
	}
	@Transactional
	public HashMap<String,Integer> loadentityFileTypeID() {
		List<String> filelist = null;
		List<Integer>fidlist = null;
		HashMap<String,Integer> hsmap = new   HashMap<String,Integer>();
		TypedQuery<String> query = entityManager.createQuery("SELECT fileMask from EntityFileTypeXref",String.class);
		TypedQuery<Integer> query1 = entityManager.createQuery("SELECT entityFileTypeID from EntityFileTypeXref",Integer.class);
		filelist =  query.getResultList();
		fidlist =  query1.getResultList();
		if(fidlist!=null)
		{
			for(int i =0;i<fidlist.size();i++)
			{
				hsmap.put(filelist.get(i), fidlist.get(i));
			}
		}
		return hsmap;
	}
	@Transactional
	public HashMap<Integer, String> loadEntityFileTypeID() {
		List<Object[]> filelist = new ArrayList<>();
		HashMap<Integer, String> hsmap = new HashMap<Integer, String>();
		TypedQuery<Object[]> query = entityManager
				.createQuery("SELECT entityFileTypeID,fileMask from EntityFileTypeXref", Object[].class);
		filelist = query.getResultList();
		for (Object[] array : filelist) {
			hsmap.put((Integer) array[0], (String) array[1]);
		}
		return hsmap;
	}
	
	public void saveEntityFileTypeXref(List<EntityFileTypeXref> entitytypes) 
	{
		batchCreate(entitytypes, 50);

	}
	public void deleteEntityFileTypeXref() {
		Query query = entityManager.createQuery("delete from EntityFileTypeXref");
		query.executeUpdate();
	}
	public int getfilemaskID(String filemask,int entityid,int filetypeid) {
		int entityFileTypeID = 0;
		try{
			TypedQuery<Integer> query = entityManager
					.createQuery("SELECT entityFileTypeID from EntityFileTypeXref  where fileMask ='" + filemask + "' and entityID = '" + entityid + "' and fileTypeID =  '" + filetypeid + "'", Integer.class);
			if(query.getSingleResult()!=null)
				entityFileTypeID = query.getSingleResult();
			return entityFileTypeID;
		}
		catch (NoResultException e){
			return entityFileTypeID;
		}

	}
	public int getMaxEntityFileTypeID()
	{
		int loginid = 0;
		try
		{
			// changed 1 to 0 because to avoid data constraint voilation Exception
			TypedQuery<Integer> query = entityManager.createQuery("SELECT max(entityFileTypeID) from EntityFileTypeXref", Integer.class);
			if(query.getSingleResult()!=null)
				loginid = query.getSingleResult();
			return loginid;
		}
		catch (NoResultException e){
			return loginid;
		}
	}

	
	public List<EntityFileTypeXref> getEntityFileTypeXrefListByReleaseNo(Integer releaseNo)
	{
		CriteriaBuilder cb=entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeXref> query=cb.createQuery(EntityFileTypeXref.class);
		Root<EntityFileTypeXref> root=query.from(EntityFileTypeXref.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
		
    }
	
	@Override
	public List<Integer> getEntityTypeXrefReleaseNumbers(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<EntityFileTypeXref> root = query.from(EntityFileTypeXref.class);
		query.select(root.<Integer>get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("entityFileTypeID")).value(entityFileTypeIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllEntityFileTypeXrefReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from EntityFileTypeXref where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	
	@Override
	public List<EntityFileTypeXref> getEntityTypeXrefList(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeXref> query = cb.createQuery(EntityFileTypeXref.class);
		Root<EntityFileTypeXref> root = query.from(EntityFileTypeXref.class);
		query.select(root).distinct(true);
		query.where(cb.and(cb.in(root.get("entityFileTypeID")).value(entityFileTypeIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
	
	
	@Transactional
	public List<Integer> loadentityFileTypeid() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = criteriaBuilder.createQuery(Integer.class);
		Root<EntityFileTypeXref> makeRoot = criteriaQuery.from(EntityFileTypeXref.class);
		criteriaQuery.multiselect(makeRoot.get("entityFileTypeID")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
		}
	
	
	



}
