package com.artha.workbench.pagePreference;



import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("taskPage")
public class TaskPage {

	private String name;
	private int pageNo;
	private int noOfRows = 10;
	private String sortString;
	private String sortOrder;

	public TaskPage() {
		super();
		this.name = "";
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getNoOfRows() {
		return noOfRows;
	}

	public void setNoOfRows(int noOfRows) {
		this.noOfRows = noOfRows;
	}

	public String getSortString() {
		return sortString;
	}

	public void setSortString(String sortString) {
		this.sortString = sortString;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

}
