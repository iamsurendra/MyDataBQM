package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.RuleType;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface RuleTypeService {

	public List<RuleType> getRuleTypeList();

	public void create(RuleType RuleType);

	public void update(RuleType ruleType, boolean isReleaseChanged) throws JsonProcessingException;

	public void saveRuleType(List<RuleType> entitytypes);

	public int getmaxruleTypeID();

	public HashMap<Integer, String> loadRuleTypeIdMap();
	
	public List<RuleType> getRuleTypeListByReleaseNo(Integer releaseNo);
	
	public RuleType getPreviousRuleType(RuleType ruleType) throws IOException;
	
	public List<Integer> getRuleTypeReleaseNumbers(Set<Integer> ruleTypeIds,Integer selectedReleaseNumber);
	
	List<Integer> getAllRuleTypeReleaseIds(Integer selectedReleaseId);
	
	List<RuleType> getRuleTypeList(Set<Integer> ruleTypeIds,Integer selectedReleaseNumber);
}
