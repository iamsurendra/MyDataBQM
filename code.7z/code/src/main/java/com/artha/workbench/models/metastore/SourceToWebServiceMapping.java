package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "metastore.SourceToWebServiceMapping")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name = "sourceToWebServiceMapping")
public class SourceToWebServiceMapping extends AbstractModel {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonProperty("Key")
	private SourceToWebServiceMappingKey sourceToWebServiceMappingKey;

	@Column(name = "SourceEntityFileTypeID", insertable = false, updatable = false)
	@JsonIgnore
	private Integer sourceEntityFileTypeID;

	@Column(name = "WebServiceID", insertable = false, updatable = false)
	@JsonIgnore
	private Integer webServiceID;

	@Column(name = "TargetColumnID", insertable = false, updatable = false)
	@JsonIgnore
	private Integer targetColumnID;

	@JsonProperty("MapFunction")
	private String mapFunction;

	@JsonProperty("Active")
	private String active;

	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date effectiveDate;

	@JsonProperty("TargetColOrder")
	private int targetColOrder;

	@JsonProperty("ReleaseNum")
	private int releaseNum;

	// Getters & Setters

	@XmlTransient
	public Integer getSourceEntityFileTypeID() {
		return sourceEntityFileTypeID;
	}

	public void setSourceEntityFileTypeID(Integer sourceEntityFileTypeID) {
		this.sourceEntityFileTypeID = sourceEntityFileTypeID;
	}
	
	@XmlTransient
	public Integer getWebServiceID() {
		return webServiceID;
	}

	public void setWebServiceID(Integer webServiceID) {
		this.webServiceID = webServiceID;
	}

	@XmlTransient
	public Integer getTargetColumnID() {
		return targetColumnID;
	}

	public void setTargetColumnID(Integer targetColumnID) {
		this.targetColumnID = targetColumnID;
	}

	public String getMapFunction() {
		return mapFunction;
	}

	public void setMapFunction(String mapFunction) {
		this.mapFunction = mapFunction;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public int getTargetColOrder() {
		return targetColOrder;
	}

	public void setTargetColOrder(int targetColOrder) {
		this.targetColOrder = targetColOrder;
	}

	public SourceToWebServiceMappingKey getSourceToWebServiceMappingKey() {
		return sourceToWebServiceMappingKey;
	}

	public void setSourceToWebServiceMappingKey(SourceToWebServiceMappingKey sourceToWebServiceMappingKey) {
		this.sourceToWebServiceMappingKey = sourceToWebServiceMappingKey;
	}

	public int getReleaseNum() {
		return releaseNum;
	}

	public void setReleaseNum(int releaseNum) {
		this.releaseNum = releaseNum;
	}


}
