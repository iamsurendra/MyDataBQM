package com.artha.workbench.dao;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.RolePrivileges;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class RoleprivilegesDAOImpl extends BaseDAOImpl<RolePrivileges, Integer> implements RoleprivilegesDAO {

	public RoleprivilegesDAOImpl() {
		super(RolePrivileges.class);
	}

	public void savePrivileges(RolePrivileges roleprivileges) {
		create(roleprivileges);
	}
}
