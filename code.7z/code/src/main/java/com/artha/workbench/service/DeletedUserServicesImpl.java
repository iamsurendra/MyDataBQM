package com.artha.workbench.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.DeletedUserReportDAO;
import com.artha.workbench.to.DeletedUserTO;

@Service("deletedUserService")
public class DeletedUserServicesImpl implements DeletedUserService {
	@Autowired
	DeletedUserReportDAO deletedUserReportDAO;

	@Transactional
	public List<DeletedUserTO> fetchDeletedUserList() {
		return deletedUserReportDAO.fetchDeletedUserList();
	}

}
