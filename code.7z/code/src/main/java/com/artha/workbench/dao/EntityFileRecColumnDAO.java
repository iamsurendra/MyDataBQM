package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.EntityFileRecColumn;
import com.artha.workbench.models.metastore.EntityFileRecColumnKey;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityFileRecColumnDAO extends BaseDAO<EntityFileRecColumn, EntityFileRecColumnKey> {
	public void saveEntityFileRecColumn(List<EntityFileRecColumn> entitytypes);

	public void deleteEntityFileReccol();

	
	List<Integer> getEntityFileRecRelNumbersByTypeIds(Set<Integer> entityTypeIds,Integer selectedReleaseNumber);
	List<Integer> getEntityFileRecRelNumbersByColIds(Set<Integer> colIds,Integer selectedReleaseNumber);
	public List<EntityFileRecColumn> getEntityFileRecColumnListByReleaseNo(Integer releaseNo);
	
	List<Integer> getAllEntityFileRecColumnReleaseIds(Integer selectedReleaseId);
	List<EntityFileRecColumn> getEntityFileRecList(Set<Integer> entityTypeIds,Set<Integer> colIds,Integer selectedReleaseNumber);
}
