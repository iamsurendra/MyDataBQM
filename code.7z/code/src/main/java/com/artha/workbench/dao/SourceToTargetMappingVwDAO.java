package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.SourceToTargetMappingVw;
import com.artha.workbench.models.metastore.SourceToTargetVwKey;
import com.guvvala.framework.dao.BaseDAO;

public interface SourceToTargetMappingVwDAO extends BaseDAO<SourceToTargetMappingVw, SourceToTargetVwKey> {

	public List<SourceToTargetMappingVw> getSourceToTargetMappingVwByReleaseNo(Integer releaseNo);
	
	SourceToTargetMappingVw getSourceToTargetMappingVwByTableID(Integer sourceEFTId, Integer targetEFTId,Integer columnId);
}
