package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.core.AuditTaskInfo_VW;


public interface AuditTaskDAO {
	List<AuditTaskInfo_VW> getAuditTaskList();

	List<AuditTaskInfo_VW> getAuditTaskByAccessRight(List<String> taskAccessRights);
	
}
