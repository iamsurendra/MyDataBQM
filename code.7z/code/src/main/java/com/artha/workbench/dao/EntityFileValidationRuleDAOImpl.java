package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileValidationRule;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityFileValidationRuleDAOImpl extends BaseDAOImpl<EntityFileValidationRule, Integer>
		implements EntityFileValidationRuleDAO {

	public EntityFileValidationRuleDAOImpl() {
		super(EntityFileValidationRule.class);
	}

	public void saveEntityFileValidationRule(List<EntityFileValidationRule> entitytypes) {
		batchCreate(entitytypes, 50);

	}

	public int getMaxvalidationruleid() {
		int loginid = 0;
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(ruleID) from EntityFileValidationRule",
				Integer.class);
		if (query.getSingleResult() != null)
			loginid = query.getSingleResult();
		return loginid;
	}

	public void deleteValidationRule() {
		Query query = entityManager.createQuery("delete from EntityFileValidationRule");
		query.executeUpdate();
	}

	public void deleteValidationRuleDB() {
		Query query = entityManager.createQuery("delete from EntityFileValidationRuleVw");
		query.executeUpdate();
	}

	public void deleteEntityFileRuleXref() {
		Query query = entityManager.createQuery("delete from EntityFileRuleXref");
		query.executeUpdate();
	}

	public void deleteEntityFileRuleParam() {
		Query query = entityManager.createQuery("delete from EntityFileRuleParam");
		query.executeUpdate();
	}
	
	
	@Override
	public List<EntityFileValidationRule> getEntityFileValidationRulesById(List<Integer> ruleIds){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileValidationRule> cQuery = cb.createQuery(EntityFileValidationRule.class);
		Root<EntityFileValidationRule> root = cQuery.from(EntityFileValidationRule.class);
		cQuery.select(root);
		cQuery.where(cb.in(root.get("ruleID")).value(ruleIds));
		return entityManager.createQuery(cQuery).getResultList();
	}

}
