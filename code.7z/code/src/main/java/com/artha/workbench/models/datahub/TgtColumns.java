package com.artha.workbench.models.datahub;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import com.guvvala.framework.util.DateUtils;
import com.artha.workbench.models.metastore.AbstractModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Entity
@Table(name = "datahub.tgtcolumns")
@Audited
@NamedStoredProcedureQuery(name = "SP_TGT_UPDATE", procedureName = "SP_TGT_UPDATE", parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, type = String.class, name = "inputJson"),
		@StoredProcedureParameter(mode = ParameterMode.OUT, type = String.class, name = "outputJson"),
		@StoredProcedureParameter(mode = ParameterMode.OUT, type = Integer.class, name = "totalRefelected") })
@JsonPropertyOrder({"tableName","revRequired","tgtcol_id","modifiedvalue","Revision_Type","LAST_UPD_BY"})
public class TgtColumns extends AbstractModel {

	public static final String SP_TGT_UPDATE = "SP_TGT_UPDATE";

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "tgtcol_id")
	@JsonProperty("tgtcol_id")
	private String tgtcolId;

	@Column(name = "tgtrec_id")
	@JsonIgnore
	private String tgtrecId;

	@Column(name = "col_name")
	private String defColName;

	@Column(name = "col_value")
	private String defColValue;

	@Column(name = "col_type")
	@JsonIgnore
	private String defColType;

	@Column(name = "col_iskey")
	@JsonIgnore
	private Integer defColIskey;

	@Transient
	private Integer writeMode;

	@Transient
	@JsonIgnore
	private String oldValue;

	@Transient
	private String sourceValue;

	@Transient
	private String errorValue;
	
	@Transient
	private boolean isUpdated;
	
	@Transient
	private String tableName="tgtColumns";
	
	@Transient
	private String revRequired="true";
	
	@Transient
	@JsonProperty("Revision_Type")
	private String revision_type="1";
	
	@Transient
	@JsonProperty("LAST_UPD_BY")
	private String last_upd_by;

	public String getSourceValue() {
		return sourceValue;
	}

	public void setSourceValue(String sourceValue) {
		this.sourceValue = sourceValue;
	}

	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	public Integer getWriteMode() {
		return writeMode;
	}

	public void setWriteMode(Integer writeMode) {
		this.writeMode = writeMode;
	}

	public String getTgtcolId() {
		return tgtcolId;
	}

	public void setTgtcolId(String tgtcolId) {
		this.tgtcolId = tgtcolId;
	}

	public String getTgtrecId() {
		return tgtrecId;
	}

	public void setTgtrecId(String tgtrecId) {
		this.tgtrecId = tgtrecId;
	}

	public String getDefColName() {
		return defColName;
	}

	public void setDefColName(String defColName) {
		this.defColName = defColName;
	}

	public String getDefColValue() {
		return defColValue;
	}

	public void setDefColValue(String defColValue) {
		this.defColValue = defColValue;
	}

	public String getDefColType() {
		return defColType;
	}

	public void setDefColType(String defColType) {
		this.defColType = defColType;
	}

	public Integer getDefColIsKey() {
		return defColIskey;
	}

	public void setDefColIsKey(Integer defColIsKey) {
		this.defColIskey = defColIsKey;
	}

	public String getErrorValue() {
		return errorValue;
	}

	public void setErrorValue(String errorValue) {
		this.errorValue = errorValue;
	}

	public boolean isUpdated() {
		return isUpdated;
	}

	public void setUpdated(boolean isUpdated) {
		this.isUpdated = isUpdated;
	}
	
	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	
	public String getRevRequired() {
		return revRequired;
	}

	public void setRevRequired(String revRequired) {
		this.revRequired = revRequired;
	}

	public String getRevision_type() {
		return revision_type;
	}

	public void setRevision_type(String revision_type) {
		this.revision_type = revision_type;
	}

	public String getLast_upd_by() {
		return last_upd_by;
	}

	public void setLast_upd_by(String last_upd_by) {
		this.last_upd_by = last_upd_by;
	}

	public Integer getDefColIskey() {
		return defColIskey;
	}

	public void setDefColIskey(Integer defColIskey) {
		this.defColIskey = defColIskey;
	}
	
	

}
