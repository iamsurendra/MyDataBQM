package com.artha.workbench.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.beanParams.TaskBeanParam;
import com.artha.workbench.constant.WBConstants;
import com.artha.workbench.constant.TaskStatus;
import com.artha.workbench.dao.ChartQueryDAO;
import com.artha.workbench.dao.LockedTaskDAO;
import com.artha.workbench.dao.PagePreferenceDAO;
import com.artha.workbench.dao.SrccolumnsDAO;
import com.artha.workbench.dao.SrcextraInfoDAO;
import com.artha.workbench.dao.SrcrecordsDAO;
import com.artha.workbench.dao.StatusHistoryDAO;
import com.artha.workbench.dao.TaskDAO;
import com.artha.workbench.dao.TgtColumnsDAO;
import com.artha.workbench.dao.TgtRecordsDAO;
import com.artha.workbench.models.datahub.LockedTask;
import com.artha.workbench.models.datahub.LockedTaskPK;
import com.artha.workbench.models.datahub.SrcColumnErrorInfo;
import com.artha.workbench.models.datahub.StatusHistory;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.models.datahub.TaskType;
import com.artha.workbench.models.datahub.TgtColumns;
import com.artha.workbench.models.userConfig.PagePreference;
import com.artha.workbench.to.AdvSearchColumnsTO;
import com.artha.workbench.to.ChartQueryTO;
import com.guvvala.framework.filter.BaseFilter;
import com.guvvala.framework.filter.DateFilter;
import com.guvvala.framework.filter.StringFilter;
import com.guvvala.framework.util.StringUtils;

@Service
public class TaskServiceImpl implements TaskService {

	@Autowired
	TaskDAO taskDAO;

	@Autowired
	LockedTaskDAO lockedTaskDAO;

	@Autowired
	TgtColumnsDAO tgtColumnsDAO;

	@Autowired
	SrccolumnsDAO srccolumnsDAO;

	@Autowired
	SrcrecordsDAO srcRecordsDAO;

	@Autowired
	TgtRecordsDAO tgtRecordsDAO;

	@Autowired
	SrcextraInfoDAO srcextraInfoDAO;

	@Autowired
	PagePreferenceDAO pagePreferenceDAO;

	@Autowired
	SrcrecordsDAO srcrecordsDAO;

	@Autowired
	PopUpService popUpService;

	@Autowired
	ChartQueryDAO chartQueryDAO;
	
	@Autowired
	StatusHistoryDAO statusHistoryDAO;

	@Transactional(readOnly = true)
	public List<String> getTaskColumnsData(String columnName) {
		return taskDAO.getTaskColumnsData(columnName);
	}

	@Transactional(readOnly = true)
	public List<Task> getTaskList() {
		return taskDAO.findAll();
	}
	
	@Override
	@Transactional(readOnly =true)
	public Task findOne(String id) {
		return taskDAO.findOne(id);
	}

	@Transactional
	public void delete(List<String> taskIds) {
		for (String taskId : taskIds) {
			updateTaskStatus(taskId, TaskStatus.DELETE.value);
		}
	}

	@Transactional
	public void deleteAll() {
		taskDAO.deleteAll();
	}

	@Transactional
	public List<Task> getSearchlist(String taskStatus, String Betweenrec, String andrec) {
		return taskDAO.getSearchlist(taskStatus, Betweenrec, andrec);
	}

	@Transactional
	public List<Task> getSearchlist(TaskBeanParam taskBeanParam, String partnertAbbr, String fileTypeAbbr,
			String entityFileTypeId) {
		Map<String, String> columnNames = new HashMap<>();

		for (AdvSearchColumnsTO column : taskBeanParam.getColumns()) {
			if (!StringUtils.isEmpty(column.getName())) {
				columnNames.put(column.getName(),
						column.getOperator() + "," + (StringUtils.isEmpty(column.getValue()) ? "" : column.getValue()));
			}
		}

		List<String> taskIds = taskDAO.getSearchlist(taskBeanParam, fileTypeAbbr, partnertAbbr, columnNames,
				entityFileTypeId);
		return getAdvSearchRecords(taskIds);
	}

	@Transactional
	public List<Task> getNormaluserSearchlist(TaskBeanParam taskBeanParam, String partnertAbbr, String fileTypeAbbr,
			String entityFileTypeId, List<String> taskAccessRights) {
		Map<String, String> columnNames = new HashMap<>();
		for (AdvSearchColumnsTO column : taskBeanParam.getColumns()) {
			if (!StringUtils.isEmpty(column.getName())) {
				columnNames.put(column.getName(),
						column.getOperator() + "," + (StringUtils.isEmpty(column.getValue()) ? "" : column.getValue()));
			}
		}
		List<String> taskIds = taskDAO.getNormaluserSearchlist(taskBeanParam, fileTypeAbbr, partnertAbbr, columnNames,
				entityFileTypeId, taskAccessRights);
		return getAdvSearchRecords(taskIds);
	}

	public List<Task> getAdvSearchRecords(List<String> taskIds) {
		List<Task> tasks = new ArrayList<>();
		if (null != taskIds && !taskIds.isEmpty())
			if (taskIds.size() >= WBConstants.MAX_RECORDS) {
				// String detailMessage =
				// BusinessDWBBundle.getString(Messages.MAX_RECORDS_EXCEDED,
				// DWBConstants.MAX_RECORDS, taskIds.size());
				// FacesMessage facesMessage = new
				// FacesMessage(FacesMessage.SEVERITY_FATAL, null,
				// detailMessage);
				// tasks = taskDAO.getAllTasks(taskIds.subList(0,
				// DWBConstants.MAX_RECORDS));
				// AppWebUtils.setSattribute(DWBConstants.MAX_ROWS_EXCEED_MSG,
				// facesMessage);
				return tasks;
			} else {
				return taskDAO.getAllTasks(taskIds);
			}
		return tasks;
	}

	@Transactional
	public List<Task> getChartSearchlist(String taskStatus, boolean adminflag, List<String> taskAccessRights) {
		return taskDAO.getChartSearchlist(taskStatus, adminflag, taskAccessRights);
	}

	@Transactional
	public Boolean findLockedTask(String taskId, String userId) {
		LockedTaskPK lockedTaskPK = new LockedTaskPK();
		lockedTaskPK.setTaskId(taskId);
		lockedTaskPK.setLockType(TaskStatus.TEMP_LOCK.value);
		LockedTask lockedTask = lockedTaskDAO.findOne(lockedTaskPK);
		if (lockedTask.getLockOwnedBy().equalsIgnoreCase(userId)) {
			return true;
		}
		return false;
	}

	@Transactional
	public Boolean findLockedTaskByOtherUser(List<String> taskIdList, String userName) {
		for (String taskId : taskIdList) {
			LockedTaskPK lockedTaskPK = new LockedTaskPK();
			lockedTaskPK.setLockType(TaskStatus.TEMP_LOCK.value);
			lockedTaskPK.setTaskId(taskId);
			LockedTask lockedTask = lockedTaskDAO.findOne(lockedTaskPK);
			if (null != lockedTask && !lockedTask.getLockOwnedBy().equalsIgnoreCase(userName)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<Task> getNorSearchlist(Set<BaseFilter> userFilters, boolean adminFlag, List<String> taskAccessRights) {
		if (adminFlag) {
			Long count = taskDAO.getNorSearchlist(userFilters);
			if (count >= WBConstants.MAX_RECORDS) {
//				String detailMessage = BusinessDWBBundle.getString(Messages.MAX_RECORDS_EXCEDED,
//						DWBConstants.MAX_RECORDS, count);
//				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_FATAL, null, detailMessage);
//				AppWebUtils.setSattribute(DWBConstants.MAX_ROWS_EXCEED_MSG, facesMessage);
			}
			return taskDAO.getNorSearchlist(userFilters, WBConstants.MAX_RECORDS);
		} else {
			Integer count = taskDAO.getNorSearchlist(userFilters, taskAccessRights);
			if (count >= WBConstants.MAX_RECORDS) {
//				String detailMessage = BusinessDWBBundle.getString(Messages.MAX_RECORDS_EXCEDED,
//						DWBConstants.MAX_RECORDS, count);
//				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_FATAL, null, detailMessage);
//				AppWebUtils.setSattribute(DWBConstants.MAX_ROWS_EXCEED_MSG, facesMessage);
			}
			return taskDAO.getNorSearchlist(userFilters, taskAccessRights, WBConstants.MAX_RECORDS);
		}
	}

	@Transactional
	public void changeStatus(List<String> taskIdLists, String statusstr, String userName, List<String> resolveList) {
		for (String taskId : taskIdLists) {
			updateTaskStatus(taskId, statusstr);
			if (statusstr.equalsIgnoreCase(TaskStatus.LOCKED.value)) {
				lockedTaskDAO.createLock(taskId, userName, TaskStatus.LOCKED.value);
			}
		}
	}

	@Transactional
	public void updateTargetValues(List<TgtColumns> popUpTargets) {
		for (TgtColumns tgtColumn : popUpTargets) {
			tgtColumnsDAO.update(tgtColumn);
		}
	}

	@Transactional
	public List<String> getLockedTasksList(String userName) {
		return lockedTaskDAO.getLockedTasksList(userName);
	}

	@Transactional
	public void removeLockedTasks(String taskid, String username) {
		lockedTaskDAO.removeLockedTasks(taskid, username);
	}

	@Transactional(readOnly = true)
	public List<LockedTask> getLockedTaskList() {
		return lockedTaskDAO.findAll();
	}

	@Transactional
	public void unlockSelected(String taskId) {
		lockedTaskDAO.unlockSelected(taskId, TaskStatus.TEMP_LOCK.value);
		Task task = taskDAO.findOne(taskId);
		if (task != null && !task.getStatus().equalsIgnoreCase("resolved")) {
			List<Integer> revIds = taskDAO.getLockedTaskRevisionIds(taskId);
			if (revIds.size() > 1) {
				String status = taskDAO.getPreviousTaskStatus(revIds, taskId);
				task.setStatus(status == null ? "new" : status);
			} else {
				task.setStatus("new");
			}
			taskDAO.update(task);
		}
	}

	@Transactional
	public List<Task> getCreatedByTasklist() {
		List<Task> taskdet = new ArrayList<Task>();
		taskdet = taskDAO.getTasklist();
		return taskdet;
	}

	@Transactional
	public List<TaskType> getTaskTypelist() {
		List<TaskType> tasktypedet = new ArrayList<TaskType>();
		tasktypedet = taskDAO.getTaskTypelist();
		return tasktypedet;
	}

	@Override
	@Transactional
	public List<Task> getTaskByAccessRight(List<String> taskAccessRights) {
		return taskDAO.getTaskByAccessRight(taskAccessRights);
	}

	@Override
	@Transactional
	public List<ChartQueryTO> getDashboardCountForAdmin() {

		List<ChartQueryTO> chartQueryTOList = chartQueryDAO.executeQueries();
		return chartQueryTOList;
	}

	@Override
	@Transactional
	public List<String> getTaskIdsByAccessRight(List<String> taskAccessRights) {
		List<Task> taskList = taskDAO.getTaskByAccessRight(taskAccessRights);
		List<String> taskIdList = new ArrayList<String>();
		for (Task task : taskList) {
			taskIdList.add(task.getTask_id());
		}
		return taskIdList;
	}


	@Override
	@Transactional
	public List<Task> getAllTasks(List<String> taskIds) {
		if (!taskIds.isEmpty()) {
			return taskDAO.getAllTasks(taskIds);
		}
		return new ArrayList<Task>();
	}

	@Override
	@Transactional
	public List<Task> getAllTasksByAccessRight(List<String> taskIds, List<String> taskAccessRights) {
		List<Task> mainTaskList = new ArrayList<Task>();
		List<Task> taskLists = taskDAO.getTaskByAccessRight(taskAccessRights);
		for (Task task : taskLists) {
			for (String id : taskIds) {
				if (id.equalsIgnoreCase(task.getTask_id())) {
					mainTaskList.add(task);
					break;
				}
			}

		}
		return mainTaskList;
	}

	@Override
	@Transactional
	public PagePreference findPagePreference(Long userId, String pageName) {
		return pagePreferenceDAO.findPagePreference(userId, pageName);
	}

	@Override
	@Transactional
	public PagePreference saveOrUpdate(PagePreference pagePreference) {
		if (pagePreference.getId() == null) {
			return pagePreferenceDAO.create(pagePreference);
		} else {
			return pagePreferenceDAO.update(pagePreference);
		}
	}

	@Override
	@Transactional
	public void deletePreference(PagePreference pagePreference) {
		pagePreferenceDAO.delete(pagePreference);
	}

	@Override
	@Transactional
	public Long getTaskStatusCount(String status) {
		return taskDAO.getTaskStatusCount(status);
	}

	@Override
	@Transactional
	public List<Task> getTaskListByIds(List<String> taskIds) {
		return taskDAO.getTaskListByIds(taskIds);
	}

	@Transactional
	public Integer getTaskIdSeq() {
		return taskDAO.getTaskIdSeq();

	}
	
	@Transactional
	public Set<BaseFilter> getNormalSearchFilters(TaskBeanParam taskBeanParam) {
		Set<BaseFilter> normalSearchFilters = new HashSet<>();
		DateFilter dateFilter = new DateFilter();
		if (taskBeanParam.getColType().equals("created_on") || taskBeanParam.getColType().equals("modified_on")) {
			DateFilter dateFilter1 = dateFilter.getDateFilter(taskBeanParam.getDateValue(), null,
					taskBeanParam.getCondition(), taskBeanParam.getColType(), null);
			if (dateFilter1 != null) {
				normalSearchFilters.add(dateFilter1);
			}
		} else {
			StringFilter stringFilter = dateFilter.getStringFilter(taskBeanParam.getColValue(),
					taskBeanParam.getCondition(), taskBeanParam.getColType(), null);
			if (stringFilter != null) {
				normalSearchFilters.add(stringFilter);
			}
		}
		return normalSearchFilters;
	}
	
	@Transactional
	@Override
	public void updateTaskStatus(String taskId,String status){
		String[] taskArray =taskId.split(WBConstants.UNDER_SCORE);
		StatusHistory statusHistory = new StatusHistory(Long.valueOf(taskArray[0]), Long.valueOf(taskArray[1]),Long.valueOf(taskArray[2]), status, new Date());
		statusHistoryDAO.create(statusHistory);
	}
	

}