package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "metastore.SourceToTargetMapping")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name="sourceToTargetMapping")
public class SourceToTargetMapping extends AbstractModel {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonProperty("Key")
	private SourceToTargetMappingKey sourceToTargetMappingKey;
	
	@Column(name = "SourceEntityFileTypeID",insertable=false,updatable=false)
	@JsonIgnore
	private int SourceEntityFileTypeID;
	
	@Column(name = "TargetEntityFileTypeID",insertable=false,updatable=false)
	@JsonIgnore
	private int TargetEntityFileTypeID;
	
	@Column(name = "TargetColumnID",insertable=false,updatable=false)
	@JsonIgnore
	private int TargetColumnID;
	
	@JsonProperty("SourceEntityID")
	private Integer sourceEntityID;
	
	@JsonProperty("SourceFileTypeID")
	private Integer sourceFileTypeID;
	
	@JsonProperty("TargetEntityID")
	private Integer targetEntityID;
	
	@JsonProperty("TargetFileTypeID")
	private Integer targetFileTypeID;
	
	@JsonProperty("MapFunction")
	private String mapFunction;
	
	@JsonProperty("Active")
	private String active;
	
	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date effectiveDate;
	
	@JsonProperty("TargetColOrder")
	private Integer targetColOrder;
	
	
	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	public Integer getSourceEntityID() {
		return sourceEntityID;
	}

	public void setSourceEntityID(Integer sourceEntityID) {
		this.sourceEntityID = sourceEntityID;
	}
	public Integer getSourceFileTypeID() {
		return sourceFileTypeID;
	}

	public void setSourceFileTypeID(Integer sourceFileTypeID) {
		this.sourceFileTypeID = sourceFileTypeID;
	}

	public Integer getTargetEntityID() {
		return targetEntityID;
	}

	public void setTargetEntityID(Integer targetEntityID) {
		this.targetEntityID = targetEntityID;
	}

	public Integer getTargetFileTypeID() {
		return targetFileTypeID;
	}

	public void setTargetFileTypeID(Integer targetFileTypeID) {
		this.targetFileTypeID = targetFileTypeID;
	}

	public String getMapFunction() {
		return mapFunction;
	}

	public void setMapFunction(String mapFunction) {
		this.mapFunction = mapFunction;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Integer getTargetColOrder() {
		return targetColOrder;
	}

	public void setTargetColOrder(Integer targetColOrder) {
		this.targetColOrder = targetColOrder;
	}
	public SourceToTargetMappingKey getSourceToTargetMappingKey() {
		return sourceToTargetMappingKey;
	}
	
	public void setSourceToTargetMappingKey(SourceToTargetMappingKey sourceToTargetMappingKey) {
		this.sourceToTargetMappingKey = sourceToTargetMappingKey;
	}

	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}
	 @XmlTransient
	public int getSourceEntityFileTypeID() {
		return SourceEntityFileTypeID;
	}

	public void setSourceEntityFileTypeID(int sourceEntityFileTypeID) {
		SourceEntityFileTypeID = sourceEntityFileTypeID;
	}

	@XmlTransient
	public int getTargetEntityFileTypeID() {
		return TargetEntityFileTypeID;
	}

	public void setTargetEntityFileTypeID(int targetEntityFileTypeID) {
		TargetEntityFileTypeID = targetEntityFileTypeID;
	}

	@XmlTransient
	public int getTargetColumnID() {
		return TargetColumnID;
	}

	public void setTargetColumnID(int targetColumnID) {
		TargetColumnID = targetColumnID;
	}
	
	
	
	
}
