package com.artha.workbench.service;


import java.io.IOException;
import java.util.List;
import java.util.Set;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.EntityMasterDAO;
import com.artha.workbench.dao.FileTypeDAO;
import com.artha.workbench.dao.HeaderFooterDAO;
import com.artha.workbench.dao.HeaderFooterVwDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.metastore.HeaderFooter;
import com.artha.workbench.models.metastore.HeaderFooterKey;
import com.artha.workbench.models.metastore.HeaderFooterVw;
import com.artha.workbench.models.metastore.HeaderFooterVwkey;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("headerFooterService")
public class HeaderFooterServiceImpl implements HeaderFooterService {

	@Autowired
	HeaderFooterDAO headerFooterDAO;

	@Autowired
	HeaderFooterVwDAO headerFooterVwDAO;

	@Autowired
	FileTypeDAO fileTypeDAO;

	@Autowired
	EntityMasterDAO entityMasterDAO;

	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;
	


	@Transactional(readOnly = true)
	public List<HeaderFooter> getHeaderFooterList() {
		return headerFooterDAO.findAll();
	}
	
	@Transactional(readOnly = true)
	public List<HeaderFooterVw> getHeaderFooterVwListByReleaseNo(Integer releaseNo){
		return headerFooterVwDAO.getHeaderFooterVwListByReleaseNo(releaseNo);
	}
	
	@Transactional(readOnly = true)
	@Override
	public HeaderFooterVw getPreviousHeaderFooterVw(HeaderFooterVw headerFooterVw) throws IOException
	{
		HeaderFooterKey headerFooterKey = new HeaderFooterKey();
		headerFooterKey.setEntityFileTypeID(headerFooterVw.getEntityFileTypeId());
		headerFooterKey.setRecType(headerFooterVw.getRecType());
		headerFooterKey.setSeqNum(headerFooterVw.getSeqnum());
		String headerFooterVwJson = AppWebUtils.convertObjectToJson(headerFooterKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(headerFooterVw.getReleaseNo(), "HEADERFOOTER", headerFooterVwJson);
		HeaderFooterVw previousHeaderFooterVw = new HeaderFooterVw();
		if(releaseArchive!=null){
		previousHeaderFooterVw = AppWebUtils.convertJsonToObject(HeaderFooterVw.class, releaseArchive.getViewRecData());
		}
		return previousHeaderFooterVw;
		
	}

	@Transactional
	public void create(HeaderFooterVw headerFooterVw) {
		HeaderFooter hf = new HeaderFooter();
		HeaderFooterKey headerFooterKey = new HeaderFooterKey();
		headerFooterKey.setEntityFileTypeID(headerFooterVw.getEntityFileTypeId());
		headerFooterKey.setRecType(headerFooterVw.getRecType());
		headerFooterKey.setSeqNum(headerFooterVw.getSeqnum());
		hf.setHeaderFooterKey(headerFooterKey);
	    hf.setEntityID(headerFooterVw.getEntityId());
	    hf.setFileTypeID(headerFooterVw.getFileTypeId());
	    loadHeaderFooter(headerFooterVw, hf);
		
		headerFooterDAO.create(hf);
	}

	@Transactional
	public void update(HeaderFooterVw headerFooterVw,boolean isReleaseChanged) throws JsonProcessingException{
		HeaderFooterKey headerFooterKey = new HeaderFooterKey();
		headerFooterKey.setEntityFileTypeID(headerFooterVw.getEntityFileTypeId());
		headerFooterKey.setRecType(headerFooterVw.getRecType());
		headerFooterKey.setSeqNum(headerFooterVw.getSeqnum());
		checkForCyclicDependency(headerFooterVw);
		HeaderFooter oldEntity = headerFooterDAO.findOne(headerFooterKey);
		if(isReleaseChanged){
			HeaderFooterVwkey headerFooterVwkey = new HeaderFooterVwkey();
			headerFooterVwkey.setEntityName(headerFooterVw.getEntityName());
			headerFooterVwkey.setFileMask(headerFooterVw.getFileMask());
			headerFooterVwkey.setHSFileType(headerFooterVw.getHSFileType());
			headerFooterVwkey.setRecType(headerFooterVw.getRecType());
			headerFooterVwkey.setSeqnum(headerFooterVw.getSeqnum());
			HeaderFooterVw oldHeaderFooterVw = headerFooterVwDAO.findOne(headerFooterVwkey);
			if(oldHeaderFooterVw!=null){
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			releaseArchiveKey.setArchivedReleaseId(oldHeaderFooterVw.getReleaseNo());
			releaseArchiveKey.setReleaseId(headerFooterVw.getReleaseNo());
			releaseArchiveKey.setTableName("HEADERFOOTER");
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(oldEntity.getHeaderFooterKey()));
			
			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if(releaseArchive!=null){
				releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldHeaderFooterVw));
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(headerFooterVwkey));
				releaseArchiveDAO.update(releaseArchive);
			}else{
				releaseArchive=new ReleaseArchive();
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldHeaderFooterVw));
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(headerFooterVwkey));
				releaseArchiveDAO.create(releaseArchive);
			}
			}
		}
		if(oldEntity!=null){
			loadHeaderFooter(headerFooterVw, oldEntity);
			headerFooterDAO.update(oldEntity);
		}
	}
	
	private void checkForCyclicDependency(HeaderFooterVw headerFooterVw) throws JsonProcessingException	{
		HeaderFooterKey headerFooterKey = new HeaderFooterKey();
		headerFooterKey.setEntityFileTypeID(headerFooterVw.getEntityFileTypeId());
		headerFooterKey.setRecType(headerFooterVw.getRecType());
		headerFooterKey.setSeqNum(headerFooterVw.getSeqnum());
		String jsonId = AppWebUtils.convertObjectToJson(headerFooterKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(headerFooterVw.getReleaseNo(), "HEADERFOOTER", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	@Transactional
	public HeaderFooter loadHeaderFooter(HeaderFooterVw headerFooterVw, HeaderFooter hf) {
		hf.setHeaderFooterType(headerFooterVw.getHeaderFooterType());
		hf.setFileRecNum(headerFooterVw.getFileRecNum());
		hf.setColCnt(headerFooterVw.getColCnt());
		hf.setActive(headerFooterVw.getActive());
		hf.setEffectiveDate(headerFooterVw.getEffectiveDate());
		hf.setColumnsWidth(headerFooterVw.getColumnsWidth());
		hf.setColumnsPattern(headerFooterVw.getColumnsPattern());
		hf.setReleaseNo(headerFooterVw.getReleaseNo());
		return hf;
	}
	
	@Transactional 
	public HeaderFooter getHeaderFooter(HeaderFooterVw headerFooterVw){
		HeaderFooterKey headerFooterKey = new HeaderFooterKey();
		headerFooterKey.setEntityFileTypeID(headerFooterVw.getEntityFileTypeId());
		headerFooterKey.setRecType(headerFooterVw.getRecType());
		headerFooterKey.setSeqNum(headerFooterVw.getSeqnum());
		return headerFooterDAO.findOne(headerFooterKey);
	}
	@Transactional 
	public HeaderFooter getHeaderFooter(Integer entityFileTypeId,String recType,Integer seqNum){
		HeaderFooterKey headerFooterKey = new HeaderFooterKey();
		headerFooterKey.setEntityFileTypeID(entityFileTypeId);
		headerFooterKey.setRecType(recType);
		headerFooterKey.setSeqNum(seqNum);
		return headerFooterDAO.findOne(headerFooterKey);
	}

	@Transactional
	public List<HeaderFooterVw> getHeaderFooterVwList() {
		return headerFooterVwDAO.findAll();
	}

	@Transactional
	public void saveHeaderFooter(List<HeaderFooter> entitytypes) {
		headerFooterDAO.saveHeaderFooter(entitytypes);
	}

	@Transactional
	public List<HeaderFooter> getHeaderFooterDBList() {
		return headerFooterDAO.findAll();
	}

	@Override
	public List<String> getHeaderFooterRecTypeList() {
		return headerFooterDAO.getHeaderFooterRecTypeList();
	}

	@Override
	public List<Integer> getHeaderFooterSeqNumList() {
		return headerFooterDAO.getHeaderFooterSeqNumList();
	}
	
	@Transactional
	public List<HeaderFooter> getHeaderFooterListByReleaseNo(Integer releaseNo){
		return headerFooterDAO.getHeaderFooterListByReleaseNo(releaseNo);
	}

	@Transactional
	public List<Integer> getHeaderFooterReleaseNumbersByRecTypes(Set<String> recTypes,Integer selectedReleaseNumber){
		return headerFooterDAO.getHeaderFooterReleaseNumbersByRecTypes(recTypes, selectedReleaseNumber);
	}
	
	@Transactional
	public List<Integer> getHeaderFooterReleaseNumbersBySeqNums(Set<Integer> seqNumbers,Integer selectedReleaseNumber){
		return headerFooterDAO.getHeaderFooterReleaseNumbersBySeqNums(seqNumbers, selectedReleaseNumber);
	}
	
	@Transactional(readOnly=true)
	public List<Integer> getHeaderFooterReleaseNumbersByTypeIds(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber){
		return headerFooterDAO.getHeaderFooterReleaseNumbersByTypeIds(entityFileTypeIds, selectedReleaseNumber);
	}
	
	@Transactional(readOnly=true)
	public List<Integer> getAllHeaderFooterReleaseIds(Integer selectedReleaseId){
		return headerFooterDAO.getAllHeaderFooterReleaseIds(selectedReleaseId);
	}

	@Override
	public List<HeaderFooter> getHeaderFooterLists(Set<Integer> entityFileTypeIds, Set<String> recTypes,
			Set<Integer> seqNumbers, Integer selectedReleaseNumber) {
		return headerFooterDAO.getHeaderFooterLists(entityFileTypeIds, recTypes, seqNumbers, selectedReleaseNumber);
	}
}
