package com.artha.workbench.to;

import java.util.List;

import com.artha.workbench.models.datahub.TgtColumns;

public class TaskEditTO {
	
	private String taskName;
	private String taskStatus;
	private List<TgtColumns> targetList;
	private boolean saveDisabled;
	private List<String> selectedTaskIds;
	private String currentTaskId;
	private boolean taskLockedByOtherUser;
	
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	public List<TgtColumns> getTargetList() {
		return targetList;
	}
	public void setTargetList(List<TgtColumns> targetList) {
		this.targetList = targetList;
	}
	public boolean isSaveDisabled() {
		return saveDisabled;
	}
	public void setSaveDisabled(boolean saveDisabled) {
		this.saveDisabled = saveDisabled;
	}
	public List<String> getSelectedTaskIds() {
		return selectedTaskIds;
	}
	public void setSelectedTaskIds(List<String> selectedTaskIds) {
		this.selectedTaskIds = selectedTaskIds;
	}
	public String getCurrentTaskId() {
		return currentTaskId;
	}
	public void setCurrentTaskId(String currentTaskId) {
		this.currentTaskId = currentTaskId;
	}
	public boolean isTaskLockedByOtherUser() {
		return taskLockedByOtherUser;
	}
	public void setTaskLockedByOtherUser(boolean taskLockedByOtherUser) {
		this.taskLockedByOtherUser = taskLockedByOtherUser;
	}
	
}
