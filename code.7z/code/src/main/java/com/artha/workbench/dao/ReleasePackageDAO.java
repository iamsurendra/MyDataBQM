package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.ReleasePackages;
import com.guvvala.framework.dao.BaseDAO;

public interface ReleasePackageDAO extends BaseDAO<ReleasePackages, Integer> {

	List<ReleasePackages> fetchReleasePackages();
	
	Long getReleasePackageListCount(Set<String> releaseNames);
	
	Integer getMaxReleasePackageId();
	
	ReleasePackages getReleasePackageList(Integer releaseId,String releaseName);
	
	Integer freezeReleasePackageWithProc(Integer releasePackageId);
}
