package com.artha.workbench.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.models.userConfig.UserPreference;
import com.artha.workbench.models.userConfig.UserPreferencePK;
import com.artha.workbench.service.UserPreferenceService;
import com.guvvala.framework.util.ThreadLocalUtil;

@RestController
@RequestMapping("/api/userPreference")
public class UserPreferenceController {
	
	@Autowired
	private UserPreferenceService userPreferenceService;
	
	@RequestMapping(value = "/getUserPreferenceInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String,String> getUserPreferenceInfo() {
		List<UserPreference> userPreferenceList = userPreferenceService.getUserPreferenceByUserId(ThreadLocalUtil.getUserId());
		Map<String,String> userPreferenceMap = new HashMap<>();
		if (userPreferenceList.isEmpty()) {
			UserPreference timeOutUserPreference = new UserPreference();
			UserPreferencePK timeOutUserPreferencePK = new UserPreferencePK();
			timeOutUserPreferencePK.setUserId(ThreadLocalUtil.getUserId());
			timeOutUserPreferencePK.setPreference("TimeOut");
			timeOutUserPreference.setUserPreferencePK(timeOutUserPreferencePK);
			timeOutUserPreference.setValue("900000");
			timeOutUserPreference.setValueInMinutes("15");
			UserPreference pollIntervalUserPreference = new UserPreference();
			UserPreferencePK pollIntervalUserPreferencePK = new UserPreferencePK();
			pollIntervalUserPreferencePK.setUserId(ThreadLocalUtil.getUserId());
			pollIntervalUserPreferencePK.setPreference("POLL_INTERVAL");
			pollIntervalUserPreference.setUserPreferencePK(pollIntervalUserPreferencePK);
			pollIntervalUserPreference.setValue("60");
			userPreferenceList.add(timeOutUserPreference);
			userPreferenceList.add(pollIntervalUserPreference);
		}
		for (UserPreference userPreference : userPreferenceList) {
			if (userPreference.getUserPreferencePK().getPreference().equalsIgnoreCase("TimeOut")) {
				userPreferenceMap.put(userPreference.getUserPreferencePK().getPreference(), userPreference.getValueInMinutes());
			} else if (userPreference.getUserPreferencePK().getPreference().equalsIgnoreCase("POLL_INTERVAL")) {
				userPreferenceMap.put(userPreference.getUserPreferencePK().getPreference(), userPreference.getValue());
			}
		}
		return userPreferenceMap;
	}
	
	@RequestMapping(value = "/saveUserPreferenceInfo", method = RequestMethod.POST)
	public void saveUserPreferenceInfo(@RequestBody Map<String, String> userPreferenceInfo) {
		UserPreference timeOutPreference = new UserPreference();
		UserPreference pollIntervalPreference = new UserPreference();
		for (String preference : userPreferenceInfo.keySet()) {
			if (preference.equalsIgnoreCase("TimeOut")) {
				UserPreferencePK timeOutPreferencePK = new UserPreferencePK();
				timeOutPreferencePK.setUserId(ThreadLocalUtil.getUserId());
				timeOutPreferencePK.setPreference(preference);
				timeOutPreference.setUserPreferencePK(timeOutPreferencePK);
				timeOutPreference.setValueInMinutes(userPreferenceInfo.get(preference));
			} else if (preference.equalsIgnoreCase("POLL_INTERVAL")) {
				UserPreferencePK pollIntervalPreferencePK = new UserPreferencePK();
				pollIntervalPreferencePK.setUserId(ThreadLocalUtil.getUserId());
				pollIntervalPreferencePK.setPreference(preference);
				pollIntervalPreference.setUserPreferencePK(pollIntervalPreferencePK);
				pollIntervalPreference.setValue(userPreferenceInfo.get(preference));
			}
		}
		userPreferenceService.saveUserPreferences(timeOutPreference,pollIntervalPreference);
	}

}
