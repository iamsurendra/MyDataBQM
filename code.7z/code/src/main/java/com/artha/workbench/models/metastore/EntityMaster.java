package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.ExcelHeader;

@Entity
@Table(name = "metastore.EntityMaster")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@JsonRootName("entityMaster")
@XmlRootElement(name="entityMaster")
public class EntityMaster extends AbstractModel{

	private static final long serialVersionUID = 1L;

		@Id
		@Column(name = "EntityID", nullable = false)
		@NotNull
		@ExcelHeader(name="Entity ID")
		@JsonProperty("EntityID")
		private Integer entityID;
		
		@ExcelHeader(name="Entity Name")
		@JsonProperty("EntityName")
		private String entityName;
		
		@ExcelHeader(name="Entity Name Abbr")
		@JsonProperty("EntityNameAbbr")
		private String entityNameAbbr;
		
		@ExcelHeader(name="Entity TypeID")
		@JsonProperty("EntityTypeID")
		private Integer entityTypeID;
		
		@ExcelHeader(name="AddrLine1")
		@JsonProperty("AddrLine1")
		private String addrLine1;
		
		@ExcelHeader(name="AddrLine2")
		@JsonProperty("AddrLine2")
		private String addrLine2;
		
		@ExcelHeader(name="AddrLine3")
		@JsonProperty("AddrLine3")
		private String addrLine3;
		
		@ExcelHeader(name="City Name")
		@JsonProperty("CityName")
		private String cityName;
		
		@ExcelHeader(name="StateCd")
		@JsonProperty("StateCd")
		private String stateCd;
		
		@ExcelHeader(name="PostalCd")
		@JsonProperty("PostalCd")
		private String postalCd;
		
		@ExcelHeader(name="Postal Plus")
		@JsonProperty("PostalPlus")
		private String postalPlus;
		
		@ExcelHeader(name="Active")
		@JsonProperty("Active")
		private String active;
		
		@ExcelHeader(name="Effective Date")
		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
		@JsonProperty("EffectiveDt")
		private Date effectiveDt;
		
		@Column(name = "ReleaseNum", nullable = false)
		@JsonProperty("ReleaseNum")
		private Integer releaseNo;
		
		@Transient
	    @JsonIgnore
		private String effectiveDtstr;
		
		@Transient
		@JsonIgnore
		private String errorMsg;
		
		@Transient
		@JsonIgnore
		private boolean addMode;
		
		public EntityMaster(boolean addMode,Date effectiveDate,Integer releaseNo) {
			this.addMode = addMode;
			this.effectiveDt = effectiveDate;
			this.releaseNo = releaseNo;
			convertEffectiveDate();
		}
		
		
		public EntityMaster() {
		}

        @XmlTransient
        @JsonIgnore
		public String getErrormsg() {
			return errorMsg;
		}
		public void setErrormsg(String errormsg) {
			errorMsg = errormsg;
		}
		public Integer getEntityID() {
			return entityID;
		}
		@XmlTransient
		public String getEffectiveDtstr() {
			return effectiveDtstr;
		}
		public void setEffectiveDtstr(String effectiveDtstr) {
			this.effectiveDtstr = effectiveDtstr;
		}
		public void setEntityID(Integer entityID) {
			this.entityID = entityID;
		}
		public String getEntityName() {
			return entityName;
		}
		public void setEntityName(String entityName) {
			this.entityName = entityName;
		}
		public String getEntityNameAbbr() {
			return entityNameAbbr;
		}
		public void setEntityNameAbbr(String entityNameAbbr) {
			this.entityNameAbbr = entityNameAbbr;
		}
		public Integer getEntityTypeID() {
			return entityTypeID;
		}
		public void setEntityTypeID(Integer entityTypeID) {
			this.entityTypeID = entityTypeID;
		}
		public String getAddrLine1() {
			return addrLine1;
		}
		public void setAddrLine1(String addrLine1) {
			this.addrLine1 = addrLine1;
		}
		public String getAddrLine2() {
			return addrLine2;
		}
		public void setAddrLine2(String addrLine2) {
			this.addrLine2 = addrLine2;
		}
		public String getAddrLine3() {
			return addrLine3;
		}
		public void setAddrLine3(String addrLine3) {
			this.addrLine3 = addrLine3;
		}
		public String getCityName() {
			return cityName;
		}
		public void setCityName(String cityName) {
			this.cityName = cityName;
		}
		public String getStateCd() {
			return stateCd;
		}
		public void setStateCd(String stateCd) {
			this.stateCd = stateCd;
		}
		public String getPostalCd() {
			return postalCd;
		}
		public void setPostalCd(String postalCd) {
			this.postalCd = postalCd;
		}
		public String getPostalPlus() {
			return postalPlus;
		}
		public void setPostalPlus(String postalPlus) {
			this.postalPlus = postalPlus;
		}
		public String getActive() {
			return active;
		}
		public void setActive(String active) {
			this.active = active;
		}
		public Date getEffectiveDt() {
			return effectiveDt;
		}
		public void setEffectiveDt(Date effectiveDt) {
			this.effectiveDt = effectiveDt;
		}
		@XmlTransient
		public boolean isAddMode() {
			return addMode;
		}
		public void setAddMode(boolean addMode) {
			this.addMode = addMode;
		}
		
		public Integer getReleaseNo() {
			return releaseNo;
		}


		public void setReleaseNo(Integer releaseNo) {
			this.releaseNo = releaseNo;
		}


		@PostLoad
		public void postLoad(){
			convertEffectiveDate();
		}
		public void convertEffectiveDate(){
			this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDt());	
		}
	
	
}
