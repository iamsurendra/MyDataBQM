package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.datahub.TgtColumns;
import com.guvvala.framework.dao.BaseDAO;

public interface TgtColumnsDAO extends BaseDAO<TgtColumns, String> {

	public void deleteAllTgtColumns(List<String> recIds);

	public void updateTargetCol(List<TgtColumns> targetLists, int isModified);

	public void updateWithProcedure(String json);
}
