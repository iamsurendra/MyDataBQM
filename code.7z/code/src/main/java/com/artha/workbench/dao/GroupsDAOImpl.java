package com.artha.workbench.dao;


import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.Groups;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class GroupsDAOImpl extends BaseDAOImpl<Groups, Integer> implements GroupsDAO {

	public GroupsDAOImpl() {
		super(Groups.class);
	}
	
	@Override
	public String getGroupName(Integer groupID) {
		TypedQuery<String> query = entityManager.createQuery("select name from Groups where id = :groupID",
				String.class);
		query.setParameter("groupID", groupID);
		return query.getSingleResult();
	}

	@Override
	public Boolean groupNameExists(String groupName) {
		TypedQuery<Groups> query = entityManager.createQuery("from Groups where name = :groupName",
				Groups.class);
		query.setParameter("groupName", groupName);
		if(query.getResultList().size()>0)
		{
			return true;
		}
		return false;
	}
	@Override
	public List<Groups> getAllGroups() {
		TypedQuery<Groups> query = entityManager.createQuery("select group from  Groups group order by group.name",
				Groups.class);
		return query.getResultList();
	}


}
