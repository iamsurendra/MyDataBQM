package com.artha.workbench.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileTypeScheduleXref;
import com.artha.workbench.to.FileMaskTO;
import com.guvvala.framework.dao.BaseDAOImpl;
import com.guvvala.framework.util.StringUtils;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityFileTypeScheduleXrefDAOImpl extends BaseDAOImpl<EntityFileTypeScheduleXref, Integer> implements EntityFileTypeScheduleXrefDAO {

	public EntityFileTypeScheduleXrefDAOImpl() {
		super(EntityFileTypeScheduleXref.class);
	}
	public void saveEntityFileTypeScheduleXref(List<EntityFileTypeScheduleXref> entitytypes)
	{
		batchCreate(entitytypes, 50);
	}
	public void deleteEntityFileTypeScheduleXref() {
		Query query = entityManager.createQuery("delete from EntityFileTypeScheduleXref");
		query.executeUpdate();
	}
	public int getMaxEntitySchedID()
	{
	  int loginid = 0;// changed 1 to 0 because to avoid data constraint voilation Exception
    TypedQuery<Integer> query = entityManager.createQuery("SELECT max(entityFileTypeSchedID) from EntityFileTypeScheduleXref", Integer.class);
      	if(query.getSingleResult()!=null)
      	loginid = query.getSingleResult();
      return loginid;
	}
	@Override
	public List<FileMaskTO> loadFileMaskTO() {
		List<Object[]> filelist = new ArrayList<>();
		List<FileMaskTO> fileMaskTOList = new ArrayList<FileMaskTO>();
		TypedQuery<Object[]> query = entityManager
				.createQuery("SELECT entityFileTypeID,fileMask,shortDescription from EntityFileTypeXref", Object[].class);
		filelist = query.getResultList();
		for (Object[] array : filelist) {
			FileMaskTO fileMaskTO = new FileMaskTO();
			fileMaskTO.setEntityFileTypeID((Integer) array[0]);
			fileMaskTO.setFileMask((String) array[1]);
			fileMaskTO.setDescription((String) array[2]);
			fileMaskTOList.add(fileMaskTO);
		}
		return fileMaskTOList;
	}
	@Override
	public List<FileMaskTO> searchFileMaskTO(String fileMask,String description) {
		List<Object[]> filelist = new ArrayList<>();
		List<FileMaskTO> fileMaskTOList = new ArrayList<FileMaskTO>();
		TypedQuery<Object[]> query;
		if(StringUtils.isEmpty(fileMask)){
			query = entityManager
					.createQuery("SELECT entityFileTypeID,fileMask,shortDescription from EntityFileTypeXref where shortDescription like :shortDescription", Object[].class);
		    query.setParameter("shortDescription", "%"+description+"%");
		}else if(StringUtils.isEmpty(description)){
			query = entityManager
					.createQuery("SELECT entityFileTypeID,fileMask,shortDescription from EntityFileTypeXref where fileMask like :fileMask", Object[].class);
			query.setParameter("fileMask", "%"+fileMask+"%");
		}else{
		query = entityManager
				.createQuery("SELECT entityFileTypeID,fileMask,shortDescription from EntityFileTypeXref where fileMask like :fileMask and shortDescription like :shortDescription", Object[].class);
		    query.setParameter("fileMask", "%"+fileMask+"%");
		    query.setParameter("shortDescription", "%"+description+"%");
		}
	   
		filelist = query.getResultList();
		for (Object[] array : filelist) {
			FileMaskTO fileMaskTO = new FileMaskTO();
			fileMaskTO.setEntityFileTypeID((Integer) array[0]);
			fileMaskTO.setFileMask((String) array[1]);
			fileMaskTO.setDescription((String) array[2]);
			fileMaskTOList.add(fileMaskTO);
		}
		return fileMaskTOList;
	}

	public  List<EntityFileTypeScheduleXref> getEntityFileTypeScheduleXrefList(Integer releaseNO)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeScheduleXref> query = cb.createQuery(EntityFileTypeScheduleXref.class);
		Root<EntityFileTypeScheduleXref> root = query.from(EntityFileTypeScheduleXref.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNO));
		return this.entityManager.createQuery(query).getResultList() ;
	}
	
	@Override
	public List<Integer> getAllEntityFileTypeSchXrefReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from EntityFileTypeScheduleXref where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	
	
	public List<Integer> getEntityFileTypeSchedIds() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = criteriaBuilder.createQuery(Integer.class);
		Root<EntityFileTypeScheduleXref> root = criteriaQuery.from(EntityFileTypeScheduleXref.class);
		criteriaQuery.multiselect(root.get("entityFileTypeSchedID")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
}
