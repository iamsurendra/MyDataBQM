package com.artha.workbench.to;


import java.util.HashSet;

import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="dependencies")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder={"releasePhysicalInfo","releaseLogicalInfo"})
public class ReleaseDependenciesTO {
	
	@XmlElement(name="physical")
	private ReleasePhysicalInfoTO releasePhysicalInfo = new ReleasePhysicalInfoTO();
	
	@XmlElementWrapper(name="logical")
	@XmlElement(name="dependentRelease")
	private Set<String> releaseLogicalInfo = new HashSet<>();
	
	
	public ReleasePhysicalInfoTO getReleasePhysicalInfo() {
		return releasePhysicalInfo;
	}
	public void setReleasePhysicalInfo(ReleasePhysicalInfoTO releasePhysicalInfo) {
		this.releasePhysicalInfo = releasePhysicalInfo;
	}
	public Set<String> getReleaseLogicalInfo() {
		return releaseLogicalInfo;
	}
	public void setReleaseLogicalInfo(Set<String> releaseLogicalInfo) {
		this.releaseLogicalInfo = releaseLogicalInfo;
	}
	
	
	
	
}
