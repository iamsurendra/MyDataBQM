package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EmptyFileConfig;
import com.guvvala.framework.dao.BaseDAO;


public interface EmptyFileConfigDAO extends BaseDAO<EmptyFileConfig, Integer> {

	public int getmaxEmptyFileConfig();

	public void deleteEmptyFileConfig();

	public void saveEmptyFileConfig(List<EmptyFileConfig> emptyFileConfig);

	public List<EmptyFileConfig> getEmptyFileConfigByReleaseNo(Integer releaseNo);

	public List<Integer> getAllEmptyFileConfigReleaseIds(Integer selectedReleaseId);
}
