package com.artha.workbench.models.metastore;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SourceToTargetVwKey implements Serializable{

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	    @JsonProperty("InputFileMask")
		private String InputFileMask;
		
	    @JsonProperty("EntityName")
		private String EntityName;
		
	    @JsonProperty("HSFileType")
		private String HSFileType;
		
	    @JsonProperty("TargetEntityFileMask")
		private String TargetEntityFileMask;
		
	    @JsonProperty("TargetEntityName")
		private String TargetEntityName;	
		
	    @JsonProperty("ColumnID")
		private Integer ColumnID;
		
		
		public String getInputFileMask() {
			return InputFileMask;
		}
		public void setInputFileMask(String inputFileMask) {
			InputFileMask = inputFileMask;
		}
		public String getEntityName() {
			return EntityName;
		}
		public void setEntityName(String entityName) {
			EntityName = entityName;
		}
		public String getHSFileType() {
			return HSFileType;
		}
		public void setHSFileType(String hSFileType) {
			HSFileType = hSFileType;
		}
		public String getTargetEntityFileMask() {
			return TargetEntityFileMask;
		}
		public void setTargetEntityFileMask(String targetEntityFileMask) {
			TargetEntityFileMask = targetEntityFileMask;
		}
		public String getTargetEntityName() {
			return TargetEntityName;
		}
		public void setTargetEntityName(String targetEntityName) {
			TargetEntityName = targetEntityName;
		}
		public Integer getColumnID() {
			return ColumnID;
		}
		public void setColumnID(Integer columnID) {
			ColumnID = columnID;
		}
		
		
}
