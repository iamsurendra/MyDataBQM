package com.artha.workbench.dao;




import java.util.List;
import java.util.Set;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileTypeWebService;
import com.guvvala.framework.dao.BaseDAOImpl;



@Repository
public class EntityFileTypeWebServiceDAOImpl extends BaseDAOImpl<EntityFileTypeWebService, Integer> implements EntityFileTypeWebServiceDAO {

	public EntityFileTypeWebServiceDAOImpl() {
		super(EntityFileTypeWebService.class);
	}

	public List<Integer> getWebServiceIds() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<EntityFileTypeWebService> root = query.from(EntityFileTypeWebService.class);
		query.select(root.<Integer> get("webServiceID")).distinct(true);

		return this.entityManager.createQuery(query).getResultList();

	}
	
	public int getmaxWebService() {
		int loginid = 0;
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(webServiceID) from EntityFileTypeWebService",
				Integer.class);
		if (query.getSingleResult() != null)
			loginid = query.getSingleResult();
		return loginid;
	}


	public List<EntityFileTypeWebService> getEntityFileTypeWebServicefList(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeWebService> query = cb.createQuery(EntityFileTypeWebService.class);
		Root<EntityFileTypeWebService> root = query.from(EntityFileTypeWebService.class);
		query.select(root).distinct(true);
		query.where(cb.and(cb.in(root.get("webServiceID")).value(entityFileTypeIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<EntityFileTypeWebService> getEntityFileTypeWebServiceListByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeWebService> query = cb.createQuery(EntityFileTypeWebService.class);
		Root<EntityFileTypeWebService> root = query.from(EntityFileTypeWebService.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllEntityFileTypeWebServiceReleaseIds(Integer selectedReleaseId) {
		TypedQuery<Integer> query = entityManager.createQuery("select releaseNo from EntityFileTypeWebService where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
}
