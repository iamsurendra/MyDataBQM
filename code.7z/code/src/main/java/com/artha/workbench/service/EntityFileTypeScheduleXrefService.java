package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.EntityFileTypeScheduleXref;
import com.artha.workbench.models.metastore.EntityFileTypeScheduleXrefVw;
import com.artha.workbench.to.FileMaskTO;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EntityFileTypeScheduleXrefService {

	public List<EntityFileTypeScheduleXref> getEntityFileTypeScheduleXrefList();

	public void create(EntityFileTypeScheduleXrefVw eftSchXrefVw);

	public void update(EntityFileTypeScheduleXrefVw eftSchXrefVw,boolean isReleaseChanged) throws JsonProcessingException ;

	public List<EntityFileTypeScheduleXrefVw> getEntityFileTypeScheduleXrefVwList();

	public void saveEntityFileTypeScheduleXref(List<EntityFileTypeScheduleXref> entitytypes);

	public int getMaxEntitySchedID();
	public List<FileMaskTO> loadFileMaskTO();
	
	public List<FileMaskTO> searchFileMaskTO(String fileMask,String description);
	
	public EntityFileTypeScheduleXrefVw getPreviousEntityFileTypeScheduleXrefVw(EntityFileTypeScheduleXrefVw entityFileTypeScheduleXrefVw) throws IOException;
	
	public List<EntityFileTypeScheduleXrefVw> getEntityFileTypeScheduleXrefByReleaseNo(Integer releaseNo);
	
	public  List<EntityFileTypeScheduleXref> getEntityFileTypeScheduleXrefList(Integer releaseNO);
	
	List<Integer> getAllEntityFileTypeSchXrefReleaseIds(Integer selectedReleaseId);
}
