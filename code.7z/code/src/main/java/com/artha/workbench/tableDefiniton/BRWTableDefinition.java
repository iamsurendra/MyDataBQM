package com.artha.workbench.tableDefiniton;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "report")
@XmlType(propOrder = {"displayName", "tables"})
public class BRWTableDefinition implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String displayName;
	private List<BRWTable> tables = new ArrayList<BRWTable>();

	@XmlAttribute
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	@XmlElementWrapper(name = "tables")
	@XmlElement(name = "table", type = BRWTable.class)
	public List<BRWTable> getTables() {
		return tables;
	}

	public void setTables(List<BRWTable> tables) {
		this.tables = tables;
	}

	public Map<String, BRWTable> getTableMap() {
		Map<String, BRWTable> tableMap = new HashMap<String, BRWTable>();
		for (BRWTable table : getTables()) {
			tableMap.put(table.getId(), table);
		}
		return tableMap;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BRWTableDefinition other = (BRWTableDefinition) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	

}
