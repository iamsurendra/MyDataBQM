package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.HSFileType;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface FileTypeService {
	
	public List<HSFileType> getHSFileTypeList();
	public void create(HSFileType HSFileType);
	public void update(HSFileType HSFileType,boolean isReleaseChanged)throws JsonProcessingException;;
	 public void saveHSFileType(List<HSFileType> entitytypes);
	 public int getmaxhsFileType() ;
	 public HashMap<String,Integer> loadFiletypeId();
	 public HashMap<String,Integer> loadSelectedFiletypeId(int entityid);
	 public HashMap<Integer,String> loadFiletypeIdMap();
	 public HSFileType getPreviousFileType(HSFileType fileType) throws IOException;
	 public List<HSFileType> getFileTypeListByReleaseNo(Integer releaseNo);
	 public List<Integer> getFileTypeReleaseNumbers(Set<Integer> fileTypeIds,Integer selectedReleaseNumber);
	 List<Integer> getAllFileTypeReleaseIds(Integer selectedReleaseId);
	 List<HSFileType> getFileTypesList(Set<Integer> fileTypeIds, Integer selectedReleaseNumber) ;
}
