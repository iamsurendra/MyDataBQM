package com.artha.workbench.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.constant.UserStatus;
import com.artha.workbench.dao.GroupRolesDAO;
import com.artha.workbench.dao.GroupsDAO;
import com.artha.workbench.dao.OauthAccessTokenDAO;
import com.artha.workbench.dao.UserDAO;
import com.artha.workbench.models.userConfig.GroupRoles;
import com.artha.workbench.models.userConfig.HsSecurityAccess;
import com.artha.workbench.models.userConfig.User;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppUser;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.PasswordEncryptor;
import com.guvvala.framework.util.PasswordGenerator;
@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userDAO;

	@Autowired
	GroupsDAO groupsDAO;

	@Autowired
	GroupRolesDAO groupRolesDAO;

	@Autowired
	private MailService ms;
	
	@Autowired
	OauthAccessTokenDAO oAuthAccessTokenDAO;

	@Transactional( readOnly = true)
	public List<User> findAll() {
		List<User> users = userDAO.findAll();
		Map<Integer, String> groups = new HashMap<>();
		for (User user : users) {
			if (user.getGroupid() != null) {
				String groupName = groups.get(user.getGroupid());
				if (groupName == null) {
					groupName = groupsDAO.getGroupName(user.getGroupid());
					groups.put(user.getGroupid(), groupName);
				}
				user.setGroupName(groupName);
			}
		}
		return users;
	}

	@Transactional
	public void create(User user) {
		userDAO.create(user);
	}

	@Transactional
	public void update(User user) {
		userDAO.update(user);
	}

	@Override
	@Transactional( readOnly = true)
	public boolean uniqueUserEmail(String email) {
		return userDAO.uniqueUserEmail(email);
	}

	@Override
	@Transactional( readOnly = true)
	public boolean uniqueUserEmail(String email, String userId) {
		return userDAO.uniqueUserEmail(email, userId);
	}

	@Override
	@Transactional( readOnly = true)
	public boolean uniqueUserName(String userName) {
		return userDAO.uniqueUserName(userName);
	}

	
	@Transactional
	public AppUser getUserForLogin(String userNameOrEmail, String password) {
		User user = userDAO.getUser(userNameOrEmail);
		if (user == null) {
			throw new AppException(MessagesEnum.INVALIDUSER_MSG);
		} else {
			int loginAttemptCount = user.getLoginAttempts();
			if (isValidPassword(user, password)) {
				if (!hasExceededLoginAttempts(user)) {
					loginAttemptCount = 0;
				}
				if (user.hasPasswordExpired()) {
					user.setUserStatus(Integer.valueOf(UserStatus.USER_EXPIRED.value));
					user.setLoginAttempts(loginAttemptCount);
					userDAO.update(user);
					return new AppUser(user);
				} else if (user.getUserStatus().equals(Integer.valueOf(UserStatus.USER_DISABLED.value))) {
					throw new AppException(MessagesEnum.USER_DISABLED_MSG, user.getUserName());
				} else if (user.getUserStatus().equals(Integer.valueOf(UserStatus.USER_LOCKED.value))) {
					throw new AppException(MessagesEnum.USER_LOCKED_MSG, user.getUserName());
				}
				user.setLoginAttempts(loginAttemptCount);
				user.setLastLoginDate(new Date());
				user = userDAO.update(user);
				oAuthAccessTokenDAO.deleteOauthTokenName(user.getUserEmail());
			} else {
				++loginAttemptCount;
				if (loginAttemptCount >= 3) {
					user.setUserStatus(UserStatus.USER_LOCKED.value);
					user.setLoginAttempts(loginAttemptCount);
					user = userDAO.update(user);
					return new AppUser(user);
				}
				user.setLoginAttempts(loginAttemptCount);
				user = userDAO.update(user);
				return null;
			}
		}
		return new AppUser(user);
	}

	public boolean isValidPassword(User user, String password) {
		return PasswordEncryptor.isValidPassword(password + user.getUserSalt(), user.getPasswordHash());
	}
	
	@Override
	public boolean isValidPassword(Long userId, String password) {
		User user = userDAO.findOne(userId);
		return PasswordEncryptor.isValidPassword(password + user.getUserSalt(), user.getPasswordHash());
	}

	private boolean hasExceededLoginAttempts(User user) {
		return user.getLoginAttempts() >= 3;
	}

	@Transactional( readOnly = true)
	public User getUser(String Email) {
		return userDAO.getUser(Email);
	}

	@Transactional
	public User forgotPassword(User user, String password) {
		if (user != null) {
			String salt = PasswordEncryptor.generateSalt();
			String hash = PasswordEncryptor.applySHA256(password + salt);
			user.setUserSalt(salt);
			user.setPasswordHash(hash);
			user.setUserStatus(UserStatus.USER_FIRST_LOGIN.value);
			user.setLoginAttempts(0);
			user.setPasswordExpirationDate(DateUtils.addDays(Calendar.getInstance().getTime(), 90));
			return userDAO.update(user);
		} else {
			return null;
		}

	}
	
	

	@Transactional
	public void resetpwd(Long userid, String password) throws AddressException, MessagingException {
		User user = userDAO.findOne(userid);
		String salt = PasswordEncryptor.generateSalt();
		String hash = PasswordEncryptor.applySHA256(password + salt);
		user.setUserSalt(salt);
		user.setPasswordHash(hash);
		user.setUserStatus(UserStatus.USER_ENABLED.value);
		user.setLoginAttempts(0);
		user.setLastLoginDate(new Date());
		user.setPasswordExpirationDate(DateUtils.addDays(Calendar.getInstance().getTime(), 90));
		userDAO.update(user);
		ms.sendMail(password, user.getUserName(), user.getUserEmail(), user.getFirstName());
	}

	@Transactional
	public void unlockUser(List<Long> userIdList) {
		for (Long userId : userIdList) {
			userDAO.unlockUser(userId);
		}

	}

	@Transactional
	public void unlockUsers(String userIds[]) {
		for (String unlockid : userIds) {
			userDAO.unlockUser(Long.parseLong(unlockid));
		}
	}

	@Transactional
	public void resetPasswords(List<Long> userIds) throws AddressException, MessagingException {
		for (Long uid : userIds) {
			resetpwd(uid, String.valueOf(PasswordGenerator.generatePassword()));
			User user = userDAO.findOne(uid);
			user.setUserStatus(UserStatus.USER_FIRST_LOGIN.value);
			user.setLoginAttempts(0);
			userDAO.update(user);
		}

	}

	@Transactional
	public void updateUserGroup(Long userId, int groupid) {
		userDAO.updateUserGroup(userId, groupid);
	}

	@Transactional
	public void saveRoleGroup(GroupRoles groupRoles) {
		groupRolesDAO.create(groupRoles);
	}

	@Transactional
	public Map<String, Integer> getColAccessRights(Integer groupId) {
		Map<String, Integer> accessMap = new HashMap<String, Integer>();
		List<HsSecurityAccess> hsSecurityAccesses = userDAO.getColAccessRights(groupId);
		for (HsSecurityAccess hsSecurityAccess : hsSecurityAccesses) {
			// ENS_FTV_156
			accessMap.put(hsSecurityAccess.getPartnerName().concat("_").concat(hsSecurityAccess.getFileName())
					.concat("_").concat(hsSecurityAccess.getEntityFileTypeId()).concat("_")
					.concat(hsSecurityAccess.getColName()), hsSecurityAccess.getWriteMode());
			// ENS_FTV_-156
			accessMap.put(hsSecurityAccess.getPartnerName().concat("_").concat(hsSecurityAccess.getFileName())
					.concat("_").concat("-").concat(hsSecurityAccess.getEntityFileTypeId()).concat("_")
					.concat(hsSecurityAccess.getColName()), hsSecurityAccess.getWriteMode());
		}
		return accessMap;
	}

	@Transactional
	public List<String> getTaskAccessRights(Integer groupId) {
		List<String> taskAccessRigts = new ArrayList<String>();
		taskAccessRigts = userDAO.getTaskAccessRights(groupId);
		return taskAccessRigts;
	}

	@Transactional
	public void updateUser(User user) {
		if (user.getUserStatus().equals(UserStatus.USER_LOCKED.value)) {
			user.setLoginAttempts(3);
			user.setUserStatus(UserStatus.USER_LOCKED.value);
		} else {
			if (user.getUserStatus() != UserStatus.USER_FIRST_LOGIN.value) {
				user.setLoginAttempts(0);
				user.setUserStatus(UserStatus.USER_ENABLED.value);
			}
		}
		userDAO.update(user);
	}

	@Transactional
	public List<Long> getUsers(Integer groupId) {
		return userDAO.getUsers(groupId);
	}
	
	@Override
	@Transactional
	public void deleteUser(User userId) {
		userDAO.delete(userId);
	}
	@Override
	@Transactional(readOnly =true)
	public User findOne(Long id){
		return userDAO.findOne(id);
	}

	@Transactional
	public void usersGroupUpdate(List<Long> userIds, Integer groupId) {
		List<User> users = userDAO.getUsersList(groupId);
		for (User user : users) {
			if (!userIds.contains(user.getUserId())) {
				user.setGroupid(null);
				userDAO.update(user);
			}
		}
		for (Long userId : userIds) {
			boolean newGroup = true;
			for (User user : users) {
				if (user.getUserId().equals(userId)) {
					newGroup = false;
					break;
				}
			}
			if (newGroup) {
				User user = userDAO.findOne(userId);
				user.setGroupid(groupId);
				userDAO.update(user);
			}
		}
	}
	
	
	public List<String> getUserNames()
	{
		return userDAO.getUserNames();
	}
	
	@Transactional
	public void updateUserStatus(User user){
		userDAO.update(user);
	}
	
	@Override
	@Transactional
	public void deleteUsers(List<Long> selectedUserIdList) {
		for(Long userId : selectedUserIdList) {
			User user = userDAO.findOne(userId);
			userDAO.delete(user);
		}
	}
	
	

}
