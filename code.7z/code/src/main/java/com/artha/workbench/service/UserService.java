package com.artha.workbench.service;

import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.artha.workbench.models.userConfig.GroupRoles;
import com.artha.workbench.models.userConfig.User;
import com.guvvala.framework.util.AppUser;

public interface UserService {

	public List<User> findAll();

	public void create(User user);

	public void update(User user);

	public boolean uniqueUserEmail(String email);
	
	public boolean uniqueUserEmail(String email,String userId);

	public boolean uniqueUserName(String userName);

	public AppUser getUserForLogin(String userNameOrEmail, String password);

	public User getUser(String Email);

	public void resetpwd(Long userid, String password) throws AddressException, MessagingException;

	public User forgotPassword(User user, String password);

	void unlockUser(List<Long> userIdList);

	public void unlockUsers(String userId[]);
	
	public void updateUserGroup(Long userId,int groupid);
	
	public void saveRoleGroup(GroupRoles groupRoles);

	public void resetPasswords(List<Long> userId) throws AddressException, MessagingException;

	public Map<String,Integer> getColAccessRights(Integer groupId);
	
	public List<String> getTaskAccessRights(Integer groupId);

    public void updateUser(User user);
    
    List<Long> getUsers(Integer groupId);
    
    void usersGroupUpdate(List<Long> userIds, Integer groupId);
    
    public void deleteUser(User userId);
    
    public User findOne(Long id);
    
    List<String> getUserNames();
    
	public void updateUserStatus(User user);

	void deleteUsers(List<Long> selectedUserIdList);

	boolean isValidPassword(Long userId, String password);
}
