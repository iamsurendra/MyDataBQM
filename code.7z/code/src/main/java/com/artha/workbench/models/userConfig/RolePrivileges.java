package com.artha.workbench.models.userConfig;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the roleprivileges database table.
 * 
 */
@Entity
@Table(name="userconfig.roleprivileges")
@NamedQuery(name="RolePrivileges.findAll", query="SELECT r FROM RolePrivileges r")
public class RolePrivileges implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Column(name="CNAME_ID")
	private String cnameId;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="FILE_TYPE")
	private String fileType;

	@Column(name="PARTNER_CD")
	private String partnerCd;

	@Column(name="READ_MODE")
	private String readMode;

	@Column(name="ROLE_TYPE_ID")
	private int roleTypeId;

	private String status;

	@Column(name="UPDATED_BY")
	private String updatedBy;

	@Column(name="UPDATED_DATE")
	private Timestamp updatedDate;

	@Column(name="WRITE_MODE")
	private String writeMode;

	public RolePrivileges() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCnameId() {
		return this.cnameId;
	}

	public void setCnameId(String cnameId) {
		this.cnameId = cnameId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getFileType() {
		return this.fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getPartnerCd() {
		return this.partnerCd;
	}

	public void setPartnerCd(String partnerCd) {
		this.partnerCd = partnerCd;
	}

	public String getReadMode() {
		return this.readMode;
	}

	public void setReadMode(String readMode) {
		this.readMode = readMode;
	}

	public int getRoleTypeId() {
		return this.roleTypeId;
	}

	public void setRoleTypeId(int roleTypeId) {
		this.roleTypeId = roleTypeId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getUpdatedDate() {
		return this.updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getWriteMode() {
		return this.writeMode;
	}

	public void setWriteMode(String writeMode) {
		this.writeMode = writeMode;
	}

}