package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.EntityFileTypeXref;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityFileTypeXrefDAO extends BaseDAO<EntityFileTypeXref, Integer> {

	public HashMap<String,Integer> loadentityFileTypeID();
	public void saveEntityFileTypeXref(List<EntityFileTypeXref> entitytypes);
	 public void deleteEntityFileTypeXref();
	 public int getfilemaskID(String filemask,int entityid,int filetypeid);
	 public int getMaxEntityFileTypeID();
	 public HashMap<Integer, String> loadEntityFileTypeID();
	 public List<EntityFileTypeXref> getEntityFileTypeXrefListByReleaseNo(Integer releaseNo);
	 List<Integer> getEntityTypeXrefReleaseNumbers(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber);
	 List<Integer> getAllEntityFileTypeXrefReleaseIds(Integer selectedReleaseId);
	 List<EntityFileTypeXref> getEntityTypeXrefList(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber);
	 public List<Integer> loadentityFileTypeid();
}
