package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "metastore.EntityFileTypeQueries")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name = "entityFileTypeQueries")
public class EntityFileTypeQueries extends AbstractModel {
	
	
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	@JsonProperty("Key")
	private EntityFileTypeQueriesKey entityFileTypeQueriesKey;

	@Column(name = "EntityFileTypeID",insertable=false,updatable=false)
    @JsonIgnore
	private Integer entityFileTypeID;
	
	@Column(name = "StepID",insertable=false,updatable=false)
	@JsonIgnore
	private Integer stepID;
	
	@Column(name = "SeqOrder",insertable=false,updatable=false)
	@JsonIgnore
	private Integer  seqOrder;
	
	@JsonProperty("QueryText")
	private String queryText;
	
	@JsonProperty("Active")
	private String active;
	
	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date effectiveDate;

	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Transient
	@JsonIgnore
	private boolean addMode; 
	
	
	
	
	
	public EntityFileTypeQueries(Integer releaseNo, boolean addMode) {
		this.releaseNo = releaseNo;
		this.addMode = addMode;
	}
	
	

	public EntityFileTypeQueries() {
		
	}



	//Getters & Setters
	
	public EntityFileTypeQueriesKey getEntityFileTypeQueriesKey() {
		return entityFileTypeQueriesKey;
	}

	public void setEntityFileTypeQueriesKey(EntityFileTypeQueriesKey entityFileTypeQueriesKey) {
		this.entityFileTypeQueriesKey = entityFileTypeQueriesKey;
	}
    @XmlTransient
	public Integer getEntityFileTypeID() {
		return entityFileTypeID;
	}

	public void setEntityFileTypeID(Integer entityFileTypeID) {
		this.entityFileTypeID = entityFileTypeID;
	}
    @XmlTransient
	public Integer getStepID() {
		return stepID;
	}

	public void setStepID(Integer stepID) {
		this.stepID = stepID;
	}
    
	
    @XmlTransient
	public Integer getSeqOrder() {
		return seqOrder;
	}

	public void setSeqOrder(Integer seqOrder) {
		this.seqOrder = seqOrder;
	}

	public String getQueryText() {
		return queryText;
	}

	public void setQueryText(String queryText) {
		this.queryText = queryText;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}
    @XmlTransient
	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}
	
	
	

}
