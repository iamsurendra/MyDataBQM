package com.artha.workbench.dao;



import java.util.List;

import com.artha.workbench.models.userConfig.ContextInfo;
import com.guvvala.framework.dao.BaseDAO;

public interface ContextInfoDAO extends BaseDAO<ContextInfo, Long>{
	
	public List<ContextInfo> findAllSchemaNames();
	
	public boolean duplicateContext(ContextInfo contextInfo);
	
	public ContextInfo DefaultSchema();

}
