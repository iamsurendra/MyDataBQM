package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.artha.workbench.models.metastore.AbstractModel;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.ExcelHeader;

@Entity
@Table(name = "metastore.ThreadPoolType")
@JsonRootName("threadPoolType")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name = "threadPoolType")
public class ThreadPoolType extends AbstractModel {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "PoolID", nullable = false)
	@NotNull
	@JsonProperty("PoolID")
	@ExcelHeader(name = "PoolID")
	private Integer poolid;

	@Column(name = "Description")
	@JsonProperty("Description")
	@ExcelHeader(name = "Description")
	private String description;

	@Column(name = "EffectiveDate")
	@JsonProperty("EffectiveDate")
	@ExcelHeader(name = "EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date effectiveDate;

	@Column(name = "Active")
	@JsonProperty("Active")
	@ExcelHeader(name = "Active")
	private String active;

	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;

	@Transient
	@JsonIgnore
	private boolean addMode;

	@Transient
	@JsonIgnore
	private String effectiveDtstr;

	public ThreadPoolType() {
	}

	public ThreadPoolType(boolean addMode,Date effectiveDate, Integer releaseNo) {
		this.addMode = addMode;
		this.releaseNo = releaseNo;
		this.effectiveDate = effectiveDate;
				convertEffectiveDate();
	}

	public Integer getPoolid() {
		return poolid;
	}

	public void setPoolid(Integer poolid) {
		this.poolid = poolid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	@XmlTransient
	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}

	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}

	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}

	@PostLoad
	public void postLoad() {
		convertEffectiveDate();
	}

	public void convertEffectiveDate() {
		this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());
	}

}
