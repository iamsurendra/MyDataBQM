package com.artha.workbench.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.beanParams.TaskBeanParam;
import com.artha.workbench.constant.TaskStatus;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.models.datahub.TaskType;
import com.guvvala.framework.dao.BaseDAOImpl;
import com.guvvala.framework.filter.BaseFilter;
import com.guvvala.framework.util.DAOUtils;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.StringUtils;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class TaskDAOImpl extends BaseDAOImpl<Task, String> implements TaskDAO {

	public TaskDAOImpl() {
		super(Task.class);
	}

	public void deleteAll() {
		TypedQuery<Integer> query = entityManager.createQuery("delete from task ", Integer.class);
		query.executeUpdate();
	}
	
	@Override
	public List<Task> getNorSearchlist(Set<BaseFilter> userFilters,Integer maxRows) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Task> cQuery = criteriaBuilder.createQuery(Task.class);
		Root<Task> taskRoot = cQuery.from(Task.class);
		cQuery.select(taskRoot);
		List<Predicate> predicates = DAOUtils.buildPredicates(criteriaBuilder, taskRoot, userFilters);
		cQuery.where(predicates.toArray(new Predicate[]{}));
		return entityManager.createQuery(cQuery).setMaxResults(maxRows).getResultList();

	}

	@Override
	public List<Task> getNorSearchlist(Set<BaseFilter> userFilters, List<String> taskAccessRights,Integer maxRows) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Task> cQuery = criteriaBuilder.createQuery(Task.class);
		Root<Task> taskRoot = cQuery.from(Task.class);
		cQuery.select(taskRoot);
		List<Task> taskLists = new ArrayList<>();
		List<Predicate> predicates;
		if(!taskAccessRights.isEmpty()){
			Predicate predicate=null;
			for(String accessKey:taskAccessRights){
				if(accessKey!=null){
					predicates = DAOUtils.buildPredicates(criteriaBuilder, taskRoot, userFilters);
					predicate=criteriaBuilder.like(taskRoot.<String>get("task_id"), (accessKey + "%"));
					predicates.add(predicate);
					cQuery.where(predicates.toArray(new Predicate[]{}));
					taskLists.addAll(entityManager.createQuery(cQuery).getResultList());
				}
			}
		}
		if(!taskLists.isEmpty() && taskLists.size()>maxRows.intValue()){
			return taskLists.subList(0, maxRows);
		}
		return taskLists;
	}

	@Override
	public Long getNorSearchlist(Set<BaseFilter> userFilters) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> cQuery = criteriaBuilder.createQuery(Long.class);
		Root<Task> taskRoot = cQuery.from(Task.class);
		cQuery.select(criteriaBuilder.count(taskRoot));
		List<Predicate> predicates = DAOUtils.buildPredicates(criteriaBuilder, taskRoot, userFilters);
		cQuery.where(predicates.toArray(new Predicate[]{}));
		return entityManager.createQuery(cQuery).getSingleResult();

	}

	@Override
	public Integer getNorSearchlist(Set<BaseFilter> userFilters, List<String> taskAccessRights) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Task> cQuery = criteriaBuilder.createQuery(Task.class);
		Root<Task> taskRoot = cQuery.from(Task.class);
		cQuery.select(taskRoot);
		List<Task> taskLists = new ArrayList<>();
		List<Predicate> predicates;
		if(!taskAccessRights.isEmpty()){
			Predicate predicate=null;
			for(String accessKey:taskAccessRights){
				if(accessKey!=null){
					predicates = DAOUtils.buildPredicates(criteriaBuilder, taskRoot, userFilters);
					predicate=criteriaBuilder.like(taskRoot.<String>get("task_id"), (accessKey + "%"));
					predicates.add(predicate);
					cQuery.where(predicates.toArray(new Predicate[]{}));
					taskLists.addAll(entityManager.createQuery(cQuery).getResultList());
				}
			}
		}
		return taskLists.size();
	}

	public List<Task> getSearchlist(String taskStatus, String Betweenrec, String andrec) {
		String betStr = "";
		if (Betweenrec != null && Betweenrec.length() > 0 && andrec != null && andrec.length() > 0) {
			betStr = " LIMIT " + Betweenrec + "," + andrec;
		}
		List<Task> taskdet = new ArrayList<Task>();
		TypedQuery<Task> query = entityManager.createQuery("from Task where status ='" + taskStatus + "'" + betStr,
				Task.class);
		taskdet = query.getResultList();
		return taskdet;
	}

	@Override
	public List<String> getSearchlist(TaskBeanParam taskBeanParam, String fileType, String partner,
			Map<String, String> columnNames, String entityFileTypeId) {
		boolean and = false;
		boolean where = false;
		int index = 0;
		String query = "select distinct ad" + index + ".task_id from datahub.taskadview ad" + index;
		// Column names query
		if (!columnNames.isEmpty()) {
			for (String colName : columnNames.keySet()) {
				index++;
				query = query.concat(" join datahub.taskadview ad") + index + " on ad" + (index - 1) + ".task_id=" + "ad"
						+ index + ".task_id";
			}
			query = query.concat(" where");
			where = true;
			index = 0;
			for (String colName : columnNames.keySet()) {
				String[] columnsInfo = columnNames.get(colName).split(",");
				String columnOperator = columnsInfo[0];

				String columnValue = null;
				index++;
				if (columnsInfo.length == 2) {
					columnValue = columnsInfo[1];
					if ("containsthewords".equalsIgnoreCase(columnOperator)) {
						query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
								+ (index - 1) + ".col_value  like '%" + columnValue) + "%')";
					}else if("notcontainsthewords".equalsIgnoreCase(columnOperator)){
						query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
								+ (index - 1) + ".col_value  not like '%" + columnValue) + "%')";
					}else if("startswith".equalsIgnoreCase(columnOperator)){
						query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
								+ (index - 1) + ".col_value  like '" + columnValue) + "%')";
					}else if("endswith".equalsIgnoreCase(columnOperator)){
						query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
								+ (index - 1) + ".col_value  like '%" + columnValue) + "')";
					} else {
						query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
								+ (index - 1) + ".col_value " + columnOperator + " '" + columnValue) + "')";
					}

				} else {
					if ("!=".equalsIgnoreCase(columnOperator)) {
						query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
								+ (index - 1) + ".col_value is not null)");
					} else {
						query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
								+ (index - 1) + ".col_value is null)");
					}
				}
				if (columnNames.size() != index) {
					query = query.concat(" and");
				}
			}
			and = true;
		}
		if (!where)
			query = query + " where ";

		// Task Name query
		if (!StringUtils.isEmpty(taskBeanParam.getTaskValue())) {
			if (and)
				query = query.concat(" and ");
			if ("containsthewords".equalsIgnoreCase(taskBeanParam.getTaskOperator())) {
				String containsid = taskBeanParam.getTaskValue();
				query = query.concat(" ad0.task_name like '%" + containsid.replace("_", "$_") + "%' escape'$'");
			}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getTaskOperator())){
				String notcontainsid = taskBeanParam.getTaskValue();
				query = query.concat(" ad0.task_name not like '%" + notcontainsid.replace("_", "$_") + "%' escape'$'");
			}else if("startswith".equalsIgnoreCase(taskBeanParam.getTaskOperator())){
				String startswithid = taskBeanParam.getTaskValue();
				query = query.concat(" ad0.task_name like '" +startswithid.replace("_", "$_")+ "%' escape'$'");
			}else if("endswith".equalsIgnoreCase(taskBeanParam.getTaskOperator())){
				String endswithid = taskBeanParam.getTaskValue();
				query = query.concat(" ad0.task_name like '%" + endswithid.replace("_", "$_") + "' escape'$'");
			} else {
				query = query.concat(" ad0.task_name " + taskBeanParam.getTaskOperator() + " '"
						+ taskBeanParam.getTaskValue() + "'");
			}
			and = true;
		}
		// Task Id query
		if (!StringUtils.isEmpty(taskBeanParam.getTaskIdValue())) {
			if (and)
				query = query.concat(" and ");
			if ("containsthewords".equalsIgnoreCase(taskBeanParam.getTaskIdOperator())) {
				String containsid =taskBeanParam.getTaskIdValue();
				query = query.concat(" ad0.task_id like '%" + containsid.replace("_", "$_") + "%' escape'$'");
			}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getTaskIdOperator())){
				String notcontainsid = taskBeanParam.getTaskIdValue();
				query = query.concat(" ad0.task_id not like '%" +notcontainsid.replace("_", "$_") + "%' escape'$'");
			}else if("startswith".equalsIgnoreCase(taskBeanParam.getTaskIdOperator())){
				String startswithid = taskBeanParam.getTaskIdValue();
				query = query.concat(" ad0.task_id like '" + startswithid.replace("_", "$_") + "%' escape'$'");
			}else if("endswith".equalsIgnoreCase(taskBeanParam.getTaskIdOperator())){
				String endswithid= taskBeanParam.getTaskIdValue();
				query = query.concat(" ad0.task_id like '%" + endswithid.replace("_", "$_") + "' escape'$'");
			}else {
				query = query.concat(" ad0.task_id " + taskBeanParam.getTaskIdOperator() + " '"
						+ taskBeanParam.getTaskIdValue() + "'");
			}
			and = true;
		}

		// Status query
		if (!StringUtils.isEmpty(taskBeanParam.getSelectedStatus())) {
			if (and)
				query = query.concat(" and ");
			if ("containsthewords".equalsIgnoreCase(taskBeanParam.getStatusOperator())) {
				query = query.concat(" ad0.status like '%" + taskBeanParam.getSelectedStatus() + "%'");
			}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getStatusOperator())){
				query = query.concat(" ad0.status not like '%" + taskBeanParam.getSelectedStatus() + "%'");
			}else if("startswith".equalsIgnoreCase(taskBeanParam.getStatusOperator())){
				query = query.concat(" ad0.status like '" + taskBeanParam.getSelectedStatus() + "%'");
			}else if("endswith".equalsIgnoreCase(taskBeanParam.getStatusOperator())){
				query = query.concat(" ad0.status like '%" + taskBeanParam.getSelectedStatus() + "'");
			}else {
				query = query.concat(" ad0.status " + taskBeanParam.getStatusOperator() + " '"
						+ taskBeanParam.getSelectedStatus() + "'");
			}
			and = true;
		}
		
		
		// Owner filter query
		if (!StringUtils.isEmpty(taskBeanParam.getSelectedOwner())) {
			if (and)
				query = query.concat(" and ");
			if ("containsthewords".equalsIgnoreCase(taskBeanParam.getOwnerOperator())) {
				query = query.concat(" ad0.owner like '%" + taskBeanParam.getSelectedOwner() + "%'");
			}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getOwnerOperator())){
				query = query.concat(" ad0.owner not like '%" + taskBeanParam.getSelectedOwner() + "%'");
			}else if("startswith".equalsIgnoreCase(taskBeanParam.getOwnerOperator())){
				query = query.concat(" ad0.owner like '" + taskBeanParam.getSelectedOwner() + "%'");
			}else if("endswith".equalsIgnoreCase(taskBeanParam.getOwnerOperator())){
				query = query.concat(" ad0.owner like '%" + taskBeanParam.getSelectedOwner() + "'");
			}else {
				query = query.concat(" ad0.owner " + taskBeanParam.getOwnerOperator() + " '"
						+ taskBeanParam.getSelectedOwner() + "'");
			}
			and = true;
		}
		// Created by Query
		if (!StringUtils.isEmpty(taskBeanParam.getCreatedBy())) {
			if (and)
				query = query.concat(" and ");
			if ("containsthewords".equalsIgnoreCase(taskBeanParam.getCreatedByOperator())) {
				query = query.concat(" ad0.created_by like '%" + taskBeanParam.getCreatedBy() + "%'");
			}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getCreatedByOperator())){
				query = query.concat(" ad0.created_by not like '%" + taskBeanParam.getCreatedBy() + "%'");
			}else if("startswith".equalsIgnoreCase(taskBeanParam.getCreatedByOperator())){
				query = query.concat(" ad0.created_by like '" + taskBeanParam.getCreatedBy() + "%'");
			}else if("endswith".equalsIgnoreCase(taskBeanParam.getCreatedByOperator())){
				query = query.concat(" ad0.created_by like '%" + taskBeanParam.getCreatedBy() + "'");
			}else {
				query = query.concat(" ad0.created_by " + taskBeanParam.getCreatedByOperator() + " '"
						+ taskBeanParam.getCreatedBy() + "'");
			}
			and = true;
		}
		// Modified by Query
		if (!StringUtils.isEmpty(taskBeanParam.getModifiedBy())) {
			if (and)
				query = query.concat(" and ");
			if ("containsthewords".equalsIgnoreCase(taskBeanParam.getModifiedByOperator())) {
				query = query.concat(" ad0.modified_by like '%" + taskBeanParam.getModifiedBy() + "%'");
			}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getModifiedByOperator())){
				query = query.concat(" ad0.modified_by not like '%" + taskBeanParam.getModifiedBy() + "%'");
			}else if("startswith".equalsIgnoreCase(taskBeanParam.getModifiedByOperator())){
				query = query.concat(" ad0.modified_by like '" + taskBeanParam.getModifiedBy() + "%'");
			}else if("endswith".equalsIgnoreCase(taskBeanParam.getModifiedByOperator())){
				query = query.concat(" ad0.modified_by like '%" + taskBeanParam.getModifiedBy() + "'");
			}else {
				query = query.concat(" ad0.modified_by " + taskBeanParam.getModifiedByOperator() + " '"
						+ taskBeanParam.getModifiedBy() + "'");
			}
			and = true;
		}
		// partner and file type query
		if (!StringUtils.isEmpty(partner)) {
			if (and)
				query = query.concat(" and ");
			if (!StringUtils.isEmpty(fileType)) {
				//EntityFileTypeId
				String partnerFileType = partner + "_" + fileType + "_"+entityFileTypeId;
				query = query.concat("( ad0.task_id like '" + partnerFileType + "%'");
				//Negative partner file type
				String negativePartnerFileType = partner + "_" + fileType + "_"+"-"+entityFileTypeId;
				//Also check -EntityFileTypeId in task
				query = query.concat("or"+" ad0.task_id like '" + negativePartnerFileType + "%')");

			} else {
				query = query.concat(" ad0.task_id like '" + partner + "_%'");
			}
			and = true;
		}

		// CreatedOn query
		Date date2 = null;
		String createdOnOperator = null;
		if (taskBeanParam.getCreatedOn() != null) {

			if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("equal")) {
				createdOnOperator = ("=");
			} else if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("greater")) {
				taskBeanParam.setCreatedOn(DateUtils.addDays(taskBeanParam.getCreatedOn(), 1));
				createdOnOperator = (">=");
			} else if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("greaterorequal")) {
				createdOnOperator = (">=");
			} else if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("lessthan")) {
				createdOnOperator = ("<=");
			} else if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("lessthanequal")) {
				taskBeanParam.setCreatedOn(DateUtils.addDays(taskBeanParam.getCreatedOn(), 1));
				createdOnOperator = ("<=");
			} else if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("notequal")) {
				createdOnOperator = ("!=");
			}
			if (and)
				query = query.concat(" and ");

			date2 = DateUtils.addDays(taskBeanParam.getCreatedOn(), 1);
			if (createdOnOperator.equals("=")) {
				query = query.concat(" (ad0.created_on >= :date1 and ad0.created_on < :date2)");
			} else if (createdOnOperator.equals("!=")) {
				query = query
						.concat(" (ad0.created_on < :date1 or ad0.created_on >= :date2 or ad0.created_on is null)");
			} else {
				query = query.concat(" ad0.created_on " + createdOnOperator + ":date1");
			}
			and = true;
		}
		// Modified query
		Date modifiedOnDate2 = null;
		String modifiedOnOperator = null;
		if (taskBeanParam.getModifiedOn() != null) {

			if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("equal")) {
				modifiedOnOperator = ("=");
			} else if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("greater")) {
				taskBeanParam.setModifiedOn(DateUtils.addDays(taskBeanParam.getModifiedOn(), 1));
				modifiedOnOperator = (">=");
			} else if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("greaterorequal")) {
				modifiedOnOperator = (">=");
			} else if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("lessthan")) {
				modifiedOnOperator = ("<=");
			} else if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("lessthanequal")) {
				taskBeanParam.setModifiedOn(DateUtils.addDays(taskBeanParam.getModifiedOn(), 1));
				modifiedOnOperator = ("<=");
			} else if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("notequal")) {
				modifiedOnOperator = ("!=");
			}
			if (and)
				query = query.concat(" and ");

			modifiedOnDate2 = DateUtils.addDays(taskBeanParam.getModifiedOn(), 1);
			if (modifiedOnOperator.equals("=")) {
				query = query.concat(" (ad0.modified_on >= :modifiedDate1 and ad0.modified_on < :modifiedOnDate2)");
			} else if (modifiedOnOperator.equals("!=")) {
				query = query.concat(
						" (ad0.modified_on < :modifiedDate1 or ad0.modified_on >= :modifiedOnDate2 or ad0.modified_on is null)");
			} else {
				query = query.concat(" ad0.modified_on " + modifiedOnOperator + ":modifiedDate1");
			}
			and = true;
		}

		List<String> srcRecordErrorIds = null;
		if(taskBeanParam.getErrorKey()!=null || taskBeanParam.getErrorValue()!=null)
		{
			srcRecordErrorIds = getErrorQuery(taskBeanParam);
			if(null!=srcRecordErrorIds && srcRecordErrorIds.size()>0)
			{
				if (and)
					query = query.concat(" and ");
				query = query.concat("ad0.srcrec_id in :srcErrorRecIds");
			}
			else
			{
				return null;
			}
		}
		
		Query typedQuery = entityManager.createNativeQuery(query);
		if (taskBeanParam.getCreatedOn() != null) {
			typedQuery.setParameter("date1", taskBeanParam.getCreatedOn(), TemporalType.TIMESTAMP);
			if (query.contains("date2"))
				typedQuery.setParameter("date2", date2, TemporalType.TIMESTAMP);
		}
		if (taskBeanParam.getModifiedOn() != null) {
			typedQuery.setParameter("modifiedDate1", taskBeanParam.getModifiedOn(), TemporalType.TIMESTAMP);
			if (query.contains("modifiedOnDate2"))
				typedQuery.setParameter("modifiedOnDate2", modifiedOnDate2, TemporalType.TIMESTAMP);
		}
		if(taskBeanParam.getErrorKey()!=null || taskBeanParam.getErrorValue()!=null)
		{
				typedQuery.setParameter("srcErrorRecIds",srcRecordErrorIds );
		}
		return typedQuery.getResultList();

	}

	@Override
	public List<String> getNormaluserSearchlist(TaskBeanParam taskBeanParam, String fileType, String partner, 
			Map<String, String> columnNames,String entityFileTypeId , List<String> taskAccessRights) {
		boolean and = false;
		boolean where = false;
		int index = 0;
		List<String> taskdet = new ArrayList<String>();
		for (String accessKey : taskAccessRights) {
			if (null != accessKey) {
				String query = "select distinct ad" + index + ".task_id from datahub.taskadview ad" + index;
				// Column names query
				if (!columnNames.isEmpty()) {
					for (String colName : columnNames.keySet()) {
						index++;
						query = query.concat(" join datahub.taskadview ad") + index + " on ad" + (index - 1) + ".task_id="
								+ "ad" + index + ".task_id";
					}
					query = query.concat(" where");
					where = true;
					index = 0;
					for (String colName : columnNames.keySet()) {
						String[] columnsInfo = columnNames.get(colName).split(",");
						String columnOperator = columnsInfo[0];

						String columnValue = null;
						index++;
						if (columnsInfo.length == 2) {
							columnValue = columnsInfo[1];
							if ("containsthewords".equalsIgnoreCase(columnOperator)) {
								query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
										+ (index - 1) + ".col_value  like '%" + columnValue) + "%')";
							}else if("notcontainsthewords".equalsIgnoreCase(columnOperator)) {
								query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
										+ (index - 1) + ".col_value  not like '%" + columnValue) + "%')";
							}else if("startswith".equalsIgnoreCase(columnOperator)) {
								query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
										+ (index - 1) + ".col_value  like '" + columnValue) + "%')";
							}else if("endswith".equalsIgnoreCase(columnOperator)) {
								query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
										+ (index - 1) + ".col_value  like '%" + columnValue) + "')";
							} else {
								query = query
										.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
												+ (index - 1) + ".col_value " + columnOperator + " '" + columnValue)
										+ "')";
							}

						} else {
							if ("!=".equalsIgnoreCase(columnOperator)) {
								query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
										+ (index - 1) + ".col_value is not null)");
							} else {
								query = query.concat(" (ad" + (index - 1) + ".col_name = '" + colName + "' and" + " ad"
										+ (index - 1) + ".col_value is null)");
							}
						}
						if (columnNames.size() != index) {
							query = query.concat(" and");
						}
					}
					and = true;
				}
				if (!where)
					query = query + " where ";

				// Task Name query
				if (!StringUtils.isEmpty(taskBeanParam.getTaskValue())) {
					if (and)
						query = query.concat(" and ");
					if ("containsthewords".equalsIgnoreCase(taskBeanParam.getTaskOperator())) {
						String containsid = taskBeanParam.getTaskValue();
						query = query.concat(" ad0.task_name like '%" + containsid.replace("_", "$_") + "%' escape'$'");
					}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getTaskOperator())){
						String notcontainsid = taskBeanParam.getTaskValue();
						query = query.concat(" ad0.task_name not like '%" +notcontainsid.replace("_", "$_") + "%' escape'$'");
					}else if("startswith".equalsIgnoreCase(taskBeanParam.getTaskOperator())){
						String startswithid = taskBeanParam.getTaskValue();
						query = query.concat(" ad0.task_name like '" +startswithid.replace("_", "$_") + "%' escape'$'");
					}else if("endswith".equalsIgnoreCase(taskBeanParam.getTaskOperator())){
						String endswithid = taskBeanParam.getTaskValue();
						query = query.concat(" ad0.task_name like '%" + endswithid.replace("_", "$_")  +"' escape'$'");
					}else {
						query = query.concat(" ad0.task_name " + taskBeanParam.getTaskOperator() + " '"
								+ taskBeanParam.getTaskValue() + "'");
					}
					and = true;
				}
				// Task Id query
				if (!StringUtils.isEmpty(taskBeanParam.getTaskIdValue())) {
					if (and)
						query = query.concat(" and ");
					if ("containsthewords".equalsIgnoreCase(taskBeanParam.getTaskIdOperator())) {
						String containsid = taskBeanParam.getTaskIdValue();
						query = query.concat(" ad0.task_id like '%" + containsid.replace("_", "$_") + "%' escape'$'");
					}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getTaskIdOperator())){
						String notcontainsid = taskBeanParam.getTaskIdValue();
						query = query.concat(" ad0.task_id not like '%" + notcontainsid.replace("_", "$_") + "%' escape'$'");
					}else if("startswith".equalsIgnoreCase(taskBeanParam.getTaskIdOperator())){
						String startswithid = taskBeanParam.getTaskIdValue();
						query = query.concat(" ad0.task_id like '" + startswithid.replace("_", "$_")+ "%' escape'$'");
					}else if("endswith".equalsIgnoreCase(taskBeanParam.getTaskIdOperator())){
						String endswithid= taskBeanParam.getTaskIdValue();
						query = query.concat(" ad0.task_id like '%" + endswithid.replace("_", "$_") + "' escape'$'");
					} else {
						query = query.concat(" ad0.task_id " + taskBeanParam.getTaskIdOperator() + " '"
								+ taskBeanParam.getTaskIdValue() + "'");
					}
					and = true;
				}

				// Status query
				if (!StringUtils.isEmpty(taskBeanParam.getSelectedStatus())) {
					if (and)
						query = query.concat(" and ");
					if ("containsthewords".equalsIgnoreCase(taskBeanParam.getStatusOperator())) {
						query = query.concat(" ad0.status like '%" + taskBeanParam.getSelectedStatus() + "%'");
					}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getStatusOperator())){
						query = query.concat(" ad0.status not like '%" + taskBeanParam.getSelectedStatus() + "%'");
					}else if("startswith".equalsIgnoreCase(taskBeanParam.getStatusOperator())){
						query = query.concat(" ad0.status like '" + taskBeanParam.getSelectedStatus() + "%'");
					}else if("endswith".equalsIgnoreCase(taskBeanParam.getStatusOperator())){
						query = query.concat(" ad0.status like '%" + taskBeanParam.getSelectedStatus() + "'");
					} else {
						query = query.concat(" ad0.status " + taskBeanParam.getStatusOperator() + " '"
								+ taskBeanParam.getSelectedStatus() + "'");
					}
					and = true;
				}

				
				// Owner filter query
				if (!StringUtils.isEmpty(taskBeanParam.getSelectedOwner())) {
					if (and)
						query = query.concat(" and ");
					if ("containsthewords".equalsIgnoreCase(taskBeanParam.getOwnerOperator())) {
						query = query.concat(" ad0.owner like '%" + taskBeanParam.getSelectedOwner() + "%'");
					}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getOwnerOperator())){
						query = query.concat(" ad0.owner not like '%" + taskBeanParam.getSelectedOwner() + "%'");
					}else if("startswith".equalsIgnoreCase(taskBeanParam.getOwnerOperator())){
						query = query.concat(" ad0.owner like '" + taskBeanParam.getSelectedOwner() + "%'");
					}else if("endswith".equalsIgnoreCase(taskBeanParam.getOwnerOperator())){
						query = query.concat(" ad0.owner like '%" + taskBeanParam.getSelectedOwner() + "'");
					} else {
						query = query.concat(" ad0.owner " + taskBeanParam.getOwnerOperator() + " '"
								+ taskBeanParam.getSelectedOwner() + "'");
					}
					and = true;
				}
				// Created by Query
				if (!StringUtils.isEmpty(taskBeanParam.getCreatedBy())) {
					if (and)
						query = query.concat(" and ");
					if ("containsthewords".equalsIgnoreCase(taskBeanParam.getCreatedByOperator())) {
						query = query.concat(" ad0.created_by like '%" + taskBeanParam.getCreatedBy() + "%'");
					}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getCreatedByOperator())){
						query = query.concat(" ad0.created_by not like '%" + taskBeanParam.getCreatedBy() + "%'");
					}else if("startswith".equalsIgnoreCase(taskBeanParam.getCreatedByOperator())){
						query = query.concat(" ad0.created_by like '" + taskBeanParam.getCreatedBy() + "%'");
					}else if("endswith".equalsIgnoreCase(taskBeanParam.getCreatedByOperator())){
						query = query.concat(" ad0.created_by like '%" + taskBeanParam.getCreatedBy() + "'");
					} else {
						query = query.concat(" ad0.created_by " + taskBeanParam.getCreatedByOperator() + " '"
								+ taskBeanParam.getCreatedBy() + "'");
					}
					and = true;
				}
				// Modified by Query
				if (!StringUtils.isEmpty(taskBeanParam.getModifiedBy())) {
					if (and)
						query = query.concat(" and ");
					if ("containsthewords".equalsIgnoreCase(taskBeanParam.getModifiedByOperator())) {
						query = query.concat(" ad0.modified_by like '%" + taskBeanParam.getModifiedBy() + "%'");
					}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getModifiedByOperator())){
						query = query.concat(" ad0.modified_by not like '%" + taskBeanParam.getModifiedBy() + "%'");
					}else if("startswith".equalsIgnoreCase(taskBeanParam.getModifiedByOperator())){
						query = query.concat(" ad0.modified_by like '" + taskBeanParam.getModifiedBy() + "%'");
					}else if("endswith".equalsIgnoreCase(taskBeanParam.getModifiedByOperator())){
						query = query.concat(" ad0.modified_by like '%" + taskBeanParam.getModifiedBy() + "'");
					} else {
						query = query.concat(" ad0.modified_by " + taskBeanParam.getModifiedByOperator() + " '"
								+ taskBeanParam.getModifiedBy() + "'");
					}
					and = true;
				}
				// partner and file type query
				if (!StringUtils.isEmpty(partner)) {
					if (and)
						query = query.concat(" and ");
					if (!StringUtils.isEmpty(fileType)) {
						String partnerFileType = partner + "_" + fileType + "_"+entityFileTypeId;
						query = query.concat("( ad0.task_id like '" + partnerFileType + "%'");
						//Negative partner file type
						String negativePartnerFileType = partner + "_" + fileType + "_"+"-"+entityFileTypeId;
						if(!accessKey.equals(partnerFileType) && !accessKey.equals(negativePartnerFileType))
						{
							//quit since no rights and partner type , file type
							index=0;
							continue;
						}
						//Also check -EntityFileTypeId in task
						query = query.concat("or "+" ad0.task_id like '" + negativePartnerFileType + "%')");
					} else {
						int partnerIndex = accessKey.indexOf("_");
							if(!accessKey.substring(0, partnerIndex).equals(partner))
							{
								//quit since no rights and partner type , file type
								continue;
							}
							query = query.concat(" ad0.task_id like '" + partner + "_%'");
					}
					and = true;
				}
				// CreatedOn query
				Date date2 = null;
				Date date1 = null;
				String createdOnOperator = null;
				if (taskBeanParam.getCreatedOn() != null) {
					if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("equal")) {
						date1 = taskBeanParam.getCreatedOn();
						createdOnOperator = "=";
					} else if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("greater")) {
						date1 = (DateUtils.addDays(taskBeanParam.getCreatedOn(), 1));
						createdOnOperator = ">=";
					} else if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("greaterorequal")) {
						date1 = taskBeanParam.getCreatedOn();
						createdOnOperator = (">=");
					} else if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("lessthan")) {
						date1 = taskBeanParam.getCreatedOn();
						createdOnOperator = ("<=");
					} else if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("lessthanequal")) {
						date1 = (DateUtils.addDays(taskBeanParam.getCreatedOn(), 1));
						createdOnOperator = ("<=");
					} else if (taskBeanParam.getCreatedOnOperator().equalsIgnoreCase("notequal")) {
						date1 = taskBeanParam.getCreatedOn();
						createdOnOperator = ("!=");
					}
					if (and)
						query = query.concat(" and ");

					date2 = DateUtils.addDays(date1, 1);
					if (createdOnOperator.equals("=")) {
						query = query.concat(" (ad0.created_on >= :date1 and ad0.created_on < :date2)");
					} else if (createdOnOperator.equals("!=")) {
						query = query.concat(
								" (ad0.created_on < :date1 or ad0.created_on >= :date2 or ad0.created_on is null)");
					} else {
						query = query.concat(" ad0.created_on " + createdOnOperator + ":date1");
					}
					and = true;
				}
				// ModifiedOn query
				Date modifiedOnDate2 = null;
				Date modifiedOnDate1 = null;
				String modifiedOnOperator = null;
				if (taskBeanParam.getModifiedOn() != null) {
					if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("equal")) {
						modifiedOnDate1 = taskBeanParam.getModifiedOn();
						modifiedOnOperator = ("=");
					} else if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("greater")) {
						modifiedOnDate1 = (DateUtils.addDays(taskBeanParam.getModifiedOn(), 1));
						modifiedOnOperator = (">=");
					} else if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("greaterorequal")) {
						modifiedOnDate1 = taskBeanParam.getModifiedOn();
						modifiedOnOperator = (">=");
					} else if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("lessthan")) {
						modifiedOnDate1 = taskBeanParam.getModifiedOn();
						modifiedOnOperator = ("<=");
					} else if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("lessthanequal")) {
						modifiedOnDate1 = (DateUtils.addDays(taskBeanParam.getModifiedOn(), 1));
						modifiedOnOperator = ("<=");
					} else if (taskBeanParam.getModifiedOnOperator().equalsIgnoreCase("notequal")) {
						modifiedOnDate1 = taskBeanParam.getModifiedOn();
						modifiedOnOperator = ("!=");
					}

					if (and)
						query = query.concat(" and ");

					modifiedOnDate2 = DateUtils.addDays(modifiedOnDate1, 1);
					if (modifiedOnOperator.equals("=")) {
						query = query
								.concat(" (ad0.modified_on >= :modifiedDate1 and ad0.modified_on < :modifiedOnDate2)");
					} else if (modifiedOnOperator.equals("!=")) {
						query = query.concat(
								" (ad0.modified_on < :modifiedDate1 or ad0.modified_on >= :modifiedOnDate2 or ad0.modified_on is null)");
					} else {
						query = query.concat(" ad0.modified_on " + modifiedOnOperator + ":modifiedDate1");
					}
					and = true;
				}
				if (StringUtils.isEmpty(partner))
				{
					if (and)
						query = query.concat(" and ");
					query = query.concat(" ad0.task_id like :accessKey");
					and = true;
				}
				List<String> srcRecordErrorIds = null;
				if(taskBeanParam.getErrorKey()!=null || taskBeanParam.getErrorValue()!=null)
				{
					srcRecordErrorIds = getErrorQuery(taskBeanParam);
					if(null!=srcRecordErrorIds && srcRecordErrorIds.size()>0)
					{
						if (and)
							query = query.concat(" and ");
						query = query.concat("ad0.srcrec_id in :srcErrorRecIds");
					}
					else
					{
						return taskdet;
					}
				}
				Query typedQuery = entityManager.createNativeQuery(query);
				if (taskBeanParam.getCreatedOn() != null) {
					typedQuery.setParameter("date1", date1, TemporalType.TIMESTAMP);
					if (query.contains("date2"))
						typedQuery.setParameter("date2", date2, TemporalType.TIMESTAMP);
				}
				if (taskBeanParam.getModifiedOn() != null) {
					typedQuery.setParameter("modifiedDate1", modifiedOnDate1, TemporalType.TIMESTAMP);
					if (query.contains("modifiedOnDate2"))
						typedQuery.setParameter("modifiedOnDate2", modifiedOnDate2, TemporalType.TIMESTAMP);
				}
				if (StringUtils.isEmpty(partner))
				{
					typedQuery.setParameter("accessKey", accessKey + "%");
				}
				if(taskBeanParam.getErrorKey()!=null || taskBeanParam.getErrorValue()!=null)
				{
						typedQuery.setParameter("srcErrorRecIds",srcRecordErrorIds );
				}
				List<String> tempTaskList = typedQuery.getResultList();
				and = false;
				//Having this because there are chances of duplicate task ids because of -ve partner in access keys
				taskdet.removeAll(tempTaskList);
				taskdet.addAll(tempTaskList);
			}
			index = 0;
		}

		return taskdet;

	}
	
	
	public List<String> getErrorQuery(TaskBeanParam taskBeanParam)
	{
		String errorQuery="select distinct top 1500 srcrecord_id from srcextrainfo where ";
		boolean and=false;
		if(taskBeanParam.getErrorKey()!=null)
		{
			if ("containsthewords".equalsIgnoreCase(taskBeanParam.getErrorKeyOperator())) {
				errorQuery = errorQuery.concat(" info_key like '%" + taskBeanParam.getErrorKey() + "%'");
			}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getErrorKeyOperator())){
				errorQuery = errorQuery.concat(" info_key not like '%" + taskBeanParam.getErrorKey() + "%'");
			}else if("startswith".equalsIgnoreCase(taskBeanParam.getErrorKeyOperator())){
				errorQuery = errorQuery.concat(" info_key like '" + taskBeanParam.getErrorKey() + "%'");
			}else if("endswith".equalsIgnoreCase(taskBeanParam.getErrorKeyOperator())){
				errorQuery = errorQuery.concat(" info_key like '%" + taskBeanParam.getErrorKey() + "'");
			}else {
				errorQuery = errorQuery.concat(" info_key " + taskBeanParam.getErrorKeyOperator() + " '"
						+ taskBeanParam.getErrorKey() + "'");
			}
			and=true;
		}
		
		if(taskBeanParam.getErrorValue()!=null)
		{
			if(and)
			{
				errorQuery =errorQuery.concat("and");
			}
			//since if value has : then results are not fetched so making it as like operator if it contains :
			if(taskBeanParam.getErrorValue().contains(":"))
			{
				taskBeanParam.setErrorValue(taskBeanParam.getErrorValue().replace(":", "%"));
			}
			if ("containsthewords".equalsIgnoreCase(taskBeanParam.getErrorValueOperator())) {
				errorQuery = errorQuery.concat(" info_value like '%" + taskBeanParam.getErrorValue() + "%'");
			}else if("notcontainsthewords".equalsIgnoreCase(taskBeanParam.getErrorValueOperator())){
				errorQuery = errorQuery.concat(" info_value not like '%" + taskBeanParam.getErrorValue() + "%'");
			}else if("startswith".equalsIgnoreCase(taskBeanParam.getErrorValueOperator())){
				errorQuery = errorQuery.concat(" info_value like '" + taskBeanParam.getErrorValue() + "%'");
			}else if("endswith".equalsIgnoreCase(taskBeanParam.getErrorValueOperator())){
				errorQuery = errorQuery.concat(" info_value like '%" + taskBeanParam.getErrorValue() + "'");
			}else {
				if(taskBeanParam.getErrorValue().contains("%") && taskBeanParam.getErrorValueOperator().equals("="))
				{
					errorQuery = errorQuery.concat(" info_value like '%" + taskBeanParam.getErrorValue() + "%'");
				}
				else{
				errorQuery = errorQuery.concat(" info_value " + taskBeanParam.getErrorValueOperator() + " '"
						+ taskBeanParam.getErrorValue() + "'");
				}
			}
		}
		Query typedQuery = entityManager.createNativeQuery(errorQuery);
		return typedQuery.getResultList();
	}

	public Task getTaskById(String taskId) {
		return entityManager.find(Task.class, taskId);
	}

	public void updatePendingTasks(String taskId, String userName, String status) {
		Task task = findOne(taskId);
		task.setModified_by(userName);
		task.setOwner(userName);
		task.setModified_on(new Date());
		task.setStatus(status);
		update(task);
	}

	public void updateresolvedtask(String taskId, String userName) {
		Task task = findOne(taskId);
		task.setModified_by(userName);
		task.setOwner(userName);
		task.setModified_on(new Date());
		task.setStatus("resolved");
		update(task);

	}

	@Override
	public List<Task> getNorSearchlist(String colType, String condition, String colvalue, boolean adminFlag,
			List<String> taskAccessRights) {
		List<Task> taskdet = new ArrayList<Task>();
		if (adminFlag) {
			if (condition.equalsIgnoreCase("equalto")) {
				TypedQuery<Task> query = entityManager.createQuery("from Task where " + colType + "='" + colvalue + "'",
						Task.class);
				taskdet = query.getResultList();
			} else if (condition.equalsIgnoreCase("containsthewords")) {
				TypedQuery<Task> query = entityManager.createQuery("from Task where " + colType + " like :colval1",
						Task.class);
				query.setParameter("colval1", "%" + colvalue + "%");
				taskdet = query.getResultList();
			} else {
				TypedQuery<Task> query = entityManager
						.createQuery("from Task where " + colType + "!='" + colvalue + "'", Task.class);
				taskdet = query.getResultList();
			}
		} else {
			if (condition.equalsIgnoreCase("equalto")) {
				for (String accessKey : taskAccessRights) {
					if (null != accessKey) {
						TypedQuery<Task> query = entityManager.createQuery(
								"from Task where " + colType + "='" + colvalue + " ' and task_id like :accessKey",
								Task.class);
						query.setParameter("accessKey", accessKey + "%");
						List<Task> tempTaskList = query.getResultList();
						taskdet.addAll(tempTaskList);
					}
				}
			} else if (condition.equalsIgnoreCase("containsthewords")) {
				for (String accessKey : taskAccessRights) {
					if (null != accessKey) {
						TypedQuery<Task> query = entityManager.createQuery(
								"from Task where " + colType + " like :colval1 and task_id like :accessKey",
								Task.class);
						query.setParameter("colval1", "%" + colvalue + "%");
						query.setParameter("accessKey", accessKey + "%");
						List<Task> tempTaskList = query.getResultList();
						taskdet.addAll(tempTaskList);
					}
				}
			} else {
				for (String accessKey : taskAccessRights) {
					if (null != accessKey) {
						TypedQuery<Task> query = entityManager.createQuery(
								"from Task where " + colType + "!='" + colvalue + "' and task_id like :accessKey",
								Task.class);
						query.setParameter("accessKey", accessKey + "%");
						List<Task> tempTaskList = query.getResultList();
						taskdet.addAll(tempTaskList);
					}
				}
			}
		}

		return taskdet;
	}

	@Override
	public List<Task> getNorSearchlist(String colType, String condition, Date date1, boolean adminFlag,
			List<String> taskAccessRights) {
		List<Task> taskdet1 = new ArrayList<Task>();
		String conditionOperator = null;
		if (condition.equalsIgnoreCase("equalto")) {
			Date date2 = DateUtils.addDays(date1, 1);
			if (adminFlag) {
				TypedQuery<Task> query = entityManager
						.createQuery("from Task where " + colType + ">=:date1 and " + colType + "< :date2", Task.class);
				query.setParameter("date1", date1, TemporalType.TIMESTAMP);
				query.setParameter("date2", date2, TemporalType.TIMESTAMP);
				taskdet1 = query.getResultList();
			} else {
				for (String accessKey : taskAccessRights) {
					if (null != accessKey) {
						TypedQuery<Task> query = entityManager.createQuery("from Task where " + colType
								+ ">=:date1 and " + colType + "< :date2 and task_id like :accessKey", Task.class);
						query.setParameter("date1", date1, TemporalType.TIMESTAMP);
						query.setParameter("date2", date2, TemporalType.TIMESTAMP);
						query.setParameter("accessKey", accessKey + "%");
						List<Task> tempTaskList = query.getResultList();
						taskdet1.addAll(tempTaskList);
					}
				}

			}
			return taskdet1;
		} else if (condition.equalsIgnoreCase("greaterthan")) {
			date1 = DateUtils.addDays(date1, 1);
			conditionOperator = ">=";
		} else if (condition.equalsIgnoreCase("greaterorequal")) {

			conditionOperator = ">=";
		} else if (condition.equalsIgnoreCase("lowerthan")) {
			conditionOperator = "<";
		} else if (condition.equalsIgnoreCase("lowerorequal")) {
			date1 = DateUtils.addDays(date1, 1);
			conditionOperator = "<";
		} else if (condition.equalsIgnoreCase("notequalto")) {
			conditionOperator = "!=";
			Date date2 = DateUtils.addDays(date1, 1);
			if (adminFlag) {
				TypedQuery<Task> query = entityManager.createQuery("from Task where (" + colType + "< :date1 or "
						+ colType + " >= :date2 ) or " + colType + " is null", Task.class);
				query.setParameter("date1", date1, TemporalType.TIMESTAMP);
				query.setParameter("date2", date2, TemporalType.TIMESTAMP);
				taskdet1 = query.getResultList();
			} else {
				for (String accessKey : taskAccessRights) {
					if (null != accessKey) {
						TypedQuery<Task> query = entityManager.createQuery(
								"from Task where ((" + colType + "< :date1 or " + colType + " >= :date2 )  or "
										+ colType + " is null ) and task_id like :accessKey",
								Task.class);
						query.setParameter("date1", date1, TemporalType.TIMESTAMP);
						query.setParameter("date2", date2, TemporalType.TIMESTAMP);
						query.setParameter("accessKey", accessKey + "%");
						List<Task> tempTaskList = query.getResultList();
						taskdet1.addAll(tempTaskList);
					}
				}
			}
			return taskdet1;
		}
		if (adminFlag) {
			TypedQuery<Task> query = entityManager
					.createQuery("from Task where " + colType + conditionOperator + ":date1", Task.class);
			query.setParameter("date1", date1, TemporalType.TIMESTAMP);
			taskdet1 = query.getResultList();
		} else {
			for (String accessKey : taskAccessRights) {
				if (null != accessKey) {
					TypedQuery<Task> query = entityManager.createQuery(
							"from Task where " + colType + conditionOperator + ":date1 and task_id like :accessKey",
							Task.class);
					query.setParameter("date1", date1, TemporalType.TIMESTAMP);
					query.setParameter("accessKey", accessKey + "%");
					List<Task> tempTaskList = query.getResultList();
					taskdet1.addAll(tempTaskList);
				}
			}
		}
		return taskdet1;

	}

	public void changeStatus(String taskId, String statusStr) {
		Task task = findOne(taskId);
		task.setStatus(statusStr);
		update(task);
	}

	public List<Task> getChartSearchlist(String taskStatus, boolean adminflag, List<String> taskAccessRights) {
		List<Task> taskdet = new ArrayList<Task>();
		if (adminflag) {
			TypedQuery<Task> query = entityManager.createQuery("from Task where status ='" + taskStatus + "'",
					Task.class);
			taskdet = query.getResultList();
		} else {
			for (String accessKey : taskAccessRights) {
				if (null != accessKey) {
					TypedQuery<Task> query = entityManager.createQuery(
							"from Task where status ='" + taskStatus + "' and task_id like :accessKey", Task.class);
					query.setParameter("accessKey", accessKey + "%");
					List<Task> tempTaskList = query.getResultList();
					taskdet.addAll(tempTaskList);
				}
			}
		}
		return taskdet;
	}

	@Override
	public List<Task> getTasklist() {
		List<Task> taskdet = new ArrayList<Task>();
		TypedQuery<Task> query = entityManager.createQuery("from Task", Task.class);
		taskdet = query.getResultList();
		return taskdet;
	}

	public List<TaskType> getTaskTypelist() {
		List<TaskType> tasktypedet = new ArrayList<TaskType>();
		TypedQuery<TaskType> query = entityManager.createQuery("from TaskType", TaskType.class);
		tasktypedet = query.getResultList();
		return tasktypedet;
	}

	private String getKeyforTaskId(String tempTaskId) {
		String key = new String();
		String[] parts = tempTaskId.split("_");
		String[] firstTwoEntries = Arrays.copyOf(parts, 2);

		for (String entry : firstTwoEntries) {
			key.concat(entry);
		}

		return key;
	}

	@Override
	public List<Task> getTaskByAccessRight(List<String> taskAccessRights) {
		List<Task> taskdet = new ArrayList<Task>();
		for (String accessKey : taskAccessRights) {
			if (null != accessKey) {
				Query query = entityManager.createNamedQuery("FetchTaskByRights");

				query.setParameter(1, accessKey + "%");

				List<Task> tempTaskList = query.getResultList();
				taskdet.addAll(tempTaskList);
			}
		}
		return taskdet;
	}

	@Override
	public List<Task> getAllTasks(List<String> taskIds) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Task> cQuery = criteriaBuilder.createQuery(Task.class);
		Root<Task> taskRoot = cQuery.from(Task.class);
		cQuery.select(taskRoot);
		cQuery.where(criteriaBuilder.in(taskRoot.get("task_id")).value(taskIds));
		return entityManager.createQuery(cQuery).getResultList();

	}

	public void deleteTasksByIds(List<String> taskIds) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Task> query = cb.createQuery(Task.class);
		Root<Task> root = query.from(Task.class);
		query.where(root.get("task_id").in(taskIds));
		deleteAll(this.entityManager.createQuery(query).getResultList());
	}

	public List<String> getTaskColumnsData(String columnName) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> query = cb.createQuery(String.class);
		Root<Task> root = query.from(Task.class);
		query.distinct(true).select(root.<String> get(columnName));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	public List<Task> getTaskListByIds(List<String> taskIds){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Task> query = cb.createQuery(Task.class);
		Root<Task> root = query.from(Task.class);
		query.where(cb.in(root.get("task_id")).value(taskIds));
		return (this.entityManager.createQuery(query).getResultList());
		
	}
	

	public List<Integer> getLockedTaskRevisionIds(String taskId) {
		Query query = entityManager.createNativeQuery(
				"select REV_ID from task_rev where task_id= :taskId and status = :status order by REV_ID DESC");
		query.setParameter("taskId", taskId);
		query.setParameter("status", TaskStatus.TEMP_LOCK.value);
		return query.getResultList();
	}

	public String getPreviousTaskStatus(List<Integer> lockedRevIds, String taskId) {
		List<Integer> revIds = new ArrayList<Integer>();
		Query query = entityManager.createNativeQuery(
				"select REV_ID from task_rev where REV_ID > :revId and task_id= :taskId order by REV_ID DESC");
		query.setParameter("revId", lockedRevIds.get(0));
		query.setParameter("taskId", taskId);
		List<Integer> revIdsLatest = query.getResultList();
		if (revIdsLatest.isEmpty()) {

			for (Integer revId : lockedRevIds) {
				Query query1 = entityManager.createNativeQuery(
						"select REV_ID from task_rev where REV_ID < :revId and task_id= :taskId order by REV_ID DESC");
				query1.setParameter("revId", revId);
				query1.setParameter("taskId", taskId);
				revIds = query1.getResultList();
				if (revIds.isEmpty()) {
					return null;
				}
				Query query2 = entityManager
						.createNativeQuery("SELECT status from task_rev where task_id= :taskId  and REV_ID = :revId");
				query2.setParameter("revId", revIds.get(0));
				query2.setParameter("taskId", taskId);
				if (((String) query2.getResultList().get(0)).equalsIgnoreCase(TaskStatus.TEMP_LOCK.value)) {
					continue;
				} else {
					return (String) query2.getResultList().get(0);
				}
			}

		} else {
			revIds.addAll(revIdsLatest);
			Query query2 = entityManager
					.createNativeQuery("SELECT status from task_rev where task_id= :taskId  and REV_ID = :revId");
			query2.setParameter("revId", revIds.get(0));
			query2.setParameter("taskId", taskId);

			return (String) query2.getResultList().get(0);
		}
		return null;
	}

	public Long getTaskStatusCount(String status) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> cquery = cb.createQuery(Long.class);
		Root<Task> root = cquery.from(Task.class);
		cquery.select(cb.count(root.get("status"))).where(cb.equal(root.get("status"), status));
		Query query = entityManager.createQuery(cquery);
		return (Long) query.getSingleResult();
	}

	public Integer getTaskIdSeq(){
		Query query = entityManager.createNativeQuery("SELECT NEXT VALUE FOR [dbo].TaskIdSeq ");
		return (Integer) query.getSingleResult();
		
	}

}
