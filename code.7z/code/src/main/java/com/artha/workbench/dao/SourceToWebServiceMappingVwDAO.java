package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.SourceToWebServiceMappingVw;
import com.artha.workbench.models.metastore.SourceToWebServiceMappingVwKey;
import com.guvvala.framework.dao.BaseDAO;


public interface SourceToWebServiceMappingVwDAO  extends  BaseDAO<SourceToWebServiceMappingVw, SourceToWebServiceMappingVwKey>

{
	public List<SourceToWebServiceMappingVw> getsourceToWebServiceMappingVwListByReleaseNum (Integer releaseNum);
}
