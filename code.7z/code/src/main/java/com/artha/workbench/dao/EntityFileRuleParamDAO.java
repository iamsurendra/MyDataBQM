package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EntityFileRuleParam;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityFileRuleParamDAO extends BaseDAO<EntityFileRuleParam,Integer> {
	
	 public void saveEntityFileRuleParam(List<EntityFileRuleParam> entitytypes);
	 
	 List<EntityFileRuleParam> getEntityFileRuleParamList(Integer xrefId);
	 
	 List<EntityFileRuleParam> getEntityFileRuleParamList(List<Integer> xrefIds);

}
