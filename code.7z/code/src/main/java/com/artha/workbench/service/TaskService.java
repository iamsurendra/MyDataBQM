package com.artha.workbench.service;

import java.util.List;
import java.util.Set;

import com.artha.workbench.beanParams.TaskBeanParam;
import com.artha.workbench.models.datahub.LockedTask;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.models.datahub.TaskType;
import com.artha.workbench.models.datahub.TgtColumns;
import com.artha.workbench.models.userConfig.PagePreference;
import com.guvvala.framework.filter.BaseFilter;
import com.artha.workbench.to.ChartQueryTO;

public interface TaskService {

	public List<Task> getTaskList();
	
	Task findOne(String id);

	public void delete(List<String> taskids);

	public void deleteAll();

	public List<Task> getSearchlist(String taskStatus, String Betweenrec, String andrec);

	Boolean findLockedTask(String taskId, String userId);

	List<Task> getNorSearchlist(Set<BaseFilter> userFilters, boolean adminFlag, List<String> taskAccessRights);

	public void changeStatus(List<String> taskIdLists, String statusstr, String userName, List<String> resolveList);
	
	public List<String> getLockedTasksList(String userName);

	public void removeLockedTasks(String taskid, String username);

	public List<Task> getChartSearchlist(String taskStatus, boolean adminflag, List<String> taskAccessRights);

	public List<LockedTask> getLockedTaskList();

	public void unlockSelected(String taskid);

	Boolean findLockedTaskByOtherUser(List<String> taskIdList, String userName);

	public List<Task> getSearchlist(TaskBeanParam taskBeanParam, String partnertAbbr, String fileTypeAbbr, String entityFileTypeId);

	public List<TaskType> getTaskTypelist();

	public List<Task> getCreatedByTasklist();

	public List<Task> getTaskByAccessRight(List<String> taskAccessRights);

	public List<String> getTaskColumnsData(String columnName);

	public List<Task> getNormaluserSearchlist(TaskBeanParam taskBeanParam, String partnertAbbr, String fileTypeAbbr,
			String entityFileTypeId, List<String> taskAccessRights);

	List<Task> getAllTasks(List<String> taskIds);

	List<Task> getAllTasksByAccessRight(List<String> taskIds, List<String> taskAccessRights);

	Long getTaskStatusCount(String status);

	List<String> getTaskIdsByAccessRight(List<String> taskAccessRights);

	PagePreference findPagePreference(Long userId, String pageName);

	PagePreference saveOrUpdate(PagePreference pagePreference);

	void deletePreference(PagePreference pagePreference);

	public void updateTargetValues(List<TgtColumns> popUpTargets);
	
	List<Task> getTaskListByIds(List<String> selectedTaskList);
	
	Integer getTaskIdSeq();
	
	List<ChartQueryTO> getDashboardCountForAdmin();
	
	public Set<BaseFilter> getNormalSearchFilters(TaskBeanParam taskBeanParam);

	void updateTaskStatus(String taskId, String status);
	
	
	
}
