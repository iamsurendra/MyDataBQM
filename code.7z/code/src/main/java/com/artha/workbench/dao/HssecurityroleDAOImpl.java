package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.Hssecurityrole;
import com.artha.workbench.models.userConfig.HssecurityrolePK;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class HssecurityroleDAOImpl extends BaseDAOImpl<Hssecurityrole, HssecurityrolePK>
		implements HssecurityroleDAO {

	public HssecurityroleDAOImpl() {
		super(Hssecurityrole.class);
	}

	public List<Long> findPartnerByRoleID(Long roleId) {
		TypedQuery<Long> query = entityManager.createQuery(
				"select distinct hssec.partnerId from Hssecurityrole hssec where hssec.id.roleId=" + roleId, Long.class);
		return query.getResultList();
	}

	public List<Long> findPartnerIdByRoleID(List<Long> roleIds) {
		TypedQuery<Long> query = entityManager.createQuery(
				"select distinct hssec.partnerId from Hssecurityrole hssec where hssec.id.roleId in(:param1)", Long.class);
		query.setParameter("param1", roleIds);
		return query.getResultList();
	}
	
	public List<Long> findFileTypeByPartnerID(Long partnerID) {
		TypedQuery<Long> query = entityManager.createQuery(
				"select hssec.id.entityFileTypeId from Hssecurityrole hssec where hssec.partnerId=" + partnerID, Long.class);
		return query.getResultList();
	}
	
	public List<Long> findFileTypeByPartnerIDRoleId(Long partnerID,Long roleId) {
		TypedQuery<Long> query = entityManager.createQuery(
				"select distinct hssec.id.entityFileTypeId from Hssecurityrole hssec where hssec.partnerId= :partnerID and hssec.id.roleId  = :roleId", Long.class);
		query.setParameter("partnerID", partnerID);
		query.setParameter("roleId", roleId);
		return query.getResultList();
	}
	
	public List<Hssecurityrole> findColumnByPartnerIdFileTypeID(Long partnerTypeId, Long entityFileTypeid,Long roleId)
	{
		TypedQuery<Hssecurityrole> query = entityManager.createQuery(
				"select hssec from Hssecurityrole hssec where hssec.partnerId= :partnerID and hssec.id.roleId  = :roleId and  hssec.id.entityFileTypeId = :entityFileTypeId", Hssecurityrole.class);
		query.setParameter("partnerID", partnerTypeId);
		query.setParameter("entityFileTypeId", entityFileTypeid);
		query.setParameter("roleId", roleId);
		return query.getResultList();
	}
	
	public List<Hssecurityrole> findAllByRoleID(Long roleId) {
		TypedQuery<Hssecurityrole> query = entityManager.createQuery(
				"select hssec from Hssecurityrole hssec where hssec.id.roleId = :roleId", Hssecurityrole.class);
		query.setParameter("roleId", roleId);
		return query.getResultList();
	}

	public List<Long> findEntityFileTypeId(Long partnerID,List<Long> roleId) {
		TypedQuery<Long> query = entityManager.createQuery(
				"select hssec.id.entityFileTypeId from Hssecurityrole hssec where hssec.id.roleId in(:roleId) and hssec.partnerId= :partnerID", Long.class);
		query.setParameter("roleId", roleId);
		query.setParameter("partnerID", partnerID);
		return query.getResultList();
	}
	
	@Override
	public int deleteColumnsByPartnerIdFileTypeID(List<Long> partnerTypeIds, List<Long> entityFileTypeIds,Long roleId)
	{
		Query query = entityManager.createQuery(
				"delete from Hssecurityrole hssec where hssec.partnerId in(:partnerIDs) and hssec.id.roleId  = :roleId and  hssec.id.entityFileTypeId in(:entityFileTypeIds)");
		query.setParameter("partnerIDs", partnerTypeIds);
		query.setParameter("entityFileTypeIds", entityFileTypeIds);
		query.setParameter("roleId", roleId);
		return query.executeUpdate();
	}
	@Override
	public int findColumnByPartnerIdFileTypeID(List<Long> partnerTypeIds, List<Long> entityFileTypeIds,Long roleId)
	{
		TypedQuery<Long> query = entityManager.createQuery(
				"select count(hssec) from Hssecurityrole hssec where hssec.partnerId in(:partnerIDs) and hssec.id.roleId  = :roleId and  hssec.id.entityFileTypeId in( :entityFileTypeIds)", Long.class);
		query.setParameter("partnerIDs", partnerTypeIds);
		query.setParameter("entityFileTypeIds", entityFileTypeIds);
		query.setParameter("roleId", roleId);
		return query.getFirstResult();
	}
	
	public List<Hssecurityrole> findHssecurityroleByPartnerIdRoleID(Long partnerTypeId, Long roleId) {
		TypedQuery<Hssecurityrole> query = entityManager.createQuery(
				"select hssec from Hssecurityrole hssec where hssec.partnerId= :partnerID and hssec.id.roleId  = :roleId",
				Hssecurityrole.class);
		query.setParameter("partnerID", partnerTypeId);
		query.setParameter("roleId", roleId);
		return query.getResultList();
	}

}
