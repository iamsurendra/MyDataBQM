package com.artha.workbench.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.models.userConfig.Groups;
import com.artha.workbench.service.GroupService;
import com.artha.workbench.service.UserRolesService;
import com.artha.workbench.service.UserService;
import com.artha.workbench.to.GroupPrivilegeTO;
import com.guvvala.framework.errorHandler.AppException;

@RestController
@RequestMapping("/api/groupPrivilege")
public class GroupPrivilegeController {

	@Autowired
	GroupService groupService;

	@Autowired
	private UserService userService;

	@Autowired
	UserRolesService userRolesService;

	@RequestMapping(value = "/getAllGroups", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Groups> getGroupsList() {
		return groupService.getGroupsList();
	}

	@RequestMapping(value = "/createGroup", method = RequestMethod.POST)
	public Groups submitSelected(@RequestBody Groups group) {
		if (groupService.groupNameExists(group.getName())) {
			throw new AppException(MessagesEnum.DUPLICATE_GROUP_NAME);
		} else {
			return groupService.saveGroup(group);
		}
	}

	@RequestMapping(value = "/getSelectedUserAndRoleIds/{selectedGroupId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public GroupPrivilegeTO getSelectedUserIdList(@PathVariable("selectedGroupId") Integer selectedGroupId) {
		GroupPrivilegeTO groupPrivilegeTO = new GroupPrivilegeTO();
		groupPrivilegeTO.setUserIdList(userService.getUsers(selectedGroupId));
		groupPrivilegeTO.setRoleIdList(groupService.getGroupRoles(selectedGroupId));
		return groupPrivilegeTO;
	}

	@RequestMapping(value = "/saveGroupPrivilege/{groupId}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void saveGroupPrivilege(@PathVariable("groupId") Integer groupId,
			@RequestBody GroupPrivilegeTO groupPrivilegeTO) {
		groupService.updateGroupRoles(groupPrivilegeTO.getRoleIdList(), groupId);
		userService.usersGroupUpdate(groupPrivilegeTO.getUserIdList(), groupId);
	}

	@RequestMapping(value = "/deleteGroup/{groupId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void deleteGroup(@PathVariable("groupId") Integer groupId) {
		groupService.deleteGroup(groupId);
	}

}