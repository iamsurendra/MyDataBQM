package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.FileValStepXref;
import com.guvvala.framework.dao.BaseDAO;

public interface FileValStepXrefDAO extends BaseDAO<FileValStepXref, Integer> {
	public void saveFileValStepXref(List<FileValStepXref> entitytypes);

	public void deleteFileValStepXref();
	
	public FileValStepXref getFileValStepXref(Integer entityFileTypeID, Integer stepId);

	public List<FileValStepXref> getFileValStepXrefListByReleaseNo(Integer releaseNo);

	List<Integer> getAllFileValStepXrefReleaseIds(Integer selectedReleaseId);
}
