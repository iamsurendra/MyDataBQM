package com.artha.workbench.to;

import java.util.Date;

import com.guvvala.framework.util.DateUtils;

public class AuditTaskTO {

	private String taskId;

	private String taskName;

	private Integer typeId;
	
	private String modifiedBy;

	private Date modifiedOn;
	
	private String owner;

	private String previousStatus;
	
	private String presentStatus;
	
	private String modifiedOnString;

	
	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getPreviousStatus() {
		return previousStatus;
	}

	public void setPreviousStatus(String previousStatus) {
		this.previousStatus = previousStatus;
	}

	public String getPresentStatus() {
		return presentStatus;
	}

	public void setPresentStatus(String presentStatus) {
		this.presentStatus = presentStatus;
	}

	public String getModifiedOnString() {
		return getModifiedOn()!=null ? DateUtils.convertDateFormat(getModifiedOn(), DateUtils.DISPLAY_DATE_TIME_FORMAT):null;
	}

	public void setModifiedOnString(String modifiedOnString) {
		this.modifiedOnString = modifiedOnString;
	}
	
}
