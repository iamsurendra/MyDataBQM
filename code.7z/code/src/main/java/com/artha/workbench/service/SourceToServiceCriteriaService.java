package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.SourceToServiceCriteria;
import com.artha.workbench.models.metastore.SourceToServiceCriteriaVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface SourceToServiceCriteriaService {
	
	public List<SourceToServiceCriteriaVw> getSourceToServiceCriteriaVwList();
	public void create(SourceToServiceCriteriaVw sourceToServiceCriteriaVw);
	public void update(SourceToServiceCriteriaVw sourceToServiceCriteriaVw, boolean isReleaseChanged) throws JsonProcessingException;
	public List<SourceToServiceCriteriaVw> getSourceToServiceCriteriaVwListByReleaseNo(Integer releaseNo);
	public SourceToServiceCriteriaVw getPreviousSourceToServiceCriteriaVw(SourceToServiceCriteriaVw sourceToServiceCriteriaVw) throws IOException;
	public List<SourceToServiceCriteria> getSourceToServiceCriteriaListByReleaseNo(Integer releaseNo);
	public SourceToServiceCriteria getSourceToServiceCriteria(SourceToServiceCriteriaVw sourceToServiceCriteriaVw);
}
