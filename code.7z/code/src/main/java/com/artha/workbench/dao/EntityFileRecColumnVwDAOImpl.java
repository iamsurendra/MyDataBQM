package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.EntityFileRecColumnVw;
import com.artha.workbench.models.metastore.EntityFileReccolVwkey;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityFileRecColumnVwDAOImpl extends
		BaseDAOImpl<EntityFileRecColumnVw, EntityFileReccolVwkey> implements
		EntityFileRecColumnVwDAO {

	public EntityFileRecColumnVwDAOImpl() {
		super(EntityFileRecColumnVw.class);
	}
	

	@Transactional
	public List<EntityFileRecColumnVw> getEntityFileRecColVwListByReleaseNo(Integer releaseNo)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileRecColumnVw> query = cb.createQuery(EntityFileRecColumnVw.class);
		Root<EntityFileRecColumnVw> root = query.from(EntityFileRecColumnVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}

}
