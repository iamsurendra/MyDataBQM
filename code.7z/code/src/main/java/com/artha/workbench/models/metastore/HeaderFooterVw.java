package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "metastore.headerfooter_v")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@IdClass(HeaderFooterVwkey.class)
public class HeaderFooterVw extends AbstractModel{
	private static final long serialVersionUID = 1L;
	
	@Id 
	@Column(name="entityfiletypeid")
	@JsonProperty("entityfiletypeid")
	private Integer entityFileTypeId;
	
	
	@Column(name = "FileMask", nullable = false)
	@JsonProperty("filemask")
	private String FileMask;
	
	
	@Column(name = "rectype")
	@JsonProperty("rectype")
	private String RecType;
	
	
	@Column(name = "seqnum")
	@JsonProperty("seqnum")
	private Integer seqnum;
	
	
	@Column(name = "entityname")
	@JsonProperty("entityname")
	private String EntityName;
	
	
	@Column(name = "hsfiletype")
	@JsonProperty("hsfiletype")
	private String HSFileType;
	
	
	@Column(name = "headerfootertype")
	@JsonProperty("headerfootertype")
	private String HeaderFooterType;
	
	
	@Column(name = "filerecnum")
	@JsonProperty("filerecnum")
	private String FileRecNum;
	
	
	@Column(name = "colcnt")
	@JsonProperty("colcnt")
	private Integer ColCnt;
	
	
	@Column(name = "active")
	@JsonProperty("active")
	private String Active;
	
	
	@Column(name = "effectivedate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@JsonProperty("effectivedate")
	private Date EffectiveDate;
	
	@Column(name = "columnswidth")
	@JsonProperty("columnswidth")
	private Integer ColumnsWidth;
	
	
	@Column(name = "columnspattern")
	@JsonProperty("columnspattern")
	private String ColumnsPattern;

	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Transient
	@JsonIgnore
	private String Comments;
	
	
	@Transient
	@JsonIgnore
	private String effectiveDatestr;
	
	
	@Transient
	@JsonIgnore
	private boolean addMode;
	
	@Transient
	@JsonIgnore
	private Integer entityId;
	
	@Transient
	@JsonIgnore
	private Integer fileTypeId;
	
	
	
	public HeaderFooterVw(boolean addMode,Date effectiveDate,Integer releaseNo){
		this.addMode = addMode;
		this.EffectiveDate = effectiveDate;
		this.releaseNo = releaseNo;
		convertEffectiveDate();
	}
	
	public HeaderFooterVw(){
		
	}
	
	
	
	public Integer getEntityId() {
		return entityId;
	}

	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}

	public Integer getFileTypeId() {
		return fileTypeId;
	}

	public void setFileTypeId(Integer fileTypeId) {
		this.fileTypeId = fileTypeId;
	}

	public Integer getEntityFileTypeId() {
		return entityFileTypeId;
	}

	public void setEntityFileTypeId(Integer entityFileTypeId) {
		this.entityFileTypeId = entityFileTypeId;
	}

	public Integer getSeqnum() {
		return seqnum;
	}

	public void setSeqnum(Integer seqnum) {
		this.seqnum = seqnum;
	}

	public String getEffectiveDatestr() {
		return effectiveDatestr;
	}

	public void setEffectiveDatestr(String effectiveDatestr) {
		this.effectiveDatestr = effectiveDatestr;
	}

	public String getFileMask() {
		return FileMask;
	}
	
	public void setFileMask(String fileMask) {
		FileMask = fileMask;
	}
	
	public String getRecType() {
		return RecType;
	}
	
	public void setRecType(String recType) {
		RecType = recType;
	}
	
	public Integer getSeqNum() {
		return seqnum;
	}
	
	public void setSeqNum(Integer seqNum) {
		seqnum = seqNum;
	}
	
	public String getEntityName() {
		return EntityName;
	}
	
	public void setEntityName(String entityName) {
		EntityName = entityName;
	}
	
	public String getHSFileType() {
		return HSFileType;
	}
	
	public void setHSFileType(String hSFileType) {
		HSFileType = hSFileType;
	}
	
	public String getHeaderFooterType() {
		return HeaderFooterType;
	}
	
	public void setHeaderFooterType(String headerFooterType) {
		HeaderFooterType = headerFooterType;
	}
	
	public String getFileRecNum() {
		return FileRecNum;
	}
	
	public void setFileRecNum(String fileRecNum) {
		FileRecNum = fileRecNum;
	}
	
	public Integer getColCnt() {
		return ColCnt;
	}
	
	public void setColCnt(Integer colCnt) {
		ColCnt = colCnt;
	}
	
	public String getActive() {
		return Active;
	}
	
	public void setActive(String active) {
		Active = active;
	}
	
	public Date getEffectiveDate() {
		return EffectiveDate;
	}
	
	public void setEffectiveDate(Date effectiveDate) {
		EffectiveDate = effectiveDate;
	}
	
	public Integer getColumnsWidth() {
		return ColumnsWidth;
	}
	
	public void setColumnsWidth(Integer columnsWidth) {
		ColumnsWidth = columnsWidth;
	}
	
	public String getColumnsPattern() {
		return ColumnsPattern;
	}
	
	public void setColumnsPattern(String columnsPattern) {
		ColumnsPattern = columnsPattern;
	}
	
	public String getComments() {
		return Comments;
	}
	
	public void setComments(String comments) {
		Comments = comments;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}
	
	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}

	@PostLoad
	public void postLoad(){
		convertEffectiveDate();
	}
	public void convertEffectiveDate(){
		this.effectiveDatestr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());	
	}
	

}
	

