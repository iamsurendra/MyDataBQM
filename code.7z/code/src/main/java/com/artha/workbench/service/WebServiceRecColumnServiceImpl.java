package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.WebServiceRecColumnDAO;
import com.artha.workbench.dao.WebServiceRecColumnVwDAO;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.models.metastore.WebServiceRecColumn;
import com.artha.workbench.models.metastore.WebServiceRecColumnKey;
import com.artha.workbench.models.metastore.WebServiceRecColumnVw;
import com.artha.workbench.models.metastore.WebServiceRecColumnVwKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("webServiceRecColumnService")
public class WebServiceRecColumnServiceImpl implements WebServiceRecColumnService{
@Autowired
WebServiceRecColumnDAO webServiceRecColumnDAO;

@Autowired
WebServiceRecColumnVwDAO webServiceRecColumnVwDAO;

@Autowired
ReleaseArchiveDAO releaseArchiveDAO;

@Transactional(readOnly = true)
public List<Integer> getWebServiceIds() {
	return webServiceRecColumnDAO.getWebServiceIds();
}

@Transactional(readOnly = true)
public List<Integer> getTargetColumnIds(Integer webServiceId) {
	return webServiceRecColumnDAO.getTargetColumnIds(webServiceId);
}


@Transactional
public List<WebServiceRecColumn> getWebServiceRecColumn() {
	return webServiceRecColumnDAO.findAll();
	
}

@Transactional
public List<WebServiceRecColumnVw> getWebServiceRecColumnVw() {
	return webServiceRecColumnVwDAO.findAll();
	
}

@Transactional
public void createWebServiceRec(WebServiceRecColumnVw webServiceRecColumnVw){
	WebServiceRecColumn column = new WebServiceRecColumn();
	WebServiceRecColumnKey columnKey = new WebServiceRecColumnKey();
	columnKey.setColumnID(webServiceRecColumnVw.getColumnID());
	columnKey.setWebServiceID(webServiceRecColumnVw.getWebServiceID());
	column.setWebServiceRecColumnKey(columnKey);
	loadWebServiceRecColumn(column,webServiceRecColumnVw);
	webServiceRecColumnDAO.create(column);
	
}

private void loadWebServiceRecColumn(WebServiceRecColumn column, WebServiceRecColumnVw webServiceRecColumnVw) {
	// TODO Auto-generated method stub
	column.setActive(webServiceRecColumnVw.getActive());
	column.setAllowNullValue(webServiceRecColumnVw.getAllowNullValue());
	column.setColLength(webServiceRecColumnVw.getColLength());
	column.setColMask(webServiceRecColumnVw.getColMask());
	column.setDataType(webServiceRecColumnVw.getDataType());
	column.setEffectiveDate(webServiceRecColumnVw.getEffectiveDate());
	column.setReleaseNum(webServiceRecColumnVw.getReleaseNum());
	column.setColName(webServiceRecColumnVw.getColName());
	column.setxPathParent(webServiceRecColumnVw.getxPathParent());
	column.setStartPosition(webServiceRecColumnVw.getStartPosition());
}


	
	@Transactional
	public void updateWebServiceRecColumn(WebServiceRecColumnVw webServiceRecColumnVw, boolean isReleaseChanged)
			throws JsonProcessingException {

		WebServiceRecColumnKey webServiceRecColumnKey = new WebServiceRecColumnKey();

		webServiceRecColumnKey.setColumnID(webServiceRecColumnVw.getColumnID());
		webServiceRecColumnKey.setWebServiceID(webServiceRecColumnVw.getWebServiceID());
		checkForCyclicDependency(webServiceRecColumnVw);
		WebServiceRecColumn webServiceRecColumn = webServiceRecColumnDAO.findOne(webServiceRecColumnKey);

		if (isReleaseChanged) {
			WebServiceRecColumnVwKey columnVwKey = new WebServiceRecColumnVwKey();
			columnVwKey.setColumnID(webServiceRecColumnVw.getColumnID());
			columnVwKey.setWebServiceID(webServiceRecColumnVw.getWebServiceID());
			WebServiceRecColumnVw oldEntity = webServiceRecColumnVwDAO.findOne(columnVwKey);
			if (oldEntity != null) {
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNum());
				releaseArchiveKey.setReleaseId(webServiceRecColumnVw.getReleaseNum());
				releaseArchiveKey.setTableName("WEBSERVICERECCOLUMN");
				releaseArchiveKey.setTableRecId(
						AppWebUtils.convertObjectToJson(webServiceRecColumn.getWebServiceRecColumnKey()));
				ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
				if (releaseArchive != null) {
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(webServiceRecColumn));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(webServiceRecColumnKey));
					releaseArchiveDAO.update(releaseArchive);
				} else {
					releaseArchive = new ReleaseArchive();
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(columnVwKey));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(webServiceRecColumn));
					releaseArchiveDAO.create(releaseArchive);
				}
			}
		}
		if (webServiceRecColumn != null) {
			webServiceRecColumnVw.setWebServiceID(webServiceRecColumnVw.getWebServiceID());
			webServiceRecColumnVw.setColumnID(webServiceRecColumnVw.getColumnID());
			webServiceRecColumn.setColName(webServiceRecColumnVw.getColName());
			webServiceRecColumn.setDataType(webServiceRecColumnVw.getDataType());
			webServiceRecColumn.setColLength(webServiceRecColumnVw.getColLength());
			webServiceRecColumn.setStartPosition(webServiceRecColumnVw.getStartPosition());
			webServiceRecColumn.setColMask(webServiceRecColumnVw.getColMask());
			webServiceRecColumn.setAllowNullValue(webServiceRecColumnVw.getAllowNullValue());
			webServiceRecColumn.setActive(webServiceRecColumnVw.getActive());
			webServiceRecColumn.setEffectiveDate(webServiceRecColumnVw.getEffectiveDate());
			webServiceRecColumn.setxPathParent(webServiceRecColumnVw.getxPathParent());
			webServiceRecColumn.setReleaseNum(webServiceRecColumnVw.getReleaseNum());
			webServiceRecColumn.setActive(webServiceRecColumnVw.getActive());
			webServiceRecColumnDAO.update(webServiceRecColumn);

		}

	}
	
	private void checkForCyclicDependency(WebServiceRecColumnVw webServiceRecColumnVw) throws JsonProcessingException {

		WebServiceRecColumnKey recColumnKey = new WebServiceRecColumnKey();
		recColumnKey.setColumnID(webServiceRecColumnVw.getColumnID());
		recColumnKey.setWebServiceID(webServiceRecColumnVw.getWebServiceID());
		String jsonId = AppWebUtils.convertObjectToJson(recColumnKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO
				.getReleaseArchiveByArchiveId(webServiceRecColumnVw.getReleaseNum(), "WEBSERVICERECCOLUMN", jsonId);
		if (releaseArchive != null) {
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);  
		}
	}

	@Transactional
	public WebServiceRecColumnVw getPreviousWebServiceRecColsVw(WebServiceRecColumnVw webServiceRecColumnVw) throws IOException{
	
		WebServiceRecColumnKey webServiceRecColumnKey = new WebServiceRecColumnKey();
		webServiceRecColumnKey.setColumnID(webServiceRecColumnVw.getColumnID());
		webServiceRecColumnKey.setWebServiceID(webServiceRecColumnVw.getWebServiceID());
		String webServiceRecColVwJson = AppWebUtils.convertObjectToJson(webServiceRecColumnKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(webServiceRecColumnVw.getReleaseNum(), "WEBSERVICERECCOLUMN", webServiceRecColVwJson);
		WebServiceRecColumnVw previousHeaderFooterColsVw = new WebServiceRecColumnVw();
		if(releaseArchive!=null){
			previousHeaderFooterColsVw = AppWebUtils.convertJsonToObject(WebServiceRecColumnVw.class, releaseArchive.getViewRecData());
		}
		return previousHeaderFooterColsVw;
		
	}
	
	@Transactional
	public List<WebServiceRecColumnVw> getWebServiceRecColumnVwListByReleaseNo(Integer releaseNo){
		return webServiceRecColumnVwDAO.getWebServiceRecColumnListByReleaseNo(releaseNo);
	}
	
	public List<WebServiceRecColumn> getWebServiceRecColumnListByReleaseNo(Integer releaseNo){
		return webServiceRecColumnDAO.getWebServiceRecColumnListByReleaseNo(releaseNo);
	}
	
	@Transactional
	public List<WebServiceRecColumn> getWebServiceRecColumnList(Set<Integer> webServiceIds, Set<Integer> colIds, Integer selectedReleaseNumber) {
		return webServiceRecColumnDAO.getWebServiceRecColumnList(webServiceIds, colIds, selectedReleaseNumber);
	}
	
	@Transactional
	public WebServiceRecColumn getWebServiceRecColumn(WebServiceRecColumnVw webServiceRecColumnVw) {
		WebServiceRecColumnKey webServiceRecColumnKey = new WebServiceRecColumnKey();
		webServiceRecColumnKey.setWebServiceID(webServiceRecColumnVw.getWebServiceID());
		webServiceRecColumnKey.setColumnID(webServiceRecColumnVw.getColumnID());
		WebServiceRecColumn webServiceRecColumn = webServiceRecColumnDAO.findOne(webServiceRecColumnKey);
		return webServiceRecColumn;
	}
	
	@Transactional(readOnly = true)
    public WebServiceRecColumn getWebServiceRecColumn(Integer webServiceId,Integer columnId){
		WebServiceRecColumnKey webServiceRecColumnKey = new WebServiceRecColumnKey();
		webServiceRecColumnKey.setWebServiceID(webServiceId);
		webServiceRecColumnKey.setColumnID(columnId);
		WebServiceRecColumn webServiceRecColumn = webServiceRecColumnDAO.findOne(webServiceRecColumnKey);
		return webServiceRecColumn;
	}
}
