package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.EntityType;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityTypeDAO extends BaseDAO<EntityType, Integer> {
	 public void saveEntityType(List<EntityType> entitytypes);
	    public int getmaxEntitytype();
	    public HashMap<Integer,String> loadentityTypeid() ;
	    public void deleteEntityType();
	    List<EntityType> getEntityTypeListByReleaseNo(Integer releaseNo);
	    List<Integer> getEntityTypeReleaseNumbers(Set<Integer> entityTypeIds,Integer selectedReleaseNumber);
	    List<Integer> getAllEntityTypeReleaseIds(Integer selectedReleaseId);
	    List<EntityType> getEntityTypeList(Set<Integer> entityTypeIds,Integer selectedReleaseId);
}
