package com.artha.workbench.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.core.AuditTgtColInfo_VW;
import com.artha.workbench.models.datahub.Srccolumns;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class AuditTgtColumnDAOImpl extends BaseDAOImpl<AuditTgtColInfo_VW, Integer> implements AuditTgtColumnDAO {

	public AuditTgtColumnDAOImpl() {
		super(AuditTgtColInfo_VW.class);
	}

	public List<AuditTgtColInfo_VW> getAuditTgtColumnList(String taskId) {
		List<AuditTgtColInfo_VW> tgtColList = new ArrayList<AuditTgtColInfo_VW>();
		Query fetchTgtColId = entityManager.createNativeQuery(
				"Select tgtcol_id from tgtcolumns_rev colRev , tgtrecords_rev recRev where recRev.task_id = ?1 and colRev.tgtrec_id=recRev.tgtrec_id");
		fetchTgtColId.setParameter(1, taskId);
		List<String> tgtColIdList = fetchTgtColId.getResultList();
		if (!tgtColIdList.isEmpty()) {
			Query fetchTgtColQuery = entityManager
					.createNativeQuery("Select * from audittgtcolinfo  where tgtcol_id in ?1 ");
			fetchTgtColQuery.setParameter(1, tgtColIdList);
			List<Object[]> tgtColQueryResultList = fetchTgtColQuery.getResultList();
			for (Object[] tgtCol : tgtColQueryResultList) {
				AuditTgtColInfo_VW audit = new AuditTgtColInfo_VW();
				audit.setTgtcolId(tgtCol[0].toString());
				audit.setTgtrecId(tgtCol[1].toString());
				if(null!=tgtCol[2])
				audit.setModifiedvalue(tgtCol[2].toString());
				if(null!=tgtCol[3])
				audit.setRevId((Integer) tgtCol[3]);
				if(null!=tgtCol[4])
				audit.setLastUpdBy(tgtCol[4].toString());
				if(null!=tgtCol[5])
				audit.setLastUpdDt((Timestamp) tgtCol[5]);
				if(null!=tgtCol[6])
				audit.setDefColName(tgtCol[6].toString());
				tgtColList.add(audit);

			}
		}
		return tgtColList;
	}

	public List<Srccolumns> getSourceValues(String taskId)
	{
		List<Srccolumns> srccolumns = new ArrayList<Srccolumns>();
		Query srcColumnQuery = entityManager.createNativeQuery(
				"Select colRev from srccolumns colRev , srcrecords recRev where recRev.task_id = ?1 and colRev.srcrec_id=recRev.srcrec_id");
		srcColumnQuery.setParameter(1, taskId);
		List<Object[]> srcColumnList = srcColumnQuery.getResultList();
		for(Object[] srcColumnObject : srcColumnList)
		{
			Srccolumns srcColumn = new Srccolumns();
			srcColumn.setSrccol_id(srcColumnObject[0].toString());
			srcColumn.setSrcrec_id(srcColumnObject[1].toString());
			srcColumn.setCol_name(srcColumnObject[2].toString());
			srcColumn.setCol_type(srcColumnObject[3].toString());
			srcColumn.setCol_iskey((Integer)srcColumnObject[4]);
			srccolumns.add(srcColumn);
			
		}
		return srccolumns;
	}
}
