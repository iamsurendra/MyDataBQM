package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.HeaderFooterVw;
import com.artha.workbench.models.metastore.HeaderFooterVwkey;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class HeaderFooterVwDAOImpl extends
		BaseDAOImpl<HeaderFooterVw, HeaderFooterVwkey> implements
		HeaderFooterVwDAO {

	public HeaderFooterVwDAOImpl() {
		super(HeaderFooterVw.class);
	}
	
	@Transactional
	public List<HeaderFooterVw> getHeaderFooterVwListByReleaseNo(Integer releaseNo)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<HeaderFooterVw> query = cb.createQuery(HeaderFooterVw.class);
		Root<HeaderFooterVw> root = query.from(HeaderFooterVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
}
