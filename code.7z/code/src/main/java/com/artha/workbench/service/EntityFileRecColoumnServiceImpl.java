package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileRecColumnDAO;
import com.artha.workbench.dao.EntityFileRecColumnVwDAO;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.EntityMasterDAO;
import com.artha.workbench.dao.FileTypeDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.metastore.EntityFileRecColumn;
import com.artha.workbench.models.metastore.EntityFileRecColumnKey;
import com.artha.workbench.models.metastore.EntityFileRecColumnVw;
import com.artha.workbench.models.metastore.EntityFileReccolVwkey;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;


@Service("entityFileRecColoumnService")
public class EntityFileRecColoumnServiceImpl implements EntityFileRecColoumnService {

	@Autowired
	EntityFileRecColumnDAO entityFileRecColumnDAO;

	@Autowired
	EntityFileRecColumnVwDAO entityFileRecColumnVwDAO;

	@Autowired
	EntityMasterDAO entityMasterDAO;

	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefdbDAO;

	@Autowired
	FileTypeDAO fileTypeDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;


	@Transactional(readOnly = true)
	public List<EntityFileRecColumn> getEntityFileRecColumnList() {
		return entityFileRecColumnDAO.findAll();
	}
	
	@Transactional(readOnly = true)
	@Override
	public List<EntityFileRecColumnVw> getEntityFileRecColVwListByReleaseNo(Integer releaseNo) {
		return entityFileRecColumnVwDAO.getEntityFileRecColVwListByReleaseNo(releaseNo);
	}
	@Transactional(readOnly = true)
	@Override
	public EntityFileRecColumnVw getPreviousEntityFileRecColVw(EntityFileRecColumnVw entityFileRecColumnVw) throws IOException
	{
		EntityFileRecColumnKey entityFileRecColKey = new EntityFileRecColumnKey();
		entityFileRecColKey.setEntityFileTypeID(entityFileRecColumnVw.getEntityFileTypeID());
		entityFileRecColKey.setColumnID(entityFileRecColumnVw.getColumnID());
		String entityTypeIdJson = AppWebUtils.convertObjectToJson(entityFileRecColKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(entityFileRecColumnVw.getReleaseNo(), "ENTITYFILERECCOLUMN", entityTypeIdJson);
		EntityFileRecColumnVw previousEntityFileRecColumnVw = new EntityFileRecColumnVw();
		if(releaseArchive!=null){
		previousEntityFileRecColumnVw = AppWebUtils.convertJsonToObject(EntityFileRecColumnVw.class, releaseArchive.getViewRecData());
		}
		return previousEntityFileRecColumnVw;
		
	}


	@Transactional
	public void create(EntityFileRecColumnVw entityFileRecColumnVw) {
		EntityFileRecColumnKey entityFileRecColKey = new EntityFileRecColumnKey();
		entityFileRecColKey.setEntityFileTypeID(entityFileRecColumnVw.getEntityFileTypeID());
		entityFileRecColKey.setColumnID(entityFileRecColumnVw.getColumnID());
		EntityFileRecColumn entityFileRecColumn = new EntityFileRecColumn();
		entityFileRecColumn.setEntityFileRecColKey(entityFileRecColKey);
		loadEntityFileRecColumn(entityFileRecColumn, entityFileRecColumnVw);
		entityFileRecColumnDAO.create(entityFileRecColumn);
	}

	@Transactional
	public void update(EntityFileRecColumnVw entityFileRecColumnVw, boolean isReleaseChanged)
			throws JsonProcessingException {
		EntityFileRecColumnKey entityFileRecColKey = new EntityFileRecColumnKey();
		entityFileRecColKey.setEntityFileTypeID(entityFileRecColumnVw.getEntityFileTypeID());
		entityFileRecColKey.setColumnID(entityFileRecColumnVw.getColumnID());
		EntityFileRecColumn entityFileRecColumn = entityFileRecColumnDAO.findOne(entityFileRecColKey);
		checkForCyclicDependency(entityFileRecColumnVw);
		if (isReleaseChanged) {
			// For release Archive
			EntityFileReccolVwkey entityFileReccolVwkey = new EntityFileReccolVwkey();
			entityFileReccolVwkey.setColumnID(entityFileRecColumnVw.getColumnID());
			entityFileReccolVwkey.setEntityName(entityFileRecColumnVw.getEntityName());
			entityFileReccolVwkey.setHSFileType(entityFileRecColumnVw.getHSFileType());
			entityFileReccolVwkey.setFileMask(entityFileRecColumnVw.getFileMask());
			entityFileReccolVwkey.setEntityFileTypeID(entityFileRecColumnVw.getEntityFileTypeID());
			EntityFileRecColumnVw oldViewEntity = entityFileRecColumnVwDAO.findOne(entityFileReccolVwkey);

			if (oldViewEntity != null) {
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldViewEntity.getReleaseNo());
				releaseArchiveKey.setReleaseId(entityFileRecColumnVw.getReleaseNo());
				releaseArchiveKey.setTableName("ENTITYFILERECCOLUMN");
				releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityFileRecColumn.getEntityFileRecColKey()));
				ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
				if(releaseArchive!=null){
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldViewEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileRecColumn));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileReccolVwkey));
					releaseArchiveDAO.update(releaseArchive);
				}else{
					releaseArchive= new ReleaseArchive();
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldViewEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileRecColumn));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileReccolVwkey));
					releaseArchiveDAO.create(releaseArchive);
				}
			}
		}
		
		if(entityFileRecColumn!=null){
			loadEntityFileRecColumn(entityFileRecColumn,entityFileRecColumnVw);
		entityFileRecColumnDAO.update(entityFileRecColumn);
		}
	}
	
	private void checkForCyclicDependency(EntityFileRecColumnVw entityFileRecColumnVw) throws JsonProcessingException	{
		EntityFileRecColumnKey entityFileRecColKey = new EntityFileRecColumnKey();
		entityFileRecColKey.setEntityFileTypeID(entityFileRecColumnVw.getEntityFileTypeID());
		entityFileRecColKey.setColumnID(entityFileRecColumnVw.getColumnID());
		String jsonId = AppWebUtils.convertObjectToJson(entityFileRecColKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(entityFileRecColumnVw.getReleaseNo(), "ENTITYFILERECCOLUMN", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	
	@Transactional
	public EntityFileRecColumn getEntityFileRecColInfo(EntityFileRecColumnVw entityFileRecColumnVw){
		EntityFileRecColumnKey entityFileRecColKey = new EntityFileRecColumnKey();
		entityFileRecColKey.setEntityFileTypeID(entityFileRecColumnVw.getEntityFileTypeID());
		entityFileRecColKey.setColumnID(entityFileRecColumnVw.getColumnID());
		return entityFileRecColumnDAO.findOne(entityFileRecColKey);
	}
	
	@Transactional
	public EntityFileRecColumn getEntityFileRecColInfo(Integer entityFileTypeId,Integer columnId){
		EntityFileRecColumnKey entityFileRecColKey = new EntityFileRecColumnKey();
		entityFileRecColKey.setEntityFileTypeID(entityFileTypeId);
		entityFileRecColKey.setColumnID(columnId);
		return entityFileRecColumnDAO.findOne(entityFileRecColKey);
	}

	@Transactional(readOnly = true)
	public List<EntityFileRecColumnVw> getEntityFileRecColumnVwList() {
		return entityFileRecColumnVwDAO.findAll();
	}

	@Transactional
	public void saveEntityFileRecColumn(List<EntityFileRecColumn> entitytypes) {
		entityFileRecColumnDAO.saveEntityFileRecColumn(entitytypes);
	}

	@Transactional
	public EntityFileRecColumn loadEntityFileRecColumn(EntityFileRecColumn efrs,
			EntityFileRecColumnVw entityFileRecColumnVw) {
		efrs.setColName(entityFileRecColumnVw.getColName());
		efrs.setDataType(entityFileRecColumnVw.getDataType());
		efrs.setColLength(entityFileRecColumnVw.getColLength());
		efrs.setStartPosition(entityFileRecColumnVw.getStartPosition());
		efrs.setColMask(entityFileRecColumnVw.getColMask());
		efrs.setAllowNullValue(entityFileRecColumnVw.getAllowValue());
		efrs.setActive(entityFileRecColumnVw.getActive());
		efrs.setEffectiveDate(entityFileRecColumnVw.getEffectiveDate());
		efrs.setReleaseNo(entityFileRecColumnVw.getReleaseNo());
		efrs.setIncludeInRpt(entityFileRecColumnVw.getIncludeInRpt());
		return efrs;
	}

	@Transactional
	public List<EntityFileRecColumn> getEntityFileRecColumnTempList() {
		return entityFileRecColumnDAO.findAll();
	}
	
	@Transactional(readOnly = true)
	public List<Integer> getEntityFileRecRelNumbersByTypeIds(Set<Integer> entityTypeIds,Integer selectedReleaseNumber){
		return entityFileRecColumnDAO.getEntityFileRecRelNumbersByTypeIds(entityTypeIds, selectedReleaseNumber);
	}
	
	@Transactional(readOnly = true)
	public List<Integer> getEntityFileRecRelNumbersByColIds(Set<Integer> colIds,Integer selectedReleaseNumber){
		return entityFileRecColumnDAO.getEntityFileRecRelNumbersByColIds(colIds, selectedReleaseNumber);
	}
	
	@Transactional(readOnly = true)
	public List<EntityFileRecColumn> getEntityFileRecColumnListByReleaseNo(Integer releaseNo){
		return entityFileRecColumnDAO.getEntityFileRecColumnListByReleaseNo(releaseNo);
	}
	
	@Transactional(readOnly = true)
	public List<Integer> getAllEntityFileRecColumnReleaseIds(Integer selectedReleaseId){
		return entityFileRecColumnDAO.getAllEntityFileRecColumnReleaseIds(selectedReleaseId);
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<EntityFileRecColumn> getEntityFileRecList(Set<Integer> entityTypeIds,Set<Integer> colIds,Integer selectedReleaseNumber){
		
		return entityFileRecColumnDAO.getEntityFileRecList(entityTypeIds, colIds, selectedReleaseNumber);
	}
}
