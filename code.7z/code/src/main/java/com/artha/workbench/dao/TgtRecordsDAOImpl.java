package com.artha.workbench.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.datahub.TgtRecords;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class TgtRecordsDAOImpl extends BaseDAOImpl<TgtRecords, String> implements TgtRecordsDAO {

	public TgtRecordsDAOImpl() {
		super(TgtRecords.class);
	}

	public void updatetgtrecords(String taskid,String userName) {
		Query query = entityManager.createNamedQuery("findTgtRecordByTaskId");
		query.setParameter("taskId", taskid);
		TgtRecords tgtRecord = (TgtRecords) query.getSingleResult();
		tgtRecord.setResolvedBy(userName);
		tgtRecord.setResolvedOn(new Date());
		entityManager.merge(tgtRecord);
	}

	public TgtRecords getTgtRecordsObjByTaskId(String taskid)
	{
		Query query = entityManager.createNamedQuery("findTgtRecordByTaskId");
		query.setParameter("taskId", taskid);
		TgtRecords tgtRecord = (TgtRecords) query.getSingleResult();
		return tgtRecord;
	}
	
	public void removeResolvedStatus(String taskId)
	{
		Query query = entityManager.createNamedQuery("findTgtRecordByTaskId");
		query.setParameter("taskId", taskId);
		TgtRecords tgtRecord = (TgtRecords) query.getSingleResult();
		if(tgtRecord.getResolvedBy()!=null && tgtRecord.getResolvedOn()!=null)
		{
			tgtRecord.setResolvedBy(null);
			tgtRecord.setResolvedOn(null);
			entityManager.merge(tgtRecord);
		}
	}
	public List<String> findTgtRecordsByTaskId(List<String> taskIds) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> query = cb.createQuery(String.class);
		Root<TgtRecords> root = query.from(TgtRecords.class);
		query.select(root.<String>get("tgtrecId")).where(root.get("taskId").in(taskIds));
		return this.entityManager.createQuery(query).getResultList();
	}

	public void deleteAllTgtRecords(List<String> taskIds) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<TgtRecords> query = cb.createQuery(TgtRecords.class);
		Root<TgtRecords> root = query.from(TgtRecords.class);
		query.where(root.get("taskId").in(taskIds));
		deleteAll(this.entityManager.createQuery(query).getResultList());
	}

}
