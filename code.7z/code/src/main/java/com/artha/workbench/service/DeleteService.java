package com.artha.workbench.service;

public interface DeleteService {

	 public void  deleteTableData(String fileIdentifier);
	 
	 public void deleteAllTableData();
}
