package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.SavedQuery;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class SavedQueryDAOImpl extends BaseDAOImpl<SavedQuery, Integer> implements SavedQueryDAO {

	public SavedQueryDAOImpl() {
		super(SavedQuery.class);
	}

	@Override
	public List<SavedQuery> getSavedQueryData(String createdBy) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<SavedQuery> cQuery = builder.createQuery(SavedQuery.class);
		Root<SavedQuery> savedQueryRoot = cQuery.from(SavedQuery.class);
		cQuery.select(savedQueryRoot);
		cQuery.where(builder.equal(savedQueryRoot.get("createdBy"), createdBy));
		return entityManager.createQuery(cQuery).getResultList() ;
	}

	@Override
	public SavedQuery getSavedQueryInfo(String queryName) {
		TypedQuery<SavedQuery> savedQuery = entityManager.createQuery("from SavedQuery where queryName = :queryName",SavedQuery.class);
		savedQuery.setParameter("queryName",queryName);
		List<SavedQuery> savedQueryList = savedQuery.getResultList();
		if(savedQueryList.isEmpty()){
			return null;
		}
		return savedQueryList.get(0);
	}
	
	

}
