package com.artha.workbench.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.constant.WBConstants;
import com.artha.workbench.service.AuditTaskService;
import com.artha.workbench.service.AuditTgtColumnService;
import com.artha.workbench.service.DeletedUserService;
import com.artha.workbench.to.AuditTaskTO;
import com.artha.workbench.to.AuditTgtColumnTO;
import com.artha.workbench.to.DeletedUserTO;
import com.guvvala.framework.util.ThreadLocalUtil;

@RestController
@RequestMapping("/api/auditLogManagement")
public class AuditLogManagementController {
	
	@Autowired
	AuditTaskService auditTaskService;
	
	@Autowired
	AuditTgtColumnService auditTgtColumnService;
	
	@Autowired
	DeletedUserService deletedUserService;
	
	@RequestMapping(value = "/auditTaskInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<AuditTaskTO> loadAuditTaskInfo(){
		List<AuditTaskTO> auditTaskInfoList = new ArrayList<AuditTaskTO>();
			if (ThreadLocalUtil.getUser().isSadmin() || ThreadLocalUtil.getUser().isAdmin()) {
			auditTaskInfoList = auditTaskService.getAuditTasks();
		} else {
			auditTaskInfoList = auditTaskService.getAuditTaskByAccessRight(ThreadLocalUtil.getUser().getTaskAccessRights());
		}
		return auditTaskInfoList;
		
	}
	
	@RequestMapping(value = "/showAuditLogDetails/{taskId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<AuditTgtColumnTO> showAuditLogDetails(@PathVariable("taskId") String taskId) {
		List<AuditTgtColumnTO> auditTgtColumnList = new ArrayList<AuditTgtColumnTO>();
		auditTgtColumnList = auditTgtColumnService.getAuditTgtColumns(taskId);
				if (!(ThreadLocalUtil.getUser().isSadmin()|| ThreadLocalUtil.getUser().isAdmin())) {
			List<AuditTgtColumnTO> auditTgtColumns = new ArrayList<AuditTgtColumnTO>();
			String taskKey = getKeyforTaskId(taskId);
			for (AuditTgtColumnTO tgtColumn : auditTgtColumnList) {
				String key = taskKey.concat(WBConstants.UNDER_SCORE).concat(tgtColumn.getDefColName());
				if (ThreadLocalUtil.getUser().getColAccessRights().containsKey(key)) {
					Integer writeMode = ThreadLocalUtil.getUser().getColAccessRights().get(key);
					if (writeMode == 1 || writeMode == 0) {
						auditTgtColumns.add(tgtColumn);
					}
				}
			}
			return auditTgtColumns;
		} else {
			return auditTgtColumnList;
		}
		
	}
	private String getKeyforTaskId(String tempTaskId) {
		StringBuilder key = new StringBuilder();
		String[] parts = tempTaskId.split(WBConstants.UNDER_SCORE);
		String[] firstTwoEntries = Arrays.copyOf(parts, 2);
		boolean firstTime = true;
		for (String entry : firstTwoEntries) {
			if (firstTime) {
				key.append(entry);
				firstTime = false;
			} else {
				key.append(WBConstants.UNDER_SCORE);
				key.append(entry);
			}
		}
		return key.toString();
	}
	
	@RequestMapping(value = "/fetchDeletedUserList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<DeletedUserTO> fetchDeletedUserList() {
		return deletedUserService.fetchDeletedUserList();
	}


}
