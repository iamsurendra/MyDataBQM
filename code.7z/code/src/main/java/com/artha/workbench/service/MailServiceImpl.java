package com.artha.workbench.service;

import java.util.Date;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service("mailService")
public class MailServiceImpl implements MailService {

	@Autowired
	private JavaMailSender mailSender;

	public void sendMail(String password, String loginname, String email, String fname)
			throws AddressException, MessagingException {

		try {
			// message
			String mailTo = email;
			String message = "<html>";
			message += "<table align='center' cellspacing='30' width='100%' height='100%' style='background-color:#f1f1f1; font-family:Open Sans,Helvetica,Arial,sans-serif; font-size:14px; color:black; line-height:20px'>";
			message += "<tbody>";
			message += "<tr>";
			message += "<td align='center' style='vertical-align:top'>";
			message += "<table width='600' cellspacing='0' cellpadding='0' align='center' style='text-align:left; background-color:#88bd2d'>";
			message += "<tbody>";
			message += "<tr>";
			message += "<td height='5' style='height:5px'></td>";
			message += "</tr>";
			message += "<tr>";
			message += "<td>";
			message += "<table width='100%' cellspacing='0' cellpadding='25' style='background:#ffffff'>";
			message += "<tbody>";
			message += "<tr>";
			message += "Dear  <b><u>" + fname + "</u></b> for your user name <b><u>" + loginname
					+ " </u></b> reset password is<b> <u>" + password;
			message += "  </u></b>. Please login with new password.</td>";
			message += "</tr>";
			message += "</tbody>";
			message += "</table>";
			message += "</td>";
			message += "</tr>";
			message += "<tr>";
			message += "<td>";
			message += "<table width='100%' cellspacing='0' cellpadding='25' style='color:white; font-weight:600'>";
			message += "<tbody>";
			message += "<tr>";
			message += "<td>&nbsp;</td>";
			message += "<td style='text-align:right'>Business Data Workbench</td>";
			message += "</tr>";
			message += "</tbody>";
			message += "</table>";
			message += "</td>";
			message += "</tr>";
			message += "<tr>";
			message += "<td style='background-color:#f1f1f1; padding:10px; font-size:12px; color:#666666'>";
			message += "<table>";
			message += "</table>";
			message += "</td>";
			message += "</tr>";
			message += "</tbody>";
			message += "</table>";
			message += "</td>";
			message += "</tr>";
			message += "</tbody>";
			message += "</table>";
			message += "</html>";
			final String subject = "Business Data Workbench Password for" + " " + loginname;
			sendEmail(message, subject, mailTo);
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}

	public void sendMailToUser(String password, String loginname, String email, String fname)
			throws AddressException, MessagingException {

		try {
			// message
			String mailTo = email;
			String message = "<html>";
			message += "<table align='center' cellspacing='30' width='100%' height='100%' style='background-color:#f1f1f1; font-family:Open Sans,Helvetica,Arial,sans-serif; font-size:14px; color:black; line-height:20px'>";
			message += "<tbody>";
			message += "<tr>";
			message += "<td align='center' style='vertical-align:top'>";
			message += "<table width='600' cellspacing='0' cellpadding='0' align='center' style='text-align:left; background-color:#88bd2d'>";
			message += "<tbody>";
			message += "<tr>";
			message += "<td height='5' style='height:5px'></td>";
			message += "</tr>";
			message += "<tr>";
			message += "<td>";
			message += "<table width='100%' cellspacing='0' cellpadding='25' style='background:#ffffff'>";
			message += "<tbody>";
			message += "<tr>";
			message += "Dear  <b>" + fname
					+ "</b>  <br> Your Business Data Workbench user created successfully.Login name <b><u>" + loginname
					+ ".</b></u><br>You can login with temporary password<b> <u><b>" + password;
			message += "</b></tr>";
			message += "</tbody>";
			message += "</table>";
			message += "</td>";
			message += "</tr>";
			message += "<tr>";
			message += "<td>";
			message += "<table width='100%' cellspacing='0' cellpadding='25' style='color:white; font-weight:600'>";
			message += "<tbody>";
			message += "<tr>";
			message += "<td>&nbsp;</td>";
			message += "<td style='text-align:right'>Business Data Workbench</td>";
			message += "</tr>";
			message += "</tbody>";
			message += "</table>";
			message += "</td>";
			message += "</tr>";
			message += "<tr>";
			message += "<td style='background-color:#f1f1f1; padding:10px; font-size:12px; color:#666666'>";
			message += "<table>";
			message += "</table>";
			message += "</td>";
			message += "</tr>";
			message += "</tbody>";
			message += "</table>";
			message += "</td>";
			message += "</tr>";
			message += "</tbody>";
			message += "</table>";
			message += "</html>";
			final String subject = "Business Data Workbench User Created Successfully";
			sendEmail(message, subject, mailTo);
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}

	public void sendEmail(String message, String subject, String mailTo) {
		try {
			// mail logic

			final String userName = "solutions@thinkartha.com";

			// creates a new e-mail message
			final MimeMessage msg = mailSender.createMimeMessage();

			msg.setFrom(new InternetAddress(userName));
			// add To Reciepients;
			String[] recipientList = mailTo.split(",");
			InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
			int counter = 0;
			for (String recipients : recipientList) {
				recipientAddress[counter] = new InternetAddress(recipients.trim());
				counter++;
			}
			msg.setRecipients(Message.RecipientType.TO, recipientAddress);

			// Add CC Receipients

			String List = "solutions@thinkartha.com,";
			String[] ccList = List.split(",");

			InternetAddress[] ccAddress = new InternetAddress[ccList.length];
			int cccount = 0;
			for (String ccs : ccList) {
				ccAddress[cccount] = new InternetAddress(ccs.trim());
				cccount++;
			}
			msg.addRecipients(Message.RecipientType.CC, ccAddress);
			msg.setSubject(subject);
			msg.setSentDate(new Date());
			// set plain text message
			msg.setContent(message, "text/html");
			// sends the e-mail
			mailSender.send(msg);

		} catch (Throwable th) {
			th.printStackTrace();
		}
	}
}
