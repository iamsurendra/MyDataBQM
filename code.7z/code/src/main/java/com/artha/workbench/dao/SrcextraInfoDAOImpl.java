package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.datahub.SrcextraInfo;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * @author Guvala
 *
 */
@Repository
public class SrcextraInfoDAOImpl extends BaseDAOImpl<SrcextraInfo, String> implements SrcextraInfoDAO {

	public SrcextraInfoDAOImpl() {
		super(SrcextraInfo.class);
	}

	public void deleteAllSrcextraInfo(List<String> srcRecordIds) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SrcextraInfo> query = cb.createQuery(SrcextraInfo.class);
		Root<SrcextraInfo> root = query.from(SrcextraInfo.class);
		query.where(root.get("srcRecordId").in(srcRecordIds));
		deleteAll(this.entityManager.createQuery(query).getResultList());
	}

}
