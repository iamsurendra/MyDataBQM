package com.artha.workbench.models.metastore;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EntityFileValidationRuleVwKey implements Serializable{
	
	

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("efvrid")
		private int efvrid;
	@JsonProperty("dbid")
		private int dbid;
}
