package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.UserPreference;
import com.artha.workbench.models.userConfig.UserPreferencePK;
import com.guvvala.framework.dao.BaseDAOImpl;
@Repository
public class UserPreferenceDAOImpl extends BaseDAOImpl<UserPreference,UserPreferencePK> implements UserPreferenceDAO{

	
		
	public UserPreferenceDAOImpl() {
		super(UserPreference.class);
		
	}

	public List<UserPreference> getUserPreferenceInfo(){
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserPreference> cQuery = builder.createQuery(UserPreference.class);
		Root<UserPreference> root = cQuery.from(UserPreference.class);
		cQuery.select(root);
		return  entityManager.createQuery(cQuery).getResultList();
		
		
	}
	
	public List<UserPreference> getUserPreferenceByUserId(Long userId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserPreference> cQuery = builder.createQuery(UserPreference.class);
		Root<UserPreference> root = cQuery.from(UserPreference.class);
		cQuery.select(root);
		cQuery.where(builder.equal(root.get("userId"), userId));
		return  entityManager.createQuery(cQuery).getResultList();
	}
	
}
