package com.artha.workbench.models.datahub;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/* This is contract POJO Class */
@Entity
@Table(name = "datahub.Srcrecords")
public class Srcrecords implements Serializable {

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "srcrec_id", unique = true, nullable = false)
	private String srcrec_id;

	@Column(name = "task_id")
	private String task_id;

	@Column(name = "source")
	private String source;

	@Column(name = "score")
	private Double score;

	@Column(name = "weights")
	private String weights;

	public String getSrcrec_id() {
		return srcrec_id;
	}

	public void setSrcrec_id(String srcrec_id) {
		this.srcrec_id = srcrec_id;
	}

	public String getTask_id() {
		return task_id;
	}

	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

	public String getWeights() {
		return weights;
	}

	public void setWeights(String weights) {
		this.weights = weights;
	}

	@Override
	public String toString() {
		return "Srcrecords [srcrec_id=" + srcrec_id + ", task_id=" + task_id + ", source=" + source + ", score=" + score
				+ ", weights=" + weights + "]";
	}

}
