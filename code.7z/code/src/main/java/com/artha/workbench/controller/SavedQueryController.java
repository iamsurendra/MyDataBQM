package com.artha.workbench.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.beanParams.TaskBeanParam;
import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.models.userConfig.SavedQuery;
import com.artha.workbench.service.SavedQueryService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@RestController
@RequestMapping("/api/savedQuery")

public class SavedQueryController {

	@Autowired
	SavedQueryService savedQueryService;

	@RequestMapping(value = "/getAllSavedQuery", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SavedQuery> getAllSavedQuerys() {
		return savedQueryService.getAllSavedQuerys();
	}

	@RequestMapping(value = "/deleteSavedQuery/{SavedQueryId}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void deleteQuery(@PathVariable("SavedQueryId") Integer SavedQueryId) {
		savedQueryService.deleteSavedQuery(SavedQueryId);
	}
	
	@RequestMapping(value = "/saveSearchCriteria/{searchCriteriaName}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void saveSearchCriteria(@PathVariable("searchCriteriaName")String searchCriteriaName,@RequestBody TaskBeanParam taskBeanParam) throws JsonProcessingException {
		if (savedQueryService.getSavedQueryInfo(searchCriteriaName) != null) {
			throw new AppException(MessagesEnum.QUERY_NAME_ALREADY_EXISTS);
		}
		String json = AppWebUtils.convertObjectToJson(taskBeanParam);
		savedQueryService.saveSearchCriteria(searchCriteriaName, json);
	}

}
