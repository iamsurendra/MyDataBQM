package com.artha.workbench.to;

public class AuditTgtColumnTO {
	
	private String tgtcol_id;
	
	private String tgtrec_id;
	
	private String defColName;
	
	private String previousValue;
	
	private String presentValue;

	public String getTgtcolId() {
		return tgtcol_id;
	}

	public void setTgtcolId(String tgtcolId) {
		this.tgtcol_id = tgtcolId;
	}

	public String getTgtrecId() {
		return tgtrec_id;
	}

	public void setTgtrecId(String tgtrecId) {
		this.tgtrec_id = tgtrecId;
	}

	public String getDefColName() {
		return defColName;
	}

	public void setDefColName(String defColName) {
		this.defColName = defColName;
	}

	public String getPreviousValue() {
		return previousValue;
	}

	public void setPreviousValue(String previousValue) {
		this.previousValue = previousValue;
	}

	public String getPresentValue() {
		return presentValue;
	}

	public void setPresentValue(String presentValue) {
		this.presentValue = presentValue;
	}
	
	
}


