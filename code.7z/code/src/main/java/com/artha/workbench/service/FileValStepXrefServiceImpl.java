package com.artha.workbench.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.FileValStepXrefDAO;
import com.artha.workbench.dao.FileValStepXrefVwDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.ValidationStepDAO;
import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.metastore.FileValStepVwkey;
import com.artha.workbench.models.metastore.FileValStepXref;
import com.artha.workbench.models.metastore.FileValStepXrefKey;
import com.artha.workbench.models.metastore.FileValStepXrefVw;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("fileValStepXrefService")
public class FileValStepXrefServiceImpl implements FileValStepXrefService {

	@Autowired
	FileValStepXrefDAO fileValStepXrefDAO;

	@Autowired
	FileValStepXrefVwDAO fileValStepXrefVwDAO;

	@Autowired
	ValidationStepDAO validationStepDAO;

	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Transactional(readOnly = true)
	public List<FileValStepXref> getFileValStepXrefList() {
		return fileValStepXrefDAO.findAll();
	}

	@Transactional(readOnly = true)
	public FileValStepXref getFileValStepXref(Integer entityFileTypeID, Integer stepId) {
		return fileValStepXrefDAO.getFileValStepXref(entityFileTypeID, stepId);
	}

	@Transactional
	public void create(FileValStepXref fileValStepXref) {
		fileValStepXrefDAO.create(fileValStepXref);
	}

	@Transactional(readOnly = true)
	public List<FileValStepXrefVw> getFileValStepXrefVwListByReleaseNo(Integer releaseNo) {
		return fileValStepXrefVwDAO.getFileValStepXrefVwListByReleaseNo(releaseNo);
	}

	@Transactional
	public FileValStepXrefVw getPreviousFileValStepXrefVw(FileValStepXrefVw fileValStepXrefVw) throws IOException {
		List<AbstractModel> fvsxlist = new ArrayList<AbstractModel>();
		fvsxlist.add(fileValStepXrefVw);
		List<FileValStepXref> efrclist = getEntityfileValStepXrefList(fvsxlist);
		FileValStepXrefKey fileValStepXrefKey = new FileValStepXrefKey();
		fileValStepXrefKey.setEntityFileTypeID(efrclist.get(0).getEntityFileTypeID());
		fileValStepXrefKey.setStepID(efrclist.get(0).getStepID());
		String fileValStepXrefVwIdJson = AppWebUtils.convertObjectToJson(fileValStepXrefKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(fileValStepXrefVw.getReleaseNo(),
				"FILEVALSTEPXREF", fileValStepXrefVwIdJson);
		FileValStepXrefVw previousFileValStepXrefVw = new FileValStepXrefVw();
		if (releaseArchive != null) {
			previousFileValStepXrefVw = AppWebUtils.convertJsonToObject(FileValStepXrefVw.class,
					releaseArchive.getViewRecData());
		}
		return previousFileValStepXrefVw;

	}

	@Transactional
	public void update(FileValStepXref fileValStepXref, FileValStepXrefVw fileValStepXrefVw, boolean isReleaseChanged)
			throws JsonProcessingException {
		FileValStepXref oldFileValStepXref  = 	getFileValStepXref(fileValStepXref.getEntityFileTypeID(),fileValStepXref.getStepID());
		FileValStepXrefKey fileValStepXrefKey = new FileValStepXrefKey();
		fileValStepXrefKey.setEntityFileTypeID(fileValStepXref.getEntityFileTypeID());
		fileValStepXrefKey.setStepID(fileValStepXref.getStepID());
		checkForCyclicDependency(fileValStepXref);
		if (isReleaseChanged) {
			FileValStepVwkey fileValStepVwkey = new FileValStepVwkey();
			fileValStepVwkey.setFileMask(fileValStepXrefVw.getFileMask());
			fileValStepVwkey.setStepId(fileValStepXrefVw.getStepId());
			FileValStepXrefVw oldEntity = fileValStepXrefVwDAO.findOne(fileValStepVwkey);
			if (oldEntity != null) {
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
				releaseArchiveKey.setReleaseId(fileValStepXrefVw.getReleaseNo());
				releaseArchiveKey.setTableName("FileValStepXref");
				releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(fileValStepXrefKey));

				ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
				if (releaseArchive != null) {
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldFileValStepXref));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(fileValStepVwkey));
					releaseArchiveDAO.update(releaseArchive);
				} else {
					releaseArchive = new ReleaseArchive();
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldFileValStepXref));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(fileValStepVwkey));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				}
			}
			fileValStepXrefDAO.update(fileValStepXref);
		}

	}
	
	private void checkForCyclicDependency(FileValStepXref fileValStepXref) throws JsonProcessingException	{
		FileValStepXrefKey fileValStepXrefKey = new FileValStepXrefKey();
		fileValStepXrefKey.setEntityFileTypeID(fileValStepXref.getEntityFileTypeID());
		fileValStepXrefKey.setStepID(fileValStepXref.getStepID());
		String jsonId = AppWebUtils.convertObjectToJson(fileValStepXrefKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(fileValStepXref.getReleaseNo(), "FileValStepXref", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	public List<FileValStepXref> getEntityfileValStepXrefList(List<AbstractModel> entitytypes) {
		List<FileValStepXref> efrclist = new ArrayList<FileValStepXref>();
		HashMap<String, Integer> stepidmap = validationStepDAO.loadStepId();
		FileValStepXref efrs = null;
		FileValStepXrefVw efrsdb = null;
		for (int i = 0; i < entitytypes.size(); i++) {
			efrs = new FileValStepXref();
			efrsdb = new FileValStepXrefVw();
			efrsdb = (FileValStepXrefVw) entitytypes.get(i);
			efrs.setStepOrder(efrsdb.getStepOrder());
			if (efrsdb.getEntityName() != null) {
				if (efrsdb.getEntityName().equalsIgnoreCase("Default")) {
					efrs.setEntityID(-1);
				} else if (efrsdb.getEntityName().equalsIgnoreCase("Default1")) {
					efrs.setEntityID(-2);
				} else {
					efrs.setEntityID(2);
				}
			}
			if (efrsdb.getFileType() != null) {
				if (efrsdb.getFileType().equalsIgnoreCase("Default")) {
					efrs.setFileTypeID(-1);
				} else if (efrsdb.getFileType().equalsIgnoreCase("Default1")) {
					efrs.setFileTypeID(-2);
				} else {
					efrs.setFileTypeID(10);
				}

			}
			if (efrsdb.getFileMask() != null) {
				if (efrsdb.getFileMask().equalsIgnoreCase("Default")) {
					efrs.setEntityFileTypeID(-1);

				} else if (efrsdb.getFileMask().equalsIgnoreCase("Default1")) {
					efrs.setEntityFileTypeID(-2);

				} else {
					efrs.setEntityFileTypeID(133);
				}

			}
			if (stepidmap != null && stepidmap.containsKey(efrsdb.getStepName())) {
				efrs.setStepID(stepidmap.get(efrsdb.getStepName()));
			}
			efrs.setReleaseNo(efrsdb.getReleaseNo());
			efrclist.add(efrs);
		}
		return efrclist;
	}

	@Transactional
	public void saveFileValStepXref(List<FileValStepXref> entitytypes) {
		fileValStepXrefDAO.saveFileValStepXref(entitytypes);
	}

	@Transactional
	public List<FileValStepXrefVw> getFileValStepXrefVwList() {
		return fileValStepXrefVwDAO.findAll();
	}

	@Transactional
	public List<FileValStepXref> getEntityfileValStepXrefTempList() {
		return fileValStepXrefDAO.findAll();
	}

	@Transactional(readOnly = true)
	public List<FileValStepXref> getFileValStepXrefListByReleaseNo(Integer releaseNo) {
		return fileValStepXrefDAO.getFileValStepXrefListByReleaseNo(releaseNo);
	}

	@Transactional(readOnly = true)
	public List<Integer> getAllFileValStepXrefReleaseIds(Integer selectedReleaseId) {
		return fileValStepXrefDAO.getAllFileValStepXrefReleaseIds(selectedReleaseId);
	}

}
