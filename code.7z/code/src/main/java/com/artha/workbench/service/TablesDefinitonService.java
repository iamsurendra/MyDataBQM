package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.tableDefiniton.BRWTableDefinition;

public interface TablesDefinitonService {
	
	public List<BRWTableDefinition> getAllTableDefinitions();

}
