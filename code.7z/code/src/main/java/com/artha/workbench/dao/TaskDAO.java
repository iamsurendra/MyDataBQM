package com.artha.workbench.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.artha.workbench.beanParams.TaskBeanParam;
import com.artha.workbench.models.datahub.Task;
import com.artha.workbench.models.datahub.TaskType;
import com.guvvala.framework.dao.BaseDAO;
import com.guvvala.framework.filter.BaseFilter;

public interface TaskDAO extends BaseDAO<Task, String> {
	public void deleteAll();

	public List<Task> getSearchlist(String taskStatus, String Betweenrec, String andrec);

	Task getTaskById(String taskId);

	public void updatePendingTasks(String taskid,String userName, String status);

	public List<Task> getNorSearchlist(String colType, String condition, String colvalue,boolean adminFlag,List<String> taskAccessRights);

	public void changeStatus(String taskid, String statusstr);

	public void updateresolvedtask(String taskid,String userName);

	public List<Task> getNorSearchlist(String colType, String condition, Date date,boolean adminFlag,List<String> taskAccessRights);

	public List<Task> getChartSearchlist(String taskStatus,boolean adminflag,List<String> taskAccessRights);

	public List<Task> getTasklist();

	public List<TaskType> getTaskTypelist();

	public List<String> getSearchlist(TaskBeanParam taskBeanParam, String fileType, String partner, Map<String, String> columnNames, String entityFileTypeId);
	
	public List<String> getNormaluserSearchlist(TaskBeanParam taskBeanParam, String fileType, String partner, Map<String, String> columnNames,String entityFileTypeId, List<String> taskAccessRights);

	List<Task> getTaskByAccessRight(List<String> taskAccessRights);

	List<Task> getAllTasks(List<String> taskIds);
	
	public void deleteTasksByIds(List<String> taskIds);
	
	public List<String> getTaskColumnsData(String columnName);
	
	List<Integer> getLockedTaskRevisionIds(String taskId);
	
	String getPreviousTaskStatus(List<Integer> revIds,String taskId);
	
	Long getTaskStatusCount(String status);
	
	public List<Task> getNorSearchlist(Set<BaseFilter> userFilters,Integer maxRows);
	
	public List<Task> getNorSearchlist(Set<BaseFilter> userFilters,List<String> taskAccessRights,Integer maxRows);
	
	public List<Task> getTaskListByIds(List<String> taskIds);
	 
	public Long getNorSearchlist(Set<BaseFilter> userFilters);
	
	public Integer getNorSearchlist(Set<BaseFilter> userFilters, List<String> taskAccessRights);
	
	public Integer getTaskIdSeq();

}
