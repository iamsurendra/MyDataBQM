package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.DataStewardGroups;
import com.artha.workbench.models.metastore.DataStewardGroupsKey;
import com.guvvala.framework.dao.BaseDAO;

public interface DataStewardGroupDAO extends BaseDAO<DataStewardGroups, DataStewardGroupsKey> {

	public void saveDataStewardGroups(List<DataStewardGroups> dataStewardGroups);

	public void deleteDataStewardGroups();

	public List<DataStewardGroups> getDataStewardGroupsByReleaseNo(Integer releaseNo);
	
	public List<Integer> getAllDatastewardgroupsReleaseIds(Integer selectedReleaseId);

}
