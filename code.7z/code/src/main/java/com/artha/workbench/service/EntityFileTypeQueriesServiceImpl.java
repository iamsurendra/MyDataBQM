package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileTypeQueriesDAO;
import com.artha.workbench.dao.EntityFileTypeQueriesVwDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.metastore.EntityFileTypeQueries;
import com.artha.workbench.models.metastore.EntityFileTypeQueriesKey;
import com.artha.workbench.models.metastore.EntityFileTypeQueriesVw;
import com.artha.workbench.models.metastore.EntityFileTypeQueriesVwKey;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("entityFileTypeQueriesService")
public class EntityFileTypeQueriesServiceImpl implements EntityFileTypeQueriesService{
	
	@Autowired
	EntityFileTypeQueriesDAO entityFileTypeQueriesDAO;
	
	@Autowired
	EntityFileTypeQueriesVwDAO entityFileTypeQueriesVwDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;
	
	@Transactional(readOnly = true)
	public List<EntityFileTypeQueries> getEntityFileTypeQueriesList(){
		return  entityFileTypeQueriesDAO.findAll();
	}

	@Transactional(readOnly = true)
	public List<EntityFileTypeQueriesVw> getEntityFileTypeQueriesVwList(){
		return entityFileTypeQueriesVwDAO.findAll();
	}
	
	
	@Transactional
	public void create(EntityFileTypeQueriesVw entityFileTypeQueriesVw){
		EntityFileTypeQueries entityFileTypeQueries = new EntityFileTypeQueries();
		EntityFileTypeQueriesKey entityFileTypeQueriesKey = new EntityFileTypeQueriesKey();
		entityFileTypeQueriesKey.setStepID(entityFileTypeQueriesVw.getStepID());
		entityFileTypeQueriesKey.setSeqOrder(entityFileTypeQueriesVw.getSeqOrder());
		entityFileTypeQueriesKey.setEntityFileTypeID(entityFileTypeQueriesVw.getEntityFileTypeID());
		entityFileTypeQueries.setEntityFileTypeQueriesKey(entityFileTypeQueriesKey);
		loadEntityFileTypeQueries(entityFileTypeQueries, entityFileTypeQueriesVw);
		entityFileTypeQueriesDAO.create(entityFileTypeQueries);
	}

	private void loadEntityFileTypeQueries(EntityFileTypeQueries entityFileTypeQueries,
			EntityFileTypeQueriesVw entityFileTypeQueriesVw) {
		// TODO Auto-generated method stub
		entityFileTypeQueries.setActive(entityFileTypeQueriesVw.getActive());
		entityFileTypeQueries.setQueryText(entityFileTypeQueriesVw.getQueryText());
		entityFileTypeQueries.setReleaseNo(entityFileTypeQueriesVw.getReleaseNo());
		entityFileTypeQueries.setEffectiveDate(entityFileTypeQueriesVw.getEffectiveDate());
	}
	
	@Transactional
	public void update(EntityFileTypeQueriesVw entityFileTypeQueriesVw,boolean isReleaseChanged) throws JsonProcessingException {
		EntityFileTypeQueriesKey entityFileTypeQueriesKey = new EntityFileTypeQueriesKey();
		entityFileTypeQueriesKey.setEntityFileTypeID(entityFileTypeQueriesVw.getEntityFileTypeID());  
		entityFileTypeQueriesKey.setSeqOrder(entityFileTypeQueriesVw.getSeqOrder());
		entityFileTypeQueriesKey.setStepID(entityFileTypeQueriesVw.getStepID());
		checkForCyclicDependency(entityFileTypeQueriesVw);
		EntityFileTypeQueries entityFileTypeQueries = entityFileTypeQueriesDAO.findOne(entityFileTypeQueriesKey);
		if (isReleaseChanged) {
			EntityFileTypeQueriesVwKey entityFileTypeQueriesVwKey = new EntityFileTypeQueriesVwKey();
			entityFileTypeQueriesVwKey.setEntityFileTypeID(entityFileTypeQueriesVw.getEntityFileTypeID());
			entityFileTypeQueriesVwKey.setEntityName(entityFileTypeQueriesVw.getEntityName());
			entityFileTypeQueriesVwKey.setFileMask(entityFileTypeQueriesVw.getFileMask());
			entityFileTypeQueriesVwKey.setHsFileType(entityFileTypeQueriesVw.getHsFileType());
			entityFileTypeQueriesVwKey.setStepID(entityFileTypeQueriesVw.getStepID());
			entityFileTypeQueriesVwKey.setSeqOrder(entityFileTypeQueriesVw.getSeqOrder());
			EntityFileTypeQueriesVw oldEntity = entityFileTypeQueriesVwDAO.findOne(entityFileTypeQueriesVwKey);
			if(oldEntity!=null){
			    ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			    releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
			    releaseArchiveKey.setReleaseId(entityFileTypeQueriesVw.getReleaseNo());
			    releaseArchiveKey.setTableName("ENTITYFILETYPEQUERIES");
			    releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityFileTypeQueries.getEntityFileTypeQueriesKey()));
			    ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			    if(releaseArchive!=null){
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileTypeQueries));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileTypeQueriesVwKey));
					releaseArchiveDAO.update(releaseArchive);
				}else{
					releaseArchive = new ReleaseArchive();
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileTypeQueries));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileTypeQueriesVwKey));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				}
			}
		}
		if(entityFileTypeQueries!=null){
			entityFileTypeQueries.setActive(entityFileTypeQueriesVw.getActive());
			entityFileTypeQueries.setReleaseNo(entityFileTypeQueriesVw.getReleaseNo());
			entityFileTypeQueries.setQueryText(entityFileTypeQueriesVw.getQueryText());
			entityFileTypeQueries.setEffectiveDate(entityFileTypeQueriesVw.getEffectiveDate());
			entityFileTypeQueriesDAO.update(entityFileTypeQueries);
		}
	}
	
	private void checkForCyclicDependency(EntityFileTypeQueriesVw entityFileTypeQueriesVw) throws JsonProcessingException	{
		EntityFileTypeQueriesKey entityFileTypeQueriesKey = new EntityFileTypeQueriesKey();
		entityFileTypeQueriesKey.setEntityFileTypeID(entityFileTypeQueriesVw.getEntityFileTypeID());  
		entityFileTypeQueriesKey.setSeqOrder(entityFileTypeQueriesVw.getSeqOrder());
		entityFileTypeQueriesKey.setStepID(entityFileTypeQueriesVw.getStepID());
		String jsonId = AppWebUtils.convertObjectToJson(entityFileTypeQueriesKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(entityFileTypeQueriesVw.getReleaseNo(), "ENTITYFILETYPEQUERIES", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	
	@Transactional
	public List<EntityFileTypeQueriesVw> getEntityFileTypeQueriesVwListByReleaseNo(Integer releaseNo) {
		return entityFileTypeQueriesVwDAO.getEntityFileTypeQueriesVwListByReleaseNo(releaseNo);
	}
	
	
	@Transactional
	public List<EntityFileTypeQueries> getEntityFileTypeQueriesListByReleaseNo(Integer releaseNo) {
		return entityFileTypeQueriesDAO.getEntityFileTypeQueriesListByReleaseNo(releaseNo);
	}

	@Override
	public EntityFileTypeQueriesVw getPreviousEntityFileTypeQueriesVw(EntityFileTypeQueriesVw entityFileTypeQueriesVw)
			throws IOException {
		EntityFileTypeQueriesKey entityFileTypeQueriesKey = new EntityFileTypeQueriesKey();
		entityFileTypeQueriesKey.setEntityFileTypeID(entityFileTypeQueriesVw.getEntityFileTypeID());
		entityFileTypeQueriesKey.setSeqOrder(entityFileTypeQueriesVw.getSeqOrder());
		entityFileTypeQueriesKey.setStepID(entityFileTypeQueriesVw.getStepID());
		String entityFileTypeQueriesVwJson = AppWebUtils.convertObjectToJson(entityFileTypeQueriesKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(entityFileTypeQueriesVw.getReleaseNo(), "ENTITYFILETYPEQUERIES", entityFileTypeQueriesVwJson);
		EntityFileTypeQueriesVw previousEntityFileTypeQueriesVw = new EntityFileTypeQueriesVw();
		if(releaseArchive!=null){
			previousEntityFileTypeQueriesVw = AppWebUtils.convertJsonToObject(EntityFileTypeQueriesVw.class, releaseArchive.getViewRecData());
		}
		return previousEntityFileTypeQueriesVw;
	}
	
	@Transactional
	public EntityFileTypeQueries getEntityFileTypeQueries(EntityFileTypeQueriesVw entityFileTypeQueriesVw) {
		EntityFileTypeQueriesKey entityFileTypeQueriesKey = new EntityFileTypeQueriesKey();
		entityFileTypeQueriesKey.setEntityFileTypeID(entityFileTypeQueriesVw.getEntityFileTypeID());
		entityFileTypeQueriesKey.setSeqOrder(entityFileTypeQueriesVw.getSeqOrder());
		entityFileTypeQueriesKey.setStepID(entityFileTypeQueriesVw.getStepID());
		EntityFileTypeQueries entityFileTypeQueries = entityFileTypeQueriesDAO.findOne(entityFileTypeQueriesKey);
		return entityFileTypeQueries;
	}
}
