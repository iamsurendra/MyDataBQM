package com.artha.workbench.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.core.AuditTaskInfo_VW;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class AuditTaskDAOImpl extends BaseDAOImpl<AuditTaskInfo_VW, Integer> implements AuditTaskDAO {

	public AuditTaskDAOImpl() {
		super(AuditTaskInfo_VW.class);

	}

	public List<AuditTaskInfo_VW> getAuditTaskList() {
		List<AuditTaskInfo_VW> taskRevList = new ArrayList<AuditTaskInfo_VW>();
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<AuditTaskInfo_VW> query = cb.createQuery(AuditTaskInfo_VW.class);
		Root<AuditTaskInfo_VW> c = query.from(AuditTaskInfo_VW.class);
		query.select(c);
		query.orderBy(cb.desc(c.get("revId")));
		taskRevList = entityManager.createQuery(query).getResultList();
		return taskRevList;
	}

	@Override
	public List<AuditTaskInfo_VW> getAuditTaskByAccessRight(List<String> taskAccessRights) {
		List<AuditTaskInfo_VW> taskdet = new ArrayList<AuditTaskInfo_VW>();
		for (String accessKey : taskAccessRights) {
			if (null != accessKey) {
				Query query = entityManager.createNamedQuery("FetchAuditTaskByRights");
				query.setParameter(1, accessKey + "%");
				List<AuditTaskInfo_VW> tempTaskList = query.getResultList();
				taskdet.addAll(tempTaskList);
			}
		}

		return taskdet;
	}

}
