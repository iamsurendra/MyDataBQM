package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "metastore.SourceToServiceCriteria")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name = "sourceToServiceCriteria")
public class SourceToServiceCriteria extends AbstractModel {


	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonProperty("Key")
	private SourceToServiceCriteriaKey sourceToServiceCriteriaKey;

	@Column(name = "SourceEntityFileTypeID",insertable=false,updatable=false)
	@JsonIgnore
	private Integer sourceEntityFileTypeID;
	
	@Column(name = "WebServiceID",insertable=false,updatable=false)
	@JsonIgnore
	private Integer webServiceID;
	
	@JsonProperty("Criteria")
	private String criteria;
	
	@JsonProperty("SeqOrder")
	private  Integer seqOrder;
	
	@JsonProperty("Active")
	private  String active;

	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date effectiveDate;
	
	@JsonProperty("ReleaseNum")
	private  Integer releaseNum;
	
	// Getters & Setters

    @XmlTransient
	public Integer getSourceEntityFileTypeID() {
		return sourceEntityFileTypeID;
	}

	public void setSourceEntityFileTypeID(Integer sourceEntityFileTypeID) {
		this.sourceEntityFileTypeID = sourceEntityFileTypeID;
	}

	@XmlTransient
	public Integer getWebServiceID() {
		return webServiceID;
	}

	public void setWebServiceID(Integer webServiceID) {
		this.webServiceID = webServiceID;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	

	
	public Integer getSeqOrder() {
		return seqOrder;
	}

	public void setSeqOrder(Integer seqOrder) {
		this.seqOrder = seqOrder;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	
	public Integer getReleaseNum() {
		return releaseNum;
	}

	public void setReleaseNum(Integer releaseNum) {
		this.releaseNum = releaseNum;
	}

	public SourceToServiceCriteriaKey getSourceToServiceCriteriaKey() {
		return sourceToServiceCriteriaKey;
	}

	public void setSourceToServiceCriteriaKey(SourceToServiceCriteriaKey sourceToServiceCriteriaKey) {
		this.sourceToServiceCriteriaKey = sourceToServiceCriteriaKey;
	}
	
	
}
