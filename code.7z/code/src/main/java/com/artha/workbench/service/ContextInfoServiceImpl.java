package com.artha.workbench.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.ContextInfoDAO;
import com.artha.workbench.models.userConfig.ContextInfo;
import com.guvvala.framework.util.DataSourceRouting;

@Service("contextInfoService")
public class ContextInfoServiceImpl implements ContextInfoService {

	@Autowired
	ContextInfoDAO contextInfoDAO;

	//TODO need to set @autowired
	protected DataSourceRouting routing = new DataSourceRouting();

	@Override
	public List<ContextInfo> getContexInfoList() {
		return contextInfoDAO.findAll();
	}

	@Transactional(transactionManager = "configTM")
	public void createContextInfo(ContextInfo contexInfo) {
		contextInfoDAO.create(contexInfo);
	}

	@Transactional(transactionManager = "configTM")
	public void update(ContextInfo contexInfo) {
		contextInfoDAO.update(contexInfo);
	}

	public List<ContextInfo> findAllSchemaNames() {
		return contextInfoDAO.findAllSchemaNames();
	}

	public boolean duplicateContext(ContextInfo contextInfo) {
		return contextInfoDAO.duplicateContext(contextInfo);
	}

	public ContextInfo DefaultSchema() {
		return contextInfoDAO.DefaultSchema();
	}

}
