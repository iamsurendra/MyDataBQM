package com.artha.workbench.controller;

import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.models.userConfig.User;
import com.artha.workbench.service.MailService;
import com.artha.workbench.service.UserService;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.PasswordGenerator;

@RestController
@RequestMapping("/login")

public class LoginController {
	@Autowired
	UserService userService;

	@Autowired
	private MailService mailService;

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
	public void  forgotPassword(@RequestBody Map<String, Object> userDetails) throws AddressException, MessagingException {
		String userEmail = (String) userDetails.get("userEmail");
		String userName = (String) userDetails.get("userName");{
		if (StringUtils.isEmpty(userName)) {
			throw new AppException(MessagesEnum.PLEASE_ENTER_USERNAME);
		}
		if (StringUtils.isEmpty(userEmail)) {
			throw new AppException(MessagesEnum.PLEASE_ENTER_EMAIL_TO_GET_PASSWORD);
		}
		User validUser = userService.getUser(userName);
		if (validUser != null) {
			if (validUser.getUserEmail().equalsIgnoreCase((userEmail.trim()))) {
				String password = String.valueOf(PasswordGenerator.generatePassword());
				
				User user = userService.forgotPassword(validUser, password);
				if (user != null) {
					mailService.sendMail(password, user.getUserName(), user.getUserEmail(), user.getFirstName());
					
				}
			} else {
				throw new AppException(MessagesEnum.INVALIDMAIL);
			}
		} else {
			throw new AppException(MessagesEnum.USER_NAME_IS_NOT_REGISTERED);
		}
	}
	}
}
