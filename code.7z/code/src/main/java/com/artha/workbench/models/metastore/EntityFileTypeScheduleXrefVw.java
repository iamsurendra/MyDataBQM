package com.artha.workbench.models.metastore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;


@Entity
@Table(name = "metastore.EntityFileTypeScheduleXref_v")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
public class EntityFileTypeScheduleXrefVw extends AbstractModel {
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue
	@JsonProperty("EntityFileTypeSchedID")
	private Integer EntityFileTypeSchedID;
	
	@JsonProperty("entityname")
	private String EntityName;
	
	@JsonProperty("entityfiletypeid")
	private Integer Entityfiletypeid;
	
	@JsonProperty("hsfiletype")
	private String HSFileType;
	
	@JsonProperty("filemask")
	private String FileMask;
	
	@JsonProperty("ScheduleFequencyType")
	private String ScheduleFequencyType;
	
	@JsonProperty("SchFrequencyValue")
	private Integer SchFrequencyValue;
	
	@JsonProperty("ScheduleOffsetType")
	private String ScheduleOffsetType;
	
	@JsonProperty("ScheduleOffsetValue")
	private Integer ScheduleOffsetValue;
	
	@JsonProperty("FileDirection")
	private String FileDirection;
	
	@JsonProperty("Active")
	private String Active;
	
	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Transient
	@JsonIgnore
	private boolean addMode;
	
	
	@Transient
	@JsonIgnore
	private Integer entityId;
	
	
	@Transient
	@JsonIgnore	
	private Integer fileTypeId;
	
	
	
	public EntityFileTypeScheduleXrefVw() {
		
	}
	
	public EntityFileTypeScheduleXrefVw(boolean addMode,Integer releaseNo) {
		this.addMode = addMode;
		this.releaseNo = releaseNo;
	}

	public Integer getEntityFileTypeSchedID() {
		return EntityFileTypeSchedID;
	}
	
	public void setEntityFileTypeSchedID(Integer entityFileTypeSchedID) {
		EntityFileTypeSchedID = entityFileTypeSchedID;
	}
	
	public String getEntityName() {
		return EntityName;
	}
	
	public void setEntityName(String entityName) {
		EntityName = entityName;
	}
	
	public String getHSFileType() {
		return HSFileType;
	}
	
	public void setHSFileType(String hSFileType) {
		HSFileType = hSFileType;
	}
	
	public String getFileMask() {
		return FileMask;
	}
	
	public void setFileMask(String fileMask) {
		FileMask = fileMask;
	}
	
	public String getScheduleFequencyType() {
		return ScheduleFequencyType;
	}
	
	public void setScheduleFequencyType(String scheduleFequencyType) {
		ScheduleFequencyType = scheduleFequencyType;
	}
	
	public Integer getSchFrequencyValue() {
		return SchFrequencyValue;
	}
	
	public void setSchFrequencyValue(Integer schFrequencyValue) {
		SchFrequencyValue = schFrequencyValue;
	}
	
	public String getScheduleOffsetType() {
		return ScheduleOffsetType;
	}
	
	public void setScheduleOffsetType(String scheduleOffsetType) {
		ScheduleOffsetType = scheduleOffsetType;
	}
	
	public Integer getScheduleOffsetValue() {
		return ScheduleOffsetValue;
	}
	
	public void setScheduleOffsetValue(Integer scheduleOffsetValue) {
		ScheduleOffsetValue = scheduleOffsetValue;
	}
	
	public String getFileDirection() {
		return FileDirection;
	}
	
	public void setFileDirection(String fileDirection) {
		FileDirection = fileDirection;
	}
	
	public String getActive() {
		return Active;
	}
	
	public void setActive(String active) {
		Active = active;
	}
	
	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public Integer getEntityfiletypeid() {
		return Entityfiletypeid;
	}

	public void setEntityfiletypeid(Integer entityfiletypeid) {
		Entityfiletypeid = entityfiletypeid;
	}

	public Integer getEntityId() {
		return entityId;
	}

	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}

	public Integer getFileTypeId() {
		return fileTypeId;
	}

	public void setFileTypeId(Integer fileTypeId) {
		this.fileTypeId = fileTypeId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}
	
	
	
	
}
