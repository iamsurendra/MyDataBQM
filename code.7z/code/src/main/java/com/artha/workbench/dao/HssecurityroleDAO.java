package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.Hssecurityrole;
import com.artha.workbench.models.userConfig.HssecurityrolePK;
import com.guvvala.framework.dao.BaseDAO;

public interface HssecurityroleDAO extends BaseDAO<Hssecurityrole, HssecurityrolePK> {

	public List<Long> findPartnerByRoleID(Long roleId);

	public List<Long> findFileTypeByPartnerID(Long partnerID);

	public List<Long> findFileTypeByPartnerIDRoleId(Long partnerID, Long roleId);

	public List<Hssecurityrole> findColumnByPartnerIdFileTypeID(Long partnerTypeId, Long fileTypeid,Long roleId);
	
	public List<Hssecurityrole> findAllByRoleID(Long roleId);
	
	public List<Long> findPartnerIdByRoleID(List<Long> roleIds);
	
	public List<Long> findEntityFileTypeId(Long partnerID,List<Long> roleId);

	int deleteColumnsByPartnerIdFileTypeID(List<Long> partnerTypeIds, List<Long> entityFileTypeIds, Long roleId);

	int findColumnByPartnerIdFileTypeID(List<Long> partnerTypeIds, List<Long> entityFileTypeIds, Long roleId);

	List<Hssecurityrole> findHssecurityroleByPartnerIdRoleID(Long partnerTypeId, Long roleId);
}
