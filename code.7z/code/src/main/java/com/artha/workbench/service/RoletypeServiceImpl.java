package com.artha.workbench.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.GroupRolesDAO;
import com.artha.workbench.dao.RoleFunctionsDAO;
import com.artha.workbench.dao.RoleTypeDAO;
import com.artha.workbench.dao.RolesDAO;
import com.artha.workbench.models.config.RoleType;
import com.artha.workbench.models.userConfig.GroupRoles;
import com.artha.workbench.models.userConfig.RoleFunctions;
import com.artha.workbench.models.userConfig.Roles;


@Service("roleTypeService")
public class RoletypeServiceImpl implements RoleTypeService {

	@Autowired
	RoleTypeDAO roletypeDAO;
	
	@Autowired
	RolesDAO rolesDAO;
	
	@Autowired
	GroupRolesDAO groupRolesDAO;
	
	@Autowired
	RoleFunctionsDAO roleFunctionsDAO;
	
	
	

	@Transactional(transactionManager = "configTM")
	public HashMap<Integer, String> loadlogintypeid() {

		return roletypeDAO.loadlogintypeid();
	}

	@Transactional(readOnly = true, transactionManager = "configTM")
	public List<RoleType> getRoleTypeList() {
		return roletypeDAO.findAll();
	}

	@Transactional(readOnly = true, transactionManager = "configTM")
	public List<RoleType> getRoleDetails() {
		return roletypeDAO.getRoleDetails();
	}

	@Transactional(transactionManager = "configTM")
	public void create(RoleType roleType) {
		roletypeDAO.create(roleType);
	}

	@Transactional(transactionManager = "configTM")
	public int getMaxRoleid() {
		return roletypeDAO.getMaxRoleid();
	}

	@Transactional(transactionManager = "configTM")
	public String checkRoleExist(String lname) {
		return roletypeDAO.checkRoleExist(lname);
	}
	@Transactional()
	public List<Roles> getUserRoles()
	{
		return rolesDAO.findAll();
	}
	@Transactional()
	public List<GroupRoles> loadRoals(int groupid)
	{
		return groupRolesDAO.getGroupRolesList(groupid);
	}
	
	public List<Integer> getGroupRoles(Integer groupId) {
		return groupRolesDAO.getGroupRoles(groupId);
	}
	@Transactional()
	public List<RoleFunctions> getRolefunctions()
	{
		return roleFunctionsDAO.findAll();
	}
	
	public List<RoleFunctions> getRoleFunctionsById(List<Integer> roleIds)
	{
		return roleFunctionsDAO.getRoleFunctionsById(roleIds);
	}
	public List<String> getRoleNamesById(List<Long> roleIds){
		//TODO need verify.
		//return rolesDAO.getRoleNamesById(roleIds);
		return null;
	}
}