package com.artha.workbench.models.userConfig;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "userconfig.grouproles")
@IdClass(GroupRolesKey.class)
public class GroupRoles implements Serializable {

	public Integer getGroupid() {
		return groupid;
	}

	public void setGroupid(Integer groupid) {
		this.groupid = groupid;
	}

	public Integer getRoleid() {
		return roleid;
	}

	public void setRoleid(Integer roleid) {
		this.roleid = roleid;
	}

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "GROUP_ID", unique = true)
	private Integer groupid;
	
	@Column(name = "ROLE_ID", unique = true)
	private Integer roleid;
	
}
