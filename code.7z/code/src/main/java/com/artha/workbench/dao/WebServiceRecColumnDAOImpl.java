package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.WebServiceRecColumn;
import com.artha.workbench.models.metastore.WebServiceRecColumnKey;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class WebServiceRecColumnDAOImpl extends BaseDAOImpl<WebServiceRecColumn, WebServiceRecColumnKey>implements WebServiceRecColumnDAO{

	public WebServiceRecColumnDAOImpl() {
		super(WebServiceRecColumn.class);
		// TODO Auto-generated constructor stub
	}
	

	@Override
	public List<Integer> getWebServiceIds() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<WebServiceRecColumn> root = query.from(WebServiceRecColumn.class);
		query.select(root.<Integer> get("webServiceID")).distinct(true);

		return this.entityManager.createQuery(query).getResultList();

	}
	@Override
	public List<Integer> getTargetColumnIds(Integer webServiceId) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<WebServiceRecColumn> root = query.from(WebServiceRecColumn.class);
		query.select(root.<Integer> get("columnID")).distinct(true);
		query.where(cb.equal(root.get("webServiceID"), webServiceId));;
		return this.entityManager.createQuery(query).getResultList();

	}
	
	
	@Override
	public List<WebServiceRecColumn> getWebServiceRecColumnListByReleaseNo(Integer releaseNo){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<WebServiceRecColumn> query = cb.createQuery(WebServiceRecColumn.class);
		Root<WebServiceRecColumn> root = query.from(WebServiceRecColumn.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNum"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	

	@Override
	public List<WebServiceRecColumn> getWebServiceRecColumnList(Set<Integer> webServiceIds, Set<Integer> colIds, Integer selectedReleaseNumber) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<WebServiceRecColumn> query = cb.createQuery(WebServiceRecColumn.class);
		Root<WebServiceRecColumn> root = query.from(WebServiceRecColumn.class);
		query.select(root).distinct(true);
		query.where(cb.and(cb.in(root.get("webServiceID")).value(webServiceIds),cb.in(root.get("columnID")).value(colIds),
				cb.notEqual(root.get("releaseNum"), selectedReleaseNumber)));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllWebServiceRecColReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select releaseNum from WebServiceRecColumn where releaseNum !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}


}
