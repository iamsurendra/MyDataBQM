package com.artha.workbench.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.guvvala.framework.dao.BaseDAO;

public interface ReleaseArchiveDAO extends BaseDAO<ReleaseArchive, ReleaseArchiveKey>{
	
	ReleaseArchive getReleaseArchive(Integer releaseId, String tableName, String tableRecId);
	
	List<Integer> getArchiveReleaseIds(Integer releaseId);
	
	List<Integer> getArchiveReleaseInfo(Integer releaseId,String tableName,List<String> primaryKeys);
	
	List<String> getReleaseArchiveRecData(Integer releaseId, String tableName);
	
	List<String> getReleaseArchiveViewRecData(Integer releaseId, String tableName);
	
	List<Integer> getArchiveTableReleaseInfo(Integer releaseId,String tableName,List<String> primaryKeys);
	
	Set<Integer> getBaseReleases(String parametars);
	
	ReleaseArchive getReleaseArchiveByViewPK(Integer releaseId, String tableName, String viewRecId);

	Map<String,Integer> getBaseReleasesAndPksMap(String parametars);
	
	ReleaseArchive getReleaseArchiveByArchiveId(Integer releaseId, String tableName, String tableRecId);
	
	List<String> getTablesListInArchiveByReleaseNo(Integer releaseId);
}
