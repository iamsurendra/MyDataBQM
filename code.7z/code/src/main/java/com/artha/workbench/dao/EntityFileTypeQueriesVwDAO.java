package com.artha.workbench.dao;


import java.util.List;

import com.artha.workbench.models.metastore.EntityFileTypeQueriesVw;
import com.artha.workbench.models.metastore.EntityFileTypeQueriesVwKey;
import com.guvvala.framework.dao.BaseDAO;

public interface EntityFileTypeQueriesVwDAO  extends BaseDAO<EntityFileTypeQueriesVw, EntityFileTypeQueriesVwKey> {
	
	public List<EntityFileTypeQueriesVw> getEntityFileTypeQueriesVwListByReleaseNo(Integer releaseNo);

}
