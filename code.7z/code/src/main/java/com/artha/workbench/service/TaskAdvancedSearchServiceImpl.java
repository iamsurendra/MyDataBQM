package com.artha.workbench.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.FileTypeColumnsDAO;
import com.artha.workbench.dao.PartnerFileTypesDAO;

@Service("taskAdvancedSearchService")
public class TaskAdvancedSearchServiceImpl implements TaskAdvancedSearchService {

	@Autowired
	FileTypeColumnsDAO fileTypeColumnsDAO;

	@Autowired
	PartnerFileTypesDAO partnerFileTypesDAO;

	@Transactional
	public List<String> findAllPartners() {
		return partnerFileTypesDAO.findAllPartnerCodes();
	}

	@Transactional
	public List<String> findFileTypebyPartnerName(String partnerName) {
		return partnerFileTypesDAO.findFileTypebyPartnerName(partnerName);
	}

	@Transactional
	public List<String> findColumnsByFileName(String fileName) {
		return fileTypeColumnsDAO.findColumnsByFileName(fileName);
	}

}