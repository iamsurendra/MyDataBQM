package com.artha.workbench.models.userConfig;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the userroles database table.
 * 
 */
@Entity
@Table(name = "userconfig.userroles")
public class UserRoles implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "ID")
	private int id;

	@Column(name = "EFRCRW_FLAG")
	private String efrcrwFlag;

	@Column(name = "EFRCV_FLAG")
	private String efrcvFlag;

	@Column(name = "EFTSXRW_FLAG")
	private String eftsxrwFlag;

	@Column(name = "EFTSXV_FLAG")
	private String eftsxvFlag;

	@Column(name = "EFTXRW_FLAG")
	private String eftxrwFlag;

	@Column(name = "EFTXV_FLAG")
	private String eftxvFlag;

	@Column(name = "EMRW_FLAG")
	private String emrwFlag;

	@Column(name = "EMV_FLAG")
	private String emvFlag;

	@Column(name = "ETRW_FLAG")
	private String etrwFlag;

	@Column(name = "ETV_FLAG")
	private String etvFlag;

	@Column(name = "FFRW_FLAG")
	private String ffrwFlag;

	@Column(name = "FFV_FLAG")
	private String ffvFlag;

	@Column(name = "FVSXRW_FLAG")
	private String fvsxrwFlag;

	@Column(name = "FVSXV_FLAG")
	private String fvsxvFlag;

	@Column(name = "HFCRW_FLAG")
	private String hfcrwFlag;

	@Column(name = "HFCV_FLAG")
	private String hfcvFlag;

	@Column(name = "HFRW_FLAG")
	private String hfrwFlag;

	@Column(name = "HFTRW_FLAG")
	private String hftrwFlag;

	@Column(name = "HFTV_FLAG")
	private String hftvFlag;

	@Column(name = "HFV_FLAG")
	private String hfvFlag;

	@Column(name = "RTRW_FLAG")
	private String rtrwFlag;

	@Column(name = "RTV_FLAG")
	private String rtvFlag;

	private String status;

	@Column(name = "STMRW_FLAG")
	private String stmrwFlag;

	@Column(name = "STMV_FLAG")
	private String stmvFlag;

	@Column(name = "VRRW_FLAG")
	private String vrrwFlag;

	@Column(name = "VRV_FLAG")
	private String vrvFlag;

	@Column(name = "VSRW_FLAG")
	private String vsrwFlag;

	@Column(name = "VSV_FLAG")
	private String vsvFlag;

	public UserRoles() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEfrcrwFlag() {
		return this.efrcrwFlag;
	}

	public void setEfrcrwFlag(String efrcrwFlag) {
		this.efrcrwFlag = efrcrwFlag;
	}

	public String getEfrcvFlag() {
		return this.efrcvFlag;
	}

	public void setEfrcvFlag(String efrcvFlag) {
		this.efrcvFlag = efrcvFlag;
	}

	public String getEftsxrwFlag() {
		return this.eftsxrwFlag;
	}

	public void setEftsxrwFlag(String eftsxrwFlag) {
		this.eftsxrwFlag = eftsxrwFlag;
	}

	public String getEftsxvFlag() {
		return this.eftsxvFlag;
	}

	public void setEftsxvFlag(String eftsxvFlag) {
		this.eftsxvFlag = eftsxvFlag;
	}

	public String getEftxrwFlag() {
		return this.eftxrwFlag;
	}

	public void setEftxrwFlag(String eftxrwFlag) {
		this.eftxrwFlag = eftxrwFlag;
	}

	public String getEftxvFlag() {
		return this.eftxvFlag;
	}

	public void setEftxvFlag(String eftxvFlag) {
		this.eftxvFlag = eftxvFlag;
	}

	public String getEmrwFlag() {
		return this.emrwFlag;
	}

	public void setEmrwFlag(String emrwFlag) {
		this.emrwFlag = emrwFlag;
	}

	public String getEmvFlag() {
		return this.emvFlag;
	}

	public void setEmvFlag(String emvFlag) {
		this.emvFlag = emvFlag;
	}

	public String getEtrwFlag() {
		return this.etrwFlag;
	}

	public void setEtrwFlag(String etrwFlag) {
		this.etrwFlag = etrwFlag;
	}

	public String getEtvFlag() {
		return this.etvFlag;
	}

	public void setEtvFlag(String etvFlag) {
		this.etvFlag = etvFlag;
	}

	public String getFfrwFlag() {
		return this.ffrwFlag;
	}

	public void setFfrwFlag(String ffrwFlag) {
		this.ffrwFlag = ffrwFlag;
	}

	public String getFfvFlag() {
		return this.ffvFlag;
	}

	public void setFfvFlag(String ffvFlag) {
		this.ffvFlag = ffvFlag;
	}

	public String getFvsxrwFlag() {
		return this.fvsxrwFlag;
	}

	public void setFvsxrwFlag(String fvsxrwFlag) {
		this.fvsxrwFlag = fvsxrwFlag;
	}

	public String getFvsxvFlag() {
		return this.fvsxvFlag;
	}

	public void setFvsxvFlag(String fvsxvFlag) {
		this.fvsxvFlag = fvsxvFlag;
	}

	public String getHfcrwFlag() {
		return this.hfcrwFlag;
	}

	public void setHfcrwFlag(String hfcrwFlag) {
		this.hfcrwFlag = hfcrwFlag;
	}

	public String getHfcvFlag() {
		return this.hfcvFlag;
	}

	public void setHfcvFlag(String hfcvFlag) {
		this.hfcvFlag = hfcvFlag;
	}

	public String getHfrwFlag() {
		return this.hfrwFlag;
	}

	public void setHfrwFlag(String hfrwFlag) {
		this.hfrwFlag = hfrwFlag;
	}

	public String getHftrwFlag() {
		return this.hftrwFlag;
	}

	public void setHftrwFlag(String hftrwFlag) {
		this.hftrwFlag = hftrwFlag;
	}

	public String getHftvFlag() {
		return this.hftvFlag;
	}

	public void setHftvFlag(String hftvFlag) {
		this.hftvFlag = hftvFlag;
	}

	public String getHfvFlag() {
		return this.hfvFlag;
	}

	public void setHfvFlag(String hfvFlag) {
		this.hfvFlag = hfvFlag;
	}

	public String getRtrwFlag() {
		return this.rtrwFlag;
	}

	public void setRtrwFlag(String rtrwFlag) {
		this.rtrwFlag = rtrwFlag;
	}

	public String getRtvFlag() {
		return this.rtvFlag;
	}

	public void setRtvFlag(String rtvFlag) {
		this.rtvFlag = rtvFlag;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStmrwFlag() {
		return this.stmrwFlag;
	}

	public void setStmrwFlag(String stmrwFlag) {
		this.stmrwFlag = stmrwFlag;
	}

	public String getStmvFlag() {
		return this.stmvFlag;
	}

	public void setStmvFlag(String stmvFlag) {
		this.stmvFlag = stmvFlag;
	}

	public String getVrrwFlag() {
		return this.vrrwFlag;
	}

	public void setVrrwFlag(String vrrwFlag) {
		this.vrrwFlag = vrrwFlag;
	}

	public String getVrvFlag() {
		return this.vrvFlag;
	}

	public void setVrvFlag(String vrvFlag) {
		this.vrvFlag = vrvFlag;
	}

	public String getVsrwFlag() {
		return this.vsrwFlag;
	}

	public void setVsrwFlag(String vsrwFlag) {
		this.vsrwFlag = vsrwFlag;
	}

	public String getVsvFlag() {
		return this.vsvFlag;
	}

	public void setVsvFlag(String vsvFlag) {
		this.vsvFlag = vsvFlag;
	}

}