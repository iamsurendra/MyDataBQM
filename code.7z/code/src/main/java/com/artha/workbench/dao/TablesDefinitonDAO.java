package com.artha.workbench.dao;

import com.artha.workbench.models.metastore.TablesDefinition;
import com.guvvala.framework.dao.BaseDAO;

public interface TablesDefinitonDAO extends BaseDAO<TablesDefinition, String> {

}
