package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.PrePersist;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.ThreadLocalUtil;

@Entity
@Table(name = "metastore.ReleasePackages")
@NamedQuery(name="ReleasePackages.findAll", query="SELECT relPackage FROM ReleasePackages relPackage order by createdDate")
@NamedStoredProcedureQuery(name = "metastore.SP_REL_MANAGMENT", procedureName = "metastore.SP_REL_MANAGMENT", parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, type = Integer.class, name = "RELEASE"),@StoredProcedureParameter(mode = ParameterMode.OUT, type = Integer.class, name = "STATUS")})
public class ReleasePackages extends AbstractModel {

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "RELEASE_PACKAGE_ID")
	@JsonProperty("RELEASE_PACKAGE_ID")
	private Integer releasePackageNo;
	
	@Column(name = "RELEASE_PACKAGE_NAME")
	@JsonProperty("RELEASE_PACKAGE_NAME")
	private String releasePackageName;

	@Column(name = "STATUS")
	@JsonProperty("STATUS")
	private String status;
	
	@Column(name = "CREATED_BY", nullable = false)
	@JsonProperty("CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DT", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@JsonProperty("CREATED_DT")
	private Date createdDate;

	@Column(name = "LAST_UPD_BY", nullable = false)
	@JsonProperty("LAST_UPD_BY")
	private String lastUpdBy;

	@Column(name = "LAST_UPD_DT", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@JsonProperty("LAST_UPD_DT")
	private Date lastUpdDate;
	
	@Transient
	@JsonIgnore
	private boolean addMode;
	
	@Transient
	@JsonIgnore
	private boolean baseRelease;
	
	public ReleasePackages() {
	}


	public ReleasePackages(boolean addMode) {
		this.addMode = addMode;
	}


	@PrePersist
	public void prePresist() {
		setCreatedBy(ThreadLocalUtil.getUserName());
		setLastUpdBy(ThreadLocalUtil.getUserName());
		setCreatedDate(new Date());
		setLastUpdDate(new Date());
	}

	
	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public String getLastUpdBy() {
		return lastUpdBy;
	}


	public void setLastUpdBy(String lastUpdBy) {
		this.lastUpdBy = lastUpdBy;
	}


	public Date getLastUpdDate() {
		return lastUpdDate;
	}


	public void setLastUpdDate(Date lastUpdDate) {
		this.lastUpdDate = lastUpdDate;
	}



	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public boolean isAddMode() {
		return addMode;
	}


	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}


	public boolean isBaseRelease() {
		return baseRelease;
	}


	public void setBaseRelease(boolean baseRelease) {
		this.baseRelease = baseRelease;
	}


	public Integer getReleasePackageNo() {
		return releasePackageNo;
	}


	public void setReleasePackageNo(Integer releasePackageId) {
		this.releasePackageNo = releasePackageId;
	}


	public String getReleasePackageName() {
		return releasePackageName;
	}


	public void setReleasePackageName(String releasePackageName) {
		this.releasePackageName = releasePackageName;
	}
	
	

}
