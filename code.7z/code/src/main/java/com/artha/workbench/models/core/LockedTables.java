package com.artha.workbench.models.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.artha.workbench.models.metastore.AbstractModel;
import com.guvvala.framework.util.DateUtils;



@Entity
@Table(name = "lockedtables")
public class LockedTables extends AbstractModel {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "tableno", nullable = false)
	private Integer tableno;
	private String tablename;
	private Long loginid;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_on")
	private Date createdOn;
	
	@Transient
	private String createdOnDtstr;
	
	@Transient
	private String loginname;
	
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	public Integer getTableno() {
		return tableno;
	}
	public void setTableno(Integer tableno) {
		this.tableno = tableno;
	}
	public String getLoginname() {
		return loginname;
	}
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	public String getTablename() {
		return tablename;
	}
	public void setTablename(String tablename) {
		this.tablename = tablename;
	}
	public Long getLoginid() {
		return loginid;
	}
	public void setLoginid(Long loginid) {
		this.loginid = loginid;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getCreatedOnDtstr() {
		return createdOnDtstr;
	}
	public void setCreatedOnDtstr(String createdOnDtstr) {
		this.createdOnDtstr = createdOnDtstr;
	}
	
	@PostLoad
	public void postLoad(){
		convertCreatedOnDate();
	}
	public void convertCreatedOnDate(){
		this.createdOnDtstr = DateUtils.convertToSimpleDateFormat(getCreatedOn());	
	}
	
}
