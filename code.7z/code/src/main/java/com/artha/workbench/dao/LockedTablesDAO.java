package com.artha.workbench.dao;

import com.artha.workbench.models.core.LockedTables;
import com.guvvala.framework.dao.BaseDAO;

public interface LockedTablesDAO extends BaseDAO<LockedTables, Integer> {

}
