package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileValidationRuleVw;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityFileValidationRuleVwDAOImpl extends
		BaseDAOImpl<EntityFileValidationRuleVw, Integer> implements
		EntityFileValidationRuleVwDAO {

	public EntityFileValidationRuleVwDAOImpl() {
		super(EntityFileValidationRuleVw.class);
	}
	public void saveEntityFileValidationRuleVw(List<EntityFileValidationRuleVw> entitytypes)
	{
		batchCreate(entitytypes, 50);
	}
	public int getmaxEfvrid()
	{
		int loginid = 0;// changed 1 to 0 because to avoid data constraint voilation Exception
	      TypedQuery<Integer> query = entityManager.createQuery("SELECT max(efvrid) from EntityFileValidationRuleVw", Integer.class);
	        	if(query.getSingleResult()!=null)
	        	loginid = query.getSingleResult();
	        return loginid;
	}
	
	public List<EntityFileValidationRuleVw> getEntityFileValRuleVwListByReleaseNo(Integer releaseNo){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileValidationRuleVw> query = cb.createQuery(EntityFileValidationRuleVw.class);
		Root<EntityFileValidationRuleVw> root = query.from(EntityFileValidationRuleVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllEntityFileValRuleReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from EntityFileValidationRuleVw where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
}
