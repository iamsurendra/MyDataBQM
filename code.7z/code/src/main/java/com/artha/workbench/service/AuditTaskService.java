package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.to.AuditTaskTO;

public interface AuditTaskService {

	List<AuditTaskTO> getAuditTasks();
	List<AuditTaskTO> getAuditTaskByAccessRight(List<String> taskAccessRights);

}
