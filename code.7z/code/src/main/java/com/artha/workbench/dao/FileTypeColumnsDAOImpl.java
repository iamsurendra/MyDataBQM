package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.FileTypeColumns;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class FileTypeColumnsDAOImpl extends BaseDAOImpl<FileTypeColumns, Integer> implements FileTypeColumnsDAO {

	public FileTypeColumnsDAOImpl() {
		super(FileTypeColumns.class);
	}

	public List<String> findColumnsByFileName(String fileName) {
		TypedQuery<String> query = entityManager
				.createQuery("select colName from FileTypeColumns where hsFileType='" + fileName + "'", String.class);
		return query.getResultList();
	}

	public List<FileTypeColumns> findColumnsByEntityFileTypeID(Long id) {
		TypedQuery<FileTypeColumns> query = entityManager
				.createQuery("select ftc from FileTypeColumns ftc where entityFileTypeId=" + id+" order by UPPER(ftc.colName)", FileTypeColumns.class);
		return query.getResultList();
	}
	
	public List<FileTypeColumns> findFileTypeColumnsByEntityFileTypeID(Long id){
		TypedQuery<FileTypeColumns> query = entityManager
				.createQuery("select ftc from FileTypeColumns ftc where entityFileTypeId=" + id+" order by (ftc.colId)", FileTypeColumns.class);
		return query.getResultList();
		
	}
	
	public List<FileTypeColumns> findColumnsByEntityFileTypeId(Integer id){
		TypedQuery<FileTypeColumns> query = entityManager
				.createQuery("select ftc from FileTypeColumns ftc where entityFileTypeId=" + id+" order by (ftc.colId)",FileTypeColumns.class);
		return query.getResultList();
	}
	
	public List<String> getColumnsByEntityFileTypeId(Long id){
		TypedQuery<String> query = entityManager
				.createQuery("select ftc.colName from FileTypeColumns ftc where entityFileTypeId=" + id+" order by (ftc.colId)",String.class);
		return query.getResultList();
	}

}
