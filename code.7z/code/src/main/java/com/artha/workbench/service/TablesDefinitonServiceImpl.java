package com.artha.workbench.service;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.tableDefiniton.BRWTableDefinition;

import com.artha.workbench.dao.TablesDefinitonDAO;
import com.artha.workbench.models.metastore.TablesDefinition;

@Service("tablesDefinitonService")
public class TablesDefinitonServiceImpl implements TablesDefinitonService {
	
	@Autowired
	TablesDefinitonDAO tablesDefinitonDAO;
	
	@Transactional(readOnly = true)
	public List<BRWTableDefinition> getAllTableDefinitions(){
		List<BRWTableDefinition> brwTableDefinitions = new ArrayList<>();
		List<TablesDefinition> tablesDefinitions = tablesDefinitonDAO.findAll();
		try {
			JAXBContext context = JAXBContext.newInstance(BRWTableDefinition.class);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			for(TablesDefinition tableDefinition : tablesDefinitions){
				StringReader reader =  new StringReader(tableDefinition.getValue());
				BRWTableDefinition brwTableDefinition = (BRWTableDefinition) unmarshaller.unmarshal(new StreamSource(reader));
				if(brwTableDefinition!=null){
					brwTableDefinitions.add(brwTableDefinition);
				}
			}
		} catch (Exception e) {
            e.printStackTrace();
        }
		return brwTableDefinitions;
	}

}
