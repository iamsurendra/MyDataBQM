package com.artha.workbench.models.config;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "rolefunctions")

public class RoleFunctionsType implements Serializable {

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "WRITE_MODE")
	private Integer writeMode;


	public RoleFunctionsType() {
		super();
	}
	@Id
	@Column(name = "ROLE_ID")
	private Integer roleid;
	
	public Integer getRoleid() {
		return roleid;
	}

	@Column(name = "FUNCTION_ID")
	private Integer functionID;

	public Integer getFunctionID() {
		return functionID;
	}

	public void setFunctionID(Integer functionID) {
		this.functionID = functionID;
	}

	public void setRoleid(Integer roleid) {
		this.roleid = roleid;
	}

	public Integer getWriteMode() {
		return writeMode;
	}

	public void setWriteMode(Integer writeMode) {
		this.writeMode = writeMode;
	}

}
