package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.FileValStepVwkey;
import com.artha.workbench.models.metastore.FileValStepXrefVw;
import com.guvvala.framework.dao.BaseDAO;


public interface FileValStepXrefVwDAO extends BaseDAO<FileValStepXrefVw,FileValStepVwkey> {
	
	List<FileValStepXrefVw> getFileValStepXrefVwListByReleaseNo(Integer releaseNo);
	
	
}
