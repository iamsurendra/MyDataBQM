package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.FileValStepXref;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class FileValStepXrefDAOImpl extends BaseDAOImpl<FileValStepXref, Integer> implements FileValStepXrefDAO {

	public FileValStepXrefDAOImpl() {
		super(FileValStepXref.class);
	}

	public void saveFileValStepXref(List<FileValStepXref> entitytypes) {
		batchCreate(entitytypes, 50);
	}

	public void deleteFileValStepXref() {
		Query query = entityManager.createQuery("delete from FileValStepXref");
		query.executeUpdate();
	}

	public FileValStepXref getFileValStepXref(Integer entityFileTypeID, Integer stepId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FileValStepXref> cQuery = builder.createQuery(FileValStepXref.class);
		Root<FileValStepXref> root = cQuery.from(FileValStepXref.class);
		cQuery.select(root);
		cQuery.where(builder.equal(root.get("entityFileTypeID"), entityFileTypeID),
				builder.equal(root.get("stepID"), stepId));
		return findSingle(cQuery);
	}
	public List<FileValStepXref> getFileValStepXrefListByReleaseNo(Integer releaseNo)
	{
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<FileValStepXref> query = cb.createQuery(FileValStepXref.class);
		Root<FileValStepXref> root = query.from(FileValStepXref.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllFileValStepXrefReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from FileValStepXref where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
}
