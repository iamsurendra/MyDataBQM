package com.artha.workbench.models.datahub;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/* This is contract POJO Class */
@Entity
@Table(name = "datahub.srccolumns")
public class Srccolumns implements Serializable {

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "srccol_id", unique = true, nullable = false)
	private String srccol_id;

	@Column(name = "srcrec_id")
	private String srcrec_id;

	@Column(name = "col_name")
	private String col_name;

	@Column(name = "col_value")
	private String col_value;

	@Column(name = "col_type")
	private String col_type;

	@Column(name = "col_iskey")
	private Integer col_iskey;
	
	@Transient
	private boolean writeMode;
	
	@Transient
	private String task_Id;

	@Transient
	private String errorValue;
	
	@Transient
	private Long colId;
	
	@Override
	public String toString() {
		return "Srccolumns [srccol_id=" + srccol_id + ", task_id=" + task_Id + ",srcrec_id=" + srcrec_id + ", col_name=" + col_name
				+ ", col_value=" + col_value + ", col_type=" + col_type + ", col_iskey=" + col_iskey + "]";
	}

	

	public String getTask_Id() {
		return task_Id;
	}


	public void setTask_Id(String task_Id) {
		this.task_Id = task_Id;
	}


	public String getSrccol_id() {
		return srccol_id;
	}

	public void setSrccol_id(String srccol_id) {
		this.srccol_id = srccol_id;
	}

	public String getSrcrec_id() {
		return srcrec_id;
	}

	public void setSrcrec_id(String srcrec_id) {
		this.srcrec_id = srcrec_id;
	}

	public String getCol_name() {
		return col_name;
	}

	public void setCol_name(String col_name) {
		this.col_name = col_name;
	}

	public String getCol_value() {
		return col_value;
	}

	public void setCol_value(String col_value) {
		this.col_value = col_value;
	}

	public String getCol_type() {
		return col_type;
	}

	public void setCol_type(String col_type) {
		this.col_type = col_type;
	}

	public Integer getCol_iskey() {
		return col_iskey;
	}

	public void setCol_iskey(Integer col_iskey) {
		this.col_iskey = col_iskey;
	}

	public String getErrorValue() {
		return errorValue;
	}

	public void setErrorValue(String errorValue) {
		this.errorValue = errorValue;
	}


	public Long getColId() {
		return colId;
	}

	public void setColId(Long colId) {
		this.colId = colId;
	}

	public boolean isWriteMode() {
		return writeMode;
	}

	public void setWriteMode(boolean writeMode) {
		this.writeMode = writeMode;
	}

	
	
}
