package com.artha.workbench.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.constant.WBConstants;
import com.artha.workbench.dao.DataStewardGroupDAO;
import com.artha.workbench.dao.EmptyFileConfigDAO;
import com.artha.workbench.dao.EntityFileRecColumnDAO;
import com.artha.workbench.dao.EntityFileRecColumnVwDAO;
import com.artha.workbench.dao.EntityFileRuleParamDAO;
import com.artha.workbench.dao.EntityFileRuleXrefDAO;
import com.artha.workbench.dao.EntityFileTypeQueriesDAO;
import com.artha.workbench.dao.EntityFileTypeQueriesVwDAO;
import com.artha.workbench.dao.EntityFileTypeScheduleXrefDAO;
import com.artha.workbench.dao.EntityFileTypeScheduleXrefVwDAO;
import com.artha.workbench.dao.EntityFileTypeStepChunkDAO;
import com.artha.workbench.dao.EntityFileTypeWebServiceDAO;
import com.artha.workbench.dao.EntityFileTypeWebServiceVwDAO;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.EntityFileTypeXrefVwDAO;
import com.artha.workbench.dao.EntityFileValidationRuleDAO;
import com.artha.workbench.dao.EntityFileValidationRuleVwDAO;
import com.artha.workbench.dao.EntityMasterDAO;
import com.artha.workbench.dao.EntityTypeDAO;
import com.artha.workbench.dao.FileFormatDAO;
import com.artha.workbench.dao.FileTypeDAO;
import com.artha.workbench.dao.FileValStepXrefDAO;
import com.artha.workbench.dao.FileValStepXrefVwDAO;
import com.artha.workbench.dao.HeaderFooterColsDAO;
import com.artha.workbench.dao.HeaderFooterColsVwDAO;
import com.artha.workbench.dao.HeaderFooterDAO;
import com.artha.workbench.dao.HeaderFooterVwDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.ReleasePackageDAO;
import com.artha.workbench.dao.RuleTypeDAO;
import com.artha.workbench.dao.SourceToServiceCriteriaDAO;
import com.artha.workbench.dao.SourceToServiceCriteriaVwDAO;
import com.artha.workbench.dao.SourceToTargetMappingDAO;
import com.artha.workbench.dao.SourceToTargetMappingVwDAO;
import com.artha.workbench.dao.SourceToTargetSplitDAO;
import com.artha.workbench.dao.SourceToTargetSplitVwDAO;
import com.artha.workbench.dao.SourceToWebServiceMappingDAO;
import com.artha.workbench.dao.SourceToWebServiceMappingVwDAO;
import com.artha.workbench.dao.ThreadPoolTypeDAO;
import com.artha.workbench.dao.ThreadThreadPoolXrefDAO;
import com.artha.workbench.dao.ValidationStepDAO;
import com.artha.workbench.dao.WebServiceRecColumnDAO;
import com.artha.workbench.dao.WebServiceRecColumnVwDAO;
import com.artha.workbench.models.metastore.DataStewardGroups;
import com.artha.workbench.models.metastore.DataStewardGroupsKey;
import com.artha.workbench.models.metastore.EmptyFileConfig;
import com.artha.workbench.models.metastore.EmptyFileConfigId;
import com.artha.workbench.models.metastore.EntityFileRecColumn;
import com.artha.workbench.models.metastore.EntityFileRecColumnKey;
import com.artha.workbench.models.metastore.EntityFileRecColumnVw;
import com.artha.workbench.models.metastore.EntityFileReccolVwkey;
import com.artha.workbench.models.metastore.EntityFileRuleParam;
import com.artha.workbench.models.metastore.EntityFileRuleXref;
import com.artha.workbench.models.metastore.EntityFileTypeQueries;
import com.artha.workbench.models.metastore.EntityFileTypeQueriesVw;
import com.artha.workbench.models.metastore.EntityFileTypeQueriesVwKey;
import com.artha.workbench.models.metastore.EntityFileTypeScheduleXref;
import com.artha.workbench.models.metastore.EntityFileTypeScheduleXrefId;
import com.artha.workbench.models.metastore.EntityFileTypeScheduleXrefVw;
import com.artha.workbench.models.metastore.EntityFileTypeStepChunk;
import com.artha.workbench.models.metastore.EntityFileTypeStepChunkKey;
import com.artha.workbench.models.metastore.EntityFileTypeWebService;
import com.artha.workbench.models.metastore.EntityFileTypeWebServiceId;
import com.artha.workbench.models.metastore.EntityFileTypeWebServiceVw;
import com.artha.workbench.models.metastore.EntityFileTypeWebServiceVwKey;
import com.artha.workbench.models.metastore.EntityFileTypeXref;
import com.artha.workbench.models.metastore.EntityFileTypeXrefId;
import com.artha.workbench.models.metastore.EntityFileTypeXrefVw;
import com.artha.workbench.models.metastore.EntityFileValidationRule;
import com.artha.workbench.models.metastore.EntityFileValidationRuleVw;
import com.artha.workbench.models.metastore.EntityFileValidationRuleVwId;
import com.artha.workbench.models.metastore.EntityMaster;
import com.artha.workbench.models.metastore.EntityMasterId;
import com.artha.workbench.models.metastore.EntityType;
import com.artha.workbench.models.metastore.EntityTypeId;
import com.artha.workbench.models.metastore.FileFormat;
import com.artha.workbench.models.metastore.FileFormatId;
import com.artha.workbench.models.metastore.FileValStepVwkey;
import com.artha.workbench.models.metastore.FileValStepXref;
import com.artha.workbench.models.metastore.FileValStepXrefKey;
import com.artha.workbench.models.metastore.FileValStepXrefVw;
import com.artha.workbench.models.metastore.HSFileType;
import com.artha.workbench.models.metastore.HSFileTypeId;
import com.artha.workbench.models.metastore.HeaderFooter;
import com.artha.workbench.models.metastore.HeaderFooterColVwKey;
import com.artha.workbench.models.metastore.HeaderFooterCols;
import com.artha.workbench.models.metastore.HeaderFooterColsVw;
import com.artha.workbench.models.metastore.HeaderFooterKey;
import com.artha.workbench.models.metastore.HeaderFooterVw;
import com.artha.workbench.models.metastore.HeaderFooterVwkey;
import com.artha.workbench.models.metastore.Headerfootercolkey;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.models.metastore.ReleasePackages;
import com.artha.workbench.models.metastore.RuleType;
import com.artha.workbench.models.metastore.RuleTypeId;
import com.artha.workbench.models.metastore.SourceToServiceCriteria;
import com.artha.workbench.models.metastore.SourceToServiceCriteriaVw;
import com.artha.workbench.models.metastore.SourceToServiceCriteriaVwKey;
import com.artha.workbench.models.metastore.SourceToTargetMapping;
import com.artha.workbench.models.metastore.SourceToTargetMappingKey;
import com.artha.workbench.models.metastore.SourceToTargetMappingVw;
import com.artha.workbench.models.metastore.SourceToTargetSplit;
import com.artha.workbench.models.metastore.SourceToTargetSplitVw;
import com.artha.workbench.models.metastore.SourceToTargetSplitVwKey;
import com.artha.workbench.models.metastore.SourceToTargetVwKey;
import com.artha.workbench.models.metastore.SourceToWebServiceMapping;
import com.artha.workbench.models.metastore.SourceToWebServiceMappingVw;
import com.artha.workbench.models.metastore.SourceToWebServiceMappingVwKey;
import com.artha.workbench.models.metastore.ThreadPoolType;
import com.artha.workbench.models.metastore.ThreadPoolTypeId;
import com.artha.workbench.models.metastore.ThreadThreadPoolXref;
import com.artha.workbench.models.metastore.ThreadThreadPoolXrefKey;
import com.artha.workbench.models.metastore.ValidationStep;
import com.artha.workbench.models.metastore.ValidationStepId;
import com.artha.workbench.models.metastore.WebServiceRecColumn;
import com.artha.workbench.models.metastore.WebServiceRecColumnVw;
import com.artha.workbench.models.metastore.WebServiceRecColumnVwKey;
import com.artha.workbench.to.ReleaseMetadataTO;
import com.artha.workbench.to.ReleasePackageInfoTO;
import com.artha.workbench.to.ValidationRuleDetailsInfoTO;
import com.artha.workbench.to.ValidationRulesInfoTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.logging.AppLogger;
import com.guvvala.framework.logging.AppLoggerFactory;
import com.guvvala.framework.util.AppWebUtils;


@Service("releasePackageService")
public class ReleasePackageServiceImpl implements ReleasePackageService{
	
	private AppLogger logger = AppLoggerFactory.getLogger(this.getClass().getName());
	
	@Autowired
	ReleasePackageDAO releasePackageDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;
	
	@Autowired
	EntityTypeDAO entityTypeDAO;

	@Autowired
	FileFormatDAO fileFormatDAO;

	@Autowired
	FileTypeDAO fileTypeDAO;

	@Autowired
	EntityMasterDAO entityMasterDAO;

	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefDAO;

	@Autowired
	EntityFileRecColumnDAO entityFileRecColumnDAO;

	@Autowired
	SourceToTargetMappingDAO sourceToTargetMappingDAO;

	@Autowired
	EntityFileTypeScheduleXrefDAO entityFileTypeScheduleXrefDAO;

	@Autowired
	HeaderFooterDAO headerFooterDAO;

	@Autowired
	HeaderFooterColsDAO headerFooterColsDAO;

	@Autowired
	RuleTypeDAO ruleTypeDAO;

	@Autowired
	ValidationStepDAO validationStepDAO;
	
	@Autowired
	EntityFileValidationRuleVwDAO entityFileValidationRuleVwDAO;
	
	@Autowired
	EntityFileValidationRuleDAO entityFileValidationRuleDAO;
	
	@Autowired
	EntityFileRuleXrefDAO entityFileRuleXrefDAO;
	
	@Autowired
	EntityFileRuleParamDAO entityFileRuleParamDAO;

	@Autowired
	FileValStepXrefDAO fileValStepXrefDAO;
	
	@Autowired
	EntityFileTypeXrefVwDAO entityFileTypeXrefVwDAO;
	
	@Autowired
	SourceToTargetMappingVwDAO sourceToTargetMappingVwDAO;
	
	@Autowired
	HeaderFooterVwDAO headerFooterVwDAO;
	
	@Autowired
	EntityFileRecColumnVwDAO entityFileRecColumnVwDAO;
	
	@Autowired
	HeaderFooterColsVwDAO headerFooterColsVwDAO;
	
	@Autowired
	FileValStepXrefVwDAO fileValStepXrefVwDAO;
	
	@Autowired
	EntityFileTypeScheduleXrefVwDAO entityFileTypeScheduleXrefVwDAO;
	
	@Autowired
	WebServiceRecColumnDAO webServiceRecColumnDAO;
	
	@Autowired
	EntityFileTypeWebServiceDAO entityFileTypeWebServiceDAO;
	
	@Autowired
	EntityFileTypeWebServiceVwDAO entityFileTypeWebServiceVwDAO;
	
	@Autowired
	WebServiceRecColumnVwDAO webServiceRecColumnVwDAO;
	
	@Autowired
	SourceToTargetSplitDAO sourceToTargetSplitDAO;
	
	@Autowired
	SourceToWebServiceMappingDAO sourceToWebServiceMappingDAO;
	
	@Autowired
	SourceToServiceCriteriaDAO sourceToServiceCriteriaDAO;
	
	@Autowired
	EntityFileTypeQueriesDAO entityFileTypeQueriesDAO;
	
	@Autowired
	EntityFileTypeQueriesVwDAO entityFileTypeQueriesVwDAO;
	
	@Autowired
	SourceToTargetSplitVwDAO sourceToTargetSplitVwDAO;
	
	@Autowired
	SourceToServiceCriteriaVwDAO sourceToServiceCriteriaVwDAO;
	
	@Autowired
	SourceToWebServiceMappingVwDAO sourceToWebServiceMappingVwDAO;
	
	@Autowired
	DataStewardGroupDAO dataStewardGroupDAO;
	
	@Autowired
	ThreadPoolTypeDAO threadPoolTypeDAO;
	
	@Autowired
	ThreadThreadPoolXrefDAO threadThreadPoolXrefDAO;
	
	@Autowired
	EntityFileTypeStepChunkDAO entityFileTypeStepChunkDAO;
	
	@Autowired
	EmptyFileConfigDAO emptyFileConfigDAO;

	@Transactional
	public List<ReleasePackages> fetchReleasePackages()
	{
		return releasePackageDAO.fetchReleasePackages();
	}
	@Transactional
	public ReleasePackages createReleasePackage(String releasePackageId)
	{
		ReleasePackages releasePackages =  new ReleasePackages();
		releasePackages.setReleasePackageNo(releasePackageDAO.getMaxReleasePackageId()+1);
		releasePackages.setReleasePackageName(releasePackageId);
		releasePackages.setStatus(WBConstants.RELEASE_INPROGRESS_STATUS);
		releasePackages.setAddMode(Boolean.FALSE);
		releasePackageDAO.create(releasePackages);
		return releasePackages;
	}
	
	@Transactional
	public ReleasePackages createReleasePackage(Integer releasePackageId,String releasePackageName)
	{
		ReleasePackages releasePackage =  new ReleasePackages();
		releasePackage.setReleasePackageNo(releasePackageId);
		releasePackage.setReleasePackageName(releasePackageName);
		releasePackage.setStatus(WBConstants.RELEASE_INPROGRESS_STATUS);
		return releasePackageDAO.update(releasePackage);
	}
	
	@Transactional
	public ReleasePackages freezeReleasePackages(Integer releasePackageId)
	{
		
		//releasePackages = releasePackageDAO.update(releasePackages);*/
		ReleasePackages oldReleasePackages = releasePackageDAO.findOne(releasePackageId);
		if(oldReleasePackages.getStatus().equals(WBConstants.RELEASE_FREEZED_STATUS))
		{
			throw new AppException(MessagesEnum.RELEASE_ALREADY_FREEZED);
		}
		Integer status = releasePackageDAO.freezeReleasePackageWithProc(releasePackageId);
		if(status!=null && status.equals(1))
		{
		ReleasePackages releasePackages = releasePackageDAO.findOne(releasePackageId);
		return releasePackages;
		}
		throw new AppException(MessagesEnum.RELEASE_FRREZE_FAILED);
	}
	@Transactional
	public ReleasePackages findReleasePackage(Integer releasePackageId)
	{
		ReleasePackages releasePackages = releasePackageDAO.findOne(releasePackageId);
		return releasePackages;
	}
	
	@Transactional(readOnly = true)
	public List<Integer> getArchiveReleaseIds(Integer releaseId){
		return releaseArchiveDAO.getArchiveReleaseIds(releaseId);
	}
	
	@Override
	@Transactional(readOnly = true)
	public Set<Integer> getArchiveReleaseInfo(Integer releaseId,String tableName,Set<String> primaryKeys){
		Set<Integer> archiveIds = new HashSet<>();
		List<String> primaryKeysList = new ArrayList<>(primaryKeys);
		if(primaryKeys.size()>=2001){
			archiveIds.addAll(releaseArchiveDAO.getArchiveReleaseInfo(releaseId, tableName, primaryKeysList.subList(0, 2000)));
			archiveIds.addAll(releaseArchiveDAO.getArchiveReleaseInfo(releaseId, tableName, primaryKeysList.subList(2000, primaryKeys.size())));
		}else{
			archiveIds.addAll(releaseArchiveDAO.getArchiveReleaseInfo(releaseId, tableName, primaryKeysList));
		}
		return archiveIds;
	}
	
	@Override
	@Transactional(readOnly = true)
	public Long getReleasePackageListCount(Set<String> releaseNames){
		return releasePackageDAO.getReleasePackageListCount(releaseNames);
	}
	
	
	@Override
	@Transactional
	public void saveRelaseInfo(ReleasePackageInfoTO releasePackageInfo){
		createReleasePackage(releasePackageInfo.getReleasePackageNumber(),releasePackageInfo.getReleasePackageName());
		ReleaseMetadataTO releaseMetadata = releasePackageInfo.getReleaseMetadata();
		try
		{
		updateEntityType(releaseMetadata.getEntityTypeList());
		updateFileFormat(releaseMetadata.getFileFormatList());
		updateFileType(releaseMetadata.getHsFileTypeList());
		updateEntityMaster(releaseMetadata.getEntityMasterList());
		updateEntityFileTypeXref(releaseMetadata.getEntityFileTypeXrefList());
		updateEntityFileRecColumn(releaseMetadata.getEntityFileRecColumnList());
		updateSourceToTargetMapping(releaseMetadata.getSourceToTargetMappingList());
		updateEntityFileTypeScheduleXref(releaseMetadata.getEntityFileTypeScheduleXrefList());
		updateHeaderFooter(releaseMetadata.getHeaderFooterList());
		updateHeaderFooterCols(releaseMetadata.getHeaderFooterColsList());
		updateRuleType(releaseMetadata.getRuleTypeList());
		updateValidationStep(releaseMetadata.getValidationStepList());
		/*ValidationRulesInfoTO validationRulesInfo = releaseMetadata.getValidationRules();
		entityFileValidationRuleVwDAO.batchUpdate(validationRulesInfo.getEntityFileValidationRuleList(), 50);
		entityFileValidationRuleDAO.batchUpdate(validationRulesInfo.getEntityFileValidationRules(), 50);
		entityFileRuleXrefDAO.batchUpdate(validationRulesInfo.getEntityFileRuleXrefs(), 50);
		entityFileRuleParamDAO.batchUpdate(validationRulesInfo.getEntityFileRuleParams(), 50);*/
		List<ValidationRuleDetailsInfoTO> validationRulesXmlTOs = releaseMetadata.getValidationRules().getValidationRulesXmlTOs();
		updateValidationRules(validationRulesXmlTOs);
		updateFileValStepXref(releaseMetadata.getFileValStepXrefList());
		updateEntityFileTypeWebService(releaseMetadata.getEntityFileTypeWebServiceList());
		updateWebServiceRecColumn(releaseMetadata.getWebServiceRecColumnList());
		updateEntityFileTypeQueries(releaseMetadata.getEntityFileTypeQueriesList());
		updateSourceToTargetSplit(releaseMetadata.getSourceToTargetSplitList());
		updateSourceToServiceCriteria(releaseMetadata.getSourceToServiceCriteriaList());
		updateSourceToWebServiceMapping(releaseMetadata.getSourceToWebServiceMappingList());
		updateDataStewardGroups(releaseMetadata.getDataStewardGroupsList());
		updateThreadPoolType(releaseMetadata.getThreadPoolTypeList());
		updateThreadThreadPoolXref(releaseMetadata.getThreadThreadPoolXrefList());
		updateEntityFileTypeStepChunk(releaseMetadata.getEntityFileTypeStepChunkList());
		updateEmptyFileConfig(releaseMetadata.getEmptyFileConfigList());
		}
		catch (JsonProcessingException e) {
			logger.error("ERROR IN JSON PARSING", e);
		}
	}
	
	private void updateSourceToWebServiceMapping(List<SourceToWebServiceMapping> sourceToWebServiceMappingList) throws JsonProcessingException
	{
		for (SourceToWebServiceMapping sourceToWebServiceMapping : sourceToWebServiceMappingList) {
			SourceToWebServiceMapping oldSourceToWebServiceMapping = sourceToWebServiceMappingDAO
					.findOne(sourceToWebServiceMapping.getSourceToWebServiceMappingKey());
			if (oldSourceToWebServiceMapping != null) {
					EntityFileTypeXrefVw sourceEntityFileTypeXrefVw = entityFileTypeXrefVwDAO.findOne(sourceToWebServiceMapping.getSourceToWebServiceMappingKey().getSourceEntityFileTypeID());
					SourceToWebServiceMappingVwKey sourceToWebServiceMappingVwKey = new SourceToWebServiceMappingVwKey();
					sourceToWebServiceMappingVwKey.setEntityName(sourceEntityFileTypeXrefVw.getEntityName());
					sourceToWebServiceMappingVwKey.sethSFileType(sourceEntityFileTypeXrefVw.getHSFileType());
					sourceToWebServiceMappingVwKey.setFileMask(sourceEntityFileTypeXrefVw.getFileMask());
					sourceToWebServiceMappingVwKey
							.setSourceEntityFileTypeID(sourceToWebServiceMapping.getSourceToWebServiceMappingKey().getSourceEntityFileTypeID());
					sourceToWebServiceMappingVwKey.setWebServiceID(sourceToWebServiceMapping.getSourceToWebServiceMappingKey().getWebServiceID());
					sourceToWebServiceMappingVwKey.setTargetColumnID(sourceToWebServiceMapping.getSourceToWebServiceMappingKey().getTargetColumnID());
					SourceToWebServiceMappingVw oldEntity = sourceToWebServiceMappingVwDAO
							.findOne(sourceToWebServiceMappingVwKey);
					if (oldEntity != null) {
						ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();

						releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNum());
						releaseArchiveKey.setReleaseId(sourceToWebServiceMapping.getReleaseNum());
						releaseArchiveKey.setTableName("SOURCETOWEBSERVICEMAPPING");
						releaseArchiveKey.setTableRecId(
								AppWebUtils.convertObjectToJson(sourceToWebServiceMapping.getSourceToWebServiceMappingKey()));
						ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
						if (releaseArchive != null) {
							releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
							releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToWebServiceMapping));
							releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToWebServiceMappingVwKey));
							releaseArchiveDAO.update(releaseArchive);
						} else {
							releaseArchive = new ReleaseArchive();
							releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
							releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToWebServiceMapping));
							releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToWebServiceMappingVwKey));
							releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
							releaseArchiveDAO.create(releaseArchive);
						}
					}
					sourceToWebServiceMappingDAO.update(sourceToWebServiceMapping);
			}

			else {
				sourceToWebServiceMappingDAO.create(sourceToWebServiceMapping);
			}
		}
	}
	
	private void updateSourceToServiceCriteria(List<SourceToServiceCriteria> sourceToServiceCriteriaList) throws JsonProcessingException
	{
		for (SourceToServiceCriteria sourceToServiceCriteria : sourceToServiceCriteriaList) {
			SourceToServiceCriteria oldSourceToServiceCriteria = sourceToServiceCriteriaDAO
					.findOne(sourceToServiceCriteria.getSourceToServiceCriteriaKey());
			if (oldSourceToServiceCriteria != null) {
					EntityFileTypeXrefVw sourceEntityFileTypeXrefVw = entityFileTypeXrefVwDAO.findOne(sourceToServiceCriteria.getSourceEntityFileTypeID().intValue());
					SourceToServiceCriteriaVwKey sourceToServiceCriteriaVwKey = new SourceToServiceCriteriaVwKey();
					sourceToServiceCriteriaVwKey.setSourceEntityFileTypeID(sourceToServiceCriteria.getSourceEntityFileTypeID());
					sourceToServiceCriteriaVwKey.setEntityName(sourceEntityFileTypeXrefVw.getEntityName());
					sourceToServiceCriteriaVwKey.setFileMask(sourceEntityFileTypeXrefVw.getFileMask());
					sourceToServiceCriteriaVwKey.setHsFileType(sourceEntityFileTypeXrefVw.getHSFileType());
					sourceToServiceCriteriaVwKey.setWebServiceID(sourceToServiceCriteria.getSourceToServiceCriteriaKey().getWebServiceID());
					SourceToServiceCriteriaVw oldEntity = sourceToServiceCriteriaVwDAO.findOne(sourceToServiceCriteriaVwKey);
					if(oldEntity!=null){
				    ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
					releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNum());
					releaseArchiveKey.setReleaseId(sourceToServiceCriteria.getReleaseNum());
					releaseArchiveKey.setTableName("SOURCETOSERVICECRITERIA");
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(sourceToServiceCriteria.getSourceToServiceCriteriaKey()));
					ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
					if(releaseArchive!=null){
						releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
						releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToServiceCriteria));
						releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToServiceCriteriaVwKey));
						releaseArchiveDAO.update(releaseArchive);
					}else{
						releaseArchive = new ReleaseArchive();
						releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
						releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToServiceCriteria));
						releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToServiceCriteriaVwKey));
						releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
						releaseArchiveDAO.create(releaseArchive);
					}
					}
					sourceToServiceCriteriaDAO.update(sourceToServiceCriteria);
			}

			else {
				sourceToServiceCriteriaDAO.create(sourceToServiceCriteria);
			}
		}
	}
	
	private void updateSourceToTargetSplit(List<SourceToTargetSplit> sourceToTargetSplitList) throws JsonProcessingException
	{
		for (SourceToTargetSplit sourceToTargetSplit : sourceToTargetSplitList) {
			SourceToTargetSplit oldSourceToTargetSplit = sourceToTargetSplitDAO
					.findOne(sourceToTargetSplit.getSourceToTargetSplitKey());
			if (oldSourceToTargetSplit != null) {
					EntityFileTypeXrefVw sourceEntityFileTypeXrefVw = entityFileTypeXrefVwDAO.findOne(sourceToTargetSplit.getSourceToTargetSplitKey().getSourceEntityFileTypeID().intValue());
					EntityFileTypeXrefVw targetEntityFileTypeXrefVw = entityFileTypeXrefVwDAO.findOne(sourceToTargetSplit.getSourceToTargetSplitKey().getTargetEntityFileTypeID().intValue());
					SourceToTargetSplitVwKey sourceToTargetSplitVwKey = new SourceToTargetSplitVwKey();
					sourceToTargetSplitVwKey.setSourceEntityFileTypeID(sourceToTargetSplit.getSourceToTargetSplitKey().getSourceEntityFileTypeID());
					sourceToTargetSplitVwKey.setSourceEntityName(sourceEntityFileTypeXrefVw.getEntityName());
					sourceToTargetSplitVwKey.setSourceFileMask(sourceEntityFileTypeXrefVw.getFileMask());
					sourceToTargetSplitVwKey.setSourceHsFileType(sourceEntityFileTypeXrefVw.getHSFileType());
					sourceToTargetSplitVwKey.setTargetEntityFileTypeID(sourceToTargetSplit.getSourceToTargetSplitKey().getTargetEntityFileTypeID());
					sourceToTargetSplitVwKey.setTargetEntityName(targetEntityFileTypeXrefVw.getEntityName());
					sourceToTargetSplitVwKey.setTargetFileMask(targetEntityFileTypeXrefVw.getFileMask());
					sourceToTargetSplitVwKey.setTargetHsFileType(targetEntityFileTypeXrefVw.getHSFileType());
					SourceToTargetSplitVw oldEntity = sourceToTargetSplitVwDAO.findOne(sourceToTargetSplitVwKey);
					if(oldEntity!=null){
				    ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
					releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNum());
					releaseArchiveKey.setReleaseId(sourceToTargetSplit.getReleaseNo());
					releaseArchiveKey.setTableName("SOURCETOTARGETSPLIT");
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(sourceToTargetSplit.getSourceToTargetSplitKey()));
					ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
					if(releaseArchive!=null){
						releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
						releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToTargetSplit));
						releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToTargetSplitVwKey));
						releaseArchiveDAO.update(releaseArchive);
					}else{
						releaseArchive = new ReleaseArchive();
						releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
						releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToTargetSplit));
						releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToTargetSplitVwKey));
						releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
						releaseArchiveDAO.create(releaseArchive);
					}
					}
					sourceToTargetSplitDAO.update(sourceToTargetSplit);
			}

			else {
				sourceToTargetSplitDAO.create(sourceToTargetSplit);
			}
		}
	}
	
	private void updateEntityFileTypeQueries(List<EntityFileTypeQueries> entityFileTypeQueryList) throws JsonProcessingException
	{
		for (EntityFileTypeQueries entityFileTypeQuery : entityFileTypeQueryList) {
			EntityFileTypeQueries oldEntityFileTypeQuery = entityFileTypeQueriesDAO
					.findOne(entityFileTypeQuery.getEntityFileTypeQueriesKey());
			if (oldEntityFileTypeQuery != null) {
					EntityFileTypeXrefVw entityFileTypeXrefVw = entityFileTypeXrefVwDAO.findOne(oldEntityFileTypeQuery.getEntityFileTypeID());
					EntityFileTypeQueriesVwKey entityFileTypeQueriesVwKey = new EntityFileTypeQueriesVwKey();
					entityFileTypeQueriesVwKey.setEntityFileTypeID(entityFileTypeXrefVw.getEntityFileTypeID());
					entityFileTypeQueriesVwKey.setEntityName(entityFileTypeXrefVw.getEntityName());
					entityFileTypeQueriesVwKey.setFileMask(entityFileTypeXrefVw.getFileMask());
					entityFileTypeQueriesVwKey.setHsFileType(entityFileTypeXrefVw.getHSFileType());
					entityFileTypeQueriesVwKey.setStepID(oldEntityFileTypeQuery.getStepID());
					entityFileTypeQueriesVwKey.setSeqOrder(oldEntityFileTypeQuery.getSeqOrder());
					EntityFileTypeQueriesVw oldEntity = entityFileTypeQueriesVwDAO.findOne(entityFileTypeQueriesVwKey);
					if(oldEntity!=null){
					    ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
					    releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
					    releaseArchiveKey.setReleaseId(entityFileTypeQuery.getReleaseNo());
					    releaseArchiveKey.setTableName("ENTITYFILETYPEQUERIES");
					    releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityFileTypeQuery.getEntityFileTypeQueriesKey()));
					    ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
					    if(releaseArchive!=null){
							releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
							releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileTypeQuery));
							releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileTypeQueriesVwKey));
							releaseArchiveDAO.update(releaseArchive);
						}else{
							releaseArchive = new ReleaseArchive();
							releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
							releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileTypeQuery));
							releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileTypeQueriesVwKey));
							releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
							releaseArchiveDAO.create(releaseArchive);
						}
					}
					entityFileTypeQueriesDAO.update(entityFileTypeQuery);
			}

			else {
				entityFileTypeQueriesDAO.create(entityFileTypeQuery);
			}
		}
	}
	
	private void updateWebServiceRecColumn(List<WebServiceRecColumn> webServiceRecColumnList) throws JsonProcessingException
	{
		for (WebServiceRecColumn webServiceRecColumn : webServiceRecColumnList) {
			WebServiceRecColumn oldWebServiceRecColumn = webServiceRecColumnDAO.findOne(webServiceRecColumn.getWebServiceRecColumnKey());
			if (oldWebServiceRecColumn != null) {
					WebServiceRecColumnVwKey columnVwKey = new WebServiceRecColumnVwKey();
					columnVwKey.setColumnID(webServiceRecColumn.getWebServiceRecColumnKey().getColumnID());
					columnVwKey.setWebServiceID(webServiceRecColumn.getWebServiceRecColumnKey().getWebServiceID());
					WebServiceRecColumnVw oldEntity = webServiceRecColumnVwDAO.findOne(columnVwKey);
					if (oldEntity != null) {
						ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
						releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNum());
						releaseArchiveKey.setReleaseId(webServiceRecColumn.getReleaseNum());
						releaseArchiveKey.setTableName("WEBSERVICERECCOLUMN");
						releaseArchiveKey.setTableRecId(
								AppWebUtils.convertObjectToJson(webServiceRecColumn.getWebServiceRecColumnKey()));
						ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
						if (releaseArchive != null) {
							releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
							releaseArchive.setRecData(AppWebUtils.convertObjectToJson(webServiceRecColumn));
							releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(webServiceRecColumn.getWebServiceRecColumnKey()));
							releaseArchiveDAO.update(releaseArchive);
						} else {
							releaseArchive = new ReleaseArchive();
							releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
							releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
							releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(columnVwKey));
							releaseArchive.setRecData(AppWebUtils.convertObjectToJson(webServiceRecColumn));
							releaseArchiveDAO.create(releaseArchive);
						}
					}
					webServiceRecColumnDAO.update(webServiceRecColumn);
			}

			else {
				webServiceRecColumnDAO.create(webServiceRecColumn);
			}
		}
	}
	
	private void updateEntityFileTypeWebService(List<EntityFileTypeWebService> entityFileTypeWebServiceList) throws JsonProcessingException
	{
		for (EntityFileTypeWebService entityFileTypeWebService : entityFileTypeWebServiceList) {
			EntityFileTypeWebService oldEntityFileTypeWebService = entityFileTypeWebServiceDAO
					.findOne(entityFileTypeWebService.getWebServiceID());
			if (oldEntityFileTypeWebService != null) {
					EntityFileTypeWebServiceVwKey entityFileTypeWebServiceVwKey = new EntityFileTypeWebServiceVwKey();
					entityFileTypeWebServiceVwKey.setWebServiceID(entityFileTypeWebService.getWebServiceID());
					EntityFileTypeWebServiceVw oldEntity = entityFileTypeWebServiceVwDAO
							.findOne(entityFileTypeWebServiceVwKey);
					if (oldEntity != null) {
						ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
						releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
						releaseArchiveKey.setReleaseId(entityFileTypeWebService.getReleaseNo());
						releaseArchiveKey.setTableName("ENTITYFILETYPEWEBSERVICE");
						EntityFileTypeWebServiceId entityFileTypeWebServiceId = new EntityFileTypeWebServiceId();
						entityFileTypeWebServiceId.setWebServiceID(entityFileTypeWebService.getWebServiceID());
						releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityFileTypeWebServiceId));
						ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
						if (releaseArchive != null) {
							releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
							releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileTypeWebService));
							releaseArchive
									.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileTypeWebServiceVwKey));
							releaseArchiveDAO.update(releaseArchive);
						} else {
							releaseArchive = new ReleaseArchive();
							releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
							releaseArchive.setRecData(AppWebUtils.convertObjectToJson(entityFileTypeWebService));
							releaseArchive
									.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileTypeWebServiceVwKey));
							releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
							releaseArchiveDAO.create(releaseArchive);
						}
					}
					entityFileTypeWebServiceDAO.update(entityFileTypeWebService);
			}

			else {
				entityFileTypeWebServiceDAO.create(entityFileTypeWebService);
			}
		}
	}
	
	private void updateValidationRules(List<ValidationRuleDetailsInfoTO> validationRulesXmlTOs) throws JsonProcessingException
	{
		for(ValidationRuleDetailsInfoTO validationRuleDetailsInfoTO : validationRulesXmlTOs)
		{
			EntityFileValidationRuleVw entityFileValidationRuleVw = validationRuleDetailsInfoTO.getEntityFileValidationRuleVw();
			if(null!=entityFileValidationRuleVw.getEfvrid())
			{
				EntityFileValidationRuleVw oldentityFileValidationRuleVw =  entityFileValidationRuleVwDAO.findOne(entityFileValidationRuleVw.getEfvrid());
				if(oldentityFileValidationRuleVw!=null)
				{
					ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
					releaseArchiveKey.setArchivedReleaseId(oldentityFileValidationRuleVw.getReleaseNo());
					releaseArchiveKey.setReleaseId(entityFileValidationRuleVw.getReleaseNo());
					releaseArchiveKey.setTableName("VALIDATIONRULE");
					EntityFileValidationRuleVwId id = new EntityFileValidationRuleVwId();
					id.setEfvrid(oldentityFileValidationRuleVw.getEfvrid());
						releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(id));
					ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
					ValidationRulesInfoTO validationRulesInfoTO = new ValidationRulesInfoTO();
					validationRulesInfoTO.getEntityFileValidationRuleList().add(oldentityFileValidationRuleVw);
					EntityFileValidationRule efvr = entityFileValidationRuleDAO
							.findOne(oldentityFileValidationRuleVw.getEfvrid());
					EntityFileRuleXref efrxref = entityFileRuleXrefDAO
							.findOne(oldentityFileValidationRuleVw.getEfvrid());
					List<EntityFileRuleParam> paramsList = new ArrayList<>();
					if (efrxref != null) {
						paramsList = entityFileRuleParamDAO.getEntityFileRuleParamList(efrxref.getEntityfileRuleId());
					}

					validationRulesInfoTO.getEntityFileValidationRules().add(efvr);
					validationRulesInfoTO.getEntityFileRuleXrefs().add(efrxref);
					validationRulesInfoTO.getEntityFileRuleParams().addAll(paramsList);
					releaseArchive = new ReleaseArchive();
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
						releaseArchive.setRecData(AppWebUtils.convertObjectToJson(validationRulesInfoTO));
					releaseArchiveDAO.update(releaseArchive);
					entityFileValidationRuleVwDAO.update(entityFileValidationRuleVw);
					entityFileValidationRuleDAO.update(validationRuleDetailsInfoTO.getEntityFileValidationRule());
					entityFileRuleXrefDAO.update(validationRuleDetailsInfoTO.getEntityFileRuleXref());
					for(EntityFileRuleParam entityFileRuleParam : validationRuleDetailsInfoTO.getEntityFileRuleParams())
					{
						entityFileRuleParamDAO.update(entityFileRuleParam);
					}
				}
				else
				{
					entityFileValidationRuleVwDAO.create(entityFileValidationRuleVw);
					entityFileValidationRuleDAO.create(validationRuleDetailsInfoTO.getEntityFileValidationRule());
					entityFileRuleXrefDAO.create(validationRuleDetailsInfoTO.getEntityFileRuleXref());
					for(EntityFileRuleParam entityFileRuleParam : validationRuleDetailsInfoTO.getEntityFileRuleParams())
					{
						entityFileRuleParamDAO.create(entityFileRuleParam);
					}
				}
				
			}
		}
	}
	/*private void updateValidationRules(List<ValidationRulesInfoTO> validationRulesInfoTOList)
	{
		
		for(ValidationRulesInfoTO validationRulesInfoTO : validationRulesInfoTOList)
		{
			
			for(EntityFileValidationRuleVw entityFileValidationRuleVw : validationRulesInfoTO.getEntityFileValidationRuleList())
			{
				EntityFileValidationRuleVw  oldEntityFileValidationRuleVw= entityFileValidationRuleVwDAO.findOne(entityFileValidationRuleVw.getEfvrid())
				  
			}
			
		}
	}*/
	
	private void updateFileValStepXref(List<FileValStepXref> fileValStepXrefList) throws JsonProcessingException
	{
		for(FileValStepXref fileValStepXref : fileValStepXrefList)
		{
			FileValStepXrefKey fileValStepXrefKey = new FileValStepXrefKey();
			fileValStepXrefKey.setEntityFileTypeID(fileValStepXref.getEntityFileTypeID());
			fileValStepXrefKey.setStepID(fileValStepXref.getStepID());
			FileValStepXref oldFileValStepXref = fileValStepXrefDAO.getFileValStepXref(fileValStepXref.getEntityFileTypeID(), fileValStepXref.getStepID());
			if(oldFileValStepXref!=null)
			{
				EntityFileTypeXrefVw entityFileTypeXrefVw = entityFileTypeXrefVwDAO.findOne(fileValStepXref.getEntityFileTypeID());
				FileValStepXrefVw oldEntity=null;
				FileValStepVwkey fileValStepVwkey=null;
				if(null!=entityFileTypeXrefVw)
				{
				fileValStepVwkey = new FileValStepVwkey();
				fileValStepVwkey.setFileMask(entityFileTypeXrefVw.getFileMask());
				fileValStepVwkey.setStepId(fileValStepXref.getStepID());
				oldEntity = fileValStepXrefVwDAO.findOne(fileValStepVwkey);
				}
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldFileValStepXref.getReleaseNo());
				releaseArchiveKey.setReleaseId(fileValStepXref.getReleaseNo());
				releaseArchiveKey.setTableName("FileValStepXref");
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(fileValStepXrefKey));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldFileValStepXref));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					if(null!=oldEntity)
					{
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(fileValStepVwkey));
					}
					releaseArchiveDAO.create(releaseArchive);
				
				fileValStepXrefDAO.update(fileValStepXref);
			}
			
			else
			{
				fileValStepXrefDAO.create(fileValStepXref);
			}
		}
	}
	
	private void updateHeaderFooterCols(List<HeaderFooterCols> headerFooterColList) throws JsonProcessingException
	{
		for(HeaderFooterCols headerFooterCol : headerFooterColList)
		{
			Headerfootercolkey key = headerFooterCol.getHeaderFooterColKey();
			HeaderFooterCols oldHeaderFooterCol = headerFooterColsDAO.findOne(key);
			if(oldHeaderFooterCol!=null)
			{
				EntityFileTypeXrefVw entityFileTypeXrefVw = entityFileTypeXrefVwDAO.findOne(key.getEntityFileTypeId());
				HeaderFooterColVwKey headerFooterColVwKey = new HeaderFooterColVwKey();
				headerFooterColVwKey.setColumnID(key.getColumnID());
				headerFooterColVwKey.setEntityName(entityFileTypeXrefVw.getEntityName());
				headerFooterColVwKey.setFileMask(entityFileTypeXrefVw.getFileMask());
				headerFooterColVwKey.setHSFileType(entityFileTypeXrefVw.getHSFileType());
				headerFooterColVwKey.setRecType(key.getRecType());
				headerFooterColVwKey.setSeqNum(key.getSeqNum());
				HeaderFooterColsVw oldHeaderFooterColsVw = headerFooterColsVwDAO.findOne(headerFooterColVwKey);
				
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldHeaderFooterCol.getReleaseNo());
				releaseArchiveKey.setReleaseId(headerFooterCol.getReleaseNo());
				releaseArchiveKey.setTableName("HEADERFOOTERCOLS");
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(oldHeaderFooterCol.getHeaderFooterColKey()));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldHeaderFooterCol));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldHeaderFooterColsVw));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(headerFooterColVwKey));
					releaseArchiveDAO.create(releaseArchive);
				
				headerFooterColsDAO.update(headerFooterCol);
			}
			
			else
			{
				headerFooterColsDAO.create(headerFooterCol);
			}
		}
	}
	
	private void updateValidationStep(List<ValidationStep> validationStepList) throws JsonProcessingException
	{
		for(ValidationStep validationStep : validationStepList)
		{
			ValidationStep oldValidationStep = validationStepDAO.findOne(validationStep.getStepID());
			if(oldValidationStep!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldValidationStep.getReleaseNo());
				releaseArchiveKey.setReleaseId(validationStep.getReleaseNo());
				releaseArchiveKey.setTableName("VALIDATIONSTEP");
				ValidationStepId validationid = new ValidationStepId();
				validationid.setStepID(oldValidationStep.getStepID());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(validationid));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldValidationStep));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
				validationStepDAO.update(validationStep);
			}
			
			else
			{
				validationStepDAO.create(validationStep);
			}
		}
	}
	
	private void updateRuleType(List<RuleType> ruleTypeList) throws JsonProcessingException
	{
		for(RuleType ruleType : ruleTypeList)
		{
			RuleType oldRuleType = ruleTypeDAO.findOne(ruleType.getRuleTypeID());
			if(oldRuleType!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldRuleType.getReleaseNo());
				releaseArchiveKey.setReleaseId(ruleType.getReleaseNo());
				releaseArchiveKey.setTableName("RULETYPE");
				RuleTypeId ruleTypeId = new RuleTypeId();
				ruleTypeId.setRuleTypeID(oldRuleType.getRuleTypeID());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(ruleTypeId));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldRuleType));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
				ruleTypeDAO.update(ruleType);
			}
			
			else
			{
				ruleTypeDAO.create(ruleType);
			}
		}
	}
	
	private void updateHeaderFooter(List<HeaderFooter> headerFooterList) throws JsonProcessingException
	{
		for(HeaderFooter headerFooter : headerFooterList)
		{
			HeaderFooterKey headerFooterKey = headerFooter.getHeaderFooterKey();
			HeaderFooter oldHeaderFooter = headerFooterDAO.findOne(headerFooterKey);
			if(oldHeaderFooter!=null)
			{
				EntityFileTypeXrefVw entityFileTypeXrefVw = entityFileTypeXrefVwDAO.findOne(headerFooterKey.getEntityFileTypeID());
				HeaderFooterVwkey headerFooterVwkey = new HeaderFooterVwkey();
				headerFooterVwkey.setEntityName(entityFileTypeXrefVw.getEntityName());
				headerFooterVwkey.setFileMask(entityFileTypeXrefVw.getFileMask());
				headerFooterVwkey.setHSFileType(entityFileTypeXrefVw.getHSFileType());
				headerFooterVwkey.setRecType(headerFooterKey.getRecType());
				headerFooterVwkey.setSeqnum(headerFooterKey.getSeqNum());
				HeaderFooterVw oldHeaderFooterVw = headerFooterVwDAO.findOne(headerFooterVwkey);
				
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldHeaderFooter.getReleaseNo());
				releaseArchiveKey.setReleaseId(headerFooter.getReleaseNo());
				releaseArchiveKey.setTableName("HEADERFOOTER");
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(oldHeaderFooter.getHeaderFooterKey()));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldHeaderFooter));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldHeaderFooterVw));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(headerFooterVwkey));
					releaseArchiveDAO.create(releaseArchive);
				
				headerFooterDAO.update(headerFooter);
			}
			
			else
			{
				headerFooterDAO.create(headerFooter);
			}
		}
	}
	
	private void updateEntityFileTypeScheduleXref(List<EntityFileTypeScheduleXref> entityFileTypeSchedXrefList) throws JsonProcessingException
	{
		for(EntityFileTypeScheduleXref entityFileTypeSchedXref : entityFileTypeSchedXrefList)
		{
			EntityFileTypeScheduleXref oldEnFileTypeSchedXref =  entityFileTypeScheduleXrefDAO
					.findOne(entityFileTypeSchedXref.getEntityFileTypeSchedID());
			if(oldEnFileTypeSchedXref!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldEnFileTypeSchedXref.getReleaseNo());
				releaseArchiveKey.setReleaseId(entityFileTypeSchedXref.getReleaseNo());
				releaseArchiveKey.setTableName("EntityFileTypeScheduleXref");
				EntityFileTypeScheduleXrefId entityFileTypeScheduleXrefId = new EntityFileTypeScheduleXrefId();
				entityFileTypeScheduleXrefId.setEntityFileTypeSchedID(entityFileTypeSchedXref.getEntityFileTypeSchedID());
				EntityFileTypeScheduleXrefVw oldVIewEntity =entityFileTypeScheduleXrefVwDAO.findOne(entityFileTypeSchedXref.getEntityFileTypeSchedID());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityFileTypeScheduleXrefId));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEnFileTypeSchedXref));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldVIewEntity));
					releaseArchiveDAO.create(releaseArchive);
				
				entityFileTypeScheduleXrefDAO.update(entityFileTypeSchedXref);
			}
			
			else
			{
				entityFileTypeScheduleXrefDAO.create(entityFileTypeSchedXref);
			}
		}
	}
	private void updateSourceToTargetMapping(List<SourceToTargetMapping> sourceToTargetMappingList) throws JsonProcessingException
	{
		for(SourceToTargetMapping sourceToTargetMapping : sourceToTargetMappingList)
		{
			SourceToTargetMappingKey sourceToTargetMappingKey = sourceToTargetMapping.getSourceToTargetMappingKey();
			SourceToTargetMapping oldSourceToTargetMapping = sourceToTargetMappingDAO.findOne(sourceToTargetMappingKey);
			if(oldSourceToTargetMapping!=null)
			{
				SourceToTargetMappingVw oldEntity = sourceToTargetMappingVwDAO.getSourceToTargetMappingVwByTableID(sourceToTargetMappingKey.getSourceEntityFileTypeID(), sourceToTargetMappingKey.getTargetEntityFileTypeID(), sourceToTargetMappingKey.getTargetColumnID());
				SourceToTargetVwKey sourceToTargetVwKey= new SourceToTargetVwKey();
				if(null!=oldEntity)
				{
				sourceToTargetVwKey.setColumnID(oldEntity.getColumnID());
				sourceToTargetVwKey.setEntityName(oldEntity.getEntityName());
				sourceToTargetVwKey.setHSFileType(oldEntity.getHSFileType());
				sourceToTargetVwKey.setInputFileMask(oldEntity.getInputFileMask());
				sourceToTargetVwKey.setTargetEntityFileMask(oldEntity.getTargetEntityFileMask());
				sourceToTargetVwKey.setTargetEntityName(oldEntity.getTargetEntityName());
				}
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldSourceToTargetMapping.getReleaseNo());
				releaseArchiveKey.setReleaseId(sourceToTargetMapping.getReleaseNo());
				releaseArchiveKey.setTableName("SOURCETOTARGETMAPPING");
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(oldSourceToTargetMapping.getSourceToTargetMappingKey()));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldSourceToTargetMapping));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToTargetVwKey));
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
					releaseArchiveDAO.create(releaseArchive);
				
				sourceToTargetMappingDAO.update(sourceToTargetMapping);
			}
			
			else
			{
				sourceToTargetMappingDAO.create(sourceToTargetMapping);
			}
		}
	}
	
	private void updateEntityFileRecColumn(List<EntityFileRecColumn> entityFileRecColumnList) throws JsonProcessingException
	{
		for(EntityFileRecColumn entityFileRecColumn : entityFileRecColumnList)
		{
			EntityFileRecColumnKey entityFileRecColumnKey = entityFileRecColumn.getEntityFileRecColKey();
			EntityFileRecColumn oldEntityFileRecColumn = entityFileRecColumnDAO.findOne(entityFileRecColumnKey);
			if(oldEntityFileRecColumn!=null)
			{
				EntityFileTypeXrefVw entityFileTypeXrefVw = entityFileTypeXrefVwDAO.findOne(entityFileRecColumnKey.getEntityFileTypeID());
				EntityFileReccolVwkey entityFileReccolVwkey = new EntityFileReccolVwkey();
				entityFileReccolVwkey.setColumnID(entityFileRecColumnKey.getColumnID());
				entityFileReccolVwkey.setEntityName(entityFileTypeXrefVw.getEntityName());
				entityFileReccolVwkey.setHSFileType(entityFileTypeXrefVw.getHSFileType());
				entityFileReccolVwkey.setFileMask(entityFileTypeXrefVw.getFileMask());
				entityFileReccolVwkey.setEntityFileTypeID(entityFileRecColumnKey.getEntityFileTypeID());
				EntityFileRecColumnVw oldViewEntity = entityFileRecColumnVwDAO.findOne(entityFileReccolVwkey);

				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldEntityFileRecColumn.getReleaseNo());
				releaseArchiveKey.setReleaseId(entityFileRecColumn.getReleaseNo());
				releaseArchiveKey.setTableName("ENTITYFILERECCOLUMN");
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(oldEntityFileRecColumn.getEntityFileRecColKey()));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntityFileRecColumn));
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldViewEntity));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(entityFileReccolVwkey));
					
					releaseArchiveDAO.create(releaseArchive);
				
				entityFileRecColumnDAO.update(entityFileRecColumn);
			}
			
			else
			{
				entityFileRecColumnDAO.create(entityFileRecColumn);
			}
		}
	}
	
	private void updateEntityFileTypeXref(List<EntityFileTypeXref> entityFileTypeXrefList) throws JsonProcessingException
	{
		for(EntityFileTypeXref entityFileTypeXref : entityFileTypeXrefList)
		{
			EntityFileTypeXref oldEntityFileTypeXref = entityFileTypeXrefDAO.findOne(entityFileTypeXref.getEntityFileTypeID());
			if(oldEntityFileTypeXref!=null)
			{
				EntityFileTypeXrefVw oldViewEntity = entityFileTypeXrefVwDAO
						.findOne(entityFileTypeXref.getEntityFileTypeID());
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldEntityFileTypeXref.getReleaseNo());
				releaseArchiveKey.setReleaseId(entityFileTypeXref.getReleaseNo());
				releaseArchiveKey.setTableName("EntityFileTypeXref");
				EntityFileTypeXrefId entityFileTypeXrefId = new EntityFileTypeXrefId();
				entityFileTypeXrefId.setEntityFileTypeID(entityFileTypeXref.getEntityFileTypeID());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityFileTypeXrefId));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntityFileTypeXref));
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldViewEntity));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
				entityFileTypeXrefDAO.update(entityFileTypeXref);
			}
			
			else
			{
				entityFileTypeXrefDAO.create(entityFileTypeXref);
			}
		}
	}
	
	private void updateEntityMaster(List<EntityMaster> entityMasterList) throws JsonProcessingException
	{
		for(EntityMaster entityMaster : entityMasterList)
		{
			EntityMaster oldEntityMaster = entityMasterDAO.findOne(entityMaster.getEntityID());
			if(oldEntityMaster!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldEntityMaster.getReleaseNo());
				releaseArchiveKey.setReleaseId(entityMaster.getReleaseNo());
				releaseArchiveKey.setTableName("EntityMaster");
				EntityMasterId entityMasterId = new EntityMasterId();
				entityMasterId.setEntityID(oldEntityMaster.getEntityID());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityMasterId));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntityMaster));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
				entityMasterDAO.update(entityMaster);
			}
			
			else
			{
				entityMasterDAO.create(entityMaster);
			}
		}
	}
	
	private void updateFileType(List<HSFileType> fileTypeList) throws JsonProcessingException
	{
		for(HSFileType hsFileType : fileTypeList)
		{
			HSFileType oldHsFileType = fileTypeDAO.findOne(hsFileType.getFileTypeID());
			if(oldHsFileType!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldHsFileType.getReleaseNo());
				releaseArchiveKey.setReleaseId(hsFileType.getReleaseNo());
				releaseArchiveKey.setTableName("HSFileType");
				HSFileTypeId hsFileTypeId = new HSFileTypeId();
				hsFileTypeId.setFileTypeID(oldHsFileType.getFileTypeID());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(hsFileTypeId));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldHsFileType));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
				fileTypeDAO.update(hsFileType);
			}
			
			else
			{
				fileTypeDAO.create(hsFileType);
			}
		}
	}
	
	private void updateFileFormat(List<FileFormat> fileFormatList) throws JsonProcessingException
	{
		for(FileFormat fileFormat : fileFormatList)
		{
			FileFormat oldFileFormat = fileFormatDAO.findOne(fileFormat.getFileFormatID());
			if(oldFileFormat!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldFileFormat.getReleaseNo());
				releaseArchiveKey.setReleaseId(fileFormat.getReleaseNo());
				releaseArchiveKey.setTableName("FILEFORMAT");
				FileFormatId fileFormatId = new FileFormatId();
				fileFormatId.setFileFormatID(oldFileFormat.getFileFormatID());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(fileFormatId));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldFileFormat));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
				fileFormatDAO.update(fileFormat);
			}
			
			else
			{
				fileFormatDAO.create(fileFormat);
			}
		}
	}
	
	private void updateEntityType(List<EntityType> entityTypeList) throws JsonProcessingException
	{
		for(EntityType entityType : entityTypeList)
		{
			EntityType oldEntityType = entityTypeDAO.findOne(entityType.getEntityTypeID());
			if(oldEntityType!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldEntityType.getReleaseNo());
				releaseArchiveKey.setReleaseId(entityType.getReleaseNo());
				releaseArchiveKey.setTableName("ENTITYTYPE");
				EntityTypeId entityTypeId = new EntityTypeId();
				entityTypeId.setEntityTypeID(oldEntityType.getEntityTypeID());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityTypeId));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntityType));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
				entityTypeDAO.update(entityType);
			}
			
			else
			{
				entityTypeDAO.create(entityType);
			}
		}
	}
	
	
	
	private void updateDataStewardGroups(List<DataStewardGroups> DataStewardGroupsList) throws JsonProcessingException{
		for(DataStewardGroups dataStewardGroups : DataStewardGroupsList)
		{
			DataStewardGroupsKey key=new DataStewardGroupsKey();
			
			key.setUserName(dataStewardGroups.getDataStewardGroupsKey().getUserName());
			key.setGroupName(dataStewardGroups.getDataStewardGroupsKey().getGroupName());
			DataStewardGroups olddataStewardGroups = dataStewardGroupDAO.findOne(key);
			if(olddataStewardGroups!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(olddataStewardGroups.getReleaseNo());
				releaseArchiveKey.setReleaseId(dataStewardGroups.getReleaseNo());
				releaseArchiveKey.setTableName("DATASTEWARDGROUPS");
				DataStewardGroupsKey Id=new DataStewardGroupsKey();
				Id.setUserName(olddataStewardGroups.getDataStewardGroupsKey().getUserName());
				Id.setGroupName(olddataStewardGroups.getDataStewardGroupsKey().getGroupName());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(Id));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(olddataStewardGroups));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
					dataStewardGroupDAO.update(dataStewardGroups);
			}
			
			else
			{
				dataStewardGroupDAO.create(dataStewardGroups);
			}
		}
	}
	
	
	private void updateThreadPoolType(List<ThreadPoolType> threadPoolTypeList) throws JsonProcessingException{
		
			for(ThreadPoolType threadPoolType : threadPoolTypeList)
			{
				ThreadPoolType oldThreadPoolType = threadPoolTypeDAO.findOne(threadPoolType.getPoolid());
				if(oldThreadPoolType!=null)
				{
					ReleaseArchive releaseArchive = new ReleaseArchive();
					ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
					releaseArchiveKey.setArchivedReleaseId(oldThreadPoolType.getReleaseNo());
					releaseArchiveKey.setReleaseId(threadPoolType.getReleaseNo());
					releaseArchiveKey.setTableName("THREADPOOLTYPE");
					ThreadPoolTypeId PoolTypeId  = new ThreadPoolTypeId();
					PoolTypeId.setPoolid(oldThreadPoolType.getPoolid());
						releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(PoolTypeId));
						releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
						releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldThreadPoolType));
						releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
						releaseArchiveDAO.create(releaseArchive);
					
						threadPoolTypeDAO.update(threadPoolType);
				}
				
				else
				{
					threadPoolTypeDAO.create(threadPoolType);
				}
			}
	}
	
	
	private void updateThreadThreadPoolXref(List<ThreadThreadPoolXref> threadThreadPoolXrefList) throws JsonProcessingException{
		for(ThreadThreadPoolXref threadThreadPoolXref : threadThreadPoolXrefList)
		{
			ThreadThreadPoolXrefKey key=new ThreadThreadPoolXrefKey();
			
			key.setPoolid(threadThreadPoolXref.getThreadThreadPoolXrefKey().getPoolid());
			key.setThread(threadThreadPoolXref.getThreadThreadPoolXrefKey().getThread());
			ThreadThreadPoolXref oldThreadThreadPoolXref = threadThreadPoolXrefDAO.findOne(key);
			if(oldThreadThreadPoolXref!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldThreadThreadPoolXref.getReleaseNo());
				releaseArchiveKey.setReleaseId(threadThreadPoolXref.getReleaseNo());
				releaseArchiveKey.setTableName("THREADTHREADPOOLXREF");
				ThreadThreadPoolXrefKey Id=new ThreadThreadPoolXrefKey();
				Id.setPoolid(threadThreadPoolXref.getThreadThreadPoolXrefKey().getPoolid());
				Id.setThread(threadThreadPoolXref.getThreadThreadPoolXrefKey().getThread());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(Id));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldThreadThreadPoolXref));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
					threadThreadPoolXrefDAO.update(threadThreadPoolXref);
			}
			
			else
			{
				threadThreadPoolXrefDAO.create(threadThreadPoolXref);
			}
		}
	}
	
	
	private void updateEntityFileTypeStepChunk(List<EntityFileTypeStepChunk> entityFileTypeStepChunkList) throws JsonProcessingException{
		for(EntityFileTypeStepChunk entityFileTypeStepChunk : entityFileTypeStepChunkList)
		{
			EntityFileTypeStepChunkKey key=new EntityFileTypeStepChunkKey();
			
			key.setEntityFileTypeId(entityFileTypeStepChunk.getEntityFileTypeStepChunkKey().getEntityFileTypeId());
			key.setStepID(entityFileTypeStepChunk.getEntityFileTypeStepChunkKey().getStepID());
			EntityFileTypeStepChunk oldEntityFileTypeStepChunk = entityFileTypeStepChunkDAO.findOne(key);
			if(oldEntityFileTypeStepChunk!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldEntityFileTypeStepChunk.getReleaseNo());
				releaseArchiveKey.setReleaseId(entityFileTypeStepChunk.getReleaseNo());
				releaseArchiveKey.setTableName("ENTITYFILETYPESTEPCHUNK");
				EntityFileTypeStepChunkKey Id=new EntityFileTypeStepChunkKey();
				Id.setEntityFileTypeId(entityFileTypeStepChunk.getEntityFileTypeStepChunkKey().getEntityFileTypeId());
				Id.setStepID(entityFileTypeStepChunk.getEntityFileTypeStepChunkKey().getStepID());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(Id));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntityFileTypeStepChunk));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
					entityFileTypeStepChunkDAO.update(entityFileTypeStepChunk);
			}
			
			else
			{
				entityFileTypeStepChunkDAO.create(entityFileTypeStepChunk);
			}
		}
	}
	

	private void updateEmptyFileConfig(List<EmptyFileConfig> EmptyFileConfigList) throws JsonProcessingException
	{
		for(EmptyFileConfig emptyFileConfig : EmptyFileConfigList)
		{
			EmptyFileConfig oldEmptyFileConfig = emptyFileConfigDAO.findOne(emptyFileConfig.getEmptyFileConfigID());
			if(oldEmptyFileConfig!=null)
			{
				ReleaseArchive releaseArchive = new ReleaseArchive();
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldEmptyFileConfig.getReleaseNo());
				releaseArchiveKey.setReleaseId(emptyFileConfig.getReleaseNo());
				releaseArchiveKey.setTableName("EMPTYFILECONFIG");
				EmptyFileConfigId emptyFileConfigId = new EmptyFileConfigId();
				emptyFileConfigId.setEmptyFileConfigID(oldEmptyFileConfig.getEmptyFileConfigID());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(emptyFileConfigId));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEmptyFileConfig));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchiveDAO.create(releaseArchive);
				
					emptyFileConfigDAO.update(emptyFileConfig);
			}
			
			else
			{
				emptyFileConfigDAO.create(emptyFileConfig);
			}
		}
	}
	
	
	
	/**
	 * This method is used to get release archive table record data.
	 * if @param release id is null,we are getting all table name data.
	 */
	@Override
	@Transactional(readOnly = true)
	public List<?> getReleaseArchiveRecordData(Integer releaseId, String tableName) {
		try {
			
			List<String> archiveRecDataList = releaseArchiveDAO.getReleaseArchiveRecData(releaseId, tableName);
			switch (tableName) {
			case "ENTITYTYPE":
				List<EntityType> entityTypes = new ArrayList<EntityType>();
				for (String releaseRecData : archiveRecDataList) {
					entityTypes.add(AppWebUtils.convertJsonToObject(EntityType.class, releaseRecData));
				}
				return entityTypes;
			case "FILEFORMAT":
				List<FileFormat> fileFormats = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					fileFormats.add(AppWebUtils.convertJsonToObject(FileFormat.class, releaseRecData));
				}
				return fileFormats;
			case "HSFileType":
				List<HSFileType> fileTypes = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					fileTypes.add(AppWebUtils.convertJsonToObject(HSFileType.class, releaseRecData));
				}
				return fileTypes;
			case "ENTITYMASTER":
				List<EntityMaster> entityMasters = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityMasters.add(AppWebUtils.convertJsonToObject(EntityMaster.class, releaseRecData));
				}
				return entityMasters;
			case "ENTITYFILETYPEXREF":
				List<EntityFileTypeXref> entityFileTypeXrefList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileTypeXrefList.add(AppWebUtils.convertJsonToObject(EntityFileTypeXref.class, releaseRecData));
				}
				return entityFileTypeXrefList;
			case "ENTITYFILERECCOLUMN":
				List<EntityFileRecColumn> entityFileRecColumnList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileRecColumnList.add(AppWebUtils.convertJsonToObject(EntityFileRecColumn.class, releaseRecData));
				}
				return entityFileRecColumnList;
			case "SOURCETOTARGETMAPPING":
				List<SourceToTargetMapping> sourceToTargetMappingList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					sourceToTargetMappingList.add(AppWebUtils.convertJsonToObject(SourceToTargetMapping.class, releaseRecData));
				}
				return sourceToTargetMappingList;
			case "EntityFileTypeScheduleXref":
				List<EntityFileTypeScheduleXref> entityFileTypeScheduleXrefs = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileTypeScheduleXrefs.add(AppWebUtils.convertJsonToObject(EntityFileTypeScheduleXref.class, releaseRecData));
				}
				return entityFileTypeScheduleXrefs;
			case "HEADERFOOTER":
				List<HeaderFooter> headerFooters = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					headerFooters.add(AppWebUtils.convertJsonToObject(HeaderFooter.class, releaseRecData));
				}
				return headerFooters;
			case "HEADERFOOTERCOLS":
				List<HeaderFooterCols> headerFooterCols = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					headerFooterCols.add(AppWebUtils.convertJsonToObject(HeaderFooterCols.class, releaseRecData));
				}
				return headerFooterCols;
			case "RULETYPE":
				List<RuleType> ruleTypes = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					ruleTypes.add(AppWebUtils.convertJsonToObject(RuleType.class, releaseRecData));
				}
				return ruleTypes;

			case "VALIDATIONSTEP":
				List<ValidationStep> validationSteps = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					validationSteps.add(AppWebUtils.convertJsonToObject(ValidationStep.class, releaseRecData));
				}

				return validationSteps;
			case "VALIDATIONRULE":
				List<EntityFileValidationRuleVw> entityFileValidationRuleVws = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					ValidationRulesInfoTO validationRulesInfo=AppWebUtils.convertJsonToObject(ValidationRulesInfoTO.class, releaseRecData);
					if(validationRulesInfo!=null){
						entityFileValidationRuleVws.addAll(validationRulesInfo.getEntityFileValidationRuleList());
					}
				}
				return entityFileValidationRuleVws;

			case "FILEVALSTEPXREF":
				List<FileValStepXref> fileValStepXrefs = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					fileValStepXrefs.add(AppWebUtils.convertJsonToObject(FileValStepXref.class, releaseRecData));
				}
				return fileValStepXrefs;
			case "WEBSERVICERECCOLUMN":
				List<WebServiceRecColumn> webServiceRecColumns = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					webServiceRecColumns.add(AppWebUtils.convertJsonToObject(WebServiceRecColumn.class, releaseRecData));
				}
				return webServiceRecColumns;
			case "SOURCETOWEBSERVICEMAPPING":
				List<SourceToWebServiceMapping> sourceToWebServiceMappings = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					sourceToWebServiceMappings
							.add(AppWebUtils.convertJsonToObject(SourceToWebServiceMapping.class, releaseRecData));
				}
				return sourceToWebServiceMappings;
			case "SOURCETOSERVICECRITERIA":
				List<SourceToServiceCriteria> sourceToServiceCriteria = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					sourceToServiceCriteria.add(AppWebUtils.convertJsonToObject(SourceToServiceCriteria.class, releaseRecData));
				}
				return sourceToServiceCriteria;
			case "SOURCETOTARGETSPLIT":
				List<SourceToTargetSplit> sourceToTargetSplits = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					sourceToTargetSplits.add(AppWebUtils.convertJsonToObject(SourceToTargetSplit.class, releaseRecData));
				}
				return sourceToTargetSplits;	
			case "ENTITYFILETYPEQUERIES":
				List<EntityFileTypeQueries> entityFileTypeQueries = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileTypeQueries.add(AppWebUtils.convertJsonToObject(EntityFileTypeQueries.class, releaseRecData));
				}
				return entityFileTypeQueries;
			case "ENTITYFILETYPEWEBSERVICE":
				List<EntityFileTypeWebService> entityFileTypeWebServices = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileTypeWebServices.add(AppWebUtils.convertJsonToObject(EntityFileTypeWebService.class, releaseRecData));
				}
				return entityFileTypeWebServices;
				
			case "DATASTEWARDGROUPS":
				List<DataStewardGroups> dataStewardGroups = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					dataStewardGroups.add(AppWebUtils.convertJsonToObject(DataStewardGroups.class, releaseRecData));
				}
				return dataStewardGroups;
				
				
			case "THREADPOOLTYPE":
				List<ThreadPoolType> threadPoolType = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					threadPoolType.add(AppWebUtils.convertJsonToObject(ThreadPoolType.class, releaseRecData));
				}
				return threadPoolType;
				
			case "THREADTHREADPOOLXREF":
				List<ThreadThreadPoolXref> threadThreadPoolXref = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					threadThreadPoolXref.add(AppWebUtils.convertJsonToObject(ThreadThreadPoolXref.class, releaseRecData));
				}
				return threadThreadPoolXref;
				
			case "ENTITYFILETYPESTEPCHUNK":
				List<EntityFileTypeStepChunk> entityFileTypeStepChunk = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileTypeStepChunk.add(AppWebUtils.convertJsonToObject(EntityFileTypeStepChunk.class, releaseRecData));
				}
				return entityFileTypeStepChunk;
				
			case "EMPTYFILECONFIG":
				List<EmptyFileConfig> emptyFileConfig = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					emptyFileConfig.add(AppWebUtils.convertJsonToObject(EmptyFileConfig.class, releaseRecData));
				}
				return emptyFileConfig;
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<?> getReleaseArchiveViewRecordData(Integer releaseId, String tableName) {
		try {
			List<String> archiveRecDataList = releaseArchiveDAO.getReleaseArchiveViewRecData(releaseId, tableName);
			archiveRecDataList.remove(null);

			switch (tableName) {
			case "ENTITYFILETYPEXREF":
				List<EntityFileTypeXrefVw> entityFileTypeXrefVwList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileTypeXrefVwList.add(AppWebUtils.convertJsonToObject(EntityFileTypeXrefVw.class, releaseRecData));
				}
				return entityFileTypeXrefVwList;
			case "ENTITYFILERECCOLUMN":
				List<EntityFileRecColumnVw> entityFileRecColumnVwList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileRecColumnVwList.add(AppWebUtils.convertJsonToObject(EntityFileRecColumnVw.class, releaseRecData));
				}
				return entityFileRecColumnVwList;
			case "SOURCETOTARGETMAPPING":
				List<SourceToTargetMappingVw> sourceToTargetMappingVwList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					sourceToTargetMappingVwList.add(AppWebUtils.convertJsonToObject(SourceToTargetMappingVw.class, releaseRecData));
				}
				return sourceToTargetMappingVwList;
			case "EntityFileTypeScheduleXref":
				List<EntityFileTypeScheduleXrefVw> entityFileTypeScheduleXrefVws = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileTypeScheduleXrefVws.add(AppWebUtils.convertJsonToObject(EntityFileTypeScheduleXrefVw.class, releaseRecData));
				}
				return entityFileTypeScheduleXrefVws;
			case "HEADERFOOTER":
				List<HeaderFooterVw> headerFooterVws = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					headerFooterVws.add(AppWebUtils.convertJsonToObject(HeaderFooterVw.class, releaseRecData));
				}
				return headerFooterVws;
			case "HEADERFOOTERCOLS":
				List<HeaderFooterColsVw> headerFooterColsVws = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					headerFooterColsVws.add(AppWebUtils.convertJsonToObject(HeaderFooterColsVw.class, releaseRecData));
				}
				return headerFooterColsVws;
			case "FILEVALSTEPXREF":
				List<FileValStepXrefVw> fileValStepXrefVws = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					fileValStepXrefVws.add(AppWebUtils.convertJsonToObject(FileValStepXrefVw.class, releaseRecData));
				}
				return fileValStepXrefVws;
			case "WEBSERVICERECCOLUMN":
				List<WebServiceRecColumnVw> webServiceRecColumnVwList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					webServiceRecColumnVwList.add(AppWebUtils.convertJsonToObject(WebServiceRecColumnVw.class, releaseRecData));
				}
				return webServiceRecColumnVwList;
			case "SOURCETOWEBSERVICEMAPPING":
				List<SourceToWebServiceMappingVw> sourceToWebServiceMappingVwList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					sourceToWebServiceMappingVwList
							.add(AppWebUtils.convertJsonToObject(SourceToWebServiceMappingVw.class, releaseRecData));
				}
				return sourceToWebServiceMappingVwList;
			case "SOURCETOSERVICECRITERIA":
				List<SourceToServiceCriteriaVw> sourceToServiceCriteriaVwList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					sourceToServiceCriteriaVwList.add(AppWebUtils.convertJsonToObject(SourceToServiceCriteriaVw.class, releaseRecData));
				}
				return sourceToServiceCriteriaVwList;
			case "SOURCETOTARGETSPLIT":
				List<SourceToTargetSplitVw> sourceToTargetSplitVwList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					sourceToTargetSplitVwList.add(AppWebUtils.convertJsonToObject(SourceToTargetSplitVw.class, releaseRecData));
				}
				return sourceToTargetSplitVwList;	
			case "ENTITYFILETYPEQUERIES":
				List<EntityFileTypeQueriesVw> entityFileTypeQueriesVwList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileTypeQueriesVwList.add(AppWebUtils.convertJsonToObject(EntityFileTypeQueriesVw.class, releaseRecData));
				}
				return entityFileTypeQueriesVwList;
			case "ENTITYFILETYPEWEBSERVICE":
				List<EntityFileTypeWebServiceVw> entityFileTypeWebServiceVwList = new ArrayList<>();
				for (String releaseRecData : archiveRecDataList) {
					entityFileTypeWebServiceVwList.add(AppWebUtils.convertJsonToObject(EntityFileTypeWebServiceVw.class, releaseRecData));
				}
				return entityFileTypeWebServiceVwList;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	@Transactional(readOnly = true)
	public Set<Integer> getArchiveTableReleaseInfo(Integer releaseId, String tableName, Set<String> primaryKeys) {
		Set<Integer> archiveIds = new HashSet<>();
		List<String> primaryKeysList = new ArrayList<>(primaryKeys);
		if(primaryKeys.size()>=2001){
			archiveIds.addAll(releaseArchiveDAO.getArchiveTableReleaseInfo(releaseId, tableName, primaryKeysList.subList(0, 2000)));
			archiveIds.addAll(releaseArchiveDAO.getArchiveTableReleaseInfo(releaseId, tableName, primaryKeysList.subList(2000,primaryKeysList.size())));
			return archiveIds;
		}else{
		archiveIds.addAll(releaseArchiveDAO.getArchiveTableReleaseInfo(releaseId, tableName, primaryKeysList));
		}
		return archiveIds;
	}
	

	@Override
	@Transactional(readOnly = true)
	public void loadValidationRuleReleaseData(Integer releaseId,List<ValidationRuleDetailsInfoTO> validationRuleDetailsInfoTOs) throws Exception{
		List<String> archiveRecDataList = releaseArchiveDAO.getReleaseArchiveRecData(releaseId, "VALIDATIONRULE");
		for(String archiveRecData :archiveRecDataList){
			ValidationRulesInfoTO validationRulesInfoTO = AppWebUtils.convertJsonToObject(ValidationRulesInfoTO.class, archiveRecData);
			if(validationRulesInfoTO!=null){
				ValidationRuleDetailsInfoTO validationRuleDetailsInfoTO= new ValidationRuleDetailsInfoTO();
				List<EntityFileValidationRuleVw> entityFileValidationRuleList = validationRulesInfoTO.getEntityFileValidationRuleList();
				List<EntityFileValidationRule> entityFileValidationRules =validationRulesInfoTO.getEntityFileValidationRules();
				List<EntityFileRuleXref> entityFileRuleXrefs = validationRulesInfoTO.getEntityFileRuleXrefs();
				List<EntityFileRuleParam> entityFileRuleParams = validationRulesInfoTO.getEntityFileRuleParams();
				
				if(!entityFileValidationRuleList.isEmpty()){
					validationRuleDetailsInfoTO.setEntityFileValidationRuleVw(entityFileValidationRuleList.get(0));
				}if(!entityFileValidationRules.isEmpty()){
					validationRuleDetailsInfoTO.setEntityFileValidationRule(entityFileValidationRules.get(0));
				}if(!entityFileRuleXrefs.isEmpty()){
					validationRuleDetailsInfoTO.setEntityFileRuleXref(entityFileRuleXrefs.get(0));
				}if(!entityFileRuleParams.isEmpty()){
					validationRuleDetailsInfoTO.setEntityFileRuleParams(entityFileRuleParams);
				}
				validationRuleDetailsInfoTOs.add(validationRuleDetailsInfoTO);
			}
		}
	}
	
	@Override
	@Transactional(readOnly = true)
	public ReleasePackages getReleasePackageList(Integer releaseId, String releaseName) {
		return releasePackageDAO.getReleasePackageList(releaseId,releaseName);
	}
	
	@Override
	@Transactional(readOnly = true)
	public Set<Integer> getAllReleaseLogicalDependencies(Integer selectedReleasePackageId){
		Set<Integer> allLogicalDependencies = new HashSet<>();
		allLogicalDependencies.addAll(entityTypeDAO.getAllEntityTypeReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(fileFormatDAO.getAllFileFormatReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(fileTypeDAO.getAllFileTypeReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(entityMasterDAO.getAllEntityMasterReleaseIds(selectedReleasePackageId));
		allLogicalDependencies
				.addAll(entityFileTypeXrefDAO.getAllEntityFileTypeXrefReleaseIds(selectedReleasePackageId));
		allLogicalDependencies
				.addAll(entityFileRecColumnDAO.getAllEntityFileRecColumnReleaseIds(selectedReleasePackageId));
		allLogicalDependencies
				.addAll(sourceToTargetMappingDAO.getAllSourceToTargetMappingReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(
				entityFileTypeScheduleXrefDAO.getAllEntityFileTypeSchXrefReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(headerFooterDAO.getAllHeaderFooterReleaseIds(selectedReleasePackageId));
		allLogicalDependencies
				.addAll(headerFooterColsDAO.getAllHeaderFooterColsReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(ruleTypeDAO.getAllRuleTypeReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(validationStepDAO.getAllValidationStepReleaseIds(selectedReleasePackageId));
		allLogicalDependencies
				.addAll(entityFileValidationRuleVwDAO.getAllEntityFileValRuleReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(fileValStepXrefDAO.getAllFileValStepXrefReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(webServiceRecColumnDAO.getAllWebServiceRecColReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(sourceToTargetSplitDAO.getAllSourceToTargetSplitReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(sourceToWebServiceMappingDAO.getAllSourceToWebServiceMappingReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(sourceToServiceCriteriaDAO.getAllSourceToServiceCriteriaReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(entityFileTypeQueriesDAO.getAllEntityFileTypeQueriesReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(entityFileTypeWebServiceDAO.getAllEntityFileTypeWebServiceReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(dataStewardGroupDAO.getAllDatastewardgroupsReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(threadPoolTypeDAO.getAllThreadPoolTypeReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(threadThreadPoolXrefDAO.getAllThreadThreadPoolXrefReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(entityFileTypeStepChunkDAO.getAllEntityFileTypeStepChunkReleaseIds(selectedReleasePackageId));
		allLogicalDependencies.addAll(emptyFileConfigDAO.getAllEmptyFileConfigReleaseIds(selectedReleasePackageId));
		return allLogicalDependencies;
	}
	
	@Override
	public Set<Integer> getBaseReleases(String parametars) {
		return releaseArchiveDAO.getBaseReleases(parametars);
	}
	@Override
	public Map<String, Integer> getBaseReleasesAndPksMap(String parametars) {
		return releaseArchiveDAO.getBaseReleasesAndPksMap(parametars);
	}
	
	public List<String> getTablesListInArchiveByReleaseNo(Integer releaseId)
	{
		return releaseArchiveDAO.getTablesListInArchiveByReleaseNo(releaseId);
	}
}
