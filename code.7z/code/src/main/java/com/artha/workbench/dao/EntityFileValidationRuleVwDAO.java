package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EntityFileValidationRuleVw;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityFileValidationRuleVwDAO extends BaseDAO<EntityFileValidationRuleVw, Integer> {

	public void saveEntityFileValidationRuleVw(List<EntityFileValidationRuleVw> entitytypes);

	public int getmaxEfvrid();

	public List<EntityFileValidationRuleVw> getEntityFileValRuleVwListByReleaseNo(Integer releaseNo);

	List<Integer> getAllEntityFileValRuleReleaseIds(Integer selectedReleaseId);
}
