package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.DateUtils;


@Entity
@Table(name = "metastore.sourcetotargetmapping_v")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@IdClass(SourceToTargetVwKey.class)
public class SourceToTargetMappingVw extends AbstractModel {
	private static final long serialVersionUID = 1L;
	
	@Id 
	@Column(name = "InputFileMask", nullable = false)
	@JsonProperty("InputFileMask")
	private String InputFileMask;
	
	@JsonProperty("sourceEntityFileTypeID")
	private Integer sourceEntityFileTypeID;
	
	@JsonProperty("targetEntityFileTypeID")
	private Integer targetEntityFileTypeID;
	
	@JsonProperty("EntityName")
	private String EntityName;
	
	@JsonProperty("HSFileType")
	private String HSFileType;
	
	@JsonProperty("TargetEntityFileMask")
	private String TargetEntityFileMask;
	
	@JsonProperty("TargetEntityName")
	private String TargetEntityName;
	
	@JsonProperty("ColumnID")
	private Integer ColumnID;
	
	@JsonProperty("MapFunction")
	private String MapFunction;
	
	@JsonProperty("Active")
	private String Active;
	
	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date EffectiveDate;
	
	@JsonProperty("TargetColOrder")
	private Integer TargetColOrder;
	
	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Transient
	@JsonIgnore
	private String Comments;
	
	@Transient
	@JsonIgnore
	private String effectiveDtstr;
	
	@Transient
	@JsonIgnore
	private boolean addMode;
	
	
	@Transient
	@JsonIgnore
	private Integer SourceEntityID;
	
	@Transient
	@JsonIgnore
	private Integer SourceFileTypeID;
	
	@Transient
	@JsonIgnore
	private Integer TargetEntityID;
	
	@Transient
	@JsonIgnore
	private Integer TargetFileTypeID;
	
	public SourceToTargetMappingVw(boolean addMode,Date effectiveDate,Integer releaseNo) {
		this.EffectiveDate = effectiveDate;
		this.addMode = addMode;
		this.releaseNo = releaseNo;
		convertEffectiveDate();
	}
	public SourceToTargetMappingVw() {
	}
	public boolean isAddMode() {
		return addMode;
	}
	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}
	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}
	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}
	
	public String getInputFileMask() {
		return InputFileMask;
	}
	
	public void setInputFileMask(String inputFileMask) {
		InputFileMask = inputFileMask;
	}
	
	public String getEntityName() {
		return EntityName;
	}
	
	public void setEntityName(String entityName) {
		EntityName = entityName;
	}
	
	public String getHSFileType() {
		return HSFileType;
	}
	
	public void setHSFileType(String hSFileType) {
		HSFileType = hSFileType;
	}
	
	public String getTargetEntityFileMask() {
		return TargetEntityFileMask;
	}
	
	public void setTargetEntityFileMask(String targetEntityFileMask) {
		TargetEntityFileMask = targetEntityFileMask;
	}
	
	public String getTargetEntityName() {
		return TargetEntityName;
	}
	
	public void setTargetEntityName(String targetEntityName) {
		TargetEntityName = targetEntityName;
	}
	
	public Integer getColumnID() {
		return ColumnID;
	}
	
	public void setColumnID(Integer columnID) {
		ColumnID = columnID;
	}
	
	public String getMapFunction() {
		return MapFunction;
	}
	
	public void setMapFunction(String mapFunction) {
		MapFunction = mapFunction;
	}
	
	public String getActive() {
		return Active;
	}
	
	public void setActive(String active) {
		Active = active;
	}
	
	public Date getEffectiveDate() {
		return EffectiveDate;
	}
	
	public void setEffectiveDate(Date effectiveDate) {
		EffectiveDate = effectiveDate;
	}
	
	public Integer getTargetColOrder() {
		return TargetColOrder;
	}
	
	public void setTargetColOrder(Integer targetColOrder) {
		TargetColOrder = targetColOrder;
	}
	
	public String getComments() {
		return Comments;
	}
	
	public void setComments(String comments) {
		Comments = comments;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Integer getSourceEntityID() {
		return SourceEntityID;
	}
	public void setSourceEntityID(Integer sourceEntityID) {
		SourceEntityID = sourceEntityID;
	}
	public Integer getSourceFileTypeID() {
		return SourceFileTypeID;
	}
	public void setSourceFileTypeID(Integer sourceFileTypeID) {
		SourceFileTypeID = sourceFileTypeID;
	}
	public Integer getTargetEntityID() {
		return TargetEntityID;
	}
	public void setTargetEntityID(Integer targetEntityID) {
		TargetEntityID = targetEntityID;
	}
	public Integer getTargetFileTypeID() {
		return TargetFileTypeID;
	}
	public void setTargetFileTypeID(Integer targetFileTypeID) {
		TargetFileTypeID = targetFileTypeID;
	}
	public Integer getSourceEntityFileTypeID() {
		return sourceEntityFileTypeID;
	}
	public void setSourceEntityFileTypeID(Integer sourceEntityFileTypeID) {
		this.sourceEntityFileTypeID = sourceEntityFileTypeID;
	}
	public Integer getTargetEntityFileTypeID() {
		return targetEntityFileTypeID;
	}
	public void setTargetEntityFileTypeID(Integer targetEntityFileTypeID) {
		this.targetEntityFileTypeID = targetEntityFileTypeID;
	}
	
	public Integer getReleaseNo() {
		return releaseNo;
	}
	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}
	@PostLoad
	public void postLoad(){
		convertEffectiveDate();
	}
	public void convertEffectiveDate(){
		this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());	
	}
	
	
}
