package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.EntityFileTypeStepChunk;
import com.artha.workbench.models.metastore.EntityFileTypeStepChunkKey;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class EntityFileTypeStepChunkDAOImpl extends BaseDAOImpl<EntityFileTypeStepChunk, EntityFileTypeStepChunkKey>
		implements EntityFileTypeStepChunkDAO {

	public EntityFileTypeStepChunkDAOImpl() {
		super(EntityFileTypeStepChunk.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<EntityFileTypeStepChunk> getEntityFileTypeStepChunByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileTypeStepChunk> query = cb.createQuery(EntityFileTypeStepChunk.class);
		Root<EntityFileTypeStepChunk> root = query.from(EntityFileTypeStepChunk.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}

	@Override
	@Transactional
	public List<Integer> getAllEntityFileTypeStepChunkReleaseIds(Integer selectedReleaseId) {
		TypedQuery<Integer> query = entityManager.createQuery(
				"select distinct releaseNo from EntityFileTypeStepChunk where releaseNo !=:releaseNo", Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}

}
