package com.artha.workbench.service;

import java.util.HashMap;


public interface TaskTypeService {

	 public HashMap<Integer,String> loadtaskType();
}
