package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.HeaderFooterCols;
import com.artha.workbench.models.metastore.Headerfootercolkey;
import com.guvvala.framework.dao.BaseDAO;



public interface HeaderFooterColsDAO extends BaseDAO<HeaderFooterCols, Headerfootercolkey> {
	public void saveHeaderFooterCol(List<HeaderFooterCols> entitytypes);

	public void deleteHeaderFooterCol();

	public List<HeaderFooterCols> getHeadeFooterColsListByReleaseNo(Integer releaseNo);

	List<Integer> getAllHeaderFooterColsReleaseIds(Integer selectedReleaseId);
}
