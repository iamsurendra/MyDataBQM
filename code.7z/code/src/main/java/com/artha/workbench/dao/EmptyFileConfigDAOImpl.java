package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.EmptyFileConfig;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class EmptyFileConfigDAOImpl extends BaseDAOImpl<EmptyFileConfig, Integer> implements EmptyFileConfigDAO {

	public EmptyFileConfigDAOImpl() {
		super(EmptyFileConfig.class);
	}

	public int getmaxEmptyFileConfig() {
		int loginid = 0;
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(emptyFileConfigID) from EmptyFileConfig",
				Integer.class);
		if (query.getSingleResult() != null)
			loginid = query.getSingleResult();
		return loginid;
	}

	@Transactional
	public void saveEmptyFileConfig(List<EmptyFileConfig> emptyFileConfig) {
		batchCreate(emptyFileConfig, 50);

	}

	public void deleteEmptyFileConfig() {
		Query query = entityManager.createQuery("delete from EmptyFileConfig");
		query.executeUpdate();
	}
	
	
	@Override
	public List<EmptyFileConfig> getEmptyFileConfigByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EmptyFileConfig> query = cb.createQuery(EmptyFileConfig.class);
		Root<EmptyFileConfig> root = query.from(EmptyFileConfig.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	
	@Override
	@Transactional
	public List<Integer> getAllEmptyFileConfigReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from EmptyFileConfig where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}


}
