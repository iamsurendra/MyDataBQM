package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.EntityFileTypeWebService;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityFileTypeWebServiceDAO extends BaseDAO<EntityFileTypeWebService, Integer> {
	
	public int getmaxWebService();
	
	public List<Integer> getWebServiceIds();
	
	public List<EntityFileTypeWebService> getEntityFileTypeWebServicefList(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber);
	
	public List<EntityFileTypeWebService> getEntityFileTypeWebServiceListByReleaseNo(Integer releaseNo);
	
	List<Integer> getAllEntityFileTypeWebServiceReleaseIds(Integer selectedReleaseId);

}
