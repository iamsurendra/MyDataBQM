package com.artha.workbench.service;


import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.EntityMasterDAO;
import com.artha.workbench.dao.FileTypeDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.SourceToTargetMappingDAO;
import com.artha.workbench.dao.SourceToTargetMappingVwDAO;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.models.metastore.SourceToTargetMapping;
import com.artha.workbench.models.metastore.SourceToTargetMappingKey;
import com.artha.workbench.models.metastore.SourceToTargetMappingVw;
import com.artha.workbench.models.metastore.SourceToTargetVwKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("sourceToTargetMappingService")
public class SourceToTargetMappingServiceImpl implements SourceToTargetMappingService {

	@Autowired
	SourceToTargetMappingDAO sourceToTargetMappingDAO;
	
	@Autowired
	SourceToTargetMappingVwDAO sourceToTargetMappingVwDAO;
	
	@Autowired
	EntityMasterDAO entityMasterDAO;
	
	@Autowired
	FileTypeDAO fileTypeDAO;
	
	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefdbDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;
	
	@Transactional(readOnly = true)
	public List<SourceToTargetMapping> getSourceToTargetMappingList() {
		return sourceToTargetMappingDAO.findAll();
	}
	
	@Transactional(readOnly = true)
	public List<SourceToTargetMappingVw> getSourceToTargetMappingVwByReleaseNo(Integer releaseNo){
		return sourceToTargetMappingVwDAO.getSourceToTargetMappingVwByReleaseNo(releaseNo);
	}
	
	@Transactional(readOnly = true)
	@Override
	public SourceToTargetMappingVw getPreviousSourceToTargetMappingVw(SourceToTargetMappingVw sourceToTargetMappingVw) throws IOException
	{
		SourceToTargetMappingKey sourceToTargetMappingKey = new SourceToTargetMappingKey();
		sourceToTargetMappingKey.setSourceEntityFileTypeID(sourceToTargetMappingVw.getSourceEntityFileTypeID());
		sourceToTargetMappingKey.setTargetEntityFileTypeID(sourceToTargetMappingVw.getTargetEntityFileTypeID());
		sourceToTargetMappingKey.setTargetColumnID(sourceToTargetMappingVw.getColumnID());
		String sourceToTargetVwKeyIdJson = AppWebUtils.convertObjectToJson(sourceToTargetMappingKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(sourceToTargetMappingVw.getReleaseNo(), "SOURCETOTARGETMAPPING", sourceToTargetVwKeyIdJson);
		SourceToTargetMappingVw previousSourceToTargetMappingVw = new SourceToTargetMappingVw();
		if(releaseArchive!=null){
		previousSourceToTargetMappingVw = AppWebUtils.convertJsonToObject(SourceToTargetMappingVw.class, releaseArchive.getViewRecData());
		}
		return previousSourceToTargetMappingVw;
		
	}

	@Transactional
	public void create(SourceToTargetMappingVw sourceToTargetMappingVw) {
		SourceToTargetMapping sourceToTargetMapping = new SourceToTargetMapping();
		SourceToTargetMappingKey sourceToTargetMappingKey = new SourceToTargetMappingKey();
		sourceToTargetMappingKey.setSourceEntityFileTypeID(sourceToTargetMappingVw.getSourceEntityFileTypeID());
		sourceToTargetMappingKey.setTargetEntityFileTypeID(sourceToTargetMappingVw.getTargetEntityFileTypeID());
		sourceToTargetMappingKey.setTargetColumnID(sourceToTargetMappingVw.getColumnID());
		sourceToTargetMapping.setSourceToTargetMappingKey(sourceToTargetMappingKey);
		loadSourceToTargetMapping(sourceToTargetMapping, sourceToTargetMappingVw);
		sourceToTargetMappingDAO.create(sourceToTargetMapping);
	}

	@Transactional
	public void update(SourceToTargetMappingVw sourceToTargetMappingVw,boolean isReleaseChanged) throws JsonProcessingException {
		SourceToTargetMappingKey sourceToTargetMappingKey = new SourceToTargetMappingKey();
		sourceToTargetMappingKey.setSourceEntityFileTypeID(sourceToTargetMappingVw.getSourceEntityFileTypeID());
		sourceToTargetMappingKey.setTargetEntityFileTypeID(sourceToTargetMappingVw.getTargetEntityFileTypeID());
		sourceToTargetMappingKey.setTargetColumnID(sourceToTargetMappingVw.getColumnID());
		checkForCyclicDependency(sourceToTargetMappingVw);
		SourceToTargetMapping sourceToTargetMapping = sourceToTargetMappingDAO.findOne(sourceToTargetMappingKey);
		
		if (isReleaseChanged) {
			SourceToTargetVwKey sourceToTargetVwKey= new SourceToTargetVwKey();
			sourceToTargetVwKey.setColumnID(sourceToTargetMappingVw.getColumnID());
			sourceToTargetVwKey.setEntityName(sourceToTargetMappingVw.getEntityName());
			sourceToTargetVwKey.setHSFileType(sourceToTargetMappingVw.getHSFileType());
			sourceToTargetVwKey.setInputFileMask(sourceToTargetMappingVw.getInputFileMask());
			sourceToTargetVwKey.setTargetEntityFileMask(sourceToTargetMappingVw.getTargetEntityFileMask());
			sourceToTargetVwKey.setTargetEntityName(sourceToTargetMappingVw.getTargetEntityName());
			SourceToTargetMappingVw oldEntity = sourceToTargetMappingVwDAO.findOne(sourceToTargetVwKey);
			if(oldEntity!=null){
		    ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			
			releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
			releaseArchiveKey.setReleaseId(sourceToTargetMappingVw.getReleaseNo());
			releaseArchiveKey.setTableName("SOURCETOTARGETMAPPING");
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(sourceToTargetMapping.getSourceToTargetMappingKey()));
			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if(releaseArchive!=null){
				releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToTargetMapping));
				releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToTargetVwKey));
				releaseArchiveDAO.update(releaseArchive);
			}else{
				releaseArchive = new ReleaseArchive();
				releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(sourceToTargetMapping));
				releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(sourceToTargetVwKey));
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchiveDAO.create(releaseArchive);
			}
			}
		}
		if (sourceToTargetMapping != null) {
			sourceToTargetMapping.setTargetColOrder(sourceToTargetMappingVw.getTargetColOrder());
			sourceToTargetMapping.setActive(sourceToTargetMappingVw.getActive());
			sourceToTargetMapping.setMapFunction(sourceToTargetMappingVw.getMapFunction());
			sourceToTargetMapping.setEffectiveDate(sourceToTargetMappingVw.getEffectiveDate());
			sourceToTargetMapping.setReleaseNo(sourceToTargetMappingVw.getReleaseNo());
			sourceToTargetMappingDAO.update(sourceToTargetMapping);
		}
	}
	
	private void checkForCyclicDependency(SourceToTargetMappingVw sourceToTargetMappingVw) throws JsonProcessingException	{
		SourceToTargetMappingKey sourceToTargetMappingKey = new SourceToTargetMappingKey();
		sourceToTargetMappingKey.setSourceEntityFileTypeID(sourceToTargetMappingVw.getSourceEntityFileTypeID());
		sourceToTargetMappingKey.setTargetEntityFileTypeID(sourceToTargetMappingVw.getTargetEntityFileTypeID());
		sourceToTargetMappingKey.setTargetColumnID(sourceToTargetMappingVw.getColumnID());
		String jsonId = AppWebUtils.convertObjectToJson(sourceToTargetMappingKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(sourceToTargetMappingVw.getReleaseNo(), "SOURCETOTARGETMAPPING", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	
	@Transactional
	public List<SourceToTargetMappingVw> getSourceToTargetMappingVwList()
	{
		return sourceToTargetMappingVwDAO.findAll();
		
	}
	@Transactional
	public SourceToTargetMapping loadSourceToTargetMapping(SourceToTargetMapping sourceToTargetMapping,SourceToTargetMappingVw sourceToTargetMappingVw) {
        sourceToTargetMapping.setSourceEntityID(sourceToTargetMappingVw.getSourceEntityID());	
        sourceToTargetMapping.setSourceFileTypeID(sourceToTargetMappingVw.getSourceFileTypeID());	
        sourceToTargetMapping.setTargetEntityID(sourceToTargetMappingVw.getTargetEntityID());	
        sourceToTargetMapping.setTargetFileTypeID(sourceToTargetMappingVw.getTargetFileTypeID());	
        sourceToTargetMapping.setTargetColOrder(sourceToTargetMappingVw.getTargetColOrder());	
        sourceToTargetMapping.setActive(sourceToTargetMappingVw.getActive());	
        sourceToTargetMapping.setMapFunction(sourceToTargetMappingVw.getMapFunction());	
        sourceToTargetMapping.setEffectiveDate(sourceToTargetMappingVw.getEffectiveDate());
        sourceToTargetMapping.setReleaseNo(sourceToTargetMappingVw.getReleaseNo());
      return sourceToTargetMapping;
    }
	@Transactional
	public void saveSourceToTargetMappingS(List<SourceToTargetMapping> entitytypes)
	{
		for (SourceToTargetMapping ref : entitytypes) {
			sourceToTargetMappingDAO.create(ref);
		}
	}
	@Transactional
	public List<SourceToTargetMapping> getSourceToTargetMappingTempList()
	{
		return sourceToTargetMappingDAO.findAll();
	}
	
	@Transactional
	public SourceToTargetMapping getSourceToTargetMapping(SourceToTargetMappingVw sourceToTargetMappingVw) {
		SourceToTargetMappingKey sourceToTargetMappingKey = new SourceToTargetMappingKey();
		sourceToTargetMappingKey.setSourceEntityFileTypeID(sourceToTargetMappingVw.getSourceEntityFileTypeID());
		sourceToTargetMappingKey.setTargetEntityFileTypeID(sourceToTargetMappingVw.getTargetEntityFileTypeID());
		sourceToTargetMappingKey.setTargetColumnID(sourceToTargetMappingVw.getColumnID());
		SourceToTargetMapping sourceToTargetMapping = sourceToTargetMappingDAO.findOne(sourceToTargetMappingKey);

		return sourceToTargetMapping;
		
	}
	
	@Transactional(readOnly=true)
	public List<SourceToTargetMapping> getSourceToTargetMappingListByReleaseNo(Integer releaseNo){
		return sourceToTargetMappingDAO.getSourceToTargetMappingListByReleaseNo(releaseNo);
	}
	
	@Override
	@Transactional(readOnly=true)
	public List<Integer> getAllSourceToTargetMappingReleaseIds(Integer selectedReleaseId){
		return sourceToTargetMappingDAO.getAllSourceToTargetMappingReleaseIds(selectedReleaseId);
	}
}
