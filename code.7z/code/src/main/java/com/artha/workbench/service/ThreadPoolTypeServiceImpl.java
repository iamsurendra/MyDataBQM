package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.ThreadPoolTypeDAO;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.models.metastore.ThreadPoolType;
import com.artha.workbench.models.metastore.ThreadPoolTypeId;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("threadPoolTypeService")
public class ThreadPoolTypeServiceImpl implements ThreadPoolTypeService{
	
	@Autowired
	ThreadPoolTypeDAO threadPoolTypeDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;
	
	
	@Transactional
	public List<ThreadPoolType> getThreadPoolTypeList() {
		return threadPoolTypeDAO.findAll();
	}
	
	
	
	@Transactional
	@Override
	public void update(ThreadPoolType threadPoolType,boolean isReleaseChanged) throws JsonProcessingException {
		ThreadPoolType oldThreadPoolType = threadPoolTypeDAO.findOne(threadPoolType.getPoolid());
		checkForCyclicDependency(threadPoolType);
		if(isReleaseChanged)
		{
		ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
		releaseArchiveKey.setArchivedReleaseId(oldThreadPoolType.getReleaseNo());
		releaseArchiveKey.setReleaseId(oldThreadPoolType.getReleaseNo());
		releaseArchiveKey.setTableName("THREADPOOLTYPE");
		ThreadPoolTypeId threadPoolTypeId = new ThreadPoolTypeId();
		threadPoolTypeId.setPoolid(oldThreadPoolType.getPoolid());
		releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(threadPoolTypeId));

		ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
		if(releaseArchive!=null){
			releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldThreadPoolType));
			releaseArchiveDAO.update(releaseArchive);
		}else{
			releaseArchive=new ReleaseArchive();
			releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldThreadPoolType));
			releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
			releaseArchiveDAO.create(releaseArchive);
		}
		}
		threadPoolTypeDAO.update(threadPoolType);
	}
	
	@Transactional
	private void checkForCyclicDependency(ThreadPoolType threadPoolType) throws JsonProcessingException
	{
		ThreadPoolTypeId threadPoolTypeId = new ThreadPoolTypeId();
		threadPoolTypeId.setPoolid(threadPoolType.getPoolid());
		String jsonId = AppWebUtils.convertObjectToJson(threadPoolTypeId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(threadPoolType.getReleaseNo(), "THREADPOOLTYPE", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	
	
	@Transactional
	public void saveThreadPoolType(List<ThreadPoolType> threadPoolType) {
		threadPoolTypeDAO.deleteThreadPoolType();
		threadPoolTypeDAO.saveThreadPoolType(threadPoolType);;
	}
	
	@Transactional
	public int getmaxThreadPoolType()
	{ 
		return threadPoolTypeDAO.getmaxThreadPoolType();
	}
	
	@Transactional
	public void create(ThreadPoolType threadPoolType) {
		threadPoolTypeDAO.create(threadPoolType);
		
	}
	
	@Transactional
	public List<ThreadPoolType> getThreadPoolTypeListByReleaseNo(Integer releaseNo){
		
		return threadPoolTypeDAO.getThreadPoolTypeListByReleaseNo(releaseNo);
		
	}
	
	
	@Transactional(readOnly = true)
	@Override
	public ThreadPoolType getPreviousThreadPoolType(ThreadPoolType threadPoolType) throws IOException
	{
		ThreadPoolTypeId threadPoolTypeId = new ThreadPoolTypeId();
		threadPoolTypeId.setPoolid(threadPoolType.getPoolid());
		String threadPoolTypeIdJson = AppWebUtils.convertObjectToJson(threadPoolTypeId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(threadPoolType.getReleaseNo(), "THREADPOOLTYPE", threadPoolTypeIdJson);
		ThreadPoolType previousThreadPoolType = new ThreadPoolType();
		if(releaseArchive!=null){
			previousThreadPoolType = AppWebUtils.convertJsonToObject(ThreadPoolType.class, releaseArchive.getRecData());
		}
		return previousThreadPoolType;
		
	}
	
	@Transactional
	public List<ThreadPoolType> getThreadPoolTypeList(Set<Integer> poolIds, Integer selectedReleaseNumber) {
		return threadPoolTypeDAO.getThreadPoolTypeList(poolIds, selectedReleaseNumber);
	}
}
