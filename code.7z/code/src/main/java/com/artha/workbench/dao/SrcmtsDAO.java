package com.artha.workbench.dao;

import com.artha.workbench.models.core.Srcmts;
import com.guvvala.framework.dao.BaseDAO;

/**
 * @author Guvala
 *
 */
public interface SrcmtsDAO extends BaseDAO<Srcmts, String> {

}
