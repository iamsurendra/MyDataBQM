package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.metastore.FileValStepXref;
import com.artha.workbench.models.metastore.FileValStepXrefVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface FileValStepXrefService {

	public List<FileValStepXref> getFileValStepXrefList();

	public void create(FileValStepXref FileValStepXref);

	public void update(FileValStepXref FileValStepXref, FileValStepXrefVw fileValStepXrefVw, boolean isReleaseChanged)
			throws JsonProcessingException;

	public List<FileValStepXref> getEntityfileValStepXrefList(List<AbstractModel> entitytypes);

	public void saveFileValStepXref(List<FileValStepXref> entitytypes);

	public List<FileValStepXrefVw> getFileValStepXrefVwList();

	public List<FileValStepXref> getEntityfileValStepXrefTempList();

	public List<FileValStepXrefVw> getFileValStepXrefVwListByReleaseNo(Integer releaseNo);

	public FileValStepXrefVw getPreviousFileValStepXrefVw(FileValStepXrefVw fileValStepXrefVw) throws IOException;

	public FileValStepXref getFileValStepXref(Integer entityFileTypeID, Integer stepId);

	public List<FileValStepXref> getFileValStepXrefListByReleaseNo(Integer releaseNo);

	List<Integer> getAllFileValStepXrefReleaseIds(Integer selectedReleaseId);

}
