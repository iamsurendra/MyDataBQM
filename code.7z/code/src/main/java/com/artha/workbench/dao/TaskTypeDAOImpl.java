package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.datahub.TaskType;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class TaskTypeDAOImpl extends BaseDAOImpl<TaskType, Integer> implements TaskTypeDAO {

	public TaskTypeDAOImpl() {
		super(TaskType.class);
	}

	public HashMap<Integer, String> loadtaskType() {
		HashMap<Integer, String> tasktypemap = new HashMap<Integer, String>();
		List<TaskType> taskTypes = findAll();
		for (TaskType tType : taskTypes) {
			tasktypemap.put(tType.getTypeId(), tType.getLabel());
		}
		return tasktypemap;
	}
}
