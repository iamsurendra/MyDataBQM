package com.artha.workbench.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.constant.UserStatus;
import com.artha.workbench.models.userConfig.User;
import com.artha.workbench.service.MailService;
import com.artha.workbench.service.UserService;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppUser;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.PasswordEncryptor;
import com.guvvala.framework.util.PasswordGenerator;
import com.guvvala.framework.util.ThreadLocalUtil;

@RestController
@RequestMapping("/api/user")

public class UserController {

	@Autowired
	UserService userService;

	@Autowired
	private MailService mailService;

	@Resource(name = "tokenServices")
	ConsumerTokenServices tokenServices;

	/*
	 * *Get All user list
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public AppUser getUser() {
		return ThreadLocalUtil.getUser();
	}

	@RequestMapping(value = "/getAllUsers", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<User> findAll() {
		return userService.findAll();
	}

	@RequestMapping(value = "/createUser", method = RequestMethod.POST)
	public void createUser(@RequestBody User user) {
		if (userService.uniqueUserName(user.getUserName())) {
			throw new AppException(MessagesEnum.LOGIN_NAME_ALREADY_EXISTS);
		} else {
			user.setUserStatus(UserStatus.USER_FIRST_LOGIN.value);
			String password = String.valueOf(PasswordGenerator.generatePassword());
			String salt = PasswordEncryptor.generateSalt();
			String hash = PasswordEncryptor.applySHA256(password + salt);
			user.setUserSalt(salt);
			user.setPasswordHash(hash);
			user.setPasswordExpirationDate(DateUtils.addDays(Calendar.getInstance().getTime(), 90));
			userService.create(user);
			try {
				mailService.sendMailToUser(password, user.getUserName(), user.getUserEmail(), user.getFirstName());
			} catch (MessagingException e) {
				throw new AppException(MessagesEnum.UNSENT_EMAIL);
			}
		}
	}

	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public void updateUser(@RequestBody User user) {
		// TODO need to add @JsonIgnore
		User dbUser = userService.getUser(user.getUserName());
		if (dbUser != null && !dbUser.getUserId().equals(user.getUserId())) {
			throw new AppException(MessagesEnum.LOGIN_NAME_ALREADY_EXISTS);
		} else {
			User existingUser = userService.findOne(user.getUserId()); 
			existingUser.setUserName(user.getUserName());
			existingUser.setFirstName(user.getFirstName());
			existingUser.setLastName(user.getLastName());
			existingUser.setUserEmail(user.getUserEmail());
			existingUser.setUserStatus(user.getUserStatus());
			existingUser.setAdmin(user.isAdmin());
			existingUser.setSadmin(user.isSadmin());
			existingUser.setCreateTask(user.isCreateTask());
			userService.updateUser(existingUser);
		}
	}

	@RequestMapping(value = "/unlockUsers", method = RequestMethod.POST)
	public void unlockUsers(@RequestBody List<Long> selectedUserIdList) {
		List<Long> userIdList = new ArrayList<Long>();
		for (Long userId : selectedUserIdList) {
			User user = userService.findOne(userId);
			if (user.getUserStatus().equals(UserStatus.USER_LOCKED.value)) {
				userIdList.add(userId);
			}
		}
		userService.unlockUser(userIdList);
	}

	@RequestMapping(value = "/deleteUsers", method = RequestMethod.POST)
	public void deleteUsers(@RequestBody List<Long> selectedUserIdList) {
		userService.deleteUsers(selectedUserIdList);
	}

	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
	public void resetpassword(@RequestBody List<Long> selectedUserIdList) throws AddressException, MessagingException {
		userService.resetPasswords(selectedUserIdList);
	}

	@RequestMapping(value = "/logout", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void logout(@RequestBody Map<String, String> token) {
		String tokenId = token.get("access_token");
		tokenServices.revokeToken(tokenId);
	}
	

	@RequestMapping(value = "/changePwd", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void resetPwdButton(@RequestBody Map<String, Object> userDetails) throws AddressException, MessagingException {
		userService.resetpwd(ThreadLocalUtil.getUserId(), (String) userDetails.get("newPassword"));
	}

	@RequestMapping(value = "/renewalPwd", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void renewalPwd(@RequestBody Map<String, Object> userDetails) throws AddressException, MessagingException {
		String oldPassword = (String) userDetails.get("oldPassword");
		String newPassword = (String) userDetails.get("newPassword");
		Long userId = ThreadLocalUtil.getUserId();
		if(userService.isValidPassword(userId,oldPassword)){
		   userService.resetpwd(userId, newPassword);
		}else{
			throw new AppException(MessagesEnum.INVALID_OLD_PASSWORD);
		}
	}

}
