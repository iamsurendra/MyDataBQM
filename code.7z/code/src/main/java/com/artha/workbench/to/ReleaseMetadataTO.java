package com.artha.workbench.to;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.artha.workbench.models.metastore.DataStewardGroups;
import com.artha.workbench.models.metastore.EmptyFileConfig;
import com.artha.workbench.models.metastore.EntityFileRecColumn;
import com.artha.workbench.models.metastore.EntityFileTypeQueries;
import com.artha.workbench.models.metastore.EntityFileTypeScheduleXref;
import com.artha.workbench.models.metastore.EntityFileTypeStepChunk;
import com.artha.workbench.models.metastore.EntityFileTypeWebService;
import com.artha.workbench.models.metastore.EntityFileTypeXref;
import com.artha.workbench.models.metastore.EntityMaster;
import com.artha.workbench.models.metastore.EntityType;
import com.artha.workbench.models.metastore.FileFormat;
import com.artha.workbench.models.metastore.FileValStepXref;
import com.artha.workbench.models.metastore.HSFileType;
import com.artha.workbench.models.metastore.HeaderFooter;
import com.artha.workbench.models.metastore.HeaderFooterCols;
import com.artha.workbench.models.metastore.RuleType;
import com.artha.workbench.models.metastore.SourceToServiceCriteria;
import com.artha.workbench.models.metastore.SourceToTargetMapping;
import com.artha.workbench.models.metastore.SourceToTargetSplit;
import com.artha.workbench.models.metastore.SourceToWebServiceMapping;
import com.artha.workbench.models.metastore.ThreadPoolType;
import com.artha.workbench.models.metastore.ThreadThreadPoolXref;
import com.artha.workbench.models.metastore.ValidationStep;
import com.artha.workbench.models.metastore.WebServiceRecColumn;


@XmlRootElement(name = "metadata")
@XmlType(propOrder = { "entityTypeList", "fileFormatList", "hsFileTypeList", "entityMasterList",
		"entityFileTypeXrefList", "entityFileRecColumnList", "sourceToTargetMappingList",
		"entityFileTypeScheduleXrefList", "headerFooterList", "headerFooterColsList", "ruleTypeList",
		"validationStepList", "validationRules", "fileValStepXrefList", "webServiceRecColumnList",
		"sourceToTargetSplitList", "sourceToServiceCriteriaList", "sourceToWebServiceMappingList",
		"entityFileTypeQueriesList", "entityFileTypeWebServiceList", "dataStewardGroupsList", "threadPoolTypeList",
		"threadThreadPoolXrefList","entityFileTypeStepChunkList","emptyFileConfigList"})

public class ReleaseMetadataTO {

	private List<EntityType> entityTypeList = new ArrayList<>();

	private List<FileFormat> fileFormatList = new ArrayList<>();

	private List<HSFileType> hsFileTypeList = new ArrayList<>();

	private List<EntityMaster> entityMasterList = new ArrayList<>();

	private List<EntityFileTypeXref> entityFileTypeXrefList = new ArrayList<>();

	private List<EntityFileRecColumn> entityFileRecColumnList = new ArrayList<>();

	private List<SourceToTargetMapping> sourceToTargetMappingList = new ArrayList<>();

	private List<EntityFileTypeScheduleXref> entityFileTypeScheduleXrefList = new ArrayList<>();

	private List<HeaderFooter> headerFooterList = new ArrayList<>();

	private List<HeaderFooterCols> headerFooterColsList = new ArrayList<>();

	private List<RuleType> ruleTypeList = new ArrayList<>();

	private List<ValidationStep> validationStepList = new ArrayList<>();

	private ValidationRuleMainXmlTO validationRules = new ValidationRuleMainXmlTO();

	private List<FileValStepXref> fileValStepXrefList = new ArrayList<>();

	private List<WebServiceRecColumn> WebServiceRecColumnList = new ArrayList<>();

	private List<SourceToTargetSplit> sourceToTargetSplitList = new ArrayList<>();

	private List<SourceToServiceCriteria> sourceToServiceCriteriaList = new ArrayList<>();

	private List<SourceToWebServiceMapping> sourceToWebServiceMappingList = new ArrayList<>();

	private List<EntityFileTypeQueries> entityFileTypeQueriesList = new ArrayList<>();

	private List<EntityFileTypeWebService> entityFileTypeWebServiceList = new ArrayList<>();

	private List<DataStewardGroups> dataStewardGroupsList = new ArrayList<>();

	private List<ThreadPoolType> threadPoolTypeList = new ArrayList<>();

	private List<ThreadThreadPoolXref> threadThreadPoolXrefList = new ArrayList<>();

	private List<EntityFileTypeStepChunk> entityFileTypeStepChunkList = new ArrayList<>();
	
	private List<EmptyFileConfig>emptyFileConfigList=new ArrayList<>();

	@XmlElementWrapper(name = "entityTypes")
	@XmlElement(name = "entityType", type = EntityType.class)
	public List<EntityType> getEntityTypeList() {
		return entityTypeList;
	}

	public void setEntityTypeList(List<EntityType> entityTypeList) {
		this.entityTypeList = entityTypeList;
	}

	@XmlElementWrapper(name = "fileFormats")
	@XmlElement(name = "fileFormat", type = FileFormat.class)
	public List<FileFormat> getFileFormatList() {
		return fileFormatList;
	}

	public void setFileFormatList(List<FileFormat> fileFormatList) {
		this.fileFormatList = fileFormatList;
	}

	@XmlElementWrapper(name = "entityMasters")
	@XmlElement(name = "entityMaster", type = EntityMaster.class)
	public List<EntityMaster> getEntityMasterList() {
		return entityMasterList;
	}

	public void setEntityMasterList(List<EntityMaster> entityMasterList) {
		this.entityMasterList = entityMasterList;
	}

	@XmlElementWrapper(name = "entityFileTypeXrefs")
	@XmlElement(name = "entityFileTypeXref", type = EntityFileTypeXref.class)
	public List<EntityFileTypeXref> getEntityFileTypeXrefList() {
		return entityFileTypeXrefList;
	}

	public void setEntityFileTypeXrefList(List<EntityFileTypeXref> entityFileTypeXrefList) {
		this.entityFileTypeXrefList = entityFileTypeXrefList;
	}

	@XmlElementWrapper(name = "entityFileRecColumns")
	@XmlElement(name = "entityFileRecColumn", type = EntityFileRecColumn.class)
	public List<EntityFileRecColumn> getEntityFileRecColumnList() {
		return entityFileRecColumnList;
	}

	public void setEntityFileRecColumnList(List<EntityFileRecColumn> entityFileRecColumnList) {
		this.entityFileRecColumnList = entityFileRecColumnList;
	}

	@XmlElementWrapper(name = "sourceToTargetMappings")
	@XmlElement(name = "sourceToTargetMapping", type = SourceToTargetMapping.class)
	public List<SourceToTargetMapping> getSourceToTargetMappingList() {
		return sourceToTargetMappingList;
	}

	public void setSourceToTargetMappingList(List<SourceToTargetMapping> sourceToTargetMappingList) {
		this.sourceToTargetMappingList = sourceToTargetMappingList;
	}

	@XmlElementWrapper(name = "entityFileTypeScheduleXrefs")
	@XmlElement(name = "entityFileTypeScheduleXref", type = EntityFileTypeScheduleXref.class)
	public List<EntityFileTypeScheduleXref> getEntityFileTypeScheduleXrefList() {
		return entityFileTypeScheduleXrefList;
	}

	public void setEntityFileTypeScheduleXrefList(List<EntityFileTypeScheduleXref> entityFileTypeScheduleXrefList) {
		this.entityFileTypeScheduleXrefList = entityFileTypeScheduleXrefList;
	}

	@XmlElementWrapper(name = "headerFooters")
	@XmlElement(name = "headerFooter", type = HeaderFooter.class)
	public List<HeaderFooter> getHeaderFooterList() {
		return headerFooterList;
	}

	public void setHeaderFooterList(List<HeaderFooter> headerFooterList) {
		this.headerFooterList = headerFooterList;
	}

	@XmlElementWrapper(name = "headerFooterColsList")
	@XmlElement(name = "headerFooterCols", type = HeaderFooterCols.class)
	public List<HeaderFooterCols> getHeaderFooterColsList() {
		return headerFooterColsList;
	}

	public void setHeaderFooterColsList(List<HeaderFooterCols> headerFooterColsList) {
		this.headerFooterColsList = headerFooterColsList;
	}

	@XmlElementWrapper(name = "ruleTypes")
	@XmlElement(name = "ruleType", type = RuleType.class)
	public List<RuleType> getRuleTypeList() {
		return ruleTypeList;
	}

	public void setRuleTypeList(List<RuleType> ruleTypeList) {
		this.ruleTypeList = ruleTypeList;
	}

	@XmlElementWrapper(name = "validationSteps")
	@XmlElement(name = "validationStep", type = ValidationStep.class)
	public List<ValidationStep> getValidationStepList() {
		return validationStepList;
	}

	public void setValidationStepList(List<ValidationStep> validationStepList) {
		this.validationStepList = validationStepList;
	}

	@XmlElementWrapper(name = "fileValStepXrefs")
	@XmlElement(name = "fileValStepXref", type = FileValStepXref.class)
	public List<FileValStepXref> getFileValStepXrefList() {
		return fileValStepXrefList;
	}

	public void setFileValStepXrefList(List<FileValStepXref> fileValStepXrefList) {
		this.fileValStepXrefList = fileValStepXrefList;
	}

	@XmlElementWrapper(name = "webServiceRecColumns")
	@XmlElement(name = "webServiceRecColumn", type = WebServiceRecColumn.class)
	public List<WebServiceRecColumn> getWebServiceRecColumnList() {
		return WebServiceRecColumnList;
	}

	public void setWebServiceRecColumnList(List<WebServiceRecColumn> webServiceRecColumnList) {
		WebServiceRecColumnList = webServiceRecColumnList;
	}

	@XmlElementWrapper(name = "hsFileTypes")
	@XmlElement(name = "hsFileType", type = HSFileType.class)
	public List<HSFileType> getHsFileTypeList() {
		return hsFileTypeList;
	}

	public void setHsFileTypeList(List<HSFileType> hsFileTypeList) {
		this.hsFileTypeList = hsFileTypeList;
	}

	@XmlElement(name = "validationRules")
	public ValidationRuleMainXmlTO getValidationRules() {
		return validationRules;
	}

	public void setValidationRules(ValidationRuleMainXmlTO validationRules) {
		this.validationRules = validationRules;
	}

	@XmlElementWrapper(name = "sourceToTargetSplitList")
	@XmlElement(name = "sourceToTargetSplit", type = SourceToTargetSplit.class)
	public List<SourceToTargetSplit> getSourceToTargetSplitList() {
		return sourceToTargetSplitList;
	}

	public void setSourceToTargetSplitList(List<SourceToTargetSplit> sourceToTargetSplits) {
		sourceToTargetSplitList = sourceToTargetSplits;
	}

	@XmlElementWrapper(name = "sourceToServiceCriteriaList")
	@XmlElement(name = "sourceToServiceCriteria", type = SourceToServiceCriteria.class)
	public List<SourceToServiceCriteria> getSourceToServiceCriteriaList() {
		return sourceToServiceCriteriaList;
	}

	public void setSourceToServiceCriteriaList(List<SourceToServiceCriteria> sourceToServiceCriterias) {
		sourceToServiceCriteriaList = sourceToServiceCriterias;
	}

	@XmlElementWrapper(name = "sourceToWebServiceMappings")
	@XmlElement(name = "sourceToWebServiceMapping", type = SourceToWebServiceMapping.class)
	public List<SourceToWebServiceMapping> getSourceToWebServiceMappingList() {
		return sourceToWebServiceMappingList;
	}

	public void setSourceToWebServiceMappingList(List<SourceToWebServiceMapping> sourceToWebServiceMappings) {
		sourceToWebServiceMappingList = sourceToWebServiceMappings;
	}

	@XmlElementWrapper(name = "entityFileTypeQueriesList")
	@XmlElement(name = "entityFileTypeQueries", type = EntityFileTypeQueries.class)
	public List<EntityFileTypeQueries> getEntityFileTypeQueriesList() {
		return entityFileTypeQueriesList;
	}

	public void setEntityFileTypeQueriesList(List<EntityFileTypeQueries> entityFileTypeQueries) {
		entityFileTypeQueriesList = entityFileTypeQueries;
	}

	@XmlElementWrapper(name = "entityFileTypeWebServices")
	@XmlElement(name = "entityFileTypeWebService", type = EntityFileTypeWebService.class)
	public List<EntityFileTypeWebService> getEntityFileTypeWebServiceList() {
		return entityFileTypeWebServiceList;
	}

	public void setEntityFileTypeWebServiceList(List<EntityFileTypeWebService> entityFileTypeWebServices) {
		entityFileTypeWebServiceList = entityFileTypeWebServices;
	}

	@XmlElementWrapper(name = "dataStewardGroup")
	@XmlElement(name = "dataStewardGroup", type = DataStewardGroups.class)
	public List<DataStewardGroups> getDataStewardGroupsList() {
		return dataStewardGroupsList;
	}

	public void setDataStewardGroupsList(List<DataStewardGroups> dataStewardGroupsList) {
		this.dataStewardGroupsList = dataStewardGroupsList;
	}

	@XmlElementWrapper(name = "threadPoolType")
	@XmlElement(name = "threadPoolType", type = ThreadPoolType.class)
	public List<ThreadPoolType> getThreadPoolTypeList() {
		return threadPoolTypeList;
	}

	public void setThreadPoolTypeList(List<ThreadPoolType> threadPoolTypeList) {
		this.threadPoolTypeList = threadPoolTypeList;
	}

	@XmlElementWrapper(name = "ThreadThreadPoolXref")
	@XmlElement(name = "ThreadThreadPoolXref", type = ThreadThreadPoolXref.class)
	public List<ThreadThreadPoolXref> getThreadThreadPoolXrefList() {
		return threadThreadPoolXrefList;
	}

	public void setThreadThreadPoolXrefList(List<ThreadThreadPoolXref> threadThreadPoolXrefList) {
		this.threadThreadPoolXrefList = threadThreadPoolXrefList;
	}
	
	
	@XmlElementWrapper(name = "EntityFileTypeStepChunk")
	@XmlElement(name = "EntityFileTypeStepChunk", type = EntityFileTypeStepChunk.class)
	public List<EntityFileTypeStepChunk> getEntityFileTypeStepChunkList() {
		return entityFileTypeStepChunkList;
	}

	public void setEntityFileTypeStepChunkList(List<EntityFileTypeStepChunk> entityFileTypeStepChunkList) {
		this.entityFileTypeStepChunkList = entityFileTypeStepChunkList;
	}
	@XmlElementWrapper(name = "EmptyFileConfig")
	@XmlElement(name = "EmptyFileConfig", type = EmptyFileConfig.class)
	public List<EmptyFileConfig> getEmptyFileConfigList() {
		return emptyFileConfigList;
	}

	public void setEmptyFileConfigList(List<EmptyFileConfig> emptyFileConfigList) {
		this.emptyFileConfigList = emptyFileConfigList;
	}
	
	
	
	

}
