package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileTypeStepChunkDAO;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.ValidationStepDAO;
import com.artha.workbench.models.metastore.EntityFileTypeStepChunk;
import com.artha.workbench.models.metastore.EntityFileTypeStepChunkKey;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("entityFileTypeStepChunkService")
public class EntityFileTypeStepChunkServiceImpl implements EntityFileTypeStepChunkService {
	@Autowired
	EntityFileTypeStepChunkDAO entityFileTypeStepChunkDAO;

	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefDAO;

	@Autowired
	ValidationStepDAO validationStepDAO;

	@Transactional(readOnly = true)
	public List<EntityFileTypeStepChunk> getEntityFileTypeStepChunkList() {
		return entityFileTypeStepChunkDAO.findAll();
	}

	@Transactional
	public void update(EntityFileTypeStepChunk entityFileTypeStepChunk,boolean isReleaseChanged) throws JsonProcessingException{
		EntityFileTypeStepChunkKey key = new EntityFileTypeStepChunkKey();
		key.setEntityFileTypeId(entityFileTypeStepChunk.getEntityFileTypeID());
		key.setStepID(entityFileTypeStepChunk.getStepID());
		checkForCyclicDependency(entityFileTypeStepChunk);
		EntityFileTypeStepChunk oldentityFileTypeStepChunk = entityFileTypeStepChunkDAO.findOne(key);
		if(isReleaseChanged)
		{
			if(oldentityFileTypeStepChunk!=null){
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldentityFileTypeStepChunk.getReleaseNo());
				releaseArchiveKey.setReleaseId(entityFileTypeStepChunk.getReleaseNo());
				releaseArchiveKey.setTableName("ENTITYFILETYPESTEPCHUNK");
				releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(oldentityFileTypeStepChunk.getEntityFileTypeStepChunkKey()));
				ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
				if(releaseArchive!=null){
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldentityFileTypeStepChunk));
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(key));
					releaseArchiveDAO.update(releaseArchive);
				}else{
					releaseArchive = new ReleaseArchive();
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldentityFileTypeStepChunk));
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setTablePkRecID(AppWebUtils.convertObjectToJson(key));
					releaseArchiveDAO.create(releaseArchive);
				}
			}
		}
		if(entityFileTypeStepChunk!=null){
			entityFileTypeStepChunkDAO.update(entityFileTypeStepChunk);
		}
	}
	private void checkForCyclicDependency(EntityFileTypeStepChunk entityFileTypeStepChunk)
			throws JsonProcessingException {

		EntityFileTypeStepChunkKey entityFileTypeStepChunkId = new EntityFileTypeStepChunkKey();
		entityFileTypeStepChunkId.setEntityFileTypeId(entityFileTypeStepChunk.getEntityFileTypeID());
		entityFileTypeStepChunkId.setStepID(entityFileTypeStepChunk.getStepID());
		String jsonId = AppWebUtils.convertObjectToJson(entityFileTypeStepChunkId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(
				entityFileTypeStepChunk.getReleaseNo(), "ENTITYFILETYPESTEPCHUNK", jsonId);
		if (releaseArchive != null) {
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	@Transactional
	public List<Integer> loadEntityfiletypeIds() {
		return entityFileTypeXrefDAO.loadentityFileTypeid();
	}

	@Transactional
	public List<Integer> loadStepIds() {
		return validationStepDAO.loadeStepIds();

	}

	@Transactional
	public void createEntityFileTypeStepChunk(EntityFileTypeStepChunk entityFileTypeStepChunk) {
		EntityFileTypeStepChunk column = new EntityFileTypeStepChunk();
		EntityFileTypeStepChunkKey columnKey = new EntityFileTypeStepChunkKey();
		columnKey.setEntityFileTypeId(entityFileTypeStepChunk.getEntityFileTypeID());
		columnKey.setStepID(entityFileTypeStepChunk.getStepID());
		column.setEntityFileTypeStepChunkKey(columnKey);
		loadEntityFileTypeStepChunk(column, entityFileTypeStepChunk);
		entityFileTypeStepChunkDAO.create(column);

	}

	private void loadEntityFileTypeStepChunk(EntityFileTypeStepChunk column,
			EntityFileTypeStepChunk entityFileTypeStepChunk) {
		// TODO Auto-generated method stub
		column.setChunkNTile(entityFileTypeStepChunk.getChunkNTile());
		column.setChunkOver(entityFileTypeStepChunk.getChunkOver());
		column.setEffectiveDate(entityFileTypeStepChunk.getEffectiveDate());
		column.setActive(entityFileTypeStepChunk.getActive());
		column.setReleaseNo(entityFileTypeStepChunk.getReleaseNo());
		column.setStepID(entityFileTypeStepChunk.getStepID());
		column.setEntityFileTypeID(entityFileTypeStepChunk.getEntityFileTypeID());

	}

	@Transactional
	public EntityFileTypeStepChunk getEntityFileTypeStepChunkCheckDuplicate(
			EntityFileTypeStepChunk entityFileTypeStepChunk) {
		EntityFileTypeStepChunkKey entityFileTypeStepChunkKey = new EntityFileTypeStepChunkKey();
		entityFileTypeStepChunkKey.setEntityFileTypeId(entityFileTypeStepChunk.getEntityFileTypeID());
		entityFileTypeStepChunkKey.setStepID(entityFileTypeStepChunk.getStepID());
		EntityFileTypeStepChunk entityFileTypeStepChunk1 = entityFileTypeStepChunkDAO
				.findOne(entityFileTypeStepChunkKey);
		return entityFileTypeStepChunk1;
	}


	@Override
	@Transactional
	public EntityFileTypeStepChunk getPreviousEntityFileTypeStepChunk(EntityFileTypeStepChunk entityFileTypeStepChunk)throws IOException {
		EntityFileTypeStepChunkKey entityFileTypeStepChunkKey = new EntityFileTypeStepChunkKey();
		entityFileTypeStepChunkKey.setEntityFileTypeId(entityFileTypeStepChunk.getEntityFileTypeID());
		entityFileTypeStepChunkKey.setStepID(entityFileTypeStepChunk.getStepID());
		String entityFileTypeStepChunkJson = AppWebUtils.convertObjectToJson(entityFileTypeStepChunkKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(entityFileTypeStepChunk.getReleaseNo(), "ENTITYFILETYPESTEPCHUNK", entityFileTypeStepChunkJson);
		EntityFileTypeStepChunk previousEntityFileTypeStepChunk = new EntityFileTypeStepChunk();
		if(releaseArchive!=null){
			previousEntityFileTypeStepChunk = AppWebUtils.convertJsonToObject(EntityFileTypeStepChunk.class, releaseArchive.getRecData());
		}
		return previousEntityFileTypeStepChunk;
	}
	

	@Transactional
	@Override
	public List<EntityFileTypeStepChunk> getEntityFileTypeStepChunByReleaseNo(Integer releaseNo) {
		return entityFileTypeStepChunkDAO.getEntityFileTypeStepChunByReleaseNo(releaseNo);

	}

}
