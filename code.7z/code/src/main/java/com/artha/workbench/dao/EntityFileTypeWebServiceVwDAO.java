package com.artha.workbench.dao;



import java.util.List;

import com.artha.workbench.models.metastore.EntityFileTypeWebServiceVw;
import com.artha.workbench.models.metastore.EntityFileTypeWebServiceVwKey;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityFileTypeWebServiceVwDAO extends BaseDAO<EntityFileTypeWebServiceVw, EntityFileTypeWebServiceVwKey>{

	public List<EntityFileTypeWebServiceVw> getEntityFileTypeWebServiceVwListByReleaseNo(Integer releaseNo);
}
