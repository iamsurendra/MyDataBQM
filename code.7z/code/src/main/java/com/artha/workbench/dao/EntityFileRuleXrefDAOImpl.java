package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.EntityFileRuleXref;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class EntityFileRuleXrefDAOImpl extends BaseDAOImpl<EntityFileRuleXref, Integer>
		implements EntityFileRuleXrefDAO {

	public EntityFileRuleXrefDAOImpl() {
		super(EntityFileRuleXref.class);
	}

	public int getMaxEntityfileruleid() {
		int loginid = 0;
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(EntityfileRuleId) from EntityFileRuleXref",
				Integer.class);
		if (query.getSingleResult() != null)
			loginid = query.getSingleResult();
		return loginid;
	}

	public void saveEntityFileRuleXref(List<EntityFileRuleXref> entitytypes) {
		batchCreate(entitytypes, 50);

	}
	
	@Override
	public List<EntityFileRuleXref> getEntityFileRuleXrefsById(List<Integer> entityfileRuleIds){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<EntityFileRuleXref> cQuery = cb.createQuery(EntityFileRuleXref.class);
		Root<EntityFileRuleXref> root = cQuery.from(EntityFileRuleXref.class);
		cQuery.select(root);
		cQuery.where(cb.in(root.get("EntityfileRuleId")).value(entityfileRuleIds));
		return entityManager.createQuery(cQuery).getResultList();
	}

}
