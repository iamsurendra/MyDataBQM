package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.DateUtils;


@Entity
@Table(name = "metastore.entityfiletypexref_v")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
public class EntityFileTypeXrefVw extends AbstractModel {
	private static final long serialVersionUID = 1L;
	
	
//	private Integer eftxrid;
	@Id @GeneratedValue
	@Column(name = "EntityFileTypeID", nullable = false)
	@JsonProperty("EntityFileTypeID")
	private Integer EntityFileTypeID;
	
	@JsonProperty("EntityName")
	private String EntityName;
	
	@JsonProperty("HSFileType")
	private String HSFileType;
	
	@JsonProperty("FileFormat")
	private String FileFormat;
	
	@JsonProperty("FilePath")
	private String FilePath;
	
	@JsonProperty("FileMask")
	private String FileMask;
	
	@JsonProperty("RecDelimiter")
	private String RecDelimiter;
	
	@JsonProperty("ColumnsDelimiter")
	private String ColumnsDelimiter;
	
	@JsonProperty("ColumnsCount")
	private Integer ColumnsCount;
	
	@JsonProperty("MaxRecLen")
	private Integer MaxRecLen;
	
	@JsonProperty("AllowExtraColumns")
	private String AllowExtraColumns;
	
	@JsonProperty("NotifyRetyCount")
	private Integer NotifyRetyCount;
	
	@JsonProperty("OutboundOrder")
	private Integer OutboundOrder;
	
	@JsonProperty("Active")
	private String Active;
	
	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date EffectiveDate;
	
	@JsonProperty("ColumnsWidth")
	private Integer ColumnsWidth;
	
	@JsonProperty("DupFileCheck")
	private String DupFileCheck;
	
	@JsonProperty("ColumnsPattern")
	private String ColumnsPattern;
	
	@JsonProperty("NoDataRecordPattern")
	private String NoDataRecordPattern;
	
	@JsonProperty("NoRecordDelimiter")
	private String NoRecordDelimiter;
	
	@JsonProperty("OutBoundFilter")
	private String OutBoundFilter;
	
	@JsonProperty("SheetName")
	private String SheetName;
	
	@JsonProperty("IgnoreHeaderRowCount")
	private Integer IgnoreHeaderRowCount;
	
	@JsonProperty("IgnoreFooterRowCount")
	private Integer IgnoreFooterRowCount;
	
	@JsonProperty("FirstColumn")
	private Integer FirstColumn;
	
	@JsonProperty("LastColumn")
	private Integer LastColumn;
	
	@JsonProperty("AllowBlankRows")
	private String AllowBlankRows;
	
	@JsonProperty("EOFDelimiter")
	private String eOFDelimiter;
	
	@JsonProperty("EntityID")
	private Integer entityID;
	
	@JsonProperty("FileTypeID")
	private Integer fileTypeID;
	
	@JsonProperty("FileFormatID")
	private Integer fileFormatID;
	
	
	@Transient
	@JsonIgnore
	private String Comments;
	
	@Transient
	@JsonIgnore
	private String effectiveDtstr;
	
	@Transient
	@JsonIgnore
	private boolean addMode;
	
	@Column(name = "ReleaseNum")
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@JsonProperty("XSD")
	private String xsd;
	
	@JsonProperty("XMLLOOP")
	private String xmlLoop;
	
	@JsonProperty("Prettify")
	private String prettify;
	
	@JsonProperty("PoolID")
	private  Integer  poolID;
	 
	public EntityFileTypeXrefVw() {
		
	}
	
	public EntityFileTypeXrefVw(boolean addMode, Date effectiveDate,Integer releaseNo) {
		this.EffectiveDate = effectiveDate;
		this.addMode = addMode;
		this.releaseNo = releaseNo;
		convertEffectiveDate();
	}
	
	
	public boolean isAddMode() {
		return addMode;
	}


	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}


	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}
	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}
	
	
//	public Integer getEftxrid() {
//		return eftxrid;
//	}
//	
//	public void setEftxrid(Integer eftxrid) {
//		this.eftxrid = eftxrid;
//	}
	
	public Integer getEntityFileTypeID() {
		return EntityFileTypeID;
	}
	
	public void setEntityFileTypeID(Integer entityFileTypeID) {
		EntityFileTypeID = entityFileTypeID;
	}
	
	public String getEntityName() {
		return EntityName;
	}
	
	public void setEntityName(String entityName) {
		EntityName = entityName;
	}
	
	public String getHSFileType() {
		return HSFileType;
	}
	
	public void setHSFileType(String hSFileType) {
		HSFileType = hSFileType;
	}
	
	public String getFileFormat() {
		return FileFormat;
	}
	
	public void setFileFormat(String fileFormat) {
		FileFormat = fileFormat;
	}
	
	public String getFilePath() {
		return FilePath;
	}
	
	public void setFilePath(String filePath) {
		FilePath = filePath;
	}
	
	public String getFileMask() {
		return FileMask;
	}
	
	public void setFileMask(String fileMask) {
		FileMask = fileMask;
	}
	
	public String getRecDelimiter() {
		return RecDelimiter;
	}
	
	public void setRecDelimiter(String recDelimiter) {
		RecDelimiter = recDelimiter;
	}
	
	public String getColumnsDelimiter() {
		return ColumnsDelimiter;
	}
	
	public void setColumnsDelimiter(String columnsDelimiter) {
		ColumnsDelimiter = columnsDelimiter;
	}
	
	public Integer getColumnsCount() {
		return ColumnsCount;
	}
	
	public void setColumnsCount(Integer columnsCount) {
		ColumnsCount = columnsCount;
	}
	
	public Integer getMaxRecLen() {
		return MaxRecLen;
	}
	
	public void setMaxRecLen(Integer maxRecLen) {
		MaxRecLen = maxRecLen;
	}
	
	public String getAllowExtraColumns() {
		return AllowExtraColumns;
	}
	
	public void setAllowExtraColumns(String allowExtraColumns) {
		AllowExtraColumns = allowExtraColumns;
	}
	
	public Integer getNotifyRetyCount() {
		return NotifyRetyCount;
	}
	
	public void setNotifyRetyCount(Integer notifyRetyCount) {
		NotifyRetyCount = notifyRetyCount;
	}
	
	public Integer getOutboundOrder() {
		return OutboundOrder;
	}
	
	public void setOutboundOrder(Integer outboundOrder) {
		OutboundOrder = outboundOrder;
	}
	
	public String getActive() {
		return Active;
	}
	
	public void setActive(String active) {
		Active = active;
	}
	
	public Date getEffectiveDate() {
		return EffectiveDate;
	}
	
	public void setEffectiveDate(Date effectiveDate) {
		EffectiveDate = effectiveDate;
	}
	
	public Integer getColumnsWidth() {
		return ColumnsWidth;
	}
	
	public void setColumnsWidth(Integer columnsWidth) {
		ColumnsWidth = columnsWidth;
	}
	
	public String getDupFileCheck() {
		return DupFileCheck;
	}
	
	public void setDupFileCheck(String dupFileCheck) {
		DupFileCheck = dupFileCheck;
	}
	
	public String getColumnsPattern() {
		return ColumnsPattern;
	}
	
	public void setColumnsPattern(String columnsPattern) {
		ColumnsPattern = columnsPattern;
	}
	
	public String getNoDataRecordPattern() {
		return NoDataRecordPattern;
	}
	
	public void setNoDataRecordPattern(String noDataRecordPattern) {
		NoDataRecordPattern = noDataRecordPattern;
	}
	
	public String getNoRecordDelimiter() {
		return NoRecordDelimiter;
	}
	
	public void setNoRecordDelimiter(String noRecordDelimiter) {
		NoRecordDelimiter = noRecordDelimiter;
	}
	
	public String getOutBoundFilter() {
		return OutBoundFilter;
	}
	
	public void setOutBoundFilter(String outBoundFilter) {
		OutBoundFilter = outBoundFilter;
	}
	
	public String getSheetName() {
		return SheetName;
	}
	
	public void setSheetName(String sheetName) {
		SheetName = sheetName;
	}
	
	public Integer getIgnoreHeaderRowCount() {
		return IgnoreHeaderRowCount;
	}
	
	public void setIgnoreHeaderRowCount(Integer ignoreHeaderRowCount) {
		IgnoreHeaderRowCount = ignoreHeaderRowCount;
	}
	
	public Integer getIgnoreFooterRowCount() {
		return IgnoreFooterRowCount;
	}
	
	public void setIgnoreFooterRowCount(Integer ignoreFooterRowCount) {
		IgnoreFooterRowCount = ignoreFooterRowCount;
	}
	
	public Integer getFirstColumn() {
		return FirstColumn;
	}
	
	public void setFirstColumn(Integer firstColumn) {
		FirstColumn = firstColumn;
	}
	
	public Integer getLastColumn() {
		return LastColumn;
	}
	
	public void setLastColumn(Integer lastColumn) {
		LastColumn = lastColumn;
	}
	
	public String getAllowBlankRows() {
		return AllowBlankRows;
	}
	
	public void setAllowBlankRows(String allowBlankRows) {
		AllowBlankRows = allowBlankRows;
	}
	
	
	public String geteOFDelimiter() {
		return eOFDelimiter;
	}

	public void seteOFDelimiter(String eOFDelimiter) {
		this.eOFDelimiter = eOFDelimiter;
	}

	public String getComments() {
		return Comments;
	}
	
	public void setComments(String comments) {
		Comments = comments;
	}
	
	public Integer getEntityID() {
		return entityID;
	}

	public void setEntityID(Integer entityID) {
		this.entityID = entityID;
	}

	public Integer getFileTypeID() {
		return fileTypeID;
	}

	public void setFileTypeID(Integer fileTypeID) {
		this.fileTypeID = fileTypeID;
	}
	

	

	public Integer getPoolID() {
		return poolID;
	}

	public void setPoolID(Integer poolID) {
		this.poolID = poolID;
	}

	public Integer getFileFormatID() {
		return fileFormatID;
	}

	public void setFileFormatID(Integer fileFormatID) {
		this.fileFormatID = fileFormatID;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}
	
	

	public String getXsd() {
		return xsd;
	}

	public void setXsd(String xsd) {
		this.xsd = xsd;
	}

	public String getXmlLoop() {
		return xmlLoop;
	}

	public void setXmlLoop(String xmlLoop) {
		this.xmlLoop = xmlLoop;
	}

	public String getPrettify() {
		return prettify;
	}

	public void setPrettify(String prettify) {
		this.prettify = prettify;
	}

	@PostLoad
	public void postLoad(){
		convertEffectiveDate();
	}
	public void convertEffectiveDate(){
		this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());	
	}
	
}
