package com.artha.workbench.to;

import java.util.Map;

public class ChartQueryTO {

	private String description;
	private Map<String, Integer> statusNumberMap;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Map<String, Integer> getStatusNumberMap() {
		return statusNumberMap;
	}

	public void setStatusNumberMap(Map<String, Integer> statusNumberMap) {
		this.statusNumberMap = statusNumberMap;
	}

}
