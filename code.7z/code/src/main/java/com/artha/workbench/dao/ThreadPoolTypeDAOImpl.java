package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.ThreadPoolType;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class ThreadPoolTypeDAOImpl extends BaseDAOImpl<ThreadPoolType, Integer> implements ThreadPoolTypeDAO {

	public ThreadPoolTypeDAOImpl() {
		super(ThreadPoolType.class);
		// TODO Auto-generated constructor stub
	}

	public void saveThreadPoolType(List<ThreadPoolType> threadPoolType) {
		batchCreate(threadPoolType, 50);

	}

	@Transactional
	public void deleteThreadPoolType() {
		Query query = entityManager.createQuery("delete from ThreadPoolType");
		query.executeUpdate();
	}

	public int getmaxThreadPoolType() {
		int loginid = 0;
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(poolid) from ThreadPoolType", Integer.class);
		if (query.getSingleResult() != null)
			loginid = query.getSingleResult();
		return loginid;
	}

	@Transactional
	public List<ThreadPoolType> getThreadPoolTypeListByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<ThreadPoolType> query = cb.createQuery(ThreadPoolType.class);
		Root<ThreadPoolType> root = query.from(ThreadPoolType.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	
	
	public List<Integer> getPoolIds() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = criteriaBuilder.createQuery(Integer.class);
		Root<ThreadPoolType> root = criteriaQuery.from(ThreadPoolType.class);
		criteriaQuery.multiselect(root.get("poolid")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	@Override
	public List<Integer> getAllThreadPoolTypeReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from ThreadPoolType where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	@Override
	public List<ThreadPoolType> getThreadPoolTypeList(Set<Integer> poolIds, Integer selectedReleaseNumber) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<ThreadPoolType> query = cb.createQuery(ThreadPoolType.class);
		Root<ThreadPoolType> root = query.from(ThreadPoolType.class);
		query.select(root).distinct(true);
		query.where(cb.and(cb.in(root.get("poolid")).value(poolIds),
				cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));
		return this.entityManager.createQuery(query).getResultList();
	}
}
