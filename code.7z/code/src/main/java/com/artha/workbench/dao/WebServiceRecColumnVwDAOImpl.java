package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.WebServiceRecColumnVw;
import com.artha.workbench.models.metastore.WebServiceRecColumnVwKey;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class WebServiceRecColumnVwDAOImpl extends BaseDAOImpl<WebServiceRecColumnVw, WebServiceRecColumnVwKey> implements WebServiceRecColumnVwDAO{

	public WebServiceRecColumnVwDAOImpl()
	{
		
		super(WebServiceRecColumnVw.class);
		
	}
	
	public List<WebServiceRecColumnVw> getWebServiceRecColumnListByReleaseNo(Integer releaseNo){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<WebServiceRecColumnVw> query = cb.createQuery(WebServiceRecColumnVw.class);
		Root<WebServiceRecColumnVw> root = query.from(WebServiceRecColumnVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNum"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
}
