package com.artha.workbench.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.artha.workbench.constant.ListOfTablesEnum;
import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.models.metastore.EmptyFileConfig;
import com.artha.workbench.models.metastore.EntityFileRecColumn;
import com.artha.workbench.models.metastore.EntityFileRecColumnVw;
import com.artha.workbench.models.metastore.EntityFileTypeXref;
import com.artha.workbench.models.metastore.EntityFileTypeXrefVw;
import com.artha.workbench.models.metastore.EntityMaster;
import com.artha.workbench.models.metastore.EntityType;
import com.artha.workbench.models.metastore.FileFormat;
import com.artha.workbench.models.metastore.HSFileType;
import com.artha.workbench.models.metastore.RuleType;
import com.artha.workbench.models.metastore.ValidationStep;
import com.artha.workbench.service.EmptyFileConfigService;
import com.artha.workbench.service.EntityFileRecColoumnService;
import com.artha.workbench.service.EntityFileTypeScheduleXrefService;
import com.artha.workbench.service.EntityFileTypeXrefService;
import com.artha.workbench.service.EntityMasterService;
import com.artha.workbench.service.EntityTypeService;
import com.artha.workbench.service.FileFormatService;
import com.artha.workbench.service.FileTypeService;
import com.artha.workbench.service.LockedTableService;
import com.artha.workbench.service.RuleTypeService;
import com.artha.workbench.service.TablesListService;
import com.artha.workbench.service.ValidationStepService;
import com.artha.workbench.to.FileMaskTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.ThreadLocalUtil;

@RestController
@RequestMapping("/api/rulesManagement")

public class RulesManagementController {

	@Autowired
	EntityTypeService entityTypeService;

	@Autowired
	FileFormatService fileFormatService;

	@Autowired
	FileTypeService fileTypeService;

	@Autowired
	TablesListService tablesListService;

	@Autowired
	EntityMasterService entityMasterService;

	@Autowired
	EmptyFileConfigService emptyFileConfigService;

	@Autowired
	LockedTableService lockedTableService;

	@Autowired
	RuleTypeService ruleTypeService;

	@Autowired
	ValidationStepService validationStepService;

	@Autowired
	EntityFileRecColoumnService entityFileRecColoumnService;

	@Autowired
	EntityFileTypeScheduleXrefService entityFileTypeScheduleXrefService;

	@Autowired
	EntityFileTypeXrefService entityFileTypeXrefService;

	///// entityType

	@RequestMapping(value = "/entityType/description", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getEntityTypeDescription() {
		return tablesListService.getDescription(ListOfTablesEnum.ENTITY_TYPE.name);
	}

	@RequestMapping(value = "/entityType/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EntityType> getEntityTypeList() {
		return entityTypeService.getEntityTypeList();
	}

	@RequestMapping(value = "/entityType/save", method = RequestMethod.POST)
	public void createEntityType(@RequestBody EntityType entityType) {
		entityType.setEntityTypeID(entityTypeService.getmaxEntitytype() + 1);
		entityTypeService.create(entityType);
	}

	@RequestMapping(value = "/entityType/edit", method = RequestMethod.POST)
	public void updateEntityType(@RequestBody EntityType entityType) {
		boolean isReleaseChanged = false;
		if (entityType.getReleaseNo() != ThreadLocalUtil.getSelectedRelease()) {
			isReleaseChanged = Boolean.TRUE;
			entityType.setReleaseNo(ThreadLocalUtil.getSelectedRelease().intValue());
			try {
				entityTypeService.update(entityType, isReleaseChanged);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			} catch (AppException appException) {
				throw appException;
			}
		}
	}

	///// fileFormat

	@RequestMapping(value = "/fileFormat/description", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getFileFormatDescription() {
		return tablesListService.getDescription(ListOfTablesEnum.FILE_FORMAT.name);
	}

	@RequestMapping(value = "/fileFormat/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FileFormat> getFileFormatList() {
		return fileFormatService.getFileFormatList();
	}

	@RequestMapping(value = "/fileFormat/save", method = RequestMethod.POST)
	public void createFileFormat(@RequestBody FileFormat fileFormat) {
		fileFormat.setFileFormatID(fileFormatService.getmaxfileFormatID() + 1);
		fileFormatService.create(fileFormat);
	}

	@RequestMapping(value = "/fileFormat/edit", method = RequestMethod.POST)
	public void updateFileFormat(@RequestBody FileFormat fileFormat) {
		boolean isReleaseChanged = false;
		if (fileFormat.getReleaseNo().intValue() != ThreadLocalUtil.getSelectedRelease()) {
			isReleaseChanged = Boolean.TRUE;
			fileFormat.setReleaseNo(ThreadLocalUtil.getSelectedRelease().intValue());
		}
		try {
			fileFormatService.update(fileFormat, isReleaseChanged);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (AppException appException) {
			throw appException;
		}
	}

	//// File Type

	@RequestMapping(value = "/fileType/description", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getFileTypeDescription() {
		return tablesListService.getDescription(ListOfTablesEnum.HS_FILE_TYPE.name);
	}

	@RequestMapping(value = "/fileType/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<HSFileType> getHSFileTypeList() {
		return fileTypeService.getHSFileTypeList();
	}

	@RequestMapping(value = "/fileType/save", method = RequestMethod.POST)
	public void createFileType(@RequestBody HSFileType hSFileType) {
		hSFileType.setFileTypeID(fileTypeService.getmaxhsFileType() + 1);
		fileTypeService.create(hSFileType);
	}

	@RequestMapping(value = "/fileType/edit", method = RequestMethod.POST)
	public void updateHsFileType(@RequestBody HSFileType hSFileType) {
		boolean isReleaseChanged = false;
		if (hSFileType.getReleaseNo().intValue() != ThreadLocalUtil.getSelectedRelease()) {
			isReleaseChanged = Boolean.TRUE;
			hSFileType.setReleaseNo(ThreadLocalUtil.getSelectedRelease().intValue());
		}
		try {
			fileTypeService.update(hSFileType, isReleaseChanged);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (AppException appException) {
			throw appException;
		}
	}

	///// entityMaster

	@RequestMapping(value = "/entityMaster/description", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getEntityMasterDescription() {
		return tablesListService.getDescription(ListOfTablesEnum.ENTITY_MASTER.name);
	}

	@RequestMapping(value = "/entityMaster/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EntityMaster> getEntityMasterList() {
		return entityMasterService.getEntityMasterList();
	}

	@RequestMapping(value = "/entityMaster/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void createEntityMaster(@RequestBody EntityMaster entityMaster) {
		entityMaster.setEntityID(entityMasterService.getmaxEntitymster() + 1);
		entityMaster.convertEffectiveDate();
		entityMasterService.create(entityMaster);
	}

	@RequestMapping(value = "/entityMaster/edit", method = RequestMethod.POST)
	public void updateEntityMaster(@RequestBody EntityMaster entityMaster) {
		boolean isReleaseChanged = false;
		if (entityMaster.getReleaseNo().intValue() != ThreadLocalUtil.getSelectedRelease()) {
			isReleaseChanged = Boolean.TRUE;
			entityMaster.setReleaseNo(ThreadLocalUtil.getSelectedRelease().intValue());
		}
		try {
			entityMasterService.update(entityMaster, isReleaseChanged);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (AppException appException) {
			throw appException;
		}
	}

	@RequestMapping(value = "/entityMaster/loadEntityTypes", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public HashMap<Integer, String> loadentityTypeid() {
		return entityTypeService.loadentityTypeid();
	}
	
	////Entity File Type Xref
	
	@RequestMapping(value = "/entityFileTypeXref/description", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getEntityFileTypeXrefDescription() {
		return tablesListService.getDescription(ListOfTablesEnum.ENTITY_FILE_TYPE_XREF.name);
	}
	
	@RequestMapping(value = "/entityFileTypeXref/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EntityFileTypeXref> getEntityFileTypeXrefList() {
		return entityFileTypeXrefService.getEntityFileTypeXrefList();
	}

	@RequestMapping(value = "/entityFileTypeXref/save", method = RequestMethod.POST)
	public void createEntityFileTypeXref(@RequestBody EntityFileTypeXrefVw entityFileTypeXrefVW) {
		entityFileTypeXrefService.create(entityFileTypeXrefVW);
	}

	@RequestMapping(value = "/entityNames", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public HashMap<Integer, String> getEntityNames() {
		return entityMasterService.loadEntityIdMap();
	}

	@RequestMapping(value = "/fileTypes", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public HashMap<Integer, String> getFileTypes() {
		return fileTypeService.loadFiletypeIdMap();
	}

	@RequestMapping(value = "/fileFormats", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public HashMap<Integer, String> getFileFormats() {
		return fileFormatService.loadFileFormatId();
	}

	@RequestMapping(value = "/poolIds", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Integer> getpoolIds() {
		return entityFileTypeXrefService.getpoolIds();
	}

	@RequestMapping(value = "/entityFileTypeXref/edit", method = RequestMethod.POST)
	public void updateEntityFileTypeXref(@RequestBody EntityFileTypeXrefVw entityFileTypeXrefVw) {
		boolean isReleaseChanged = false;
		if (entityFileTypeXrefVw.getReleaseNo() != ThreadLocalUtil.getSelectedRelease().intValue()) {
			isReleaseChanged = true;
			entityFileTypeXrefVw.setReleaseNo(ThreadLocalUtil.getSelectedRelease().intValue());
		}
		entityFileTypeXrefVw
				.setEntityName(entityMasterService.loadEntityIdMap().get(entityFileTypeXrefVw.getEntityID()));
		entityFileTypeXrefVw
				.setFileFormat(fileTypeService.loadFiletypeIdMap().get(entityFileTypeXrefVw.getFileFormatID()));
		entityFileTypeXrefVw
				.setHSFileType(fileFormatService.loadFileFormatId().get(entityFileTypeXrefVw.getFileTypeID()));
		try {
			entityFileTypeXrefService.update(entityFileTypeXrefVw, isReleaseChanged);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (AppException appException) {
			throw appException;
		}
	}
	
	////Entity File Rec Column

	@RequestMapping(value = "/entityFileRecColumn/description", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getDescription() {
		return tablesListService.getDescription(ListOfTablesEnum.ENTITY_FILE_REC_COLUMN.name);
	}

	@RequestMapping(value = "/entityFileRecColumn/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EntityFileRecColumnVw> getEntityFileRecColumnList() {
		return entityFileRecColoumnService.getEntityFileRecColumnVwList();
	}

	@RequestMapping(value = "/entityFileRecColumn/save", method = RequestMethod.POST)
	public void createEntityFileRecColumn(@RequestBody EntityFileRecColumnVw entityFileRecColumnVw) {
		EntityFileRecColumn entityFileRecColumn = entityFileRecColoumnService
				.getEntityFileRecColInfo(entityFileRecColumnVw);
		if (entityFileRecColumn != null) {
			throw new AppException(MessagesEnum.REC_EXIST);
		}
		entityFileRecColoumnService.create(entityFileRecColumnVw);
	}

	@RequestMapping(value = "/entityFileRecColumn/edit", method = RequestMethod.POST)
	public void updateEntityFileRecColumn(@RequestBody EntityFileRecColumnVw entityFileRecColumnVw) {
		boolean isReleaseChanged = false;
		if (entityFileRecColumnVw.getReleaseNo() != ThreadLocalUtil.getSelectedRelease().intValue()) {
			isReleaseChanged = Boolean.TRUE;
			entityFileRecColumnVw.setReleaseNo(ThreadLocalUtil.getSelectedRelease().intValue());
		}
		try {
			entityFileRecColoumnService.update(entityFileRecColumnVw, isReleaseChanged);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (AppException appException) {
			throw appException;
		}
	}

	///// ruleType

	@RequestMapping(value = "/ruleType/description", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getRuleTypeDescription() {
		return tablesListService.getDescription(ListOfTablesEnum.RULE_TYPE.name);
	}

	@RequestMapping(value = "/ruleType/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<RuleType> getRuleTypeList() {
		return ruleTypeService.getRuleTypeList();
	}

	@RequestMapping(value = "/ruleType/save", method = RequestMethod.POST)
	public void createRuleType(@RequestBody RuleType ruleType) {
		ruleType.setRuleTypeID(ruleTypeService.getmaxruleTypeID() + 1);
		ruleTypeService.create(ruleType);
	}

	@RequestMapping(value = "/ruleType/edit", method = RequestMethod.POST)
	public void updateRuleType(@RequestBody RuleType ruleType) {
		boolean isReleaseChanged = false;
		if (ruleType.getReleaseNo().intValue() != ThreadLocalUtil.getSelectedRelease()) {
			isReleaseChanged = Boolean.TRUE;
			ruleType.setReleaseNo(ThreadLocalUtil.getSelectedRelease().intValue());
		}
		try {
			ruleTypeService.update(ruleType, isReleaseChanged);

		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (AppException appException) {
			throw appException;
		}
	}

	//// validationStep

	@RequestMapping(value = "/validationStep/description", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getValidationStepDescription() {
		return tablesListService.getDescription(ListOfTablesEnum.VALIDATION_STEP.name);
	}

	@RequestMapping(value = "/validationStep/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ValidationStep> getValidationStepList() {
		return validationStepService.getValidationStepList();
	}

	@RequestMapping(value = "/validationStep/save", method = RequestMethod.POST)
	public void createValidationStep(@RequestBody ValidationStep validationStep) {
		validationStep.setStepID(validationStepService.getmaxStepID() + 1);
		validationStepService.create(validationStep);
	}

	@RequestMapping(value = "/validationStep/edit", method = RequestMethod.POST)
	public void updateValidationStep(@RequestBody ValidationStep validationStep) {
		boolean isReleaseChanged = false;
		if (validationStep.getReleaseNo().intValue() != ThreadLocalUtil.getSelectedRelease().intValue()) {
			isReleaseChanged = Boolean.TRUE;
			validationStep.setReleaseNo(ThreadLocalUtil.getSelectedRelease().intValue());
		}
		try {
			validationStepService.update(validationStep, isReleaseChanged);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (AppException appException) {
			throw appException;
		}
	}

	///// emptyFileConfig
	
	@RequestMapping(value = "/emptyFileConfig/description", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getEmptyFileConfigDescription() {
		return tablesListService.getDescription(ListOfTablesEnum.EMPTY_FILE_CONFIG.name);
	}

	@RequestMapping(value = "/emptyFileConfig/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EmptyFileConfig> loadEmptyFileConfigList() {
		return emptyFileConfigService.getEmptyFileConfigList();
	}

	@RequestMapping(value = "/emptyFileConfig/save", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void createEmptyFileConfig(@RequestBody EmptyFileConfig emptyFileConfig) {
		emptyFileConfig.setEmptyFileConfigID(emptyFileConfigService.getmaxEmptyFileConfig() + 1);
		emptyFileConfigService.create(emptyFileConfig);
	}

	@RequestMapping(value = "/emptyFileConfig/edit", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void updateEmptyFileConfig(EmptyFileConfig emptyFileConfig) throws JsonProcessingException {
		boolean isReleaseChanged = false;
		if (emptyFileConfig.getReleaseNo() != ThreadLocalUtil.getSelectedRelease().intValue()) {
			isReleaseChanged = Boolean.TRUE;
			emptyFileConfig.setReleaseNo(ThreadLocalUtil.getSelectedRelease().intValue());
		}
		emptyFileConfigService.update(emptyFileConfig, isReleaseChanged);
		emptyFileConfig.convertEffectiveDate();
		// TODO add code for audit log
	}

	@RequestMapping(value = "/emptyFileConfig/loadEntityFileTypeId", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	List<Integer> loadEntityFileTypeId() {
		return emptyFileConfigService.loadentityFileTypeid();
	}

	@RequestMapping(value = "/emptyFileConfig/getEntityFileTypeSchedIds", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Integer> getEntityFileTypeSchedIds() {
		return emptyFileConfigService.getEntityFileTypeSchedIds();
	}	

	//// File Mask
	
	@RequestMapping(value = "/fileMask/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FileMaskTO> getFileMaskList() {
		return entityFileTypeScheduleXrefService.loadFileMaskTO();
	}

	@RequestMapping(value = "/fileMask/assignFileMask", method = RequestMethod.POST)
	public FileMaskTO assignSelectedFileMask(@RequestBody FileMaskTO fileMaskTO) {
		Map<Integer, String> fileTypeMap = fileTypeService.loadFiletypeIdMap();
		Map<Integer, String> entityNameMap = entityMasterService.loadEntityIdMap();
		EntityFileTypeXref entityFileTypeXref = entityFileTypeXrefService.findOne(fileMaskTO.getEntityFileTypeID());
		if (entityFileTypeXref != null) {
			fileMaskTO.setEntityID(entityFileTypeXref.getEntityID());
			fileMaskTO.setEntityName(entityNameMap.get(fileMaskTO.getEntityID()));
			fileMaskTO.setFileTypeID(entityFileTypeXref.getFileTypeID());
			fileMaskTO.setHsFileType(fileTypeMap.get(fileMaskTO.getFileTypeID()));
		}
		return fileMaskTO;
	}

}
