package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.SourceToServiceCriteriaVw;
import com.artha.workbench.models.metastore.SourceToServiceCriteriaVwKey;
import com.guvvala.framework.dao.BaseDAO;


public interface SourceToServiceCriteriaVwDAO extends BaseDAO<SourceToServiceCriteriaVw, SourceToServiceCriteriaVwKey> {
	public List<SourceToServiceCriteriaVw> geSourceToServiceCriteriaListByReleaseNo(Integer releaseNo);
	

}
