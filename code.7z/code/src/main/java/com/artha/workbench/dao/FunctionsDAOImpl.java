package com.artha.workbench.dao;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.Functions;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class FunctionsDAOImpl extends BaseDAOImpl<Functions, Long> implements FunctionsDAO {

	public FunctionsDAOImpl() {
		super(Functions.class);
	}
}
