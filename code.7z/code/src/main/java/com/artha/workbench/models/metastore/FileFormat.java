package com.artha.workbench.models.metastore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.guvvala.framework.util.ExcelHeader;

@Entity
@Table(name = "metastore.fileformat")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@JsonRootName("fileFormat")
@XmlRootElement(name="fileFormat")
public class FileFormat extends AbstractModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@ExcelHeader(name="FileFormatID")
	@Column(name = "FileFormatID", nullable = false)
	@Id
	@NotNull
	@JsonProperty("FileFormatID")
	private Integer fileFormatID;
	
	@ExcelHeader(name="FileFormat")
	@JsonProperty("FileFormat")
	private String fileFormat;
	
	@ExcelHeader(name="Description")
	@JsonProperty("Description")
	private String description;
	
	@Column(name = "ReleaseNum", nullable = false)
	@ExcelHeader(name="ReleaseNum")
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Transient
	@JsonIgnore
	private boolean addMode;
	
	public FileFormat(boolean addMode,Integer releaseNo) {
		this.addMode = addMode;
		this.releaseNo = releaseNo;
	}
	
	public FileFormat() {
	
	}

	public Integer getFileFormatID() {
		return fileFormatID;
	}
	public void setFileFormatID(Integer fileFormatID) {
		this.fileFormatID = fileFormatID;
	}
	public String getFileFormat() {
		return fileFormat;
	}
	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@XmlTransient
	public boolean isAddMode() {
		return addMode;
	}
	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}
	
	
	
}
