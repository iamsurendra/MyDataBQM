package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.EntityFileTypeWebService;
import com.artha.workbench.models.metastore.EntityFileTypeWebServiceVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EntityFileTypeWebServiceService {
	
	public List<Integer> getWebServiceIds();

	public int getmaxWebService();
	
	public List<EntityFileTypeWebService> getEntityFileTypeWebServiceList();
	
	public List<EntityFileTypeWebServiceVw> getEntityFileTypeWebServiceVwList();
	
	public void create(EntityFileTypeWebServiceVw entityFileTypeWebServiceVw, EntityFileTypeWebService entityFileTypeWebService);
	
	public void update(EntityFileTypeWebServiceVw entityFileTypeWebServiceVw, boolean isReleaseChanged)
			throws JsonProcessingException;
	public List<EntityFileTypeWebService> getEntityFileTypeWebServicefList(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber);
	
	public List<EntityFileTypeWebServiceVw> getEntityFileTypeWebServiceVwListByReleaseNo(Integer releaseNo);
	
	public List<EntityFileTypeWebService> getEntityFileTypeWebServiceListByReleaseNo(Integer releaseNo);
	
	public EntityFileTypeWebServiceVw getPreviousEntityFileTypeWebServiceVw(EntityFileTypeWebServiceVw entityFileTypeWebServiceVw)
			throws IOException;
	
	public EntityFileTypeWebService getEntityFileTypeWebService(EntityFileTypeWebServiceVw entityFileTypeWebServiceVw);

}
