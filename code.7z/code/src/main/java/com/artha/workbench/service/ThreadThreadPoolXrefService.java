package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.ThreadThreadPoolXref;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface ThreadThreadPoolXrefService {
	public List<ThreadThreadPoolXref> getThreadThreadPoolXrefList();

	public void update(ThreadThreadPoolXref threadThreadPoolXref, boolean isReleaseChanged)
			throws JsonProcessingException;

	public void saveThreadThreadPoolXref(List<ThreadThreadPoolXref> threadThreadPoolXref);

	public void create(ThreadThreadPoolXref threadThreadPoolXref);

	public List<ThreadThreadPoolXref> getThreadThreadPoolXrefByReleaseNo(Integer releaseNo);

	public ThreadThreadPoolXref getPreviousThreadThreadPoolXref(ThreadThreadPoolXref ThreadThreadPoolXref)
			throws IOException;

	public ThreadThreadPoolXref getThreadThreadPoolXrefInfoCheckDuplicate(ThreadThreadPoolXref threadThreadPoolXref);

	public List<Integer> getpoolIds();

}
