package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.WebServiceRecColumn;
import com.artha.workbench.models.metastore.WebServiceRecColumnKey;
import com.guvvala.framework.dao.BaseDAO;


public interface WebServiceRecColumnDAO extends BaseDAO<WebServiceRecColumn, WebServiceRecColumnKey> {

	List<WebServiceRecColumn> getWebServiceRecColumnListByReleaseNo(Integer releaseNo);

	List<WebServiceRecColumn> getWebServiceRecColumnList(Set<Integer> webServiceIds, Set<Integer> colIds,
			Integer selectedReleaseNumber);

	List<Integer> getWebServiceIds();

	List<Integer> getTargetColumnIds(Integer webServiceId);

	List<Integer> getAllWebServiceRecColReleaseIds(Integer selectedReleaseId);

}
