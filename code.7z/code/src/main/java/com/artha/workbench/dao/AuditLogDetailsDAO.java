package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.artha.workbench.models.config.AuditLogDetails;
import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.userConfig.Groups;
import com.artha.workbench.models.userConfig.Roles;
import com.guvvala.framework.dao.BaseDAO;

public interface AuditLogDetailsDAO extends BaseDAO<AuditLogDetails, Integer> {

	public void saveAll(HttpServletRequest request,HttpSession httpsession,String tname,List<? extends AbstractModel> entities,List<? extends AbstractModel> entityTypes,String reviewflag,HashMap<Integer,String> logintypemap,int reviewlistcount) ;
	 public List<AuditLogDetails> userlist(int loginid);
	 public void save(String tablename,HttpSession httpsession);
	 public void DownloadToAuditInfo(String tablename,HttpSession httpsession);
	 public void uploadToAuditInfo(String tablename, HttpSession httpsession);
	 public List<AuditLogDetails> adminlist(int loginid);
	 public void rolechangeAuditInfo(List<Roles> oldlist, List<Roles> changedlist,HttpSession httpsession);
	 public void groupchangeAuditInfo(List<Groups> oldlist, List<Groups> changedlist,HttpSession httpsession);
	 public List<AuditLogDetails> searchAll(String tablename,String changetype,String date,String modby);
	 public List<AuditLogDetails> searchAllAdmin(Long loginid,String tablename,String changetype,String date,String modby);
	 public void deleteAuditInfo(HttpSession httpsession);
}
