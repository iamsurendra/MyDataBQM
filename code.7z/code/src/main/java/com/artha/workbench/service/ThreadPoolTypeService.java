package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.ThreadPoolType;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface ThreadPoolTypeService {

	public List<ThreadPoolType> getThreadPoolTypeList();

	public void update(ThreadPoolType threadPoolType, boolean isReleaseChanged) throws JsonProcessingException;

	public void saveThreadPoolType(List<ThreadPoolType> threadPoolType);

	public int getmaxThreadPoolType();

	public void create(ThreadPoolType threadPoolType);
	
	public List<ThreadPoolType> getThreadPoolTypeListByReleaseNo(Integer releaseNo);
	
	public ThreadPoolType getPreviousThreadPoolType(ThreadPoolType threadPoolType) throws IOException;
	
	public List<ThreadPoolType> getThreadPoolTypeList(Set<Integer> poolIds, Integer selectedReleaseNumber);
}
