package com.artha.workbench.models.userConfig;

import java.io.Serializable;

public class GroupRolesKey implements Serializable{

		private int groupid;
		private int roleid;
}
