package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;



@Entity
@Table(name = "metastore.EntityFileRecColumn")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name="entityFileRecColumn")
public class EntityFileRecColumn extends AbstractModel {


	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	@JsonProperty("Key")
	private EntityFileRecColumnKey entityFileRecColKey;
	
	@Column(name = "EntityFileTypeID",insertable=false, nullable = false,updatable=false)
	@JsonIgnore
	private Integer entityFileTypeID;
	
	@Column(name = "ColumnID",insertable=false, nullable = false,updatable=false)
	@JsonIgnore
	private Integer columnID;
	
	@JsonProperty("ColName")
	private String colName;
	
	@JsonProperty("DataType")
	private String dataType;
	
	@JsonProperty("ColLength")
	private Integer colLength;
	
	@JsonProperty("StartPosition")
	private Integer startPosition;
	
	@JsonProperty("ColMask")
	private String colMask;
	
	@Column(name = "AllowNullValue", nullable = false)
	@JsonProperty("AllowNullValue")
	private String allowNullValue;
	
	@Column(name = "Active", nullable = false)
	@JsonProperty("Active")
	private String active;
	
	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date effectiveDate;
	
	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Column(name = "IncludeInRpt")
	@JsonProperty("IncludeInRpt")
	private Boolean includeInRpt;
	
	
	
	
	/*@XmlTransient
	public Integer getEntityFileTypeID() {
		return entityFileTypeID;
	}
	public void setEntityFileTypeID(Integer entityFileTypeID) {
		entityFileTypeID = entityFileTypeID;
	}*/
	
	
	
	@XmlTransient
	public Integer getColumnID() {
		return columnID;
	}
	@XmlTransient
	public Integer getEntityFileTypeID() {
		return entityFileTypeID;
	}
	public void setEntityFileTypeID(Integer entityFileTypeID) {
		this.entityFileTypeID = entityFileTypeID;
	}
	public void setColumnID(Integer columnID) {
		this.columnID = columnID;
	}
	public String getColName() {
		return colName;
	}
	public void setColName(String colName) {
		this.colName = colName;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public Integer getColLength() {
		return colLength;
	}
	public void setColLength(Integer colLength) {
		this.colLength = colLength;
	}
	public Integer getStartPosition() {
		return startPosition;
	}
	public void setStartPosition(Integer startPosition) {
		this.startPosition = startPosition;
	}
	public String getColMask() {
		return colMask;
	}
	public void setColMask(String colMask) {
		this.colMask = colMask;
	}
	public String getAllowNullValue() {
		return allowNullValue;
	}
	public void setAllowNullValue(String allowNullValue) {
		this.allowNullValue = allowNullValue;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	
	public EntityFileRecColumnKey getEntityFileRecColKey() {
		return entityFileRecColKey;
	}
	public void setEntityFileRecColKey(EntityFileRecColumnKey entityFileRecColKey) {
		this.entityFileRecColKey = entityFileRecColKey;
	}
	
	public Integer getReleaseNo() {
		return releaseNo;
	}
	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}
	

	public Boolean getIncludeInRpt() {
		return includeInRpt;
	}
	public void setIncludeInRpt(Boolean includeInRpt) {
		this.includeInRpt = includeInRpt;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((entityFileRecColKey == null) ? 0 : entityFileRecColKey.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EntityFileRecColumn other = (EntityFileRecColumn) obj;
		if (entityFileRecColKey == null) {
			if (other.entityFileRecColKey != null)
				return false;
		} else if (!entityFileRecColKey.equals(other.entityFileRecColKey))
			return false;
		return true;
	}


}
