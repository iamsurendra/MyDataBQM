package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.EntityMaster;
import com.guvvala.framework.dao.BaseDAO;


public interface EntityMasterDAO extends BaseDAO<EntityMaster, Integer> {
	@Transactional
	public void saveEntityMaster(List<EntityMaster> entitytypes);

	public int getmaxEntityMaster();

	public HashMap<String, Integer> loadEntityId();

	public void deleteEntityMaster();

	public HashMap<String, Integer> loadSelectedEntityId(int entityid);

	public HashMap<Integer, String> loadEntityIdMap();

	List<EntityMaster> getEntityMasterListByReleaseNo(Integer releaseNo);
	
	List<Integer> getEntityMasterReleaseNumbers(Set<Integer> entityIds,Integer selectedReleaseNumber);
	
	List<Integer> getAllEntityMasterReleaseIds(Integer selectedReleaseId);
	
	List<EntityMaster> getEntityMastersList(Set<Integer> entityIds,Integer selectedReleaseNumber);

}
