package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.HsSecurityAccess;
import com.artha.workbench.models.userConfig.User;
import com.guvvala.framework.dao.BaseDAO;

public interface UserDAO extends BaseDAO<User, Long> {

	public User getUser(String uname);

	public boolean uniqueUserEmail(String email);

	public boolean uniqueUserName(String userName);
	
	boolean uniqueUserEmail(String email,String userId);

	public void resetpwd(Long userid, String salt, String hash);

	public void unlockUser(Long userid);

	public void updateUserGroup(Long userId, int groupid);

	public List<HsSecurityAccess> getColAccessRights(Integer groupId);

	public List<String> getTaskAccessRights(Integer groupId);
	
	List<Long> getUsers(Integer groupId);
	
	List<User> getUsersList(Integer groupId);
	
	List<String> getUserNames();
	
	
}
