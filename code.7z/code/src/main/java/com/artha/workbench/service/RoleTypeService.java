package com.artha.workbench.service;

import java.util.HashMap;
import java.util.List;

import com.artha.workbench.models.config.RoleType;
import com.artha.workbench.models.userConfig.GroupRoles;
import com.artha.workbench.models.userConfig.RoleFunctions;


public interface RoleTypeService {

	public HashMap<Integer, String> loadlogintypeid();

	public List<RoleType> getRoleTypeList();

	public List<RoleType> getRoleDetails();

	public void create(RoleType roleType);

	public int getMaxRoleid();

	public String checkRoleExist(String lname);
	
	public List<GroupRoles> loadRoals(int groupid); 
	
	public List<RoleFunctions> getRolefunctions(); 
	
	public List<Integer> getGroupRoles(Integer groupId);
	
	public List<RoleFunctions> getRoleFunctionsById(List<Integer> roleIds);
	
	public List<String> getRoleNamesById(List<Long> roleIds);
	
}
