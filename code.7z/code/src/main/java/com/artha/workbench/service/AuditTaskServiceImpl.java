package com.artha.workbench.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.artha.workbench.dao.AuditTaskDAO;
import com.artha.workbench.models.core.AuditTaskInfo_VW;
import com.artha.workbench.to.AuditTaskTO;

@Service("auditTaskService")
public class AuditTaskServiceImpl implements AuditTaskService {

	@Autowired
	AuditTaskDAO auditTaskDAO;

	@Override
	@Transactional
	public List<AuditTaskTO> getAuditTasks() {
		List<AuditTaskInfo_VW> taskRevList = auditTaskDAO.getAuditTaskList();
		return loadAuditTask(taskRevList);
	}

	@Override
	@Transactional
	public List<AuditTaskTO> getAuditTaskByAccessRight(List<String> taskAccessRights) {
		List<AuditTaskInfo_VW> taskRevList = auditTaskDAO.getAuditTaskByAccessRight(taskAccessRights);
		return loadAuditTask(taskRevList);
	}

	private List<AuditTaskTO> loadAuditTask(List<AuditTaskInfo_VW> taskRevList) {
		Map<String, AuditTaskTO> taskMap = new HashMap<String, AuditTaskTO>();
		List<AuditTaskTO> auditTaskList = new ArrayList<AuditTaskTO>();
		for (AuditTaskInfo_VW taskRev : taskRevList) {
			// TODO check for the first record what will happen
			if (taskMap.containsKey(taskRev.getTaskId())) {
				AuditTaskTO auditTaskTO = taskMap.get(taskRev.getTaskId());
				auditTaskTO.setPreviousStatus(taskRev.getStatus());
				if (auditTaskList.contains(auditTaskTO)) {
					auditTaskList.remove(auditTaskTO);
				}
				auditTaskList.add(auditTaskTO);
			} else {
				AuditTaskTO auditTaskTO = new AuditTaskTO();
				auditTaskTO.setTaskId(taskRev.getTaskId());
				auditTaskTO.setModifiedBy(taskRev.getLastUpdBy());
				auditTaskTO.setModifiedOn(taskRev.getLastUpdDt());
				auditTaskTO.setOwner(taskRev.getOwner());
				if (null != taskRev.getRevisionTypeString()
						&& taskRev.getRevisionTypeString().equalsIgnoreCase("Deleted")) {
					auditTaskTO.setPresentStatus("Deleted");
				} else {
					auditTaskTO.setPresentStatus(taskRev.getStatus());
				}
				auditTaskTO.setTaskName(taskRev.getTaskName());
				taskMap.put(taskRev.getTaskId(), auditTaskTO);
				auditTaskList.add(auditTaskTO);
			}
		}
		return auditTaskList;
	}
}