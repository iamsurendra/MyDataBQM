package com.artha.workbench.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.artha.workbench.models.userConfig.TableList;
import com.artha.workbench.service.TablesListService;

@RestController
@RequestMapping("/api/listOfTables")
public class ListOfTablesController {

	@Autowired
	TablesListService tableListService;

	@RequestMapping(value = "/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<TableList> getTablelist(String statusFlag) {
		return tableListService.getTablelist(statusFlag);

	}

	@RequestMapping(value = "/upadateList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void updateList(@RequestBody TableList tableList) {
		tableListService.update(tableList);
	}
}
