package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.models.userConfig.UserPreference;
import com.artha.workbench.models.userConfig.UserPreferencePK;

public interface UserPreferenceService {
	
	public void saveUserPreferences(UserPreference timeOutPreference,UserPreference pollIntervalPreference);
	
    public UserPreference validateDuplicateUserPreference(UserPreferencePK userPreferencePK);
    
    List<UserPreference> getUserPreferenceByUserId(Long userId);
}
