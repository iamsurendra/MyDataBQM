package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.SourceToServiceCriteriaVw;
import com.artha.workbench.models.metastore.SourceToServiceCriteriaVwKey;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class SourceToServiceCriteriaVwDAOImpl extends BaseDAOImpl<SourceToServiceCriteriaVw, SourceToServiceCriteriaVwKey> implements SourceToServiceCriteriaVwDAO {
	
	public SourceToServiceCriteriaVwDAOImpl() {
		super(SourceToServiceCriteriaVw.class);
	}
	public List<SourceToServiceCriteriaVw> geSourceToServiceCriteriaListByReleaseNo(Integer releaseNo){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SourceToServiceCriteriaVw> query = cb.createQuery(SourceToServiceCriteriaVw.class);
		Root<SourceToServiceCriteriaVw> root = query.from(SourceToServiceCriteriaVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNum"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
}
