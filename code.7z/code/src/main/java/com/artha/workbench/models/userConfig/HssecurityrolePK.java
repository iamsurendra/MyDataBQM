package com.artha.workbench.models.userConfig;

import java.io.Serializable;

import javax.persistence.*;

/**
 * The primary key class for the hssecurityroles database table.
 * 
 */
@Embeddable
public class HssecurityrolePK implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Column(name = "EntityFileTypeID")
	private Long entityFileTypeId;

	@Column(name = "COL_NAME")
	private String colName;


	@Column(name = "ROLE_ID")
	private Long roleId;
	
	public HssecurityrolePK() {
	}

	public HssecurityrolePK(Long roleID, Long entityFileTypeId, String colName) {
		super();
		this.colName = colName;
		this.roleId = roleID;
		this.entityFileTypeId = entityFileTypeId;
	}

	
	public String getColName() {
		return colName;
	}

	public void setColName(String colName) {
		this.colName = colName;
	}

	
	public Long getEntityFileTypeId() {
		return entityFileTypeId;
	}

	public void setEntityFileTypeId(Long entityFileTypeId) {
		this.entityFileTypeId = entityFileTypeId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((entityFileTypeId == null) ? 0 : entityFileTypeId.hashCode());
		result = prime * result + ((colName == null) ? 0 : colName.hashCode());
		result = prime * result + ((roleId == null) ? 0 : roleId.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HssecurityrolePK other = (HssecurityrolePK) obj;
		if (colName == null) {
			if (other.colName != null)
				return false;
		} else if (!colName.equals(other.colName))
			return false;
		if (entityFileTypeId == null) {
			if (other.entityFileTypeId != null)
				return false;
		} else if (!entityFileTypeId.equals(other.entityFileTypeId))
			return false;
		if (roleId == null) {
			if (other.roleId != null)
				return false;
		} else if (!roleId.equals(other.roleId))
			return false;
		
		return true;
	}

}