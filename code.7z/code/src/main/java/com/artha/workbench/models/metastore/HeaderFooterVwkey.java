
package com.artha.workbench.models.metastore;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class HeaderFooterVwkey implements Serializable{

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	    @JsonProperty("filemask")
		private String FileMask;
		
	    @JsonProperty("entityname")
		private String EntityName;
		
	    @JsonProperty("hsfiletype")
		private String HSFileType;
		
	    @JsonProperty("rectype")
		private String RecType;
		
	    @JsonProperty("seqnum")
		private int seqnum;
		
		public String getFileMask() {
			return FileMask;
		}
		public void setFileMask(String fileMask) {
			FileMask = fileMask;
		}
		public String getEntityName() {
			return EntityName;
		}
		public void setEntityName(String entityName) {
			EntityName = entityName;
		}
		public String getHSFileType() {
			return HSFileType;
		}
		public void setHSFileType(String hSFileType) {
			HSFileType = hSFileType;
		}
		public String getRecType() {
			return RecType;
		}
		public void setRecType(String recType) {
			RecType = recType;
		}
		public int getSeqnum() {
			return seqnum;
		}
		public void setSeqnum(int seqnum) {
			this.seqnum = seqnum;
		}
		
		
}
