package com.artha.workbench.dao;


import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.GroupRoles;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class GroupRolesDAOImpl extends BaseDAOImpl<GroupRoles, Long> implements GroupRolesDAO {

	public GroupRolesDAOImpl() {
		super(GroupRoles.class);
	}
	
	// To get Roles based on groupId
	@Override
	public List<Integer> getGroupRoles(Integer groupId) {

		TypedQuery<Integer> query = entityManager.createQuery("select roleid from GroupRoles where groupid = :groupID",
				Integer.class);
		query.setParameter("groupID", groupId);
		return query.getResultList();
	}
	
	@Override
	public List<GroupRoles> getGroupRolesList(Integer groupId) {

		TypedQuery<GroupRoles> query = entityManager.createQuery("from GroupRoles where groupid = :groupID",
				GroupRoles.class);
		query.setParameter("groupID", groupId);
		return query.getResultList();
	}
	
}
