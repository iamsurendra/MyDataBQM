package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.LockedTablesDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.ThreadPoolTypeDAO;
import com.artha.workbench.dao.ThreadThreadPoolXrefDAO;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.models.metastore.ThreadThreadPoolXref;
import com.artha.workbench.models.metastore.ThreadThreadPoolXrefKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("threadThreadPoolXrefService")
public class ThreadThreadPoolXrefServiceImpl implements ThreadThreadPoolXrefService {
	@Autowired
	ThreadThreadPoolXrefDAO threadThreadPoolXrefDAO;

	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Autowired
	LockedTablesDAO lockedTablesDAO;

	@Autowired
	ThreadPoolTypeDAO threadPoolTypeDAO;

	@Override
	@Transactional(readOnly = true)
	public List<ThreadThreadPoolXref> getThreadThreadPoolXrefList() {
		return threadThreadPoolXrefDAO.findAll();
	}

	@Transactional
	public void create(ThreadThreadPoolXref threadThreadPoolXref) {
		ThreadThreadPoolXrefKey keyObj = new ThreadThreadPoolXrefKey();
		keyObj.setThread(threadThreadPoolXref.getThread());
		keyObj.setPoolid(threadThreadPoolXref.getPoolid());
		threadThreadPoolXref.setThreadThreadPoolXrefKey(keyObj);
		threadThreadPoolXrefDAO.create(threadThreadPoolXref);
	}

	@Transactional
	@Override
	public void update(ThreadThreadPoolXref threadThreadPoolXref, boolean isReleaseChanged)
			throws JsonProcessingException {
		ThreadThreadPoolXrefKey threadThreadPoolXrefPK = new ThreadThreadPoolXrefKey();
		threadThreadPoolXrefPK.setThread(threadThreadPoolXref.getThread());
		threadThreadPoolXrefPK.setPoolid(threadThreadPoolXref.getPoolid());
		ThreadThreadPoolXref oldthreadThreadPoolXref = threadThreadPoolXrefDAO.findOne(threadThreadPoolXrefPK);
		checkForCyclicDependency(threadThreadPoolXref);
		if (isReleaseChanged) {
			ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			releaseArchiveKey.setArchivedReleaseId(oldthreadThreadPoolXref.getReleaseNo());
			releaseArchiveKey.setReleaseId(threadThreadPoolXref.getReleaseNo());
			releaseArchiveKey.setTableName("THREADTHREADPOOLXREF");
			ThreadThreadPoolXrefKey threadThreadPoolXrefId = new ThreadThreadPoolXrefKey();
			threadThreadPoolXrefId.setThread(threadThreadPoolXref.getThread());
			threadThreadPoolXrefId.setPoolid(threadThreadPoolXref.getPoolid());
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(threadThreadPoolXrefId));

			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if (releaseArchive != null) {
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldthreadThreadPoolXref));
				releaseArchiveDAO.update(releaseArchive);
			} else {
				releaseArchive = new ReleaseArchive();
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldthreadThreadPoolXref));
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchiveDAO.create(releaseArchive);
			}
		}
		threadThreadPoolXrefDAO.update(threadThreadPoolXref);
	}

	private void checkForCyclicDependency(ThreadThreadPoolXref threadThreadPoolXref) throws JsonProcessingException {
		ThreadThreadPoolXrefKey threadThreadPoolXrefId = new ThreadThreadPoolXrefKey();
		threadThreadPoolXrefId.setThread(threadThreadPoolXref.getThread());
		threadThreadPoolXrefId.setPoolid(threadThreadPoolXref.getPoolid());
		String jsonId = AppWebUtils.convertObjectToJson(threadThreadPoolXrefId);
		ReleaseArchive releaseArchive = releaseArchiveDAO
				.getReleaseArchiveByArchiveId(threadThreadPoolXref.getReleaseNo(), "THREADTHREADPOOLXREF", jsonId);
		if (releaseArchive != null) {
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	@Transactional
	public ThreadThreadPoolXref getThreadThreadPoolXrefInfoCheckDuplicate(ThreadThreadPoolXref threadThreadPoolXref) {
		ThreadThreadPoolXrefKey threadThreadPoolXrefKey = new ThreadThreadPoolXrefKey();
		threadThreadPoolXrefKey.setThread(threadThreadPoolXref.getThread());
		threadThreadPoolXrefKey.setPoolid(threadThreadPoolXref.getPoolid());
		return threadThreadPoolXrefDAO.findOne(threadThreadPoolXrefKey);
	}

	@Transactional
	public void saveThreadThreadPoolXref(List<ThreadThreadPoolXref> threadThreadPoolXref) {
		threadThreadPoolXrefDAO.deleteThreadThreadPoolXref();
		threadThreadPoolXrefDAO.saveThreadThreadPoolXref(threadThreadPoolXref);
		;
	}

	@Transactional
	public List<ThreadThreadPoolXref> getThreadThreadPoolXrefByReleaseNo(Integer releaseNo) {
		return threadThreadPoolXrefDAO.getThreadThreadPoolXrefByReleaseNo(releaseNo);
	}

	@Override
	public ThreadThreadPoolXref getPreviousThreadThreadPoolXref(ThreadThreadPoolXref threadThreadPoolXref)
			throws IOException {
		ThreadThreadPoolXrefKey threadThreadPoolXrefKey = new ThreadThreadPoolXrefKey();
		threadThreadPoolXrefKey.setThread(threadThreadPoolXref.getThread());
		threadThreadPoolXrefKey.setPoolid(threadThreadPoolXref.getPoolid());
		String threadThreadPoolXrefJson = AppWebUtils.convertObjectToJson(threadThreadPoolXrefKey);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(threadThreadPoolXref.getReleaseNo(),
				"THREADTHREADPOOLXREF", threadThreadPoolXrefJson);
		ThreadThreadPoolXref previousThreadThreadPoolXref = new ThreadThreadPoolXref();
		if (releaseArchive != null) {
			previousThreadThreadPoolXref = AppWebUtils.convertJsonToObject(ThreadThreadPoolXref.class,
					releaseArchive.getRecData());
		}
		return previousThreadThreadPoolXref;
	}

	@Transactional
	public List<Integer> getpoolIds() {
		return threadPoolTypeDAO.getPoolIds();

	}

}
