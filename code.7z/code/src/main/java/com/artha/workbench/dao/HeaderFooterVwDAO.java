package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.HeaderFooterVw;
import com.artha.workbench.models.metastore.HeaderFooterVwkey;
import com.guvvala.framework.dao.BaseDAO;


public interface HeaderFooterVwDAO extends BaseDAO<HeaderFooterVw, HeaderFooterVwkey> {
	
	public List<HeaderFooterVw> getHeaderFooterVwListByReleaseNo(Integer releaseNo);
}
