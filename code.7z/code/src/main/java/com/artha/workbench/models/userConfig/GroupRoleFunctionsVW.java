package com.artha.workbench.models.userConfig;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "userconfig.grouprolesfunctionsvw")
public class GroupRoleFunctionsVW implements Serializable {

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private GroupRoleFunctionsPK id;

	@Column(name = "WRITE_MODE")
	private boolean write;

	public String getName() {
		return id.getName();
	}

	public boolean isWrite() {
		return write;
	}

	public void setWrite(boolean write) {
		this.write = write;
	}

}
