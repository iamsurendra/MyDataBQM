package com.artha.workbench.models.userConfig;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.ThreadLocalUtil;

/**
 * The persistent class for the Hssecurityrole database table.
 * 
 */
@Entity
@Table(name = "userconfig.hssecurityroles")
@NamedQuery(name = "Hssecurityrole.findAll", query = "SELECT h FROM Hssecurityrole h")
public class Hssecurityrole implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private HssecurityrolePK id;
	
	@Column(name = "PARTNER_ID")
	private Long partnerId;
	
	
	@Column(name = "FILE_ID")
	private Long fileId;

	@Column(name = "WRITE_MODE")
	@Type(type = "numeric_boolean")
	private boolean writeMode;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATION_DATE")
	private Timestamp creationDate;

	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;

	@Column(name = "LAST_UPDATED_DATE")
	private Timestamp lastUpdatedDate;
	
	@Transient
	private boolean readMode;

	public Hssecurityrole() {
	}

	public HssecurityrolePK getId() {
		return id;
	}

	public void setId(HssecurityrolePK id) {
		this.id = id;
	}

	public boolean isWriteMode() {
		return writeMode;
	}

	public void setWriteMode(boolean writeMode) {
		this.writeMode = writeMode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	
	

	public Long getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	public Long getFileId() {
		return fileId;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public boolean isReadMode() {
		return readMode;
	}

	public void setReadMode(boolean readMode) {
		this.readMode = readMode;
	}

	@PrePersist
	public void prePersist() {
		setCreatedBy(ThreadLocalUtil.getUserName());
		setLastUpdatedBy(ThreadLocalUtil.getUserName());
		setCreationDate(DateUtils.getCurrentTimeStamp());
		setLastUpdatedDate(DateUtils.getCurrentTimeStamp());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hssecurityrole other = (Hssecurityrole) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}