package com.artha.workbench.service;


import java.io.IOException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileTypeScheduleXrefDAO;
import com.artha.workbench.dao.EntityFileTypeScheduleXrefVwDAO;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.EntityMasterDAO;
import com.artha.workbench.dao.FileTypeDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.metastore.EntityFileTypeScheduleXref;
import com.artha.workbench.models.metastore.EntityFileTypeScheduleXrefId;
import com.artha.workbench.models.metastore.EntityFileTypeScheduleXrefVw;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.to.FileMaskTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("entityFileTypeScheduleXrefService")
public class EntityFileTypeScheduleXrefServiceImpl implements EntityFileTypeScheduleXrefService {

	@Autowired
	EntityFileTypeScheduleXrefDAO entityFileTypeScheduleXrefDAO;

	@Autowired
	EntityFileTypeScheduleXrefVwDAO entityFileTypeScheduleXrefVwDAO;

	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefdbDAO;

	@Autowired
	FileTypeDAO fileTypeDAO;

	@Autowired
	EntityMasterDAO entityMasterDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Transactional(readOnly = true)
	public List<EntityFileTypeScheduleXref> getEntityFileTypeScheduleXrefList() {
		return entityFileTypeScheduleXrefDAO.findAll();
	}
	

	@Transactional(readOnly = true)
	@Override
	public List<EntityFileTypeScheduleXrefVw> getEntityFileTypeScheduleXrefByReleaseNo(Integer releaseNo) {
		return entityFileTypeScheduleXrefVwDAO.getEntityFileTypeScheduleXrefByReleaseNo(releaseNo);
	}
	
	@Transactional(readOnly = true)
	@Override
	public EntityFileTypeScheduleXrefVw getPreviousEntityFileTypeScheduleXrefVw(EntityFileTypeScheduleXrefVw entityFileTypeScheduleXrefVw) throws IOException
	{
		EntityFileTypeScheduleXrefId entityFileTypeScheduleXrefId = new EntityFileTypeScheduleXrefId();
		entityFileTypeScheduleXrefId.setEntityFileTypeSchedID(entityFileTypeScheduleXrefVw.getEntityFileTypeSchedID());
		String entityFileTypeScheduleXrefIdJson = AppWebUtils.convertObjectToJson(entityFileTypeScheduleXrefId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(entityFileTypeScheduleXrefVw.getReleaseNo(), "EntityFileTypeScheduleXref", entityFileTypeScheduleXrefIdJson);
		EntityFileTypeScheduleXrefVw previousEntityFileTypeScheduleXrefVw = new EntityFileTypeScheduleXrefVw();
		if(releaseArchive!=null){
			previousEntityFileTypeScheduleXrefVw = AppWebUtils.convertJsonToObject(EntityFileTypeScheduleXrefVw.class, releaseArchive.getViewRecData());
		}
		return previousEntityFileTypeScheduleXrefVw;
		
	}

	
	@Transactional
	public void create(EntityFileTypeScheduleXrefVw eftSchXrefVw) {
		EntityFileTypeScheduleXref enFileTypeScheduleXref = new EntityFileTypeScheduleXref();
		enFileTypeScheduleXref.setEntityFileTypeSchedID(entityFileTypeScheduleXrefDAO.getMaxEntitySchedID() + 1);
		loadEntityFileTypeSchXrefList(enFileTypeScheduleXref, eftSchXrefVw);
		entityFileTypeScheduleXrefDAO.create(enFileTypeScheduleXref);
	}

	@Transactional
	public void update(EntityFileTypeScheduleXrefVw eftSchXrefVw,boolean isReleaseChanged) throws JsonProcessingException {
		checkForCyclicDependency(eftSchXrefVw);
		EntityFileTypeScheduleXref enFileTypeScheduleXref = entityFileTypeScheduleXrefDAO
				.findOne(eftSchXrefVw.getEntityFileTypeSchedID());
		if(isReleaseChanged)
		{
			EntityFileTypeScheduleXrefVw oldVIewEntity =entityFileTypeScheduleXrefVwDAO.findOne(eftSchXrefVw.getEntityFileTypeSchedID());
			if(oldVIewEntity!=null){
				ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
				releaseArchiveKey.setArchivedReleaseId(oldVIewEntity.getReleaseNo());
				releaseArchiveKey.setReleaseId(eftSchXrefVw.getReleaseNo());
				releaseArchiveKey.setTableName("EntityFileTypeScheduleXref");
				EntityFileTypeScheduleXrefId entityFileTypeScheduleXrefId = new EntityFileTypeScheduleXrefId();
				entityFileTypeScheduleXrefId.setEntityFileTypeSchedID(enFileTypeScheduleXref.getEntityFileTypeSchedID());
				releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityFileTypeScheduleXrefId));
				ReleaseArchive releaseArchive =releaseArchiveDAO.findOne(releaseArchiveKey);
				if(releaseArchive!=null){
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldVIewEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(enFileTypeScheduleXref));
					releaseArchiveDAO.update(releaseArchive);
				}else{
					releaseArchive=new ReleaseArchive();
					releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
					releaseArchive.setViewRecData(AppWebUtils.convertObjectToJson(oldVIewEntity));
					releaseArchive.setRecData(AppWebUtils.convertObjectToJson(enFileTypeScheduleXref));

					releaseArchiveDAO.create(releaseArchive);
				}
			}
		}
		if (enFileTypeScheduleXref != null) {
			loadEntityFileTypeSchXrefList(enFileTypeScheduleXref, eftSchXrefVw);
			entityFileTypeScheduleXrefDAO.update(enFileTypeScheduleXref);
		}
	}

	private void checkForCyclicDependency(EntityFileTypeScheduleXrefVw eftSchXrefVw) throws JsonProcessingException	{
		EntityFileTypeScheduleXrefId entityFileTypeScheduleXrefId = new EntityFileTypeScheduleXrefId();
		entityFileTypeScheduleXrefId.setEntityFileTypeSchedID(eftSchXrefVw.getEntityFileTypeSchedID());
		String jsonId = AppWebUtils.convertObjectToJson(entityFileTypeScheduleXrefId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(eftSchXrefVw.getReleaseNo(), "EntityFileTypeScheduleXref", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	
	@Transactional
	private EntityFileTypeScheduleXref loadEntityFileTypeSchXrefList(EntityFileTypeScheduleXref eftSchXref,
			EntityFileTypeScheduleXrefVw eftSchXrefVw) {

		eftSchXref.setEntityFileTypeID(eftSchXrefVw.getEntityfiletypeid());
		eftSchXref.setScheduleFequencyType(eftSchXrefVw.getScheduleFequencyType());
		eftSchXref.setSchFrequencyValue(eftSchXrefVw.getSchFrequencyValue());
		eftSchXref.setScheduleOffsetType(eftSchXrefVw.getScheduleOffsetType());
		eftSchXref.setScheduleOffsetValue(eftSchXrefVw.getScheduleOffsetValue());
		eftSchXref.setFileDirection(eftSchXrefVw.getFileDirection());
		eftSchXref.setReleaseNo(eftSchXrefVw.getReleaseNo());
		eftSchXref.setActive(eftSchXrefVw.getActive());

		return eftSchXref;
	}

	@Transactional
	public List<EntityFileTypeScheduleXrefVw> getEntityFileTypeScheduleXrefVwList() {
		return entityFileTypeScheduleXrefVwDAO.findAll();
	}

	@Transactional
	public void saveEntityFileTypeScheduleXref(List<EntityFileTypeScheduleXref> entitytypes) {
		entityFileTypeScheduleXrefDAO.saveEntityFileTypeScheduleXref(entitytypes);
	}

	@Transactional
	public int getMaxEntitySchedID() {
		return entityFileTypeScheduleXrefDAO.getMaxEntitySchedID();
	}

	@Override
	public List<FileMaskTO> loadFileMaskTO() {
		// TODO Auto-generated method stub
		return entityFileTypeScheduleXrefDAO.loadFileMaskTO();
	}
	public List<FileMaskTO> searchFileMaskTO(String fileMask,String description){
		return entityFileTypeScheduleXrefDAO.searchFileMaskTO(fileMask, description);
	}
	
	@Transactional(readOnly=true)
	public  List<EntityFileTypeScheduleXref> getEntityFileTypeScheduleXrefList(Integer releaseNO){
		return entityFileTypeScheduleXrefDAO.getEntityFileTypeScheduleXrefList(releaseNO);
	}

	@Transactional(readOnly=true)
	public List<Integer> getAllEntityFileTypeSchXrefReleaseIds(Integer selectedReleaseId){
		return entityFileTypeScheduleXrefDAO.getAllEntityFileTypeSchXrefReleaseIds(selectedReleaseId);
	}

}
