package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.datahub.SrcColumnErrorInfo;
import com.artha.workbench.models.datahub.Srccolumns;
import com.artha.workbench.models.datahub.TgtColumns;
import com.guvvala.framework.dao.BaseDAO;

public interface SrccolumnsDAO extends BaseDAO<Srccolumns, Integer> {
	public List<SrcColumnErrorInfo> getPopuplist(String srcid);

	public List<TgtColumns> getTargetPopuplist(String srcid);

	public void deleteAllSrcColumns(List<String> srcRecId);

}
