package com.artha.workbench.to;

import java.util.ArrayList;
import java.util.List;

import com.artha.workbench.models.datahub.Srccolumns;
import com.artha.workbench.models.datahub.Task;

public class CreateTaskTo {
	private List<Srccolumns> columnaccess = new ArrayList<>();
	private List<Srccolumns> noReadAccessSrcCols = new ArrayList<>();
	private Task data;

	public Task getData() {
		return data;
	}

	public void setData(Task data) {
		this.data = data;
	}

	public List<Srccolumns> getNoReadAccessSrcCols() {
		return noReadAccessSrcCols;
	}

	public void setNoReadAccessSrcCols(List<Srccolumns> noReadAccessSrcCols) {
		this.noReadAccessSrcCols = noReadAccessSrcCols;
	}

	public List<Srccolumns> getColumnaccess() {
		return columnaccess;
	}

	public void setColumnaccess(List<Srccolumns> columnaccess) {
		this.columnaccess = columnaccess;
	}

}
