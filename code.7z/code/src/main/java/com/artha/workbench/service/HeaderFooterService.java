package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.HeaderFooter;
import com.artha.workbench.models.metastore.HeaderFooterVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface HeaderFooterService {

	public List<HeaderFooter> getHeaderFooterList();

	public void create(HeaderFooterVw headerFooterVw);

	public void update(HeaderFooterVw headerFooterVw,boolean isReleaseChanged)throws JsonProcessingException;

	public List<HeaderFooterVw> getHeaderFooterVwList();

	public void saveHeaderFooter(List<HeaderFooter> entitytypes);

	public List<HeaderFooter> getHeaderFooterDBList();

	public HeaderFooter getHeaderFooter(HeaderFooterVw headerFooterVw);

	public HeaderFooter getHeaderFooter(Integer entityFileTypeId,String recType,Integer seqNum);
	
	public List<String> getHeaderFooterRecTypeList();
	
	public List<Integer> getHeaderFooterSeqNumList();
	
	public HeaderFooterVw getPreviousHeaderFooterVw(HeaderFooterVw headerFooterVw) throws IOException;

	public List<HeaderFooterVw> getHeaderFooterVwListByReleaseNo(Integer releaseNo);
	
	public List<HeaderFooter> getHeaderFooterListByReleaseNo(Integer releaseNo);
	
	List<Integer> getHeaderFooterReleaseNumbersByRecTypes(Set<String> recTypes,Integer selectedReleaseNumber);
	List<Integer> getHeaderFooterReleaseNumbersBySeqNums(Set<Integer> seqNumbers,Integer selectedReleaseNumber);
	List<Integer> getHeaderFooterReleaseNumbersByTypeIds(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber);
	
	List<Integer> getAllHeaderFooterReleaseIds(Integer selectedReleaseId);
	
	List<HeaderFooter> getHeaderFooterLists(Set<Integer> entityFileTypeIds,Set<String> recTypes,Set<Integer> seqNumbers,Integer selectedReleaseNumber);
}
