package com.artha.workbench.models.metastore;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PostLoad;

import java.util.Date;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "metastore.SourceToWebServiceMapping_V")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate

public class SourceToWebServiceMappingVw extends AbstractModel {

	private static final long serialVersionUID = 1L;
	@EmbeddedId
	private SourceToWebServiceMappingVwKey sourceToWebServiceMappingVwKey;

	@Column(name = "WebServiceID", insertable = false, updatable = false)
	@JsonProperty("WebServiceID")
	private Integer webServiceID;

	@Column(name = "EntityName", insertable = false, updatable = false)
	@JsonProperty("EntityName")
	private String entityName;

	@Column(name = "HsFileType", insertable = false, updatable = false)
	@JsonProperty("HsFileType")
	private String hsFileType;

	@Column(name = "FileMask", insertable = false, updatable = false)
	@JsonProperty("FileMask")
	private String fileMask;

	@Column(name = "SourceEntityFileTypeID", insertable = false, updatable = false)
	@JsonProperty("SourceEntityFileTypeID")
	private Integer sourceEntityFileTypeID;

	@Column(name = "TargetColumnID", insertable = false, updatable = false)
	@JsonProperty("TargetColumnID")
	private Integer targetColumnID;

	@JsonProperty("MapFunction")
	private String mapFunction;

	@JsonProperty("Active")
	private String active;

	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date effectiveDate;

	@JsonProperty("TargetColOrder")
	private Integer targetColOrder;

	@JsonProperty("ReleaseNum")
	private Integer releaseNum;

	@Transient
	@JsonIgnore
	private boolean addMode;
	
	@Transient
	@JsonIgnore
	private String effectiveDtstr;
	
	public SourceToWebServiceMappingVw(){
		
	}
	
	public SourceToWebServiceMappingVw(boolean addMode,Date effectiveDate,Integer releaseNo){
		this.effectiveDate = effectiveDate;
		this.addMode = addMode;
		this.releaseNum = releaseNo;
		convertEffectiveDate();
	}
	
	//getters/setters
	
	public Integer getWebServiceID() {
		return webServiceID;
	}

	public void setWebServiceID(Integer webServiceID) {
		this.webServiceID = webServiceID;
	}

	public String getHsFileType() {
		return hsFileType;
	}

	public void setHsFileType(String hsFileType) {
		this.hsFileType = hsFileType;
	}

	public String getFileMask() {
		return fileMask;
	}

	public void setFileMask(String fileMask) {
		this.fileMask = fileMask;
	}

	public Integer getSourceEntityFileTypeID() {
		return sourceEntityFileTypeID;
	}

	public void setSourceEntityFileTypeID(Integer sourceEntityFileTypeID) {
		this.sourceEntityFileTypeID = sourceEntityFileTypeID;
	}

	public Integer getTargetColumnID() {
		return targetColumnID;
	}

	public void setTargetColumnID(Integer targetColumnID) {
		this.targetColumnID = targetColumnID;
	}

	public String getMapFunction() {
		return mapFunction;
	}

	public void setMapFunction(String mapFunction) {
		this.mapFunction = mapFunction;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Integer getTargetColOrder() {
		return targetColOrder;
	}

	public void setTargetColOrder(Integer targetColOrder) {
		this.targetColOrder = targetColOrder;
	}

	public Integer getReleaseNum() {
		return releaseNum;
	}

	public void setReleaseNum(Integer releaseNum) {
		this.releaseNum = releaseNum;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}

	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}

	public SourceToWebServiceMappingVwKey getSourceToWebServiceMappingVwKey() {
		return sourceToWebServiceMappingVwKey;
	}

	public void setSourceToWebServiceMappingVwKey(SourceToWebServiceMappingVwKey sourceToWebServiceMappingVwKey) {
		this.sourceToWebServiceMappingVwKey = sourceToWebServiceMappingVwKey;
	}

	@PostLoad
	public void postLoad(){
		convertEffectiveDate();
	}
	public void convertEffectiveDate(){
		this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());	
	}
}
