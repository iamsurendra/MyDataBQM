package com.artha.workbench.dao;

import java.util.HashMap;

import com.artha.workbench.models.datahub.TaskType;
import com.guvvala.framework.dao.BaseDAO;

public interface TaskTypeDAO extends BaseDAO<TaskType, Integer> {
	public HashMap<Integer,String> loadtaskType();
}
