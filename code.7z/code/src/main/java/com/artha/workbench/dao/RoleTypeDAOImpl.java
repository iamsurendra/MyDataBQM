package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.config.RoleType;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class RoleTypeDAOImpl extends BaseDAOImpl<RoleType, Integer> implements RoleTypeDAO {

	public RoleTypeDAOImpl() {
		super(RoleType.class);
	}

	public HashMap<Integer, String> loadlogintypeid() {
		HashMap<Integer, String> hsmap = new HashMap<Integer, String>();
		List<Integer> filelist = null;
		List<String> fidlist = null;
		TypedQuery<Integer> query = entityManager.createQuery("SELECT roletypeid from RoleType", Integer.class);
		TypedQuery<String> query1 = entityManager.createQuery("SELECT description from RoleType", String.class);
		filelist = query.getResultList();
		fidlist = query1.getResultList();
		query1.getResultList();
		if (fidlist != null) {
			for (int i = 0; i < fidlist.size(); i++) {
				hsmap.put(filelist.get(i), fidlist.get(i));
			}
		}
		return hsmap;

	}

	public List<RoleType> getRoleDetails() {
		List<RoleType> roleTypelist = null;
		TypedQuery<RoleType> query = entityManager.createQuery("from RoleType where status='Y' ", RoleType.class);
		roleTypelist = query.getResultList();
		return roleTypelist;
	}

	public int getMaxRoleid() {
		int loginid = 0;
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(roletypeid) from RoleType", Integer.class);
		if (query.getSingleResult() != null)
			loginid = query.getSingleResult();
		return loginid;
	}

	public String checkRoleExist(String lname) {
		String loginname = "";
		TypedQuery<String> query = entityManager.createQuery("SELECT description from RoleType where description ='" + lname + "'", String.class);
		if (query.getSingleResult() != null)
			loginname = query.getSingleResult();
		return loginname;
	}

}
