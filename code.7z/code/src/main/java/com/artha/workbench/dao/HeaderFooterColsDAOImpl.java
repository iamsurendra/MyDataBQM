package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.HeaderFooterCols;
import com.artha.workbench.models.metastore.Headerfootercolkey;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class HeaderFooterColsDAOImpl extends BaseDAOImpl<HeaderFooterCols, Headerfootercolkey>
		implements HeaderFooterColsDAO {

	public HeaderFooterColsDAOImpl() {
		super(HeaderFooterCols.class);
	}

	public void saveHeaderFooterCol(List<HeaderFooterCols> entitytypes) {
		batchCreate(entitytypes, 50);
	}

	public void deleteHeaderFooterCol() {
		Query query = entityManager.createQuery("delete from HeaderFooterCols");
		query.executeUpdate();
	}

	public List<HeaderFooterCols> getHeadeFooterColsListByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<HeaderFooterCols> query = cb.createQuery(HeaderFooterCols.class);
		Root<HeaderFooterCols> root = query.from(HeaderFooterCols.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllHeaderFooterColsReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from HeaderFooterCols where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
}
