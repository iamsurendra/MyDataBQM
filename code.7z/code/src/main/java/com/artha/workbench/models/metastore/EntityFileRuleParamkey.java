package com.artha.workbench.models.metastore;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EntityFileRuleParamkey implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2843793382279791123L;

	@JsonProperty("EntityFileRuleID")
	private int EntityFileRuleId;
	
	  @JsonProperty("ParamID")
	   private String ParamID;
}
