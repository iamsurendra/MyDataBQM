package com.artha.workbench.dao;

import com.artha.workbench.models.datahub.TaskLineLayout;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * @author Guvala
 *
 */
public class TaskLineLayoutDAOImpl extends BaseDAOImpl<TaskLineLayout, String> implements TaskLineLayoutDAO {

	public TaskLineLayoutDAOImpl() {
		super(TaskLineLayout.class);
	}

}
