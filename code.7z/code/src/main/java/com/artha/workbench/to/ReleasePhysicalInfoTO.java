package com.artha.workbench.to;

import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "physical")
@XmlType(propOrder = { "fkDependentReleases", "pkDependentReleases" })
public class ReleasePhysicalInfoTO {

	private Set<String> fkDependentReleases = new HashSet<>();

	private Set<String> pkDependentReleases = new HashSet<>();
	
	@XmlElementWrapper(name="foreignKeys")
	@XmlElement(name="dependentRelease")
	public Set<String> getFkDependentReleases() {
		return fkDependentReleases;
	}

	public void setFkDependentReleases(Set<String> fkDependentReleases) {
		this.fkDependentReleases = fkDependentReleases;
	}

	@XmlElementWrapper(name="primaryKey")
	@XmlElement(name="dependentRelease")
	public Set<String> getPkDependentReleases() {
		return pkDependentReleases;
	}

	public void setPkDependentReleases(Set<String> pkDependentReleases) {
		this.pkDependentReleases = pkDependentReleases;
	}

}
