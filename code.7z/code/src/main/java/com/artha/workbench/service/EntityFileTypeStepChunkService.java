package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.EntityFileTypeStepChunk;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EntityFileTypeStepChunkService {

	public List<EntityFileTypeStepChunk> getEntityFileTypeStepChunkList();

	public void update(EntityFileTypeStepChunk entityFileTypeStepChunk, boolean isReleaseChanged)
			throws JsonProcessingException;

	public List<Integer> loadEntityfiletypeIds();

	public List<Integer> loadStepIds();

	public void createEntityFileTypeStepChunk(EntityFileTypeStepChunk entityFileTypeStepChunk);

	public EntityFileTypeStepChunk getEntityFileTypeStepChunkCheckDuplicate(
			EntityFileTypeStepChunk entityFileTypeStepChunk);

	public List<EntityFileTypeStepChunk> getEntityFileTypeStepChunByReleaseNo(Integer releaseNo);

	public EntityFileTypeStepChunk getPreviousEntityFileTypeStepChunk(EntityFileTypeStepChunk entityFileTypeStepChunk)throws IOException;

}
