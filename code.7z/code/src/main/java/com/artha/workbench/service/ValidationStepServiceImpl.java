package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.ValidationStepDAO;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.models.metastore.ValidationStep;
import com.artha.workbench.models.metastore.ValidationStepId;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("validationStepService")
public class ValidationStepServiceImpl implements ValidationStepService {

	@Autowired
	ValidationStepDAO validationStepDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;


	@Transactional(readOnly = true)
	public List<ValidationStep> getValidationStepList() {
		return validationStepDAO.findAll();
	}
	
	@Transactional(readOnly = true)
	public List<ValidationStep> getValidationStepListByReleaseNo(Integer releaseNo){
		 return validationStepDAO.getValidationStepListByReleaseNo(releaseNo);
	}
	
	@Transactional
	public ValidationStep getPreviousValidationStep(ValidationStep validationStep) throws IOException
	{
		ValidationStepId validationid = new ValidationStepId();
		validationid.setStepID(validationStep.getStepID());
		String validationStepIdJson = AppWebUtils.convertObjectToJson(validationid);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(validationStep.getReleaseNo(), "VALIDATIONSTEP", validationStepIdJson);
		ValidationStep previousValidationStep = new ValidationStep();
		if(releaseArchive!=null){
			previousValidationStep = AppWebUtils.convertJsonToObject(ValidationStep.class, releaseArchive.getRecData());
		}
		return previousValidationStep;
		
	}

	@Transactional
	public void create(ValidationStep validationStep) {
		validationStepDAO.create(validationStep);
	}

	@Transactional
	public void update(ValidationStep validationStep,boolean isReleaseChanged) throws JsonProcessingException {
		ValidationStep oldEntity = validationStepDAO.findOne(validationStep.getStepID());
		checkForCyclicDependency(validationStep);
		
		if (isReleaseChanged) {
			ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
			releaseArchiveKey.setReleaseId(validationStep.getReleaseNo());
			releaseArchiveKey.setTableName("VALIDATIONSTEP");
			ValidationStepId validationid = new ValidationStepId();
			validationid.setStepID(oldEntity.getStepID());
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(validationid));
			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if(releaseArchive!=null){
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchiveDAO.update(releaseArchive);
			}else{
				releaseArchive = new ReleaseArchive();
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchiveDAO.create(releaseArchive);
			}
			}
		validationStepDAO.update(validationStep);
	}
	
	
	private void checkForCyclicDependency(ValidationStep validationStep) throws JsonProcessingException{
		ValidationStepId validationid = new ValidationStepId();
		validationid.setStepID(validationStep.getStepID());
		String jsonId = AppWebUtils.convertObjectToJson(validationid);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(validationStep.getReleaseNo(), "VALIDATIONSTEP", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	
	@Transactional
	public void savevalidationStep(List<ValidationStep> entitytypes)
	{
		validationStepDAO.savevalidationStep(entitytypes);
	}
	@Transactional
	public int getmaxStepID()
	{
		return validationStepDAO.getmaxStepID();
	}
	@Transactional
	public HashMap<String,Integer> loadStepId() {
		return validationStepDAO.loadStepId();
	}
	@Transactional
	public HashMap<Integer,String> loadStepIdMap() {
		return validationStepDAO.loadStepIdMap();
	}
	
	@Transactional
	public List<Integer> getValidationStepReleaseNumbers(Set<Integer> stepIds,Integer selectedReleaseNumber){
		return validationStepDAO.getValidationStepReleaseNumbers(stepIds, selectedReleaseNumber);
	}
	
	@Override
	@Transactional(readOnly=true)
	public List<Integer> getAllValidationStepReleaseIds(Integer selectedReleaseId){
		return validationStepDAO.getAllValidationStepReleaseIds(selectedReleaseId);
	}

	@Override
	@Transactional(readOnly=true)
	public List<ValidationStep> getValidationStepList(Set<Integer> stepIds, Integer selectedReleaseNumber) {
		return validationStepDAO.getValidationStepList(stepIds, selectedReleaseNumber);
	}
}
