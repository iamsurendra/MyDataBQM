package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.metastore.HSFileType;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class FileTypeDAOImpl extends BaseDAOImpl<HSFileType, Integer> implements FileTypeDAO {

	public FileTypeDAOImpl() {
		super(HSFileType.class);
	}

	public void saveHSFileType(List<HSFileType> entitytypes) {
		HSFileType hSFileType = null;
		for (AbstractModel ref : entitytypes) {
			hSFileType = (HSFileType) ref;
			create(hSFileType);
		}
	}

	public int getmaxhsFileType() {
		int loginid = 0;
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(fileTypeID) from HSFileType", Integer.class);
		if (query.getSingleResult() != null)
			loginid = query.getSingleResult();
		return loginid;
	}

	public HashMap<String, Integer> loadFiletypeId() {
		List<String> filelist = null;
		List<Integer> fidlist = null;
		HashMap<String, Integer> hsmap = new HashMap<String, Integer>();
		TypedQuery<String> query = entityManager.createQuery("SELECT hsFileType from HSFileType", String.class);
		TypedQuery<Integer> query1 = entityManager.createQuery("SELECT fileTypeID from HSFileType", Integer.class);
		filelist = query.getResultList();
		fidlist = query1.getResultList();
		if (fidlist != null) {
			for (int i = 0; i < fidlist.size(); i++) {
				hsmap.put(filelist.get(i), fidlist.get(i));
			}
		}
		return hsmap;
	}

	@Override
	public HashMap<Integer, String> loadFiletypeIdMap() {

		HashMap<Integer, String> hsmap = new HashMap<Integer, String>();
		TypedQuery<Object[]> query = entityManager.createQuery("SELECT fileTypeID ,hsFileType from HSFileType",
				Object[].class);
		List<Object[]> filelist = query.getResultList();
		for (Object[] array : filelist) {
			hsmap.put((Integer) array[0], (String) array[1]);
		}

		return hsmap;
	}

	public HashMap<String, Integer> loadSelectedFiletypeId(int entityid) {
		List<String> filelist = null;
		List<Integer> fidlist = null;
		HashMap<String, Integer> hsmap = new HashMap<String, Integer>();
		TypedQuery<String> query = entityManager.createQuery(
				"SELECT hs.hsFileType from HSFileType hs,EntityFileTypeXref ef where hs.fileTypeID = ef.fileTypeID and ef.entityFileTypeID ='"
						+ entityid + "'",
				String.class);
		TypedQuery<Integer> query1 = entityManager.createQuery(
				"SELECT hs.fileTypeID from HSFileType hs,EntityFileTypeXref ef where hs.fileTypeID = ef.fileTypeID and ef.entityFileTypeID ='"
						+ entityid + "'",
				Integer.class);
		filelist = query.getResultList();
		fidlist = query1.getResultList();
		if (fidlist != null) {
			for (int i = 0; i < fidlist.size(); i++) {
				hsmap.put(filelist.get(i), fidlist.get(i));
			}
		}
		return hsmap;
	}

	public void deleteHsFiletype() {
		Query query = entityManager.createQuery("delete from HSFileType");
		query.executeUpdate();
	}

	public List<HSFileType> getFileTypeListByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<HSFileType> query = cb.createQuery(HSFileType.class);
		Root<HSFileType> root = query.from(HSFileType.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));

		return this.entityManager.createQuery(query).getResultList();
	}

	@Override
	public List<Integer> getFileTypeReleaseNumbers(Set<Integer> fileTypeIds, Integer selectedReleaseNumber) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<HSFileType> root = query.from(HSFileType.class);
		query.select(root.<Integer> get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("fileTypeID")).value(fileTypeIds),
				cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllFileTypeReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from HSFileType where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	
	@Override
	public List<HSFileType> getFileTypesList(Set<Integer> fileTypeIds, Integer selectedReleaseNumber) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<HSFileType> query = cb.createQuery(HSFileType.class);
		Root<HSFileType> root = query.from(HSFileType.class);
		query.select(root).distinct(true);
		query.where(cb.and(cb.in(root.get("fileTypeID")).value(fileTypeIds),
				cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));
		return this.entityManager.createQuery(query).getResultList();
	}

}
