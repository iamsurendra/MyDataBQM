package com.artha.workbench.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.artha.workbench.models.userConfig.ChartQuery;
import com.artha.workbench.to.ChartQueryTO;

@Repository
public class ChartQueryDAOImpl extends BaseDAOImpl<ChartQuery, Integer> implements ChartQueryDAO {

	public ChartQueryDAOImpl() {
		super(ChartQuery.class);
	}
	
	public List<ChartQueryTO> executeQueries()
	{
		List<ChartQuery> chartQueryList = findAll();
		List<ChartQueryTO> chartQueryTOList = new ArrayList<ChartQueryTO>();
		for(ChartQuery chartQuery : chartQueryList)
		{
			ChartQueryTO chartQueryTO = new ChartQueryTO();
			Map<String,Integer> statusCount = new HashMap<String,Integer>();
			Query nativeQuery = entityManager.createNativeQuery(chartQuery.getQuery());
			List<Object[]> queryResults = nativeQuery.getResultList();
			chartQueryTO.setDescription(chartQuery.getDescription());
			for(Object[] object : queryResults)
			{
				statusCount.put((String)object[0], (Integer)object[1]);
			}
			chartQueryTO.setStatusNumberMap(statusCount);
			chartQueryTOList.add(chartQueryTO);
			
		}
		return chartQueryTOList;
	}

}
