package com.artha.workbench.to;

import java.util.Date;

import com.guvvala.framework.util.DateUtils;

public class DeletedUserTO {
	
	private String userName;
	
	private String firstName;
	
	private String lastName;
	
	private String email;
	
	private boolean admin;
	
	private boolean superadmin;
	
	private Date deletedOn;
	
	private String deletedBy;
	
	private String deletedOnString;
	
	
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public boolean isSuperadmin() {
		return superadmin;
	}

	public void setSuperadmin(boolean superadmin) {
		this.superadmin = superadmin;
	}

	public Date getDeletedOn() {
		return deletedOn;
	}

	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}

	public String getDeletedBy() {
		return deletedBy;
	}

	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}

	public String getDeletedOnString() {
		return getDeletedOn()!=null ? DateUtils.convertDateFormat(getDeletedOn(), DateUtils.DISPLAY_DATE_TIME_FORMAT):null;
	}

	public void setDeletedOnString(String deletedOnString) {
		this.deletedOnString = deletedOnString;
	}

}
