package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.FileTypeColumns;
import com.guvvala.framework.dao.BaseDAO;

public interface FileTypeColumnsDAO extends BaseDAO<FileTypeColumns, Integer> {

	public List<String> findColumnsByFileName(String fileName);

	public List<FileTypeColumns> findColumnsByEntityFileTypeID(Long id);
	
	public List<FileTypeColumns> findFileTypeColumnsByEntityFileTypeID(Long id);
	
	public List<FileTypeColumns> findColumnsByEntityFileTypeId(Integer id);
	
	public List<String> getColumnsByEntityFileTypeId(Long id);

}