package com.artha.workbench.to;


import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * @author GuvalaL1
 *
 */
@XmlRootElement(name="releasePackageInfo")
@XmlType(propOrder={"releaseDependencies","releaseMetadata"})
public class ReleasePackageInfoTO {
	
	private String releasePackageName;
	
	private Integer releasePackageNumber;
	
	private ReleaseDependenciesTO releaseDependencies = new ReleaseDependenciesTO();
	
	private ReleaseMetadataTO releaseMetadata = new ReleaseMetadataTO();
	
	@XmlAttribute(name="releasePackageName")
	public String getReleasePackageName() {
		return releasePackageName;
	}

	public void setReleasePackageName(String releasePackageName) {
		this.releasePackageName = releasePackageName;
	}

	@XmlAttribute(name="releasePackageNumber")
	public Integer getReleasePackageNumber() {
		return releasePackageNumber;
	}

	public void setReleasePackageNumber(Integer releasePackageNumber) {
		this.releasePackageNumber = releasePackageNumber;
	}

	@XmlElement(name="dependencies")
	public ReleaseDependenciesTO getReleaseDependencies() {
		return releaseDependencies;
	}

	public void setReleaseDependencies(ReleaseDependenciesTO releaseDependencies) {
		this.releaseDependencies = releaseDependencies;
	}

	@XmlElement(name="metadata")
	public ReleaseMetadataTO getReleaseMetadata() {
		return releaseMetadata;
	}

	public void setReleaseMetadata(ReleaseMetadataTO releaseMetadata) {
		this.releaseMetadata = releaseMetadata;
	}	
}
