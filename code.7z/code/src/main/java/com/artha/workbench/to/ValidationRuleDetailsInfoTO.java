package com.artha.workbench.to;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.artha.workbench.models.metastore.EntityFileRuleParam;
import com.artha.workbench.models.metastore.EntityFileRuleXref;
import com.artha.workbench.models.metastore.EntityFileValidationRule;
import com.artha.workbench.models.metastore.EntityFileValidationRuleVw;


@XmlRootElement(name = "entityFileValidationRuleDetails")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder={"entityFileValidationRuleVw","entityFileValidationRule","entityFileRuleXref","entityFileRuleParams"})
public class ValidationRuleDetailsInfoTO {


	@XmlElement(name="entityFileValidationRuleVw")
	private EntityFileValidationRuleVw entityFileValidationRuleVw = new EntityFileValidationRuleVw();
	
	
	@XmlElement(name="entityFileValidationRule")
	private EntityFileValidationRule entityFileValidationRule = new EntityFileValidationRule();
	
	
	
	@XmlElement(name="entityFileRuleXref")
	private EntityFileRuleXref entityFileRuleXref = new EntityFileRuleXref();
	
	
	@XmlElementWrapper(name="entityFileRuleParams")
	@XmlElement(name="entityFileRuleParam",type=EntityFileRuleParam.class)
	private List<EntityFileRuleParam> entityFileRuleParams = new ArrayList<>();


	public EntityFileValidationRule getEntityFileValidationRule() {
		return entityFileValidationRule;
	}


	public void setEntityFileValidationRule(EntityFileValidationRule entityFileValidationRule) {
		this.entityFileValidationRule = entityFileValidationRule;
	}


	public EntityFileRuleXref getEntityFileRuleXref() {
		return entityFileRuleXref;
	}


	public void setEntityFileRuleXref(EntityFileRuleXref entityFileRuleXref) {
		this.entityFileRuleXref = entityFileRuleXref;
	}


	public List<EntityFileRuleParam> getEntityFileRuleParams() {
		return entityFileRuleParams;
	}


	public void setEntityFileRuleParams(List<EntityFileRuleParam> entityFileRuleParams) {
		this.entityFileRuleParams = entityFileRuleParams;
	}


	public EntityFileValidationRuleVw getEntityFileValidationRuleVw() {
		return entityFileValidationRuleVw;
	}


	public void setEntityFileValidationRuleVw(EntityFileValidationRuleVw entityFileValidationRuleVw) {
		this.entityFileValidationRuleVw = entityFileValidationRuleVw;
	}
	
	
	
	
	
}
