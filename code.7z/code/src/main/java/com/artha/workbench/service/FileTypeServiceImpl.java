package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.FileTypeDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.metastore.HSFileType;
import com.artha.workbench.models.metastore.HSFileTypeId;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("fileTypeService")
public class FileTypeServiceImpl implements FileTypeService {

	@Autowired
	FileTypeDAO filetypeDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Transactional(readOnly = true)
	public List<HSFileType> getHSFileTypeList() {
		return filetypeDAO.findAll();
	}
	
	@Transactional(readOnly = true)
	public List<HSFileType> getFileTypeListByReleaseNo(Integer releaseNo){
		return filetypeDAO.getFileTypeListByReleaseNo(releaseNo);
	}

	@Transactional
	public void create(HSFileType hsfileType) {
		filetypeDAO.create(hsfileType);
	}
	@Transactional(readOnly = true)

	public HSFileType getPreviousFileType(HSFileType fileType) throws IOException{	
		HSFileTypeId hsFileTypeId = new HSFileTypeId();
		hsFileTypeId.setFileTypeID(fileType.getFileTypeID());
		String fileTypeTypeIdJson = AppWebUtils.convertObjectToJson(hsFileTypeId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(fileType.getReleaseNo(), "HSFileType", fileTypeTypeIdJson);
		HSFileType previousFileType = new HSFileType();
		if(releaseArchive!=null){
			previousFileType = AppWebUtils.convertJsonToObject(HSFileType.class, releaseArchive.getRecData());
		}
		return previousFileType;
		
	}
	

	@Transactional
	public void update(HSFileType hsfileType, boolean isReleaseChanged) throws JsonProcessingException {
		HSFileType oldEntity = filetypeDAO.findOne(hsfileType.getFileTypeID());
		checkForCyclicDependency(hsfileType);
		if (isReleaseChanged) {
			ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();

			releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
			releaseArchiveKey.setReleaseId(hsfileType.getReleaseNo());
			releaseArchiveKey.setTableName("HSFileType");
			HSFileTypeId hsFileTypeId = new HSFileTypeId();
			hsFileTypeId.setFileTypeID(oldEntity.getFileTypeID());
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(hsFileTypeId));
			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if(releaseArchive!=null){
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchiveDAO.update(releaseArchive);
			}else{
				releaseArchive=new ReleaseArchive();
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchiveDAO.update(releaseArchive);
			}
		}
		filetypeDAO.update(hsfileType);
	}
	
	private void checkForCyclicDependency(HSFileType hsfileType) throws JsonProcessingException
	{
		HSFileTypeId hsFileTypeId = new HSFileTypeId();
		hsFileTypeId.setFileTypeID(hsfileType.getFileTypeID());
		
		String jsonId = AppWebUtils.convertObjectToJson(hsFileTypeId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(hsfileType.getReleaseNo(), "HSFileType", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	@Transactional
	 public void saveHSFileType(List<HSFileType> entitytypes)
	 {
		filetypeDAO.saveHSFileType(entitytypes);
	 }
	@Transactional
	 public int getmaxhsFileType() {
		return filetypeDAO.getmaxhsFileType();
	    }
	@Transactional
	 public HashMap<String,Integer> loadFiletypeId()
	 {
		 return filetypeDAO.loadFiletypeId();
	 }
	@Transactional
	 public HashMap<Integer,String> loadFiletypeIdMap()
	 {
		 return filetypeDAO.loadFiletypeIdMap();
	 }
	@Transactional
	public HashMap<String,Integer> loadSelectedFiletypeId(int entityid)
	{
		 return filetypeDAO.loadSelectedFiletypeId(entityid);
	}
	
	@Transactional(readOnly=true)
	public List<Integer> getFileTypeReleaseNumbers(Set<Integer> fileTypeIds,Integer selectedReleaseNumber){
		return filetypeDAO.getFileTypeReleaseNumbers(fileTypeIds, selectedReleaseNumber);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Integer> getAllFileTypeReleaseIds(Integer selectedReleaseId) {
		return filetypeDAO.getAllFileTypeReleaseIds(selectedReleaseId);
	}

	@Override
	public List<HSFileType> getFileTypesList(Set<Integer> fileTypeIds, Integer selectedReleaseNumber) {
		return filetypeDAO.getFileTypesList(fileTypeIds, selectedReleaseNumber);
	}
}
