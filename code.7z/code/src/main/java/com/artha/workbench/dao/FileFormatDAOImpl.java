package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.metastore.FileFormat;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class FileFormatDAOImpl extends BaseDAOImpl<FileFormat, Integer> implements FileFormatDAO {

	public FileFormatDAOImpl() {
		super(FileFormat.class);
	}

	public void saveFileFormat(List<FileFormat> fileFormats) {
		FileFormat fileFormat = null;
		for (AbstractModel ref : fileFormats) {
			fileFormat = (FileFormat) ref;
			create(fileFormat);
		}
	}

	public int getmaxfileFormatID() {
		int loginid = 0;
		TypedQuery<Integer> query1 = entityManager.createQuery("SELECT max(fileFormatID) from FileFormat",
				Integer.class);

		if (query1.getSingleResult() != null)
			loginid = query1.getSingleResult();

		return loginid;
	}

	public HashMap<Integer, String> loadFileFormatId() {

		HashMap<Integer, String> ffMap = new HashMap<Integer, String>();
		TypedQuery<Object[]> query = entityManager.createQuery("SELECT fileFormatID,fileFormat from FileFormat",
				Object[].class);
		List<Object[]> ffList = query.getResultList();
		for (Object[] row : ffList) {
			ffMap.put((Integer) row[0], (String) row[1]);
		}
		return ffMap;
	}

	public void deleteFileFormat() {
		Query query = entityManager.createQuery("delete from FileFormat");
		query.executeUpdate();
	}

	public List<FileFormat> getFileFormatListByReleaseNo(Integer releaseNo){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<FileFormat> query = cb.createQuery(FileFormat.class);
		Root<FileFormat> root = query.from(FileFormat.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getFileFormatReleaseNumbers(Set<Integer> fileFormatIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<FileFormat> root = query.from(FileFormat.class);
		query.select(root.<Integer>get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("fileFormatID")).value(fileFormatIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllFileFormatReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from FileFormat where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	
	@Override
	public List<FileFormat> getFileFormatsList(Set<Integer> fileFormatIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<FileFormat> query = cb.createQuery(FileFormat.class);
		Root<FileFormat> root = query.from(FileFormat.class);
		query.select(root).distinct(true);
		query.where(cb.and(cb.in(root.get("fileFormatID")).value(fileFormatIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
}
