package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.metastore.RuleType;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * 
 * @author Guvala
 *
 */
@Repository
public class RuleTypeDAOImpl extends BaseDAOImpl<RuleType, Integer> implements RuleTypeDAO {

	public RuleTypeDAOImpl() {
		super(RuleType.class);
	}

	public void saveRuleType(List<RuleType> entitytypes) {
		RuleType ruleType = null;
		for (AbstractModel ref : entitytypes) {
			ruleType = (RuleType) ref;
			create(ruleType);
		}
	}

	public int getmaxruleTypeID() {
		int loginid = 0;// changed 1 to 0 because to avoid data constraint
						// voilation Exception
		TypedQuery<Integer> query = entityManager.createQuery("SELECT max(ruleTypeID) from RuleType", Integer.class);
		if (query.getSingleResult() != null)
			loginid = query.getSingleResult();
		return loginid;
	}

	public HashMap<Integer, String> loadRuleTypeIdMap() {

		HashMap<Integer, String> ruleTypeIdMap = new HashMap<Integer, String>();
		TypedQuery<Object[]> query = entityManager.createQuery("SELECT ruleTypeID,ruleType from RuleType",
				Object[].class);
		List<Object[]> ruleTypeList = query.getResultList();
		for (Object[] object : ruleTypeList) {
			ruleTypeIdMap.put((Integer) object[0], (String) object[1]);
		}
		return ruleTypeIdMap;
	}

	public void deleteRuleType() {
		Query query = entityManager.createQuery("delete from RuleType");
		query.executeUpdate();
	}
	
	public List<RuleType> getRuleTypeListByReleaseNo(Integer releaseNo){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<RuleType> query = cb.createQuery(RuleType.class);
		Root<RuleType> root = query.from(RuleType.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getRuleTypeReleaseNumbers(Set<Integer> ruleTypeIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<RuleType> root = query.from(RuleType.class);
		query.select(root.<Integer>get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("ruleTypeID")).value(ruleTypeIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllRuleTypeReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from RuleType where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	
	@Override
	public List<RuleType> getRuleTypeList(Set<Integer> ruleTypeIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<RuleType> query = cb.createQuery(RuleType.class);
		Root<RuleType> root = query.from(RuleType.class);
		query.select(root).distinct(true);
		query.where(cb.and(cb.in(root.get("ruleTypeID")).value(ruleTypeIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
}
