package com.artha.workbench.models.datahub;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.artha.workbench.models.metastore.AbstractModel;

@Entity
@Table(name = "datahub.tasklayout")
public class TaskLayout extends AbstractModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "layout_id")
	private String layoutId;

	@Column(name = "task_id")
	private String taskId;

	public String getLayoutId() {
		return layoutId;
	}

	public void setLayoutId(String layoutId) {
		this.layoutId = layoutId;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

}
