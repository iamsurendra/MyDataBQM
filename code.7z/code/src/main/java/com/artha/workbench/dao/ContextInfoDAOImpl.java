package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.userConfig.ContextInfo;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class ContextInfoDAOImpl extends BaseDAOImpl<ContextInfo, Long> implements ContextInfoDAO {

	public ContextInfoDAOImpl() {
		super(ContextInfo.class);

	}

	public List<ContextInfo> findAllSchemaNames() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ContextInfo> query = criteriaBuilder.createQuery(ContextInfo.class);
		Root<ContextInfo> root = query.from(ContextInfo.class);
		query.select(criteriaBuilder.construct(ContextInfo.class, root.get("id"), root.get("schemaName"), root.get("ip"))).distinct(true);
		return entityManager.createQuery(query).getResultList();
	}

	public boolean duplicateContext(ContextInfo contextInfo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<ContextInfo> query = cb.createQuery(ContextInfo.class);
		Root<ContextInfo> root = query.from(ContextInfo.class);
		query.select(root);
		query.where(cb.equal(root.get("schemaName"), contextInfo.getSchemaName()), cb.equal(root.get("ip"), contextInfo.getIp()));
		return this.entityManager.createQuery(query).getResultList().size() > 0;
	}

	
	public ContextInfo DefaultSchema() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<ContextInfo> query = cb.createQuery(ContextInfo.class);
		Root<ContextInfo> root = query.from(ContextInfo.class);
		query.select(root);
		query.where(cb.equal(root.get("defaultDb"), true));
		return entityManager.createQuery(query).getSingleResult();
		
	}
	
}
