package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.RoleFunctions;
import com.artha.workbench.models.userConfig.RoleFunctionsPK;
import com.guvvala.framework.dao.BaseDAO;

public interface RoleFunctionsDAO extends BaseDAO<RoleFunctions, RoleFunctionsPK> {
	
	public List<RoleFunctions> getRoleFunctionsById(Integer roleId);

	public List<RoleFunctions> getRoleFunctionsById(List<Integer> roleIds);
}
