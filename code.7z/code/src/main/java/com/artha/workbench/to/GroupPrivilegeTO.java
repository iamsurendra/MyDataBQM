package com.artha.workbench.to;

import java.util.ArrayList;
import java.util.List;

public class GroupPrivilegeTO {
	
	List<Long> userIdList = new ArrayList<>();
	List<Integer> roleIdList = new ArrayList<>();
	
	//Getters and setters
	public List<Long> getUserIdList() {
		return userIdList;
	}
	public void setUserIdList(List<Long> userIdList) {
		this.userIdList = userIdList;
	}
	public List<Integer> getRoleIdList() {
		return roleIdList;
	}
	public void setRoleIdList(List<Integer> roleIdList) {
		this.roleIdList = roleIdList;
	}
}