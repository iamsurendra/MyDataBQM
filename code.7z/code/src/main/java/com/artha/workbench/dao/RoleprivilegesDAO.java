package com.artha.workbench.dao;

import com.artha.workbench.models.userConfig.RolePrivileges;
import com.guvvala.framework.dao.BaseDAO;

public interface RoleprivilegesDAO extends BaseDAO<RolePrivileges, Integer> {

	public void savePrivileges(RolePrivileges rolePrivileges);
}
