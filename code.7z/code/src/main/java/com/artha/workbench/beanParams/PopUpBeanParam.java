package com.artha.workbench.beanParams;

import java.util.ArrayList;
import java.util.List;

public class PopUpBeanParam {

	private List<String> taskIdList = new ArrayList<>();

	private boolean singleTaskEdit;

	private int taskIndex;

	public List<String> getTaskIdList() {
		return taskIdList;
	}

	public void setTaskIdList(List<String> taskIdList) {
		this.taskIdList = taskIdList;
	}

	public boolean isSingleTaskEdit() {
		return singleTaskEdit;
	}

	public void setSingleTaskEdit(boolean singleTaskEdit) {
		this.singleTaskEdit = singleTaskEdit;
	}

	public int getTaskIndex() {
		return taskIndex;
	}

	public void setTaskIndex(int taskIndex) {
		this.taskIndex = taskIndex;
	}

}
