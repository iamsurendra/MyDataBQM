package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.HeaderFooter;
import com.artha.workbench.models.metastore.HeaderFooterKey;
import com.guvvala.framework.dao.BaseDAO;


public interface HeaderFooterDAO extends BaseDAO<HeaderFooter, HeaderFooterKey> {
	public void saveHeaderFooter(List<HeaderFooter> entitytypes);
	public void deleteHeaderFooter();
	public List<String> getHeaderFooterRecTypeList();
	public List<Integer> getHeaderFooterSeqNumList();
	public List<HeaderFooter> getHeaderFooterListByReleaseNo(Integer releaseNo);
	List<Integer> getHeaderFooterReleaseNumbersByRecTypes(Set<String> recTypes,Integer selectedReleaseNumber);
	List<Integer> getHeaderFooterReleaseNumbersBySeqNums(Set<Integer> seqNumbers,Integer selectedReleaseNumber);
	List<Integer> getHeaderFooterReleaseNumbersByTypeIds(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber);
	List<Integer> getAllHeaderFooterReleaseIds(Integer selectedReleaseId);
	List<HeaderFooter> getHeaderFooterLists(Set<Integer> entityFileTypeIds,Set<String> recTypes,Set<Integer> seqNumbers,Integer selectedReleaseNumber);
}
