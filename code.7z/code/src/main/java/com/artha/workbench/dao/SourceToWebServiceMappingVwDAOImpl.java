package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.SourceToWebServiceMappingVw;
import com.artha.workbench.models.metastore.SourceToWebServiceMappingVwKey;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class SourceToWebServiceMappingVwDAOImpl  extends BaseDAOImpl<SourceToWebServiceMappingVw, SourceToWebServiceMappingVwKey> implements SourceToWebServiceMappingVwDAO{

	
	public SourceToWebServiceMappingVwDAOImpl (){
		super(SourceToWebServiceMappingVw.class);
	}
	public List<SourceToWebServiceMappingVw> getsourceToWebServiceMappingVwListByReleaseNum(Integer releaseNum){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SourceToWebServiceMappingVw> query = cb.createQuery(SourceToWebServiceMappingVw.class);
		Root<SourceToWebServiceMappingVw> root = query.from(SourceToWebServiceMappingVw.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNum"), releaseNum));
		return this.entityManager.createQuery(query).getResultList();
	}
	
}
