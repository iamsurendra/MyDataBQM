package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.ThreadThreadPoolXref;
import com.artha.workbench.models.metastore.ThreadThreadPoolXrefKey;
import com.guvvala.framework.dao.BaseDAO;

public interface ThreadThreadPoolXrefDAO extends BaseDAO<ThreadThreadPoolXref,ThreadThreadPoolXrefKey>{
	
	public void saveThreadThreadPoolXref(List<ThreadThreadPoolXref> threadThreadPoolXref);

	public void deleteThreadThreadPoolXref();

	public List<ThreadThreadPoolXref> getThreadThreadPoolXrefByReleaseNo(Integer releaseNo);
	
	public List<Integer> getAllThreadThreadPoolXrefReleaseIds(Integer selectedReleaseId);


}
