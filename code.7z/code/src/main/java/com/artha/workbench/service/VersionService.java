package com.artha.workbench.service;

import java.util.List;


public interface VersionService {
	
	 public List<Integer> getEntityTypeVersionDetails(String osname);
	    public List<Integer> getefrcVlistDetails(String osname) ;
	    public List<Integer> geteftsxVlistDetails(String osname) ;
	    public List<Integer> geteftxVlistDetails(String osname) ;
	    public List<Integer> getemVlistDetails(String osname) ;
	    public List<Integer> getffVlistDetails(String osname) ;
	    public List<Integer> getfvsxVlistDetails(String osname) ;
	    public List<Integer> gethfVlistDetails(String osname) ;
	    public List<Integer> gethfcVlistDetails(String osname);
	    public List<Integer> gethftVlistDetails(String osname);
	    public List<Integer> getrtVlistDetails(String osname);
	    public List<Integer> getsttmVlistDetails(String osname) ;
	    public List<Integer> getvrVlistDetails(String osname) ;
	    public List<Integer> getvsVlistDetails(String osname) ;
}
