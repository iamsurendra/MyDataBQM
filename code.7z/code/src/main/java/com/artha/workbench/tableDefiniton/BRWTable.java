package com.artha.workbench.tableDefiniton;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "table")
@XmlType(propOrder = { "description", "displayRows", "rowsPerPageTemplate", "columns", "tableStyleClass",
		"tableStyle" })

public class BRWTable implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String description;
	private Integer displayRows;
	private String rowsPerPageTemplate;
	private List<BRWColumn> columns;
	private String tableStyleClass;
	private String tableStyle;

	@XmlAttribute
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getDisplayRows() {
		return displayRows;
	}

	public void setDisplayRows(Integer displayRows) {
		this.displayRows = displayRows;
	}

	public String getRowsPerPageTemplate() {
		return rowsPerPageTemplate;
	}

	public void setRowsPerPageTemplate(String rowsPerPageTemplate) {
		this.rowsPerPageTemplate = rowsPerPageTemplate;
	}

	@XmlElementWrapper(name = "columns")
	@XmlElement(name = "column", type = BRWColumn.class)
	public List<BRWColumn> getColumns() {
		return columns;
	}

	public void setColumns(List<BRWColumn> columns) {
		this.columns = columns;
	}

	public String getTableStyleClass() {
		return tableStyleClass;
	}

	public void setTableStyleClass(String tableStyleClass) {
		this.tableStyleClass = tableStyleClass;
	}

	public String getTableStyle() {
		return tableStyle;
	}

	public void setTableStyle(String tableStyle) {
		this.tableStyle = tableStyle;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BRWTable other = (BRWTable) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	
}
