package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "metastore.SourceToServiceCriteria_V")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
public class SourceToServiceCriteriaVw extends AbstractModel {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SourceToServiceCriteriaVwKey sourceToServiceCriteriaVwKey;
	
	@Column(name = "WebServiceID",insertable=false,updatable=false)
	@JsonProperty("WebServiceID")
	private Integer webServiceId;

	@Column(name = "EntityName",insertable=false,updatable=false)
	@JsonProperty("EntityName")
	private String entityName;

	@Column(name = "HsFileType",insertable=false,updatable=false)
	@JsonProperty("HsFileType")
	private String hsFileType;

	@Column(name = "FileMask",insertable=false,updatable=false)
	@JsonProperty("FileMask")
	private String fileMask;

	@Column(name = "SourceEntityFileTypeID",insertable=false,updatable=false)
	@JsonProperty("SourceEntityFileTypeID")
	private Integer sourceEntityFileTypeID;

	@JsonProperty("Criteria")
	private String criteria;

	@JsonProperty("SeqOrder")
	private Integer seqOrder;

	@JsonProperty("Active")
	private String active;

	@JsonProperty("EffectiveDate")
	private Date effectiveDate;

	@JsonProperty("ReleaseNum")
	private Integer releaseNum;

	@Transient
	@JsonIgnore
	private boolean addMode;

	@Transient
	@JsonIgnore
	private String effectiveDtstring;

	public SourceToServiceCriteriaVw() {

	}

	public SourceToServiceCriteriaVw(boolean addMode, Date effectiveDate, Integer releaseNo) {
		this.effectiveDate = effectiveDate;
		this.addMode = addMode;
		this.releaseNum = releaseNo;
		convertEffectiveDate();
	}

	// getters and setters


	public String getEntityName() {
		return entityName;
	}

	public Integer getWebServiceId() {
		return webServiceId;
	}

	public void setWebServiceId(Integer webServiceId) {
		this.webServiceId = webServiceId;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getHsFileType() {
		return hsFileType;
	}

	public void setHsFileType(String hsFileType) {
		this.hsFileType = hsFileType;
	}

	public String getFileMask() {
		return fileMask;
	}

	public void setFileMask(String fileMask) {
		this.fileMask = fileMask;
	}

	

	public Integer getSourceEntityFileTypeID() {
		return sourceEntityFileTypeID;
	}

	public void setSourceEntityFileTypeID(Integer sourceEntityFileTypeID) {
		this.sourceEntityFileTypeID = sourceEntityFileTypeID;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	

	public Integer getSeqOrder() {
		return seqOrder;
	}

	public void setSeqOrder(Integer seqOrder) {
		this.seqOrder = seqOrder;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Integer getReleaseNum() {
		return releaseNum;
	}

	public void setReleaseNum(Integer releaseNum) {
		this.releaseNum = releaseNum;
	}

	public SourceToServiceCriteriaVwKey getSourceToServiceCriteriaVwKey() {
		return sourceToServiceCriteriaVwKey;
	}

	public void setSourceToServiceCriteriaVwKey(SourceToServiceCriteriaVwKey sourceToServiceCriteriaVwKey) {
		this.sourceToServiceCriteriaVwKey = sourceToServiceCriteriaVwKey;
	}

	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public String getEffectiveDtstring() {
		return effectiveDtstring;
	}

	public void setEffectiveDtstring(String effectiveDtstring) {
		this.effectiveDtstring = effectiveDtstring;
	}

	@PostLoad
	public void postLoad() {
		convertEffectiveDate();
	}

	public void convertEffectiveDate() {
		this.effectiveDtstring = DateUtils.convertToSimpleDateFormat(getEffectiveDate());
	}

}
