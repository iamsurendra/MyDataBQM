package com.artha.workbench.service;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.AuditLogDetailsDAO;
import com.artha.workbench.dao.GroupsDAO;
import com.artha.workbench.dao.UserDAO;
import com.artha.workbench.models.config.AuditLogDetails;
import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.userConfig.Groups;
import com.artha.workbench.models.userConfig.Roles;
import com.artha.workbench.models.userConfig.User;

@Service("auditLogService")
public class AuditLogDetailsServiceImpl implements AuditLogDetailsService {

	@Autowired
	AuditLogDetailsDAO auditLogDetailsDAO;
	
	@Autowired
	GroupsDAO groupsDAO;
	
	@Autowired
	UserDAO userDAO;
	
	

	@Transactional(readOnly = true,transactionManager = "configTM")
	public List<AuditLogDetails> findAll() {
		
		List<AuditLogDetails> users = auditLogDetailsDAO.findAll();
		User user =null;
		for(AuditLogDetails alog : users){
			user = new User();
			if(alog.getLoginid()==null)
				continue;
			user = userDAO.findOne(alog.getLoginid().longValue());
			if(!alog.getLoginid().equals(0) && null!=user.getGroupid()){
				alog.setGroupName(groupsDAO.getGroupName(user.getGroupid()));
			}
			else
			{
				alog.setGroupName("N/A");
			}
		}
		return users;
	}
	@Transactional(readOnly = true,transactionManager = "configTM")
	public List<AuditLogDetails> searchAll(String tablename,String changetype,String date,String modby) {
		
		List<AuditLogDetails> users = auditLogDetailsDAO.searchAll(tablename,changetype,date,modby);
		User user =null;
		for(AuditLogDetails alog : users){
			user = new User();
			user = userDAO.findOne(alog.getLoginid().longValue());
			if(!alog.getLoginid().equals(0) && null!=user.getGroupid()){
				alog.setGroupName(groupsDAO.getGroupName(user.getGroupid()));
			}
			else
			{
				alog.setGroupName("N/A");
			}
		}
		return users;
	}

	@Transactional(transactionManager = "configTM")
	public void create(AuditLogDetails dbConfig) {
		auditLogDetailsDAO.create(dbConfig);
	}

	@Transactional(transactionManager = "configTM")
	public void update(AuditLogDetails dbConfig) {
		auditLogDetailsDAO.update(dbConfig);
	}

	@Transactional(transactionManager = "configTM")
	public void saveAll(HttpServletRequest request, HttpSession httpsession, String tname,
			List<? extends AbstractModel> entities, List<? extends AbstractModel> entityTypes, String reviewflag,
			HashMap<Integer, String> logintypemap,int reviewlistcount) {
		auditLogDetailsDAO.saveAll(request, httpsession, tname, entities, entityTypes, reviewflag, logintypemap,reviewlistcount);
	}

	@Transactional(transactionManager = "configTM")
	public List<AuditLogDetails> userlist(int loginid) {
		List<AuditLogDetails> users = auditLogDetailsDAO.userlist(loginid);
		User user =null;
		for(AuditLogDetails alog : users){
			user = new User();
			user = userDAO.findOne(alog.getLoginid().longValue());
			if(alog.getLoginid() !=null){
				alog.setGroupName(groupsDAO.getGroupName(user.getGroupid()));
			}
		}
		return users;
	}

	@Transactional(transactionManager = "configTM")
	public void save(String tablename, HttpSession httpsession) {
		auditLogDetailsDAO.save(tablename, httpsession);
	}

	@Transactional(transactionManager = "configTM")
	public void DownloadToAuditInfo(String tablename, HttpSession httpsession) {
		auditLogDetailsDAO.DownloadToAuditInfo(tablename, httpsession);
	}

	@Transactional(transactionManager = "configTM")
	public void uploadToAuditInfo(String tablename, HttpSession httpsession) {
		
		auditLogDetailsDAO.uploadToAuditInfo(tablename, httpsession);
		
	}
	@Transactional(transactionManager = "configTM")
	public List<AuditLogDetails> adminlist(int loginid) {
		List<AuditLogDetails> users = auditLogDetailsDAO.adminlist(loginid);
		User user =null;
		for(AuditLogDetails alog : users){
			user = new User();
			user = userDAO.findOne(alog.getLoginid().longValue());
			if(alog.getLoginid() !=null && user.getGroupid()!=null){
				alog.setGroupName(groupsDAO.getGroupName(user.getGroupid()));
			}
			else
			{
				alog.setGroupName("N/A");
			}
		}
		return users;
	}
	@Transactional(transactionManager = "configTM")
	public void rolechangeAuditInfo(List<Roles>userrolelist,List<Roles> changedlist, HttpSession httpsession)
	{
		auditLogDetailsDAO.rolechangeAuditInfo(userrolelist, changedlist, httpsession);
	}
	@Transactional(transactionManager = "configTM")
	public void groupchangeAuditInfo(List<Groups>userrolelist,List<Groups> changedlist, HttpSession httpsession)
	{
		auditLogDetailsDAO.groupchangeAuditInfo(userrolelist, changedlist, httpsession);
	}
	@Transactional(transactionManager = "configTM")
	public List<AuditLogDetails> searchAllAdmin(Long loginid,String tablename,String changetype,String date,String modby)
	{
		return auditLogDetailsDAO.searchAllAdmin(loginid, tablename, changetype, date, modby);
	}
	@Transactional(transactionManager = "configTM")
	public void deleteAuditInfo(HttpSession httpsession)
	{
		auditLogDetailsDAO.deleteAuditInfo(httpsession);
	}
}