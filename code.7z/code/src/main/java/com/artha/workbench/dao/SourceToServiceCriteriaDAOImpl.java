package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.SourceToServiceCriteria;
import com.artha.workbench.models.metastore.SourceToServiceCriteriaKey;
import com.guvvala.framework.dao.BaseDAOImpl;


@Repository
public class SourceToServiceCriteriaDAOImpl extends BaseDAOImpl<SourceToServiceCriteria, SourceToServiceCriteriaKey> implements SourceToServiceCriteriaDAO  {
	public SourceToServiceCriteriaDAOImpl() {
		super(SourceToServiceCriteria.class);
	}

	@Override
	public List<SourceToServiceCriteria> getSourceToServiceCriteriaListByReleaseNo(Integer releaseNo) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SourceToServiceCriteria> query = cb.createQuery(SourceToServiceCriteria.class);
		Root<SourceToServiceCriteria> root = query.from(SourceToServiceCriteria.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNum"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllSourceToServiceCriteriaReleaseIds(Integer selectedReleaseId) {
		TypedQuery<Integer> query = entityManager.createQuery("select releaseNum from SourceToServiceCriteria where releaseNum !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}

}
