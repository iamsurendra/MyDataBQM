package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.userConfig.UserPreference;
import com.artha.workbench.models.userConfig.UserPreferencePK;
import com.guvvala.framework.dao.BaseDAO;

public interface UserPreferenceDAO extends BaseDAO<UserPreference,UserPreferencePK> {
	public List<UserPreference> getUserPreferenceInfo();
	
	List<UserPreference> getUserPreferenceByUserId(Long userId);
}
