package com.artha.workbench.to;

public class AdvSearchColumnsTO {
	private String name;
	private String operator;
	private String value;
	private boolean checked;

	private boolean selected;
	private Integer id;

	public AdvSearchColumnsTO() {
		super();
	}

	public AdvSearchColumnsTO(String name, String operator, String value, Integer id, boolean checked) {
		this.name = name;
		this.operator = operator;
		this.value = value;
		this.id = id;
		this.checked = checked;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
