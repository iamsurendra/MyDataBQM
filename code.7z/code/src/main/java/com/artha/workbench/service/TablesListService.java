package com.artha.workbench.service;

import java.util.List;

import com.artha.workbench.models.userConfig.TableList;

public interface TablesListService {
	
	public List<TableList> getTablelist(String statusFlag);
	public List<TableList> getUploadList();
	public void update(TableList tableList);
	public String getDescription(String tablename);
}
