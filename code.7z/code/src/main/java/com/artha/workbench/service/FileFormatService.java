package com.artha.workbench.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.FileFormat;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface FileFormatService {
	
	public List<FileFormat> getFileFormatList();
	public void create(FileFormat FileFormat);
	public void update(FileFormat FileFormat,boolean isReleaseChanged)throws JsonProcessingException;;
	public void saveFileFormat(List<FileFormat> entitytypes);
	public int getmaxfileFormatID();
	public HashMap<Integer,String> loadFileFormatId();
	public long getFileFormatDataCount();
	public void deleteFileFormatData();
	List<FileFormat> getFileFormatListByReleaseNo(Integer releaseNo);
	FileFormat getPreviousFileFormat(FileFormat fileFormat) throws IOException;
	List<Integer> getFileFormatReleaseNumbers(Set<Integer> fileFormatIds,Integer selectedReleaseNumber);
	
	List<Integer> getAllFileFormatReleaseIds(Integer selectedReleaseId);
	
	List<FileFormat> getFileFormatsList(Set<Integer> fileFormatIds,Integer selectedReleaseNumber);
	
}
