package com.artha.workbench.models.userConfig;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;

import com.artha.workbench.constant.ListOfTablesEnum;
import com.artha.workbench.models.metastore.AbstractModel;

@Entity
@Table(name = "userconfig.tablelist")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
public class TableList extends AbstractModel {


	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "sno", nullable = false)
	private Integer sno;
	
	@Size(min = 1, max = 50)
	private String tablename;
	
	@Size(min = 1, max = 250)
	private String description;
	
	@Type(type = "numeric_boolean")
	@Column(name = "status")
	private boolean status;
	
	@Column(name = "deletestatus")
	private String deletestatus;
	
	@Transient
	private boolean addMode;
	
	@Transient
	private String value;

	public Integer getSno() {
		return sno;
	}
	public void setSno(Integer sno) {
		this.sno = sno;
	}
	
	public String getTablename() {
		return tablename;
	}

	public void setTablename(String tablename) {
		this.tablename = tablename;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public boolean getStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getDeletestatus() {
		return deletestatus;
	}

	public void setDeletestatus(String deletestatus) {
		this.deletestatus = deletestatus;
	}

	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	@PostLoad
	public void postLoad() {
		this.value = ListOfTablesEnum.listOfTablesMap.get(this.tablename);
	}
}
