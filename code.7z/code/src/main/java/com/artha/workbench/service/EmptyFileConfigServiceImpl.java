package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.AuditLogDetailsDAO;
import com.artha.workbench.dao.EmptyFileConfigDAO;
import com.artha.workbench.dao.EntityFileTypeScheduleXrefDAO;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.LockedTablesDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.metastore.EmptyFileConfig;
import com.artha.workbench.models.metastore.EmptyFileConfigId;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;

@Service("emptyFileConfigService")
public class EmptyFileConfigServiceImpl implements EmptyFileConfigService {

	@Autowired
	EmptyFileConfigDAO emptyFileConfigDAO;

	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Autowired
	AuditLogDetailsDAO auditLogDetailsDAO;

	@Autowired
	EntityFileTypeScheduleXrefDAO entityFileTypeScheduleXrefDAO;

	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefDAO;

	@Autowired
	LockedTablesDAO lockedTablesDAO;

	@Transactional(readOnly = true)
	public List<EmptyFileConfig> getEmptyFileConfigList() {
		return emptyFileConfigDAO.findAll();
	}

	@Transactional
	public void create(EmptyFileConfig emptyFileConfig) {
		emptyFileConfigDAO.create(emptyFileConfig);
	}

	@Transactional
	public void saveEmptyFileConfig(List<EmptyFileConfig> emptyFileConfig) {
		emptyFileConfigDAO.deleteEmptyFileConfig();
		emptyFileConfigDAO.saveEmptyFileConfig(emptyFileConfig);

	}

	@Transactional
	@Override
	public void update(EmptyFileConfig emptyFileConfig, boolean isReleaseChanged) throws JsonProcessingException {
		EmptyFileConfig oldEntity = emptyFileConfigDAO.findOne(emptyFileConfig.getEmptyFileConfigID());
		checkForCyclicDependency(emptyFileConfig);
		if (isReleaseChanged) {
			ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
			releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
			releaseArchiveKey.setReleaseId(emptyFileConfig.getReleaseNo());
			releaseArchiveKey.setTableName("EMPTYFILECONFIG");
			EmptyFileConfigId emptyFileConfigId = new EmptyFileConfigId();
			emptyFileConfigId.setEmptyFileConfigID(oldEntity.getEmptyFileConfigID());
			releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(emptyFileConfigId));

			ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
			if (releaseArchive != null) {
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchiveDAO.update(releaseArchive);
			} else {
				releaseArchive = new ReleaseArchive();
				releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
				releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
				releaseArchiveDAO.create(releaseArchive);
			}
		}
		emptyFileConfigDAO.update(emptyFileConfig);
	}

	private void checkForCyclicDependency(EmptyFileConfig emptyFileConfig) throws JsonProcessingException {
		EmptyFileConfigId emptyFileConfigId = new EmptyFileConfigId();
		emptyFileConfigId.setEmptyFileConfigID(emptyFileConfig.getEmptyFileConfigID());
		String jsonId = AppWebUtils.convertObjectToJson(emptyFileConfigId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(emptyFileConfig.getReleaseNo(),
				"EMPTYFILECONFIG", jsonId);
		if (releaseArchive != null) {
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	@Transactional
	public int getmaxEmptyFileConfig() {
		return emptyFileConfigDAO.getmaxEmptyFileConfig();
	}

	@Transactional
	public List<Integer> getEntityFileTypeSchedIds() {
		return entityFileTypeScheduleXrefDAO.getEntityFileTypeSchedIds();
	}

	@Transactional
	public List<Integer> loadentityFileTypeid() {
		return entityFileTypeXrefDAO.loadentityFileTypeid();

	}
	
	@Transactional
	public List<EmptyFileConfig> getEmptyFileConfigByReleaseNo(Integer releaseNo){
		
		return emptyFileConfigDAO.getEmptyFileConfigByReleaseNo(releaseNo);
		
	}
	
	
	@Override
	@Transactional
	public EmptyFileConfig getPreviousEmptyFileConfig(EmptyFileConfig emptyFileConfig)throws IOException {
		EmptyFileConfigId emptyFileConfigId=new EmptyFileConfigId();
		emptyFileConfigId.setEmptyFileConfigID(emptyFileConfig.getEmptyFileConfigID());
		String emptyFileConfigJson = AppWebUtils.convertObjectToJson(emptyFileConfigId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(emptyFileConfig.getReleaseNo(), "EMPTYFILECONFIG", emptyFileConfigJson);
		EmptyFileConfig previousemptyFileConfig = new EmptyFileConfig();
		if(releaseArchive!=null){
			previousemptyFileConfig = AppWebUtils.convertJsonToObject(EmptyFileConfig.class, releaseArchive.getRecData());
		}
		return previousemptyFileConfig;
	}

}
