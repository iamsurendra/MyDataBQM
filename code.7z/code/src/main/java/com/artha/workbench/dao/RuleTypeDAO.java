package com.artha.workbench.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.RuleType;
import com.guvvala.framework.dao.BaseDAO;


public interface RuleTypeDAO extends BaseDAO<RuleType, Integer> {
	public void saveRuleType(List<RuleType> entitytypes);

	public int getmaxruleTypeID();

	public HashMap<Integer, String> loadRuleTypeIdMap();

	public void deleteRuleType();

	public List<RuleType> getRuleTypeListByReleaseNo(Integer releaseNo);

	public List<Integer> getRuleTypeReleaseNumbers(Set<Integer> ruleTypeIds,Integer selectedReleaseNumber);
	
	List<Integer> getAllRuleTypeReleaseIds(Integer selectedReleaseId);
	
	List<RuleType> getRuleTypeList(Set<Integer> ruleTypeIds,Integer selectedReleaseNumber);
}
