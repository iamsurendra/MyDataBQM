package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.ThreadPoolType;
import com.guvvala.framework.dao.BaseDAO;


public interface ThreadPoolTypeDAO extends BaseDAO<ThreadPoolType, Integer> {

	public void saveThreadPoolType(List<ThreadPoolType> threadPoolType);

	public void deleteThreadPoolType();
	
	public int getmaxThreadPoolType();
	
	public List<ThreadPoolType> getThreadPoolTypeListByReleaseNo(Integer releaseNo);
	

	public List<Integer> getPoolIds();
	
	public List<Integer> getAllThreadPoolTypeReleaseIds(Integer selectedReleaseId);
	
	public List<ThreadPoolType> getThreadPoolTypeList(Set<Integer> poolIds, Integer selectedReleaseNumber) ;
}
