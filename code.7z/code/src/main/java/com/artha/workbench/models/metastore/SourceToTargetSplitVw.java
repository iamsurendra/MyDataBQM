package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name ="metastore.SourceToTargetSplit_V")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
public class SourceToTargetSplitVw extends AbstractModel {
	
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private SourceToTargetSplitVwKey sourceToTargetSplitVwKey;
	
	@Column(name = "SourceEntityFileTypeID",insertable=false,updatable=false)
	@JsonProperty("SourceEntityFileTypeID")
	private Long sourceEntityFileTypeID;
	
	@Column(name = "SourceEntityName",insertable=false,updatable=false)
	@JsonProperty("SourceEntityName")
	private String sourceEntityName;
	
	@Column(name = "SourceHsFileType",insertable=false,updatable=false)
	@JsonProperty("SourceHsFileType")
	private String sourceHsFileType;
	
	@Column(name = "SourceFileMask",insertable=false,updatable=false)
	@JsonProperty("SourceFileMask")
	private String sourceFileMask;
	
	@Column(name = "TargetEntityFileTypeID",insertable=false,updatable=false)
	@JsonProperty("TargetEntityFileTypeID")
	private Long targetEntityFileTypeID;
	
	@Column(name = "TargetEntityName",insertable=false,updatable=false)
	@JsonProperty("TargetEntityName")
	private String targetEntityName;
	
	@Column(name = "TargetHsFileType",insertable=false,updatable=false)
	@JsonProperty("TargetHsFileType")
	private String targetHsFileType;
	
	@Column(name = "TargetFileMask",insertable=false,updatable=false)
	@JsonProperty("TargetFileMask")
	private String targetFileMask;
	
	@JsonProperty("SplitCriteria")
	private String splitCriteria;
	
	@JsonProperty("Active")
	private String active;
	
	@JsonProperty("EffectiveDate")
	private Date effectiveDate;
	
	@JsonProperty("ReleaseNum")
	private Integer releaseNum;
	
	@Transient
	@JsonIgnore
	private boolean addMode;
	
	@Transient
	@JsonIgnore
	private String effectiveDtstring;
	
	public SourceToTargetSplitVw() {
		
	}
	
	public SourceToTargetSplitVw(boolean addMode, Date effectiveDate, Integer releaseNo) {
		this.effectiveDate = effectiveDate;
		this.addMode = addMode;
		this.releaseNum = releaseNo;
		convertEffectiveDate();
	}

	// getters and setters

	public Long getSourceEntityFileTypeID() {
		return sourceEntityFileTypeID;
	}

	public void setSourceEntityFileTypeID(Long sourceEntityFileTypeID) {
		this.sourceEntityFileTypeID = sourceEntityFileTypeID;
	}

	public String getSourceEntityName() {
		return sourceEntityName;
	}

	public void setSourceEntityName(String sourceEntityName) {
		this.sourceEntityName = sourceEntityName;
	}

	public String getSourceHsFileType() {
		return sourceHsFileType;
	}

	public void setSourceHsFileType(String sourceHsFileType) {
		this.sourceHsFileType = sourceHsFileType;
	}

	public String getSourceFileMask() {
		return sourceFileMask;
	}

	public void setSourceFileMask(String sourceFileMask) {
		this.sourceFileMask = sourceFileMask;
	}

	public Long getTargetEntityFileTypeID() {
		return targetEntityFileTypeID;
	}

	public void setTargetEntityFileTypeID(Long targetEntityFileTypeID) {
		this.targetEntityFileTypeID = targetEntityFileTypeID;
	}

	public String getTargetEntityName() {
		return targetEntityName;
	}

	public void setTargetEntityName(String targetEntityName) {
		this.targetEntityName = targetEntityName;
	}

	public String getTargetHsFileType() {
		return targetHsFileType;
	}

	public void setTargetHsFileType(String targetHsFileType) {
		this.targetHsFileType = targetHsFileType;
	}

	public String getTargetFileMask() {
		return targetFileMask;
	}

	public void setTargetFileMask(String targetFileMask) {
		this.targetFileMask = targetFileMask;
	}

	public String getSplitCriteria() {
		return splitCriteria;
	}

	public void setSplitCriteria(String splitCriteria) {
		this.splitCriteria = splitCriteria;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Integer getReleaseNum() {
		return releaseNum;
	}

	public void setReleaseNum(Integer releaseNum) {
		this.releaseNum = releaseNum;
	}
	
	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public String getEffectiveDtstring() {
		return effectiveDtstring;
	}

	public void setEffectiveDtstring(String effectiveDtstring) {
		this.effectiveDtstring = effectiveDtstring;
	}
	
	public SourceToTargetSplitVwKey getSourceToTargetSplitVwKey() {
		return sourceToTargetSplitVwKey;
	}

	public void setSourceToTargetSplitVwKey(SourceToTargetSplitVwKey sourceToTargetSplitVwKey) {
		this.sourceToTargetSplitVwKey = sourceToTargetSplitVwKey;
	}

	@PostLoad
	public void postLoad(){
		convertEffectiveDate();
	}
	public void convertEffectiveDate(){
		this.effectiveDtstring = DateUtils.convertToSimpleDateFormat(getEffectiveDate());	
	}
	
}
