package com.artha.workbench.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.metastore.SourceToTargetSplit;
import com.artha.workbench.models.metastore.SourceToTargetSplitKey;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class SourceToTargetSplitDAOImpl extends BaseDAOImpl<SourceToTargetSplit, SourceToTargetSplitKey> implements SourceToTargetSplitDAO {
	
	public SourceToTargetSplitDAOImpl() {
		super(SourceToTargetSplit.class);
	}
	
	public List<SourceToTargetSplit> getSourceToTargetSplitListByReleaseNo(Integer releaseNo){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SourceToTargetSplit> query = cb.createQuery(SourceToTargetSplit.class);
		Root<SourceToTargetSplit> root = query.from(SourceToTargetSplit.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllSourceToTargetSplitReleaseIds(Integer selectedReleaseId) {
		TypedQuery<Integer> query = entityManager.createQuery("select releaseNo from SourceToTargetSplit where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
}
