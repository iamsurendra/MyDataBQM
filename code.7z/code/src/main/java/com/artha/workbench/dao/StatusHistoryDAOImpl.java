package com.artha.workbench.dao;

import org.springframework.stereotype.Repository;

import com.artha.workbench.models.datahub.StatusHistory;
import com.guvvala.framework.dao.BaseDAOImpl;

@Repository
public class StatusHistoryDAOImpl extends BaseDAOImpl<StatusHistory, Long> implements StatusHistoryDAO {

	public StatusHistoryDAOImpl() {
		super(StatusHistory.class);
	}

}
