package com.artha.workbench.service;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.AuditLogDetailsDAO;
import com.artha.workbench.dao.EntityTypeDAO;
import com.artha.workbench.dao.LockedTablesDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.models.config.AuditLogDetails;
import com.artha.workbench.models.core.LockedTables;
import com.artha.workbench.models.metastore.EntityType;
import com.artha.workbench.models.metastore.EntityTypeId;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;
import com.guvvala.framework.util.ThreadLocalUtil;

@Service("entityTypeService")
public class EntityTypeServiceImpl implements EntityTypeService {

	@Autowired
	EntityTypeDAO entityTypeDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;

	@Autowired
	AuditLogDetailsDAO auditLogDetailsDAO;
	
	@Autowired
	LockedTablesDAO lockedTablesDAO;

	
	@Transactional(readOnly = true)
	public List<EntityType> getEntityTypeList() {
		return entityTypeDAO.findAll();
	}

	@Transactional(readOnly = true)
	@Override
	public List<EntityType> getEntityTypeListByReleaseNo(Integer releaseNo) {
		return entityTypeDAO.getEntityTypeListByReleaseNo(releaseNo);
	}
	
	@Transactional
	public void create(EntityType entityType) {
		entityTypeDAO.create(entityType);
	}
	
	@Transactional(readOnly = true)
	@Override
	public EntityType getPreviousEntityType(EntityType entityType) throws IOException
	{
		EntityTypeId entityTypeId = new EntityTypeId();
		entityTypeId.setEntityTypeID(entityType.getEntityTypeID());
		String entityTypeIdJson = AppWebUtils.convertObjectToJson(entityTypeId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(entityType.getReleaseNo(), "ENTITYTYPE", entityTypeIdJson);
		EntityType previousEntityType = new EntityType();
		if(releaseArchive!=null){
		previousEntityType = AppWebUtils.convertJsonToObject(EntityType.class, releaseArchive.getRecData());
		}
		return previousEntityType;
		
	}

	@Transactional
	@Override
	public void update(EntityType entityType,boolean isReleaseChanged) throws JsonProcessingException {
		EntityType oldEntity = entityTypeDAO.findOne(entityType.getEntityTypeID());
		checkForCyclicDependency(entityType);
		if(isReleaseChanged)
		{
		ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
		releaseArchiveKey.setArchivedReleaseId(oldEntity.getReleaseNo());
		releaseArchiveKey.setReleaseId(entityType.getReleaseNo());
		releaseArchiveKey.setTableName("ENTITYTYPE");
		EntityTypeId entityTypeId = new EntityTypeId();
		entityTypeId.setEntityTypeID(oldEntity.getEntityTypeID());
		releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(entityTypeId));

		ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
		if(releaseArchive!=null){
			releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
			releaseArchiveDAO.update(releaseArchive);
		}else{
			releaseArchive=new ReleaseArchive();
			releaseArchive.setRecData(AppWebUtils.convertObjectToJson(oldEntity));
			releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
			releaseArchiveDAO.create(releaseArchive);
		}
		}
		entityTypeDAO.update(entityType);
	}
	
	private void checkForCyclicDependency(EntityType entityType) throws JsonProcessingException
	{
		EntityTypeId entityTypeId = new EntityTypeId();
		entityTypeId.setEntityTypeID(entityType.getEntityTypeID());
		String jsonId = AppWebUtils.convertObjectToJson(entityTypeId);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(entityType.getReleaseNo(), "ENTITYTYPE", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}

	@Transactional
	public void saveEntityType(List<EntityType> entitytypes) {
		entityTypeDAO.deleteEntityType();
		entityTypeDAO.saveEntityType(entitytypes);
	}
	@Transactional
	public int getmaxEntitytype()
	{ 
		return entityTypeDAO.getmaxEntitytype();
	}
	@Transactional(transactionManager = "configTM")
	public void createAudit(List<EntityType> DbentityTypelist, List<EntityType> entities, List<EntityType> entityTypes, String reviewflag) {
		//System.out.println("**entities**"+entities.size());
		String currentUser = ThreadLocalUtil.getUserName();
		String rolename = "";
		Integer loginid = null;
		EntityType e = null;
		EntityType e1 = null;
		for (int i = 0; i < entityTypes.size(); i++) {
			e1 = new EntityType();
			e = entityTypes.get(i);
			if (reviewflag != null && reviewflag.equals("true")) {
				e1 = DbentityTypelist.get(i);
			} else {
				e1 = entities.get(i);
			}
			if (e1.getEntityTypeID() == null) {
				e1.setEntityTypeID(0);
			}
			if (e1.getDescription() == null) {
				e1.setDescription("");
			}
			if (e.getDescription() != null && !e.getDescription().equals(e1.getDescription())) {
				try{
				AuditLogDetails auditlog = new AuditLogDetails();
				auditlog.setTablename("EntityType");
				auditlog.setUsername(rolename);
				auditlog.setChangetype("Update");
				auditlog.setChnagedfield("Description");
				auditlog.setOldvalue(e1.getDescription());
				auditlog.setNewvalue(e.getDescription());
				auditlog.setLoginid(loginid);
				auditlog.setModifieddate(new Date());
				auditlog.setModifiedby(currentUser);
				auditLogDetailsDAO.create(auditlog);
				}
				catch(Exception exc)
				{
					System.out.println("**Exception****"+exc);
				}
			}
		}
	}
	@Transactional
	 public HashMap<Integer,String> loadentityTypeid() {
		return entityTypeDAO.loadentityTypeid();
	 }
	@Transactional
	public List<LockedTables> getLockedList()
	{
		return lockedTablesDAO.findAll();
	}
	@Transactional
	public void saveLockedTables(LockedTables lockedTables)
	{
		lockedTablesDAO.create(lockedTables);
	}
	@Transactional
	public void removeLocks(LockedTables lockedTables)
	{
		lockedTablesDAO.delete(lockedTables);
	}
	
	@Transactional(readOnly=true)
	public long getEntityTypeDataCount(){
		return entityTypeDAO.count();
	}
	
	@Transactional(readOnly=true)
	public List<Integer> getEntityTypeReleaseNumbers(Set<Integer> entityTypeIds,Integer selectedReleaseNumber){
		return entityTypeDAO.getEntityTypeReleaseNumbers(entityTypeIds,selectedReleaseNumber);
	}

	@Transactional(readOnly=true)
	public List<Integer> getAllEntityTypeReleaseIds(Integer selectedReleaseId){
		return entityTypeDAO.getAllEntityTypeReleaseIds(selectedReleaseId);
	}

	@Override
	@Transactional(readOnly=true)
	public List<EntityType> getEntityTypeList(Set<Integer> entityTypeIds,Integer selectedReleaseId) {
		return entityTypeDAO.getEntityTypeList(entityTypeIds,selectedReleaseId);
	}
}
