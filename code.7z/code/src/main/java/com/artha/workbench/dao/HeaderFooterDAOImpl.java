package com.artha.workbench.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.models.metastore.HeaderFooter;
import com.artha.workbench.models.metastore.HeaderFooterKey;
import com.guvvala.framework.dao.BaseDAOImpl;


/**
 * 
 * @author Guvala
 *
 */
@Repository
public class HeaderFooterDAOImpl extends BaseDAOImpl<HeaderFooter, HeaderFooterKey> implements HeaderFooterDAO {

	public HeaderFooterDAOImpl() {
		super(HeaderFooter.class);
	}

	public void saveHeaderFooter(List<HeaderFooter> entitytypes) {
		for (HeaderFooter hf : entitytypes) {
			create(hf);
		}
	}

	public void deleteHeaderFooter() {
		Query query = entityManager.createQuery("delete from HeaderFooter");
		query.executeUpdate();
	}

	public List<String> getHeaderFooterRecTypeList() {
		TypedQuery<String> query = entityManager.createQuery("SELECT distinct headerFooterKey.recType from HeaderFooter", String.class);
		return query.getResultList();
	}

	public List<Integer> getHeaderFooterSeqNumList() {
		TypedQuery<Integer> query = entityManager.createQuery("SELECT distinct headerFooterKey.seqNum from HeaderFooter",
				Integer.class);
		return query.getResultList();
	}
	
	@Transactional
	public List<HeaderFooter> getHeaderFooterListByReleaseNo(Integer releaseNo)
	  {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<HeaderFooter> query = cb.createQuery(HeaderFooter.class);
		Root<HeaderFooter> root = query.from(HeaderFooter.class);
		query.select(root);
		query.where(cb.equal(root.get("releaseNo"), releaseNo));
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getHeaderFooterReleaseNumbersByTypeIds(Set<Integer> entityFileTypeIds,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<HeaderFooter> root = query.from(HeaderFooter.class);
		query.select(root.<Integer>get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("entityFileTypeID")).value(entityFileTypeIds),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getHeaderFooterReleaseNumbersBySeqNums(Set<Integer> seqNumbers,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<HeaderFooter> root = query.from(HeaderFooter.class);
		query.select(root.<Integer>get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("seqNum")).value(seqNumbers),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getHeaderFooterReleaseNumbersByRecTypes(Set<String> recTypes,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> query = cb.createQuery(Integer.class);
		Root<HeaderFooter> root = query.from(HeaderFooter.class);
		query.select(root.<Integer>get("releaseNo")).distinct(true);
		query.where(cb.and(cb.in(root.get("recType")).value(recTypes),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}
	
	@Override
	public List<Integer> getAllHeaderFooterReleaseIds(Integer selectedReleaseId){
		TypedQuery<Integer> query = entityManager.createQuery("select distinct releaseNo from HeaderFooter where releaseNo !=:releaseNo",Integer.class);
		query.setParameter("releaseNo", selectedReleaseId);
		return query.getResultList();
	}
	
	@Override
	public List<HeaderFooter> getHeaderFooterLists(Set<Integer> entityFileTypeIds,Set<String> recTypes,Set<Integer> seqNumbers,Integer selectedReleaseNumber){
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<HeaderFooter> query = cb.createQuery(HeaderFooter.class);
		Root<HeaderFooter> root = query.from(HeaderFooter.class);
		query.select(root).distinct(true);
		query.where(cb.and(cb.in(root.get("entityFileTypeID")).value(entityFileTypeIds),cb.in(root.get("recType")).value(recTypes),cb.in(root.get("seqNum")).value(seqNumbers),cb.notEqual(root.get("releaseNo"), selectedReleaseNumber)));	
		return this.entityManager.createQuery(query).getResultList();
	}

}
