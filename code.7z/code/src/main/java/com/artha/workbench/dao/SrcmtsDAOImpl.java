package com.artha.workbench.dao;

import com.artha.workbench.models.core.Srcmts;
import com.guvvala.framework.dao.BaseDAOImpl;

/**
 * @author Guvala
 *
 */
public class SrcmtsDAOImpl extends BaseDAOImpl<Srcmts, String> implements SrcmtsDAO {

	public SrcmtsDAOImpl() {
		super(Srcmts.class);
	}

}
