package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.datahub.LockedTask;
import com.artha.workbench.models.datahub.LockedTaskPK;
import com.guvvala.framework.dao.BaseDAO;

public interface LockedTaskDAO extends BaseDAO<LockedTask, LockedTaskPK> {

	void createLock(String taskId, String userName, String lockType);

	public List<String> getLockedTasksList(String userName);

	public void removeLockedTasks(String taskid, String username);

	public void unlockSelected(String taskid, String value);

	public void deleteAlltasks(List<String> taskIds);

	List<String> getLockedTasksList(String taskId,String lockType);
	

}
