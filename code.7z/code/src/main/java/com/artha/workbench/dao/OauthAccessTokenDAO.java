package com.artha.workbench.dao;

import com.artha.workbench.models.dbo.OauthAccessToken;
import com.guvvala.framework.dao.BaseDAO;

public interface OauthAccessTokenDAO extends BaseDAO<OauthAccessToken, String>{
	
	public void deleteOauthTokenName(String userName);

}
