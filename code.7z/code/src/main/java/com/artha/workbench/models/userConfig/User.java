package com.artha.workbench.models.userConfig;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.artha.workbench.constant.UserStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.ThreadLocalUtil;

@Entity
@Table(name = "userconfig.USERS")
public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "USER_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long userId;

	@Column(name = "USER_NAME", nullable = false)
	private String userName;

	@Column(name = "GROUP_ID")
	private Integer groupid;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "LAST_NAME")
	private String lastName;

	@Column(name = "EMAIL")
	private String userEmail;

	@Column(name = "SUPER_ADMIN")
	@Type(type = "numeric_boolean")
	private boolean sadmin;

	@Column(name = "ADMIN")
	@Type(type = "numeric_boolean")
	private boolean admin;

	@JsonIgnore
	@Column(name = "USER_SALT", nullable = false)
	private String userSalt;

	@JsonIgnore
	@Column(name = "PWD_HASH", nullable = false)
	private String passwordHash;

	@Column(name = "USER_STATUS")
	private Integer userStatus = UserStatus.USER_ENABLED.value;

	@JsonIgnore
	@Column(name = "LOGIN_ATTEMPTS")
	private Integer loginAttempts = 0;

	@JsonIgnore
	@Column(name = "LAST_LOGIN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastLoginDate;

	@JsonIgnore
	@Column(name = "PW_EXPIRATION_DT", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date passwordExpirationDate;

	@Column(name = "CREATED_BY", nullable = false)
	private String createdBy;

	@Column(name = "CREATED_DT", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	@Column(name = "LAST_UPD_BY", nullable = false)
	private String lastUpdBy;

	@Column(name = "LAST_UPD_DT", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdDate;

	@Column(name = "CREATE_TASK")
	@Type(type = "numeric_boolean")
	private boolean createTask;

	@Transient
	private String displayDate;

	@Transient
	private String displayEndDate;

	@Transient
	private String groupName;

	@JsonIgnore
	@Transient
	private String pswdExpirationDate;

	@Transient
	private String userStatusString;

	@Transient
	private String userType;

	@JsonIgnore
	@Transient
	private String lastLoginDateString;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName != null ? userName.trim() : userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName != null ? firstName.trim() : firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName != null ? lastName.trim() : lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserEmail() {
		return userEmail != null ? userEmail.trim() : userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserSalt() {
		return userSalt;
	}

	public void setUserSalt(String userSalt) {
		this.userSalt = userSalt;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public Integer getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(Integer userStatus) {
		this.userStatus = userStatus;
	}

	public Integer getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(Integer loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public Date getPasswordExpirationDate() {
		return passwordExpirationDate;
	}

	public void setPasswordExpirationDate(Date passwordExpirationDate) {
		this.passwordExpirationDate = passwordExpirationDate;
	}

	public boolean hasPasswordExpired() {
		Date today = new Date();
		return !getPasswordExpirationDate().after(today) || getUserStatus().equals(4);
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdBy() {
		return lastUpdBy;
	}

	public void setLastUpdBy(String lastUpdBy) {
		this.lastUpdBy = lastUpdBy;
	}

	public Date getLastUpdDate() {
		return lastUpdDate;
	}

	public void setLastUpdDate(Date lastUpdDate) {
		this.lastUpdDate = lastUpdDate;
	}

	public String getDisplayDate() {
		return displayDate;
	}

	public void setDisplayDate(String displayDate) {
		this.displayDate = displayDate;
	}

	public String getDisplayEndDate() {
		return displayEndDate;
	}

	public void setDisplayEndDate(String displayEndDate) {
		this.displayEndDate = displayEndDate;
	}

	public Date getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(Date lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public boolean isSadmin() {
		return sadmin;
	}

	public void setSadmin(boolean sadmin) {
		this.sadmin = sadmin;
		this.createTask = sadmin;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
		this.createTask = admin;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Integer getGroupid() {
		return groupid;
	}

	public void setGroupid(Integer groupid) {
		this.groupid = groupid;
	}

	public String getPswdExpirationDate() {
		return pswdExpirationDate;
	}

	public void setPswdExpirationDate(String pswdExpirationDate) {
		this.pswdExpirationDate = pswdExpirationDate;
	}

	public String getUserStatusString() {
		return userStatusString;
	}

	public void setUserStatusString(String userStatusString) {
		this.userStatusString = userStatusString;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public boolean isCreateTask() {
		return createTask;
	}

	public void setCreateTask(boolean createTask) {
		this.createTask = createTask;
	}

	public String getLastLoginDateString() {
		return lastLoginDateString;
	}

	public void setLastLoginDateString(String lastLoginDateString) {
		this.lastLoginDateString = lastLoginDateString;
	}

	@PostLoad
	public void postLoad() {
		if (getLastLoginDate() != null) {
			setLastLoginDateString(DateUtils.convertDateFormat(getLastLoginDate(), DateUtils.DISPLAY_DATE_TIME_FORMAT));
		}
		setDisplayDate(DateUtils.convertDateFormat(getCreatedDate(), DateUtils.DISPLAY_DATE_TIME_FORMAT));
		setPswdExpirationDate(
				DateUtils.convertDateFormat(getPasswordExpirationDate(), DateUtils.DISPLAY_DATE_TIME_FORMAT));
		setUserStatusString(UserStatus.fromInteger(userStatus).stringValue);
		if (isSadmin()) {
			this.userType = "Super Admin";
		} else if (isAdmin()) {
			this.userType = "Admin";
		}
	}

	@PrePersist
	public void prePresist() {
		setCreatedBy(ThreadLocalUtil.getUserName());
		setLastUpdBy(ThreadLocalUtil.getUserName());
		setCreatedDate(DateUtils.getCurrentTimeStamp());
		setLastUpdDate(DateUtils.getCurrentTimeStamp());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}

}
