package com.artha.workbench.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.constant.MessagesEnum;
import com.artha.workbench.dao.EntityFileRuleParamDAO;
import com.artha.workbench.dao.EntityFileRuleXrefDAO;
import com.artha.workbench.dao.EntityFileTypeXrefDAO;
import com.artha.workbench.dao.EntityFileValidationRuleDAO;
import com.artha.workbench.dao.EntityFileValidationRuleVwDAO;
import com.artha.workbench.dao.EntityMasterDAO;
import com.artha.workbench.dao.FileTypeDAO;
import com.artha.workbench.dao.ReleaseArchiveDAO;
import com.artha.workbench.dao.RuleTypeDAO;
import com.artha.workbench.dao.ValidationStepDAO;
import com.artha.workbench.models.metastore.AbstractModel;
import com.artha.workbench.models.metastore.EntityFileRuleParam;
import com.artha.workbench.models.metastore.EntityFileRuleXref;
import com.artha.workbench.models.metastore.EntityFileValidationRule;
import com.artha.workbench.models.metastore.EntityFileValidationRuleVw;
import com.artha.workbench.models.metastore.EntityFileValidationRuleVwId;
import com.artha.workbench.models.metastore.ReleaseArchive;
import com.artha.workbench.models.metastore.ReleaseArchiveKey;
import com.artha.workbench.to.ValidationRulesInfoTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;
import com.guvvala.framework.util.StringUtils;

@Service("entityFileValidationRuleService")
public class EntityFileValidationRuleServiceImpl implements EntityFileValidationRuleService {

	@Autowired
	EntityFileValidationRuleDAO entityFileValidationRuleDAO;
	
	@Autowired
	EntityFileValidationRuleVwDAO entityFileValidationRuleVwDAO;
	
	@Autowired
	RuleTypeDAO ruleTypeDAO;
	
	@Autowired
	ValidationStepDAO validationStepDAO;
	
	@Autowired
	EntityFileRuleXrefDAO entityFileRuleXrefDAO;
	
	@Autowired
	EntityFileTypeXrefDAO entityFileTypeXrefDAO;
	
	
	@Autowired
	EntityFileRuleParamDAO entityFileRuleParamDAO;
	
	@Autowired
	FileTypeDAO fileTypeDAO;
	
	@Autowired
	EntityMasterDAO entityMasterDAO;
	
	@Autowired
	ReleaseArchiveDAO releaseArchiveDAO;
	
	
	@Transactional(readOnly = true)
	public List<EntityFileValidationRuleVw> getEntityFileValRuleVwListByReleaseNo(Integer releaseNo) {
		return entityFileValidationRuleVwDAO.getEntityFileValRuleVwListByReleaseNo(releaseNo);
	}
	
	@Transactional
	public EntityFileValidationRuleVw getPreviousEntityFileValidationRuleVw(EntityFileValidationRuleVw entityFileValidationRuleVw) throws IOException
	{
		EntityFileValidationRuleVwId id = new EntityFileValidationRuleVwId();
		id.setEfvrid(entityFileValidationRuleVw.getEfvrid());
		String entityFileValidationRuleVwIdJson = AppWebUtils.convertObjectToJson(id);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchive(entityFileValidationRuleVw.getReleaseNo(), "VALIDATIONRULE", entityFileValidationRuleVwIdJson);
		EntityFileValidationRuleVw previousEntityFileValidationRuleVw = new EntityFileValidationRuleVw();
		if(releaseArchive!=null){
			ValidationRulesInfoTO validationRulesInfo = AppWebUtils.convertJsonToObject(ValidationRulesInfoTO.class, releaseArchive.getRecData());
			if(validationRulesInfo!=null && !validationRulesInfo.getEntityFileValidationRuleList().isEmpty()){
				previousEntityFileValidationRuleVw =validationRulesInfo.getEntityFileValidationRuleList().get(0);
			}
		}
		return previousEntityFileValidationRuleVw;
	}

	@Transactional(readOnly = true)
	public List<EntityFileValidationRule> getEntityFileValidationRuleList() {
		return entityFileValidationRuleDAO.findAll();
	}

	@Transactional
	public void create(EntityFileValidationRule entityFileValidationRule) {
		entityFileValidationRuleDAO.create(entityFileValidationRule);
	}

	@Transactional
	public void update(EntityFileValidationRule entityFileValidationRule) {
		entityFileValidationRuleDAO.update(entityFileValidationRule);
	}
	@Transactional
	public List<EntityFileValidationRuleVw> getEntityFileValidationRuleVwList()
	{
		return entityFileValidationRuleVwDAO.findAll();
	}
	
	@Transactional
	public void performDBupdates(EntityFileValidationRuleVw efvrDB,boolean isReleaseChanged)throws JsonProcessingException  {
		if (efvrDB.getEfvrid() == null) {
			int ruleIdSeq = entityFileValidationRuleDAO.getMaxvalidationruleid() + 1;
			efvrDB.setEfvrid(ruleIdSeq);
			entityFileValidationRuleVwDAO.create(efvrDB);
			EntityFileValidationRule efvr = new EntityFileValidationRule();
			efvr.setRuleID(ruleIdSeq);
			loadEntityFileValidationRule(efvrDB, efvr);
			entityFileValidationRuleDAO.create(efvr);
			EntityFileRuleXref efrxref = new EntityFileRuleXref();
			efrxref.setEntityfileRuleId(ruleIdSeq);
			loadEntityFileRuleXref(efvrDB, efrxref, efvr);
			entityFileRuleXrefDAO.create(efrxref);
			loadEntityFileRuleParam(efvrDB, efrxref);
		} else {
			EntityFileValidationRule efvr = entityFileValidationRuleDAO.findOne(efvrDB.getEfvrid());
			EntityFileRuleXref efrxref = entityFileRuleXrefDAO.findOne(efvrDB.getEfvrid());
			checkForCyclicDependency(efvrDB);
			List<EntityFileRuleParam> paramsList = new ArrayList<>();
			if(efrxref!=null){
				paramsList=entityFileRuleParamDAO.getEntityFileRuleParamList(efrxref.getEntityfileRuleId());
			}
			if(isReleaseChanged)
			{
				EntityFileValidationRuleVw entityFileValidationRuleVw = entityFileValidationRuleVwDAO.findOne(efvrDB.getEfvrid());
				if(entityFileValidationRuleVw!=null){
					ReleaseArchiveKey releaseArchiveKey = new ReleaseArchiveKey();
					releaseArchiveKey.setArchivedReleaseId(entityFileValidationRuleVw.getReleaseNo());
					releaseArchiveKey.setReleaseId(efvrDB.getReleaseNo());
					releaseArchiveKey.setTableName("VALIDATIONRULE");
					EntityFileValidationRuleVwId  id= new EntityFileValidationRuleVwId();
					id.setEfvrid(efvrDB.getEfvrid());
					releaseArchiveKey.setTableRecId(AppWebUtils.convertObjectToJson(id));
					ReleaseArchive releaseArchive = releaseArchiveDAO.findOne(releaseArchiveKey);
					ValidationRulesInfoTO validationRulesInfoTO = new ValidationRulesInfoTO();
					validationRulesInfoTO.getEntityFileValidationRuleList().add(entityFileValidationRuleVw);
					validationRulesInfoTO.getEntityFileValidationRules().add(efvr);
					validationRulesInfoTO.getEntityFileRuleXrefs().add(efrxref);
					validationRulesInfoTO.getEntityFileRuleParams().addAll(paramsList);
					if(releaseArchive!=null){
						releaseArchive.setRecData(AppWebUtils.convertObjectToJson(validationRulesInfoTO));
						releaseArchiveDAO.update(releaseArchive);
					}else{
						releaseArchive= new ReleaseArchive();
						releaseArchive.setReleaseArchiveKey(releaseArchiveKey);
						releaseArchive.setRecData(AppWebUtils.convertObjectToJson(validationRulesInfoTO));
						releaseArchiveDAO.create(releaseArchive);
					}

					releaseArchiveDAO.create(releaseArchive);
				}
			}
			entityFileValidationRuleVwDAO.update(efvrDB);
			if (efvr != null) {
				loadEntityFileValidationRule(efvrDB, efvr);
				entityFileValidationRuleDAO.update(efvr);
				if (efrxref != null) {
					loadEntityFileRuleXref(efvrDB, efrxref, efvr);
					entityFileRuleXrefDAO.update(efrxref);
					if(!paramsList.isEmpty()){
						entityFileRuleParamDAO.deleteAll(paramsList);
					}
					loadEntityFileRuleParam(efvrDB, efrxref);
				}
			}
			
		}

	}
	
	private void checkForCyclicDependency(EntityFileValidationRuleVw efvrDB) throws JsonProcessingException	{
		EntityFileValidationRuleVwId  id= new EntityFileValidationRuleVwId();
		id.setEfvrid(efvrDB.getEfvrid());;
		String jsonId = AppWebUtils.convertObjectToJson(id);
		ReleaseArchive releaseArchive = releaseArchiveDAO.getReleaseArchiveByArchiveId(efvrDB.getReleaseNo(), "VALIDATIONRULE", jsonId);
		if(releaseArchive!=null)
		{
			throw new AppException(MessagesEnum.CYCLIC_DEPENDENCY);
		}
	}
	
	private void loadEntityFileValidationRule(EntityFileValidationRuleVw efvrDB,EntityFileValidationRule efvr){
		efvr.setRuleTypeID(efvrDB.getRuleTypeId());
		efvr.setRuleValue(efvrDB.getRuleValue());
		efvr.setRuleDescription(efvrDB.getRuleDesc());
		efvr.setRuleforTable("[datahub].[DataSplitColumn]");
		efvr.setActive(efvrDB.getActive());
		efvr.setEffectiveDate(efvrDB.getEffectiveDate());
		efvr.setReleaseNo(efvrDB.getReleaseNo());
	}
	
	private void loadEntityFileRuleXref(EntityFileValidationRuleVw efvrDB,EntityFileRuleXref efrxref,EntityFileValidationRule efvr){
		efrxref.setEntityFileTypeID(efvrDB.getEntityFileTypeId());
		efrxref.setStepID(efvrDB.getStepId());
		efrxref.setRuleId(efvr.getRuleID());
		efrxref.setParamHash(efvrDB.getRuleParam1()+efvrDB.getRuleParam2()+efvrDB.getRuleParam3()+efvrDB.getRuleParam4()+efvrDB.getRuleParam5()+efvrDB.getRuleParam6()+efvrDB.getRuleParam7()+efvrDB.getRuleParam8()+efvrDB.getRuleParam9()+efvrDB.getRuleParam10());
		efrxref.setFailLevel(efvrDB.getFailLevel());
		efrxref.setActive(efvrDB.getActive());
		efrxref.setEffectiveDate(efvrDB.getEffectiveDate());
		efrxref.setBaseColumn(efvrDB.getBaseColumn());
		efrxref.setBaseMessage(efvrDB.getBaseMessage());
		efrxref.setReleaseNo(efvrDB.getReleaseNo());
	}
	private void loadEntityFileRuleParam(EntityFileValidationRuleVw efvrDB,EntityFileRuleXref efrxref){
		List<String> plist = new ArrayList<String>();
		if(!StringUtils.isEmpty(efvrDB.getRuleParam1()))
		{
			plist.add(efvrDB.getRuleParam1());
		}
		if(!StringUtils.isEmpty(efvrDB.getRuleParam2()))	{
			plist.add(efvrDB.getRuleParam2());
		}
		if(!StringUtils.isEmpty(efvrDB.getRuleParam3()))
		{
			plist.add(efvrDB.getRuleParam3());
		}
		if(!StringUtils.isEmpty(efvrDB.getRuleParam4()))
		{
			plist.add(efvrDB.getRuleParam4());
		}
		if(!StringUtils.isEmpty(efvrDB.getRuleParam5()))
		{
			plist.add(efvrDB.getRuleParam5());
		}
		if(!StringUtils.isEmpty(efvrDB.getRuleParam6()))
		{
			plist.add(efvrDB.getRuleParam6());
		}
		if(!StringUtils.isEmpty(efvrDB.getRuleParam7()))
		{
			plist.add(efvrDB.getRuleParam7());
		}
		if(!StringUtils.isEmpty(efvrDB.getRuleParam8()))
		{
			plist.add(efvrDB.getRuleParam8());
		}
		if(!StringUtils.isEmpty(efvrDB.getRuleParam9()))
		{
			plist.add(efvrDB.getRuleParam9());
		}
		if(!StringUtils.isEmpty(efvrDB.getRuleParam10()))
		{
			plist.add(efvrDB.getRuleParam10());
		}
		
		int cnt =1;
		for(int k=0;k<plist.size();k++)
		{
			EntityFileRuleParam efrp = new EntityFileRuleParam();
            efrp.setEntityFileRuleId(efrxref.getEntityfileRuleId());
			efrp.setParamID(":"+cnt+":");
			efrp.setParamColName(plist.get(k));
			efrp.setReleaseNo(efvrDB.getReleaseNo());
			entityFileRuleParamDAO.create(efrp);
    		cnt++;
		}
	}
	
		@Transactional
	 public List<EntityFileRuleParam> getEntityFileRuleParamList(List<AbstractModel> entitytypes,String deleteflag,List<EntityFileRuleXref> efrxlist) {
	    	        return null;
	    }
	@Transactional
	public void saveEntityFileValidationRule(List<EntityFileValidationRule> entitytypes) 
	{
		entityFileValidationRuleDAO.saveEntityFileValidationRule(entitytypes);
	}
	@Transactional
	public void saveEntityFileValidationRuleVw(List<EntityFileValidationRuleVw> entitytypes)
	{
		entityFileValidationRuleVwDAO.saveEntityFileValidationRuleVw(entitytypes);
	}
	@Transactional
	public void saveEntityFileRuleXref(List<EntityFileRuleXref> entitytypes)
	{
		entityFileRuleXrefDAO.saveEntityFileRuleXref(entitytypes);
	}
	@Transactional
	public void saveEntityFileRuleParam(List<EntityFileRuleParam> entitytypes)
	{
		entityFileRuleParamDAO.saveEntityFileRuleParam(entitytypes);
	}
	@Transactional
	public void updateEntityFileRuleXref(EntityFileRuleXref entityFileRuleXref)
	{
		entityFileRuleXrefDAO.update(entityFileRuleXref);
	}
	@Transactional
	public void createEntityFileRuleXref(EntityFileRuleXref entityFileRuleXref)
	{
		entityFileRuleXrefDAO.create(entityFileRuleXref);
	}
	
	@Transactional
	public void updateEntityFileRuleParam(EntityFileRuleParam entityFileRuleParam)
	{
		entityFileRuleParamDAO.update(entityFileRuleParam);
	}
	@Transactional
	public void createEntityFileRuleParam(EntityFileRuleParam entityFileRuleParam)
	{
		entityFileRuleParamDAO.create(entityFileRuleParam);
	}
	@Transactional
	public int getmaxEfvrid()
	{
		return entityFileValidationRuleVwDAO.getmaxEfvrid();
	}
	@Transactional
	 public void updateEntityFileValidationRuleVw(List<EntityFileValidationRuleVw> entitytypes)
	{
		for (EntityFileValidationRuleVw ref : entitytypes) {
			entityFileValidationRuleVwDAO.update(ref);
		}
	}

	//TODO plz remove below method.
	@Override
	public List<EntityFileValidationRule> getEntityfileValruleList(List<AbstractModel> entitytypes, String deleteflag) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EntityFileRuleXref> getEntityFileRuleXrefList(List<AbstractModel> entitytypes, String deleteflag,
			List<EntityFileValidationRule> efrclocallist, String editFlag) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional(readOnly = true)
	public List<EntityFileRuleParam> getEntityFileRuleParamList(List<Integer> xrefIds){
		return entityFileRuleParamDAO.getEntityFileRuleParamList(xrefIds);
		
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<EntityFileRuleXref> getEntityFileRuleXrefsById(List<Integer> entityfileRuleIds){
		return entityFileRuleXrefDAO.getEntityFileRuleXrefsById(entityfileRuleIds);
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<EntityFileValidationRule> getEntityFileValidationRulesById(List<Integer> ruleIds){
		return entityFileValidationRuleDAO.getEntityFileValidationRulesById(ruleIds);
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<Integer> getAllEntityFileValRuleReleaseIds(Integer selectedReleaseId){
		return entityFileValidationRuleVwDAO.getAllEntityFileValRuleReleaseIds(selectedReleaseId);
	}
	

	@Override
	@Transactional(readOnly = true)
	public List<EntityFileRuleParam> getEntityFileRuleParamList(Integer xrefIds){
		return entityFileRuleParamDAO.getEntityFileRuleParamList(xrefIds);
		
	}
	
	@Override
	@Transactional(readOnly = true)
	public EntityFileRuleXref getEntityFileRuleXrefsById(Integer entityfileRuleId){
		return entityFileRuleXrefDAO.findOne(entityfileRuleId);
	}
	
	@Override
	@Transactional(readOnly = true)
	public EntityFileValidationRule getEntityFileValidationRulesById(Integer ruleId){
		return entityFileValidationRuleDAO.findOne(ruleId);
	}
}
