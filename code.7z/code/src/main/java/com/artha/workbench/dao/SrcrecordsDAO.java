package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.datahub.Srcrecords;
import com.guvvala.framework.dao.BaseDAO;

public interface SrcrecordsDAO extends BaseDAO<Srcrecords, Integer> {
	public String getSrcrecid(String taskid);

	public String getTargetrecid(String taskid);

	public void deleteAllSrcRecords(List<String> taskIds);

	public List<String> findSrcRecordsByTaskId(List<String> taskIds);

}
