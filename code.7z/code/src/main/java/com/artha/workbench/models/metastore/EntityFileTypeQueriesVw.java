package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name= "metastore.EntityFileTypeQueries_V")
public class EntityFileTypeQueriesVw extends AbstractModel {
	
	
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	@JsonProperty("Key")
	private EntityFileTypeQueriesVwKey entityFileTypeQueriesVwKey; 
   
	@Column(name = "entityfiletypeid",insertable = false,updatable = false , nullable = false)
	@JsonProperty("entityfiletypeid")
	private Integer entityFileTypeID;
	
	@Column(name = "StepID",insertable = false, updatable = false , nullable = false)
	@JsonProperty("StepID")
	private Integer stepID;
	
	@Column(name = "SeqOrder",insertable = false,updatable = false, nullable = false)
	@JsonProperty("SeqOrder")
	private Integer  seqOrder;
	
	@JsonProperty("QueryText")
	private String queryText;
	
	@JsonProperty("Active")
	private String active;
	
	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date effectiveDate;

	@Column(name ="entityname",insertable = false,updatable = false)
	@JsonProperty("entityname")
	private String entityName;
	
	@Column(name ="hsfiletype",insertable = false,updatable = false)
	@JsonProperty("hsfiletype")
	private String hsFileType;
	
	@Column(name ="filemask",insertable = false,updatable = false)
	@JsonProperty("filemask")
	private String fileMask;
	
	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	@Transient
	@JsonIgnore
	private boolean addMode;
	
	@Transient
	@JsonIgnore
	private String effectiveDtstr;
	
	public EntityFileTypeQueriesVw(){
		
	}
	
	public EntityFileTypeQueriesVw(Date effectiveDate, Integer releaseNo, boolean addMode) {
		super();
		this.effectiveDate = effectiveDate;
		this.releaseNo = releaseNo;
		this.addMode = addMode;
	}

	//Getters & Setters
	
	
    @XmlTransient
	public Integer getEntityFileTypeID() {
		return entityFileTypeID;
	}
    
    public void setEntityFileTypeID(Integer entityFileTypeID) {
		this.entityFileTypeID = entityFileTypeID;
	}
    
	public Integer getStepID() {
		return stepID;
	}

	public void setStepID(Integer stepID) {
		this.stepID = stepID;
	}
    
	public Integer getSeqOrder() {
		return seqOrder;
	}

	public void setSeqOrder(Integer seqOrder) {
		this.seqOrder = seqOrder;
	}

	public String getQueryText() {
		return queryText;
	}

	public void setQueryText(String queryText) {
		this.queryText = queryText;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getHsFileType() {
		return hsFileType;
	}

	public void setHsFileType(String hsFileType) {
		this.hsFileType = hsFileType;
	}

	public String getFileMask() {
		return fileMask;
	}

	public void setFileMask(String fileMask) {
		this.fileMask = fileMask;
	}

	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}

	public boolean isAddMode() {
		return addMode;
	}

	public void setAddMode(boolean addMode) {
		this.addMode = addMode;
	}

	public String getEffectiveDtstr() {
		return effectiveDtstr;
	}

	public void setEffectiveDtstr(String effectiveDtstr) {
		this.effectiveDtstr = effectiveDtstr;
	}
	
	@PostLoad
	public void postLoad(){
		convertEffectiveDate();
	}
	public void convertEffectiveDate(){
		this.effectiveDtstr = DateUtils.convertToSimpleDateFormat(getEffectiveDate());	
	}

	public EntityFileTypeQueriesVwKey getEntityFileTypeQueriesVwKey() {
		return entityFileTypeQueriesVwKey;
	}

	public void setEntityFileTypeQueriesVwKey(EntityFileTypeQueriesVwKey entityFileTypeQueriesVwKey) {
		this.entityFileTypeQueriesVwKey = entityFileTypeQueriesVwKey;
	}
	
	
}



