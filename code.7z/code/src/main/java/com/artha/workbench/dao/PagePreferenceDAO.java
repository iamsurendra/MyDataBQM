package com.artha.workbench.dao;

import com.artha.workbench.models.userConfig.PagePreference;
import com.guvvala.framework.dao.BaseDAO;

public interface PagePreferenceDAO extends BaseDAO<PagePreference, Integer> {
	public PagePreference findPagePreference(Long userId, String pageName);

}
