package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.artha.workbench.models.metastore.EntityFileRecColumn;
import com.artha.workbench.models.metastore.EntityFileRecColumnVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EntityFileRecColoumnService {
	
	public EntityFileRecColumn loadEntityFileRecColumn(EntityFileRecColumn efrs,
			EntityFileRecColumnVw entityFileRecColumnVw);
	
	public List<EntityFileRecColumn> getEntityFileRecColumnList();

	public List<EntityFileRecColumnVw> getEntityFileRecColumnVwList();

	public void create(EntityFileRecColumnVw entityFileRecColumnVw);

	public void update(EntityFileRecColumnVw entityFileRecColumnVw,boolean isReleaseChanged)throws JsonProcessingException;

	public void saveEntityFileRecColumn(List<EntityFileRecColumn> entitytypes);

	public List<EntityFileRecColumn> getEntityFileRecColumnTempList();
	
	public EntityFileRecColumn getEntityFileRecColInfo(EntityFileRecColumnVw entityFileRecColumnVw);
	
	public EntityFileRecColumn getEntityFileRecColInfo(Integer entityFileTypeId,Integer columnId);
	
	public List<EntityFileRecColumnVw> getEntityFileRecColVwListByReleaseNo(Integer releaseNo);
	
	public EntityFileRecColumnVw getPreviousEntityFileRecColVw(EntityFileRecColumnVw entityFileRecColumnVw) throws IOException;
	
	List<Integer> getEntityFileRecRelNumbersByTypeIds(Set<Integer> entityTypeIds,Integer selectedReleaseNumber);
	List<Integer> getEntityFileRecRelNumbersByColIds(Set<Integer> colIds,Integer selectedReleaseNumber);
	
	public List<EntityFileRecColumn> getEntityFileRecColumnListByReleaseNo(Integer releaseNo);

	List<Integer> getAllEntityFileRecColumnReleaseIds(Integer selectedReleaseId);
	
	List<EntityFileRecColumn> getEntityFileRecList(Set<Integer> entityTypeIds,Set<Integer> colIds,Integer selectedReleaseNumber);
}
