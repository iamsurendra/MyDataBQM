package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.artha.workbench.models.metastore.AbstractModel;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;


@Entity
@Table(name = "metastore.ValidationRules")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name="entityFileValidationRule")
public class  EntityFileValidationRule extends AbstractModel {

	private static final long serialVersionUID = 1L;

	//DB Fields
	
	
	//@GeneratedValue(strategy=GenerationType.AUTO)
	//@GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
	@Id
	@Column(name = "RuleID", nullable = false)
	@JsonProperty("RuleID")
	private Integer ruleID;
	
	@JsonProperty("RuleTypeID")
  	private Integer ruleTypeID;
	
	@JsonProperty("Active")
  	private String active;
	
	@JsonProperty("EffectiveDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
  	private Date effectiveDate;
	
	@JsonProperty("RuleValue")
  	private String ruleValue;
	
	@JsonProperty("RuleDescription")
  	private String ruleDescription;
	
	@JsonProperty("RuleforTable")
  	private String ruleforTable;
  	
  	@Column(name = "ReleaseNum", nullable = false)
  	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
  	
  	
  	//getter and setter
  	
	public Integer getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}

	public Integer getRuleID() {
		return ruleID;
	}

	public void setRuleID(Integer ruleID) {
		this.ruleID = ruleID;
	}

	public Integer getRuleTypeID() {
		return ruleTypeID;
	}

	public void setRuleTypeID(Integer ruleTypeID) {
		this.ruleTypeID = ruleTypeID;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getRuleValue() {
		return ruleValue;
	}

	public void setRuleValue(String ruleValue) {
		this.ruleValue = ruleValue;
	}

	public String getRuleDescription() {
		return ruleDescription;
	}

	public void setRuleDescription(String ruleDescription) {
		this.ruleDescription = ruleDescription;
	}

	public String getRuleforTable() {
		return ruleforTable;
	}

	public void setRuleforTable(String ruleforTable) {
		this.ruleforTable = ruleforTable;
	}

	
	
}
