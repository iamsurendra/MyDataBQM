package com.artha.workbench.dao;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.artha.workbench.models.userConfig.User;
import com.artha.workbench.to.DeletedUserTO;

public interface DeletedUserReportDAO extends BaseDAO<User, Integer> {
	
	 List<DeletedUserTO> fetchDeletedUserList();

}
