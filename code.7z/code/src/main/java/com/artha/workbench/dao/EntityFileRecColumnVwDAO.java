package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EntityFileRecColumnVw;
import com.artha.workbench.models.metastore.EntityFileReccolVwkey;
import com.guvvala.framework.dao.BaseDAO;

public interface EntityFileRecColumnVwDAO extends BaseDAO<EntityFileRecColumnVw, EntityFileReccolVwkey> {

	public List<EntityFileRecColumnVw> getEntityFileRecColVwListByReleaseNo(Integer releaseNo);
}
