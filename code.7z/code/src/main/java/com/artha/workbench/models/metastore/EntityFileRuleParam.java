package com.artha.workbench.models.metastore;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonProperty;


@Entity
@Table(name = "metastore.EntityFileRuleParam")
@org.hibernate.annotations.DynamicInsert
@org.hibernate.annotations.DynamicUpdate
@XmlRootElement(name="entityFileRuleParam")
public class EntityFileRuleParam extends AbstractModel {


	private static final long serialVersionUID = 1L;
	
	@Id
	@JsonProperty("EntityFileRuleID")
	private Integer entityFileRuleId;

	@Id
	@Column(name = "ParamID", nullable = false)
	@JsonProperty("ParamID")
	private String paramID;
	
	@JsonProperty("ParamColName")
	private String paramColName;
	
	@Column(name = "ReleaseNum", nullable = false)
	@JsonProperty("ReleaseNum")
	private Integer releaseNo;
	
	

	public Integer getReleaseNo() {
		return releaseNo;
	}
	public void setReleaseNo(Integer releaseNo) {
		this.releaseNo = releaseNo;
	}
	
	public Integer getEntityFileRuleId() {
		return entityFileRuleId;
	}
	public void setEntityFileRuleId(Integer entityFileRuleId) {
		this.entityFileRuleId = entityFileRuleId;
	}
	public String getParamID() {
		return paramID;
	}
	public void setParamID(String paramID) {
		this.paramID = paramID;
	}
	public String getParamColName() {
		return paramColName;
	}
	public void setParamColName(String paramColName) {
		this.paramColName = paramColName;
	}
	}
