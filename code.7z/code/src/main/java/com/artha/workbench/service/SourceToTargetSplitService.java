package com.artha.workbench.service;

import java.io.IOException;
import java.util.List;

import com.artha.workbench.models.metastore.SourceToTargetSplit;
import com.artha.workbench.models.metastore.SourceToTargetSplitVw;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface SourceToTargetSplitService {

	public List<SourceToTargetSplitVw> getSourceToTargetSplitVwList();
	
	public void create(SourceToTargetSplitVw sourceToTargetSplitVw);
	
	public void update(SourceToTargetSplitVw sourceToTargetSplitVw, boolean isReleaseChanged) throws JsonProcessingException;
	
	public List<SourceToTargetSplitVw> getSourceToTargetSplitVwListByReleaseNo(Integer releaseNo);
	
	public SourceToTargetSplitVw getPreviousSourceToTargetSplitVw(SourceToTargetSplitVw sourceToTargetSplitVw) throws IOException;
	
	public List<SourceToTargetSplit> getSourceToTargetSplitListByReleaseNo(Integer releaseNo);
	
	public SourceToTargetSplit getSourceToTargetSplit(SourceToTargetSplitVw sourceToTargetSplitVw);
}
