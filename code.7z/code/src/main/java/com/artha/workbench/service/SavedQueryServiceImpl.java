package com.artha.workbench.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artha.workbench.dao.SavedQueryDAO;
import com.artha.workbench.models.userConfig.SavedQuery;

@Service("savedQueryService")
public class SavedQueryServiceImpl implements SavedQueryService {

	@Autowired
	SavedQueryDAO savedQueryDAO;

	@Override
	public List<SavedQuery> getSavedQueryData(String createdBy) {
		return savedQueryDAO.getSavedQueryData(createdBy);
	}

	@Override
	@Transactional
	public void saveSearchCriteria(String queryName, String json) {
		SavedQuery savedQuery = new SavedQuery();
		savedQuery.setQueryName(queryName);
		savedQuery.setQueryString(json);
		savedQueryDAO.create(savedQuery);
	}

	@Override
	public SavedQuery getSavedQueryInfo(String queryName) {
		return savedQueryDAO.getSavedQueryInfo(queryName);
	}

	@Transactional
	public void deleteSavedQuery(Integer SavedQueryId) {
		SavedQuery savedQuery = savedQueryDAO.findOne(SavedQueryId);
		savedQueryDAO.delete(savedQuery);
	}

	@Override
	public List<SavedQuery> getAllSavedQuerys() {
		return savedQueryDAO.findAll();
	}
	
}
