package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.EntityFileTypeScheduleXrefVw;
import com.guvvala.framework.dao.BaseDAO;

public interface EntityFileTypeScheduleXrefVwDAO extends BaseDAO<EntityFileTypeScheduleXrefVw,Integer> {
	
	public List<EntityFileTypeScheduleXrefVw> getEntityFileTypeScheduleXrefByReleaseNo(Integer releaseNo);

}
