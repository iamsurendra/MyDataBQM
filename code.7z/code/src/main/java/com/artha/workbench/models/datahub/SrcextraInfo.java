package com.artha.workbench.models.datahub;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.artha.workbench.models.metastore.AbstractModel;

@Entity
@Table(name = "datahub.srcextrainfo")
public class SrcextraInfo extends AbstractModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	private String id;

	@Column(name = "srcrecord_id")
	private String srcRecordId;

	@Column(name = "info_key")
	private String infoKey;

	@Column(name = "info_value")
	private String infoValue;

	@Column(name = "info_scope")
	private String infoScope;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSrcRecordId() {
		return srcRecordId;
	}

	public void setSrcRecordId(String srcRecordId) {
		this.srcRecordId = srcRecordId;
	}

	public String getInfoKey() {
		return infoKey;
	}

	public void setInfoKey(String infoKey) {
		this.infoKey = infoKey;
	}

	public String getInfoValue() {
		return infoValue;
	}

	public void setInfoValue(String infoValue) {
		this.infoValue = infoValue;
	}

	public String getInfoScope() {
		return infoScope;
	}

	public void setInfoScope(String infoScope) {
		this.infoScope = infoScope;
	}

}
