package com.artha.workbench.dao;

import java.util.List;

import com.artha.workbench.models.metastore.SourceToTargetMapping;
import com.artha.workbench.models.metastore.SourceToTargetMappingKey;
import com.guvvala.framework.dao.BaseDAO;


public interface SourceToTargetMappingDAO extends BaseDAO<SourceToTargetMapping, SourceToTargetMappingKey> {
	public void saveSourceToTargetMappingS(List<SourceToTargetMapping> entitytypes);
	
	public void deleteSourcetotargetMapping();
	
	public List<SourceToTargetMapping> getSourceToTargetMappingListByReleaseNo(Integer releaseNo);
	
	List<Integer> getAllSourceToTargetMappingReleaseIds(Integer selectedReleaseId);
}
