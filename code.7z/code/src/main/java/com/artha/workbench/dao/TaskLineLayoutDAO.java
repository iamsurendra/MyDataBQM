package com.artha.workbench.dao;

import com.artha.workbench.models.datahub.TaskLineLayout;
import com.guvvala.framework.dao.BaseDAO;

/**
 * @author Guvala
 *
 */
public interface TaskLineLayoutDAO extends BaseDAO<TaskLineLayout, String> {

}
