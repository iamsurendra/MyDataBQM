package com.guvvala.framework.filter;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.artha.workbench.constant.WBConstants;
import com.artha.workbench.constant.Labels;
import com.artha.workbench.constant.MessagesEnum;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.StringUtils;

/**
 * Date filters
 */
public class DateFilter extends BaseFilter implements Cloneable {

	// Use TO_DATE FOR oracle
	protected static final String FUNCTION_TO_DATE = "CONVERT";
	protected Date date1;
	protected Date date2;
	protected String formattedDate1;
	protected String formattedDate2;

	public DateFilter() {

	}

	public DateFilter(Date date1, Date date2, String operator, String attributeName, Labels labelId) {
		super();
		this.date1 = date1;
		this.date2 = date2;
		this.formattedDate1 = DateUtils.convertToFilterDateString(getDate1());
		this.formattedDate2 = DateUtils.convertToFilterDateString(getDate2());
		this.operator = operator;
		this.attributeName = attributeName;
		this.labelId = labelId;
	}

	public DateFilter(Date date1, String operator, String attributeName, Labels labelId) {
		super();
		this.date1 = date1;
		this.formattedDate1 = DateUtils.convertToFilterDateString(getDate1());
		this.operator = operator;
		this.attributeName = attributeName;
		this.labelId = labelId;
	}

	public DateFilter(FilterImpl filterImpl) {
		this.formattedDate1 = filterImpl.getValue1();
		this.formattedDate2 = filterImpl.getValue2();
		this.date1 = convertToDate(getFormattedDate1(), DateUtils.DATE_FILTER_FORMAT);
		this.date2 = convertToDate(getFormattedDate2(), DateUtils.DATE_FILTER_FORMAT);
		this.operator = filterImpl.getOperator();
		this.attributeName = filterImpl.getAttributeName();
		this.labelId = filterImpl.getLabelId();
	}

	public Date getDate1() {
		return date1;
	}

	public void setDate1(Date date1) {
		this.date1 = date1;
	}

	public Date getDate2() {
		return date2;
	}

	public void setDate2(Date date2) {
		this.date2 = date2;
	}

	public String getFormattedDate1() {
		return formattedDate1;
	}

	public void setFormattedDate1(String formattedDate1) {
		this.formattedDate1 = formattedDate1;
	}

	public String getFormattedDate2() {
		return formattedDate2;
	}

	public void setFormattedDate2(String formattedDate2) {
		this.formattedDate2 = formattedDate2;
	}

	public String getFilterType() {
		return DATE_FILTER;
	}

	@Override
	public String getEmbeddedValue1() {
		return getFormattedDate1();
	}

	@Override
	public String getEmbeddedValue2() {
		return getFormattedDate2();
	}

	// Return the list of operators available in the drop down.
	public static List<String> getOperators() {
		List<String> operators = new ArrayList<String>();
		operators.add(EQUAL_OPERATOR);
		operators.add(GREATER_THAN_OPERATOR);
		operators.add(SMALLER_THAN_OPERATOR);
		operators.add(GREATER_AND_EQUAL_THAN_OPERATOR);
		operators.add(SMALLER_AND_EQUAL_THAN_OPERATOR);
		operators.add(NOT_EQUAL_OPERATOR);
		operators.add(BETWEEN_OPERATOR);
		operators.add(EMPTY_OPERATOR);
		operators.add(NOT_EMPTY_OPERATOR);
		operators.add(TODAY_OPERATOR);
		operators.add(YESTERDAY_OPERATOR);

		return operators;
	}

	// Return the list of operators available in the drop down.
	public static List<String> getDateFilterCustomeOperators() {
		List<String> operators = new ArrayList<String>();
		operators.add(EQUAL_OPERATOR);
		operators.add(NOT_EQUAL_OPERATOR);
		operators.add(GREATER_THAN_OPERATOR);
		operators.add(GREATER_AND_EQUAL_THAN_OPERATOR);
		operators.add(SMALLER_THAN_OPERATOR);
		operators.add(SMALLER_AND_EQUAL_THAN_OPERATOR);
		return operators;
	}

	public FilterImpl toFilter() {
		return new FilterImpl(getAttributeName(), // id
				getAttributeName(), getOperator(), getFilterType(), getFormattedDate1(), getFormattedDate2(),
				getLabelId());
	}

	// Return true if the user has entered valid data to filter
	public static boolean hasFilterableSelections(Date aDate) {
		return (aDate != null);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Predicate getPredicate(CriteriaBuilder criteriaBuilder, Root root) {
		Expression<Date> dateExpression = root.get(getAttributeName());
		return getPredicate(criteriaBuilder, dateExpression);
	}

	public Predicate getPredicate(CriteriaBuilder criteriaBuilder, Expression<Date> dateExpression) {
		Predicate predicate = null;
		int addOne = 1;
		Date datePlusOne = new Date();
		if (getDate1() != null) {
			datePlusOne = DateUtils.addDays(getDate1(), addOne);
		}

		if (getOperator().equals(GREATER_THAN_OPERATOR)) {
			// Add one day to the input date
			predicate = criteriaBuilder.greaterThanOrEqualTo(dateExpression, datePlusOne);
		}
		// Operator '=' will be processed as to_date(db_date) >=
		// to_date(inputDate) && to_date(db_date) < to_date(inputDate + 1)
		else if (getOperator().equals(EQUAL_OPERATOR)) {
			Predicate gePredicate = criteriaBuilder.greaterThanOrEqualTo(dateExpression, getDate1());
			Date date2 = DateUtils.addDays(getDate1(), addOne);
			Predicate ltPredicate = criteriaBuilder.lessThan(dateExpression, date2);
			predicate = criteriaBuilder.and(gePredicate, ltPredicate);
		}
		// Operator '<' will be processed as to_date(db_date) <
		// to_date(inputDate)
		else if (getOperator().equals(SMALLER_THAN_OPERATOR)) {
			predicate = criteriaBuilder.lessThan(dateExpression, getDate1());
		}
		// Operator '>=' will be processed as to_date(db_date) >=
		// to_date(inputDate)
		else if (getOperator().equals(GREATER_AND_EQUAL_THAN_OPERATOR)) {
			predicate = criteriaBuilder.greaterThanOrEqualTo(dateExpression, getDate1());
		}
		// Operator '<=' will be processed as to_date(db_date) <
		// to_date(inputDate + 1)
		else if (getOperator().equals(SMALLER_AND_EQUAL_THAN_OPERATOR)) {
			// Add one day to the input date
			predicate = criteriaBuilder.lessThan(dateExpression, datePlusOne);
		}
		// Operator '<>' will be processed as to_date(db_date) <
		// to_date(inputDate) && to_date(db_date) >= to_date(inputDate + 1)
		else if (getOperator().equals(NOT_EQUAL_OPERATOR)) {
			Predicate ltPredicate = criteriaBuilder.lessThan(dateExpression, getDate1());
			// Add one day to the input date
			Predicate gePredicate = criteriaBuilder.greaterThanOrEqualTo(dateExpression, datePlusOne);
			predicate = criteriaBuilder.or(ltPredicate, gePredicate);
		}
		// Operator 'Between' will be processed as to_date(db_date) >=
		// to_date(inputDate1) && to_date(db_date) < to_date(inputDate2 + 1)
		else if (getOperator().equals(BETWEEN_OPERATOR)) {
			Predicate gePredicate = criteriaBuilder.greaterThanOrEqualTo(dateExpression, getDate1());
			// Add one day to the input date2
			Predicate ltPredicate = criteriaBuilder.lessThan(dateExpression, datePlusOne);
			predicate = criteriaBuilder.and(gePredicate, ltPredicate);
		} else if (getOperator().equals(EMPTY_OPERATOR)) {
			predicate = criteriaBuilder.isNull(dateExpression);
		} else if (getOperator().equals(NOT_EMPTY_OPERATOR)) {
			predicate = criteriaBuilder.isNotNull(dateExpression);
		}
		// Operator 'TODAY' will be processed as to_date(db_date) >=
		// to_date(inputDate) && to_date(db_date) < to_date(inputDate + 1)
		else if (getOperator().equals(TODAY_OPERATOR)) {
			Date today = DateUtils.truncateToMidnight(new Date());
			Predicate gePredicate = criteriaBuilder.greaterThanOrEqualTo(dateExpression, today);
			// Add one day to the current date
			Predicate ltPredicate = criteriaBuilder.lessThan(dateExpression, DateUtils.addDays(today, addOne));
			predicate = criteriaBuilder.and(gePredicate, ltPredicate);
		} else if (getOperator().equals(YESTERDAY_OPERATOR)) {
			Date yesterday = DateUtils.truncateToMidnight(DateUtils.subtractDays(new Date(), -1));
			Predicate gePredicate = criteriaBuilder.greaterThanOrEqualTo(dateExpression, yesterday);
			// Add one day to yesterday's date
			Predicate ltPredicate = criteriaBuilder.lessThan(dateExpression, DateUtils.addDays(yesterday, addOne));
			predicate = criteriaBuilder.and(gePredicate, ltPredicate);
		}
		return predicate;
	}

	protected Date convertToDate(final String aDate, final String format) {
		Date newDate = null;

		if (StringUtils.isEmpty(aDate)) {
			return newDate;
		}

		try {
			newDate = DateUtils.convertToDate(aDate, format);
		} catch (ParseException pe) {

			throw new AppException(MessagesEnum.INVALID_DATE, aDate);
		}
		return newDate;
	}

	public String getActiveFilters() {
		StringBuffer activefilter = new StringBuffer();
		activefilter.append(getOperator());

		if (!getOperator().equals(EMPTY_OPERATOR) && !getOperator().equals(NOT_EMPTY_OPERATOR)
				&& !getOperator().equals(TODAY_OPERATOR) && !getOperator().equals(YESTERDAY_OPERATOR)) {
			activefilter.append(WBConstants.BLANK_SPACE)
					.append(DateUtils.convertDateFormat(getDate1(), DateUtils.SIMPLE_DATE_FORMAT));
		}

		if (getOperator().equalsIgnoreCase(BETWEEN_OPERATOR)) {
			activefilter.append(AND_SEPARATOR)
					.append(DateUtils.convertDateFormat(getDate2(), DateUtils.SIMPLE_DATE_FORMAT));
		}

		return activefilter.toString();
	}

	
	   public  DateFilter getDateFilter(Date date01, Date date02, String operator, String attributeName, Labels labelId) {
	        return FilterUtils.getDateFilter(date01, date02, operator, attributeName, labelId);
	    }
	   
	   public StringFilter getStringFilter(String value, String operator, String attributeName, Labels labelId) {
	        return FilterUtils.getStringFilter(value, operator, attributeName, labelId);
	    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((attributeName == null) ? 0 : attributeName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DateFilter other = (DateFilter) obj;
		if (attributeName == null) {
			if (other.attributeName != null)
				return false;
		} else if (!attributeName.equals(other.attributeName))
			return false;
		return true;
	}
}
