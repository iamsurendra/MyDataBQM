package com.guvvala.framework.filter;

/**
 *  @author Guvala
 */
public interface FilterSort {

    FilterSortOrder toFilterSortOrder();
}
