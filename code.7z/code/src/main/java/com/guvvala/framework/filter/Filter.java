package com.guvvala.framework.filter;

/**
 *  @author Guvala
 */
public interface Filter {

    BaseFilter toFilterObject();
}
