package com.com.synergy.bqm.mongoDAO;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.guvvala.framework.util.MongoAppConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=MongoAppConfig.class)
public class MongoRepositoryTest {

}
