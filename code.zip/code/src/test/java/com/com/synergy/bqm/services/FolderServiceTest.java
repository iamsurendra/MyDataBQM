/**
 * 
 */
package com.com.synergy.bqm.services;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.synergy.bqm.models.Folder;
import com.synergy.bqm.models.Project;
import com.synergy.bqm.services.FolderService;
import com.synergy.bqm.services.ProjectHierarchyService;
import com.synergy.bqm.services.ProjectService;

/**
 * @author karthik
 *
 */
@EnableTransactionManagement
@Rollback(false)
public class FolderServiceTest extends BaseServiceTest {

	
	@Autowired
	FolderService folderService;
	
	@Autowired
	ProjectService projectService;
	
	@Autowired
	ProjectHierarchyService projectHierarchyService;
	
	
	
	@Test
	public void create() {
		Folder folder1 = buildFolder_1();
		folderService.createFolder(folder1);
		Folder folder2 = buildFolder_2();
		folderService.createFolder(folder2);

	}
	

	
	private Folder buildFolder_1()
	{
		Folder folder_1 = new Folder();
		folder_1.setFolderId(1);
		folder_1.setFolderName("CIVIL");
		folder_1.setProject(projectService.getProjectByProjectId(1));
		//folder_1.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(1));
		
		return folder_1;
	}
	
	private Folder buildFolder_2()
	{
		Folder folder_1 = new Folder();
		folder_1.setFolderId(2);
		folder_1.setFolderName("CIVIL_1");
		folder_1.setProject(projectService.getProjectByProjectId(1));
		//folder_1.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(1));
		folder_1.setFolder(folderService.getFolderByFolderId(1));
		
		return folder_1;
	}
}
