package com.com.synergy.bqm.services;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.synergy.bqm.models.Folder;
import com.synergy.bqm.services.FolderService;

public class FoldetTemplateDetailsTest  extends BaseServiceTest{
	
	@Autowired
	FolderService folderService;

	@Test
	public void fetchFolderTemplate() {
		List<Folder> templateFolders = folderService.getTemplateFolders();
		for(Folder templateFolder : templateFolders)
		{
			System.out.println(templateFolder.getFolderName()+"\n");
			printRecursiveFolder(templateFolder,1);
		}
	}

	private void printRecursiveFolder(Folder folder,int count)
	{
		for(Folder childFolder : folder.getFolders())
		{
			for(int i=0;i<count;i++)
			{
			System.out.print("\t");
			}
			System.out.println(childFolder.getFolderName()+"\n");
			if(null!=childFolder.getFolders() && childFolder.getFolders().size()>0)
			{
				printRecursiveFolder(childFolder,count+1);
			}
			
			
		}
	}
}
