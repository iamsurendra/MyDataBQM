package com.com.synergy.bqm.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.synergy.bqm.services.ProjectHierarchyService;

@EnableTransactionManagement
@Rollback(false)
public class FetchProjectHierarchyTest extends BaseServiceTest{
	
	@Autowired
	ProjectHierarchyService projectHierarchyService;

	/*@Test
	public void fetchCompleteParentHierarchy() {
		ProjectHierarchy projectHierarchy = projectHierarchyService.getCompleteParentHierarchy(2);
		System.out.println(projectHierarchy.getHierarchyName());
	}*/
	
	/*@Test
	public void fetchCompleteChildHierarchy() {
		List<ProjectHierarchy> projectHierarchyList = projectHierarchyService.getCompleteChildHierarchy(2);
		System.out.println(projectHierarchyList.size());
	}*/

	
}
