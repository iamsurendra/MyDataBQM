package com.guvvala.framework.util;

import java.io.Serializable;

import com.synergy.bqm.models.User;

public class AppUser implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long actualUserId;
	private User userObject;
	private String userName;

	public AppUser() {

	}

	public AppUser(User user) {
		this.actualUserId = user.getUserId();
		this.userObject = user;
		this.userName = user.getUserName();
	}

	public Long getActualUserId() {
		return actualUserId;
	}

	public void setActualUserId(Long actualUserId) {
		this.actualUserId = actualUserId;
	}

	public User getUserObject() {
		return userObject;
	}

	public void setUserObject(User userObject) {
		this.userObject = userObject;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public boolean isImpersonated() {
		return !this.userName.equals(this.getUserObject().getUserName());
	}

	public String getLastUpdatedBy() {
		int MAX_USER_ID_LENGTH = 30;
		String userName = this.getUserName().length() > MAX_USER_ID_LENGTH
				? this.getUserName().substring(0, MAX_USER_ID_LENGTH - 1) : this.getUserName();
		return userName.toUpperCase();
	}

	@Override
	public String toString() {
		return userName;
	}
	
	

}
