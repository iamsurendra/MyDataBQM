package com.guvvala.framework.oAuth;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.guvvala.framework.constants.ErrorCodeEnum;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppUser;
import com.synergy.bqm.services.UserService;

@Component
public class WorkbenchAuthProvider implements AuthenticationProvider, InitializingBean {

	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	UserService userService;

	public final void afterPropertiesSet() throws Exception {

	}

	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String username = (authentication.getPrincipal() == null) ? "NONE_PROVIDED" : authentication.getName();
		AppUser user = this.userService.getUserForLogin(username, authentication.getCredentials().toString());
		if (user == null) {
			throw new AppException(ErrorCodeEnum.INVALID_CREDENTIALS.key);
		}
		UsernamePasswordAuthenticationToken result = new UsernamePasswordAuthenticationToken(user,
				authentication.getCredentials(), null);
		result.setDetails(authentication.getDetails());
		return result;
	}

	public boolean supports(Class<?> authentication) {
		return (UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication));
	}

}
