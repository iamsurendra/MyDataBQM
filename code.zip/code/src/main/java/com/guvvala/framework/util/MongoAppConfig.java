package com.guvvala.framework.util;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.convert.MongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.synergy.bqm.constants.EnvProperties;

@Configuration
@EnableMongoRepositories(basePackages = "com.synergy.bqm.mongoRepositories")
@ComponentScan(basePackages = { "com.synergy.bqm.mongoRepositories", "com.synergy.bqm.documents" })
public class MongoAppConfig {

	public @Bean MongoDbFactory mongoDbFactory() throws Exception {
		return new SimpleMongoDbFactory(mongoClient(), "bqm");
	}

	public @Bean MongoTemplate mongoTemplate() throws Exception {
		return new MongoTemplate(mongoDbFactory());
	}

	public @Bean GridFsTemplate gridFsTemplate() throws Exception {
		MongoDbFactory mongoDb = mongoDbFactory();
		DbRefResolver dbRefResolver = new DefaultDbRefResolver(mongoDb);
		MongoConverter converter = new MappingMongoConverter(dbRefResolver, new MongoMappingContext());
		return new GridFsTemplate(mongoDb, converter);
	}

	public @Bean MongoClient mongoClient() throws Exception {

		ServerAddress server = new ServerAddress(EnvProperties.findProperty(EnvProperties.MONGODB_HOST), 27017);
		MongoClient client = new MongoClient(server,
				MongoCredential.createScramSha1Credential(EnvProperties.findProperty(EnvProperties.MONGODB_USER), EnvProperties.findProperty(EnvProperties.MONGO_AUTHDB),
						EnvProperties.findProperty(EnvProperties.MONGODB_PASSWORD).toCharArray()),
				MongoClientOptions.builder().build());
		return client;
	}
}