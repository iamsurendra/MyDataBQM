package com.guvvala.framework.util;

import java.util.Date;
import java.util.regex.Pattern;

/*import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;*/

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

//import com.deliverando.logistics.constants.MessagesEnum;
import com.guvvala.framework.errorHandler.AppException;
import com.synergy.bqm.constants.MessagesEnum;


public abstract class BaseImporter {

	public static final String msgSeperator = "<br/>";
	
	protected Row currentRow;

	protected int columnIndex = -1;
	
	/*public static <T> void validate(T obj) {
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();;
        Set<ConstraintViolation<T>> constraintViolations = validator.validate(obj);
        if (constraintViolations.size() > 0) {
            throw new ConstraintViolationException(constraintViolations);
        }
    }*/
	
	protected String getCheckStringEmpty(Cell cell) {
		String value = getString(cell);
		if (StringUtils.isEmpty(value)) {
			throw new AppException();
		}
		return value;

	}


	protected String getCheckStringEmpty(Cell cell,String header,int rowNum) {
		String value = getString(cell);
		if (StringUtils.isEmpty(value)) {
			throw new AppException(MessagesEnum.DATA_IS_REQUIRED_FOR,header,rowNum+1);	
		}
		return value;
	}

	protected String getCheckStringNumeric(Cell cell, Class<?> type) {
		String value = "";
		if(cell == null) {
			return value ;
		}
		if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
			value = String.valueOf(parseNumber(type, cell));
		} else if (cell.getCellType() != Cell.CELL_TYPE_STRING) {
			value = getString(cell);
			Pattern p = Pattern.compile("\\d+(\\.\\d+)?");
			if (!p.matcher(value).matches()) {
				return null;
			}
		}
		return value;

	}

	public Date CheckDateProperty(Cell cell, Class<?> type) {
		Date value1 = null;
		value1 = cell.getDateCellValue();
		return  value1;
	}

	/**
	 * This method is used to convert Double type (which is the default format
	 * when Excel cell containing number is read) to type of the attribute
	 * declared in Entity or DTO
	 * 
	 * @param num
	 * @param obj
	 * @return
	 * @throws IllegalArgumentException
	 * @throws NumberFormatException
	 */
	protected Object parseNumber(Class<?> type, Cell cell) throws IllegalArgumentException, NumberFormatException {
		Object result = null;
		Double d = cell.getNumericCellValue();
		if (type.equals(Double.class) || type.equals(double.class)) {
			result = (Object) d;
		} else if (type.equals(Integer.class) || type.equals(int.class)) {
			if (d % 1 == 0) {
				result = (Object) Integer.valueOf("" + d.longValue());
			} else {
				throw new IllegalArgumentException("Number containing fractions, cannot convert to Integer");
			}
		} else if (type.equals(Long.class) || type.equals(long.class)) {
			if (d % 1 == 0) {
				result = (Object) Long.valueOf("" + d.longValue());
			} else {
				throw new IllegalArgumentException("Number containing fractions, cannot convert to Long");
			}
		}
		return result;
	}

	protected String getString(Cell cell) {
		if(cell==null){
			return null;
		}
		int type = cell.getCellType();
		switch (type) {
		case Cell.CELL_TYPE_NUMERIC:
			return String.valueOf(cell.getNumericCellValue());
		case Cell.CELL_TYPE_BOOLEAN:
			return String.valueOf(cell.getBooleanCellValue());
		case Cell.CELL_TYPE_BLANK:
			return "";
		case Cell.CELL_TYPE_FORMULA:
			return "";
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue();
		default:
			return "";
		}
	}
	
	
}
