package com.synergy.bqm.controllers;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.synergy.bqm.json.CheckListServiceDTO;
import com.synergy.bqm.json.CheckListTypeDTO;
import com.synergy.bqm.models.CheckListType;
import com.synergy.bqm.models.ChecklistService;
import com.synergy.bqm.models.Client;
import com.synergy.bqm.models.Department;
import com.synergy.bqm.models.FolderTemplateDeptMapping;
import com.synergy.bqm.models.User;
import com.synergy.bqm.models.WorkflowDTO;
import com.synergy.bqm.models.WorkflowType;
import com.synergy.bqm.services.CheckListServicesService;
import com.synergy.bqm.services.CheckListTypeService;
import com.synergy.bqm.services.ClientService;
import com.synergy.bqm.services.FolderTemplateDeptMappingService;
import com.synergy.bqm.services.ProjectMemberService;
import com.synergy.bqm.services.ProjectStageService;
import com.synergy.bqm.services.ProjectStatusService;
import com.synergy.bqm.services.ProjectTypeService;
import com.synergy.bqm.services.QuestionOptionService;
import com.synergy.bqm.services.RolesService;
import com.synergy.bqm.services.UserService;
import com.synergy.bqm.services.WorkflowTypeService;

@RestController
@RequestMapping("/api/buildingLookUps")
public class BuildingLookUpController {

	@Autowired
	ProjectTypeService projectTypeService;

	@Autowired
	ProjectStageService projectStageService;

	@Autowired
	RolesService rolesService;

	@Autowired
	UserService userService;

	@Autowired
	ProjectStatusService projectStatusService;

	@Autowired
	ClientService clientService;

	@Autowired
	QuestionOptionService questionOptionService;

	@Autowired
	ProjectMemberService projectMemberService;

	@Autowired
	CheckListTypeService checkListTypeService;

	@Autowired
	CheckListServicesService checkListServicesService;

	@Autowired
	FolderTemplateDeptMappingService folderTemplateDeptMappingService;

	@Autowired
	WorkflowTypeService workflowTypeService;

	/*
	 * Get All RoleNames
	 */
	@RequestMapping(value = "/roleNames", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getAllRoleNames() {
		return rolesService.getRoleNames();

	}

	/**
	 * Get All Project Status
	 */
	@RequestMapping(value = "/projectStatus", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getAllProjectStatus() {
		return projectStatusService.getprojectStatusNames();

	}

	/*
	 * Get All Project Status
	 */
	@RequestMapping(value = "/projectStages", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getAllProjectStages() {
		return projectStageService.getprojectStageNamesList();

	}

	/**
	 * Get All users Names
	 */

	@RequestMapping(value = "/findAllUsers", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<User> findAllUsers() {
		return userService.findAllUsers();
	}

	/**
	 * Get Project Manager Names
	 */

	@RequestMapping(value = "/projectManager", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<User> getUserNameList() {
		return userService.getUserNameList();
	}

	/**
	 * Get All Client Names
	 */

	@RequestMapping(value = "/findAllClients", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Client> findAllClients() {
		return clientService.findAllClients();
	}

	/**
	 * Get Client Names
	 */

	@RequestMapping(value = "/clientNames", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getClientNameList() {
		return clientService.getClientNameList();
	}

	/*
	 * Create Client
	 */
	@RequestMapping(value = "/createClient", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Client createClient(@RequestBody Client client) {
		return clientService.createClients(client);
	}

	/*
	 * Update Client
	 */
	@RequestMapping(value = "/updateClient", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Client updateClient(@RequestBody Client client) {
		return clientService.upDateClient(client);
	}

	/*
	 * Get ClientInfo By Id
	 */
	@RequestMapping(value = "clientInfoByClientId/{clientId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Client getClientInfoByClientId(@PathVariable("clientId") Integer clientId) {
		return clientService.getClientInfoByClientId(clientId);

	}

	/*
	 * Delete Client By Id
	 */
	@RequestMapping(value = "deleteClientById/{clientId}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void deleteClientById(@PathVariable("clientId") Integer clientId) {
		clientService.deleteClientInfo(clientId);
	}

	/*
	 * Upload Logo for Client
	 */
	@RequestMapping(value = "/upLoadLogo", method = RequestMethod.POST, produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public void uploadLogo(@RequestParam("Id") Integer Id, @RequestParam("file") MultipartFile logo)
			throws IOException {
		clientService.uploadLogo(Id, logo);

	}

	/*
	 * Get Client Logo Info By Id
	 */
	@RequestMapping(value = "/getLogoById/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void getLogoAsByteArraybyId(@PathVariable("Id") Integer clientId, HttpServletResponse response)
			throws IOException {

		Client client = clientService.getClientInfoByClientId(clientId);
		if (client == null || client.getLogo() == null) {
			return;

		}
		response.setContentType("image/jpg");
		BufferedImage imageRead = ImageIO.read(new ByteArrayInputStream(client.getLogo()));
		ImageIO.write(imageRead, "jpg", response.getOutputStream());
	}

	@RequestMapping(value = "getQuestionTypes", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public HashMap<String, List<String>> getQuestionType() {
		HashMap<String, List<String>> map = new HashMap<>();

		List<String> questionOption = questionOptionService.getQuestionTypes();
		for (String option : questionOption) {
			List<String> questionOptions = questionOptionService.getQuestionOptionByQuestionType(option);
			map.put(option, questionOptions);
		}
		map.put("text", null);
		map.put("info", null);
		return map;
	}

	/*
	 * Get TeamMemberMails By ProjectId
	 */

	@RequestMapping(value = "getTeamMemberMails/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getmails(@PathVariable("projectId") Integer projectId) {
		List<Long> userIds = projectMemberService.getUserIdsByProjectId(projectId);
		return userService.getMailIdsByUserIds(userIds);
	}

	/*
	 * Get All CheckListType
	 */
	@RequestMapping(value = "getAllCheckListTypes", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<CheckListType> getAllCheckListTypes() {
		return checkListTypeService.getAllChecklistType();

	}

	/*
	 * Create or UpdateCheckListType By Passing CheckListDTO
	 */
	@RequestMapping(value = "createAndUpdateChecklisttypes", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createAndUpdateChecklisttypes(@RequestBody CheckListTypeDTO checkListTypeDTO) {
		checkListTypeService.createAndUpdateChecklisttypes(checkListTypeDTO);
	}

	@RequestMapping(value = "getAllCheckListServices", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ChecklistService> getAllCheckListServices() {
		return checkListServicesService.getAllChecklistType();

	}

	@RequestMapping(value = "createOrUpdateCheckListServices", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createOrUpdateCheckListServices(@RequestBody CheckListServiceDTO checkListServiceDTO) {
		checkListServicesService.createAndUpdateChecklistService(checkListServiceDTO);
	}

	@RequestMapping(value = "createFolderTemplateMapping/{templateId}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createFolderTemplateMapping(@PathVariable("templateId") Integer templateId,
			@RequestBody List<Department> departments) {
		List<FolderTemplateDeptMapping> folderTemplateDeptMapping = new ArrayList<>();
		for (Department department : departments) {
			if(department.isSelectedDept()){
				FolderTemplateDeptMapping deptMapping = new FolderTemplateDeptMapping();
				deptMapping.setFolderTemplateId(templateId);
				deptMapping.setDepartmentId(department.getDepartmentId());
				folderTemplateDeptMapping.add(deptMapping);
			}
		}
		folderTemplateDeptMappingService.createFolderTemplateMapping(folderTemplateDeptMapping,templateId);
	}

	
	

	@RequestMapping(value = "/workflowTypes", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getWorkflowTypes() {
		return workflowTypeService.getWorkflowTypes();

	}

	@RequestMapping(value = "subTypesByTypes", method = RequestMethod.POST, produces = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<String> getSubTypesByTypes(@RequestParam("type") String type) {
		return workflowTypeService.getSubTypesByTypes(type);

	}

	// get details of subtypes by  Workflowtype

	@RequestMapping(value = "getSubTypesByWorkflowType", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<WorkflowType> getSubTypesByWorkflowType(@RequestParam("workflowType") String workflowType) {
		return workflowTypeService.getSubTypesByWorkflowType(workflowType);
	}


	/*
	 * Create Or Update WorkflowTypes
	 */
	@RequestMapping(value = "/createOrUpdateWorkflowTypes", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createOrUpdateWorkflowTypes(@RequestBody WorkflowDTO workflowTypeDTO) {
		workflowTypeService.createOrUpdateWorkflowTypes(workflowTypeDTO);
	}
	// Delete  Workflow SubType
	@RequestMapping(value = "deleteWorkflowSubType", method = RequestMethod.POST, produces = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public void deleteWorkflowSubType(@RequestParam("Id") Integer Id) {
		workflowTypeService.deleteWorkflowSubType(Id);
	}






}