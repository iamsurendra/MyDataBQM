package com.synergy.bqm.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.synergy.bqm.models.Vendor;
import com.synergy.bqm.models.VendorServices;
import com.synergy.bqm.services.VendorService;
import com.synergy.bqm.services.VendorServicesService;

@RestController
@RequestMapping("/api/vendorServices")
public class VendorServicesController {

	@Autowired
	VendorServicesService vendorServicesService;

	@Autowired
	VendorService vendorServices;

	@RequestMapping(value = "/findAllVendorServices", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<VendorServices> findAllVendorServices() {
		return vendorServicesService.getAllVendorServices();

	}

	@RequestMapping(value = "/createOrUpdateOrDeleteVendorServices", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createOrUpdateOrDeleteVendorService(@RequestBody List<VendorServices> vendorServices) {
		vendorServicesService.createOrUpdateOrDeleteVendorService(vendorServices);
	}

	@RequestMapping(value = "/findAllVendor", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Vendor> findAllVendors() {
		return vendorServices.findAllVendors();

	}

	@RequestMapping(value = "/createVendor", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createVendor(@RequestBody Vendor vendor) {
		vendorServices.createVendor(vendor);
		
	}

	@RequestMapping(value = "/updateVendor", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void UpdateVendor(@RequestBody Vendor vendor) {
		vendorServices.updateVendor(vendor);
	}

	@RequestMapping(value = "deleteVendor/{vendorId}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void DeleteVendor(@PathVariable("vendorId") Long vendorId) {
		vendorServices.deleteVendor(vendorId);
	}

	@RequestMapping(value = "vendorInfoByVendorId/{vendorId}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Vendor getvendorInfoByVendorId(@PathVariable("vendorId") Long vendorId) {
		return vendorServices.getvendorByVendorId(vendorId);

	}

}
