package com.synergy.bqm.repositories;



import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.Department;
@Repository
public class DepartmentDAOImpl extends BaseDAOImpl<Department, Integer>implements DepartmentDAO {

	public DepartmentDAOImpl() {
		super(Department.class);
		// TODO Auto-generated constructor stub
	}
	
	public List<String> getDepartmentNames() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Department> root = criteriaQuery.from(Department.class);
		criteriaQuery.select(root.get("departmentName")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
	public List<Department> getDepartmentInfoById(List<Integer> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Department> criteriaQuery = builder.createQuery(Department.class);
		Root<Department> root = criteriaQuery.from(Department.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where((builder.in(root.get("departmentId")).value(Ids)));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
