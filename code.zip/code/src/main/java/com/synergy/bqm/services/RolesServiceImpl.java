package com.synergy.bqm.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.guvvala.framework.errorHandler.AppException;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.json.MenuActionDTO;
import com.synergy.bqm.json.RoleActionsDTO;
import com.synergy.bqm.models.Role;
import com.synergy.bqm.models.RoleActions;
import com.synergy.bqm.models.User;
import com.synergy.bqm.repositories.ProjectMemberDAO;
import com.synergy.bqm.repositories.RoleActionDAO;
import com.synergy.bqm.repositories.RolesDAO;
import com.synergy.bqm.repositories.UserDAO;
import com.synergy.bqm.repositories.UserRoleMappingDAO;

@Service("rolesService")
public class RolesServiceImpl implements RolesService {

	@Autowired
	UserDAO userDAO;

	@Autowired
	RolesDAO rolesDAO;

	@Autowired
	UserRoleMappingDAO userRoleMappingDAO;

	@Autowired
	RoleActionDAO roleActionDAO;

	@Autowired
	ProjectMemberDAO projectMemberDAO;

	@Transactional
	public void updateRoleJson(Integer roleId, List<RoleActionsDTO> roleActionsDTOs) {
		Role role = rolesDAO.findOne(roleId);
		StringBuffer jsonInString = new StringBuffer();

		for (RoleActionsDTO actionsDTO : roleActionsDTOs) {
			ObjectMapper mapper = new ObjectMapper();
			try {
				String json = mapper.writeValueAsString(actionsDTO);
				if (jsonInString.length() == 0) {
					jsonInString.append(json);
				} else {
					jsonInString.append("+").append(json);
				}
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		}
		role.setRoleJson(jsonInString.toString());
		rolesDAO.update(role);
	}

	@Transactional
	public List<String> getRoleNames() {
		return rolesDAO.getRoleNames();
	}

	@Transactional
	public List<Role> findAllRoles() {
		return rolesDAO.findAll();
	}

	@Transactional
	public List<Role> findAllRolesWithRights() {
		return rolesDAO.findAllRoles();
	}

	@Transactional
	public void createRole(String name) {
		if (rolesDAO.getRoleNames().contains(name)) {
			throw new AppException(MessagesEnum.DUPLICATE_ROLE_NAME);
		}
		Role role = new Role();
		role.setRoleName(name);
		rolesDAO.create(role);
	}

	@Transactional
	public void updateRole(Role role) {
		rolesDAO.update(role);
	}

	@Transactional
	public List<RoleActionsDTO> getRoleJson(Integer projectId, Integer userId)
			throws JsonParseException, JsonMappingException, IOException {
		User user = userDAO.findOne(userId.longValue());

		// Allowing AdminUser to get All Rights
		if (user.getAdmin() != null && user.getAdmin()) {
			return getRoles(true);
		}

		List<Integer> roleIds = projectMemberDAO.getRoleIdsByProjectIdsAndUserIds(projectId, userId);
		List<Role> roles = rolesDAO.getRoleInfoById(roleIds);
		List<RoleActionsDTO> actionsDTOs = new ArrayList<>();
		for (Role role : roles) {
			if (role.getRoleJson() == null || role.getRoleJson().isEmpty()) {
				throw new AppException(MessagesEnum.ACCESS_DENIED);
			}
			actionsDTOs.addAll(getRoleActionsByString(role));

		}

		return actionsDTOs;
	}

	private List<RoleActionsDTO> getRoleActionsByString(Role role) {
		String[] rolejson = role.getRoleJson().split("\\+");

		List<RoleActionsDTO> actionsDTOs = new ArrayList<>();

		for (String string : rolejson) {
			ObjectMapper objectMapper = new ObjectMapper();
			RoleActionsDTO actionsDTO = new RoleActionsDTO();
			try {
				actionsDTO = objectMapper.readValue(string, RoleActionsDTO.class);
			} catch (IOException e) {
				e.printStackTrace();
			}
			actionsDTOs.add(actionsDTO);
		}
		return actionsDTOs;

	}

	@Transactional
	public void deleteRoleById(Integer Id) {
		Role deleteRole = rolesDAO.findOne(Id);
		rolesDAO.delete(deleteRole);

	}

	@Transactional
	public Role findOne(Integer Id) {
		return rolesDAO.findOne(Id);

	}

	@Transactional
	public List<RoleActionsDTO> getMenuActionByRoleId(Integer roleId) {

		Role role = rolesDAO.findOne(roleId);
		if (role.getRoleJson() != null && !role.getRoleJson().isEmpty()) {
			// Getting Existing Rights based on roleId
			List<RoleActionsDTO> exitsingRole = getRoleActionsByString(role);
			// Getting All Rights
			List<RoleActionsDTO> newRights = getRoles(false);
			for (RoleActionsDTO actionsDTO : newRights) {
				for (RoleActionsDTO roleActionsDTO : exitsingRole) {
					if (actionsDTO.getMenuName().equals(roleActionsDTO.getMenuName())) {
						List<MenuActionDTO> name = new ArrayList<>();
						List<MenuActionDTO> oldName = new ArrayList<>();
						// looping to get New Rights
						for (MenuActionDTO actionDTO : actionsDTO.getMenuActions()) {
							MenuActionDTO menuAction = new MenuActionDTO();
							menuAction.setActionName(actionDTO.getActionName());
							menuAction.setActionDescription(actionDTO.getActionDescription());
							name.add(menuAction);
						}
						// looping to get old Rights
						for (MenuActionDTO actionDTO : roleActionsDTO.getMenuActions()) {
							MenuActionDTO menuAction = new MenuActionDTO();
							menuAction.setActionName(actionDTO.getActionName());
							menuAction.setActionDescription(actionDTO.getActionDescription());
							oldName.add(menuAction);
						}
						// Removing Duplicate Rights in List
					
						name.removeAll(oldName);
						if (!name.isEmpty()) {
							// Adding new Rights to Menu
							for (MenuActionDTO action : name) {
								MenuActionDTO actionDTO = new MenuActionDTO();
								actionDTO.setActionName(action.getActionName());
								actionDTO.setActionValue(false);
								actionDTO.setActionDescription(action.getActionDescription());
								roleActionsDTO.getMenuActions().add(actionDTO);
							}
						}
					}

				}
			}
			return exitsingRole;
		} else {
			return getRoles(false);
		}

	}

	private List<RoleActionsDTO> getRoles(Boolean actionType) {
		// get list of role actions
		List<RoleActions> roleActionList = roleActionDAO.findAll();

		// generating roleAction map using role action list
		Map<String, LinkedHashMap<String, String>> roleActionsMap = new LinkedHashMap<String, LinkedHashMap<String, String>>();
		for (RoleActions roleActions : roleActionList) {
			if (roleActionsMap.containsKey(roleActions.getType())) {
				roleActionsMap.get(roleActions.getType()).put(roleActions.getAction(), roleActions.getDescrition());
			} else {
				LinkedHashMap<String, String> hashMap = new LinkedHashMap<>();
				hashMap.put(roleActions.getAction(), roleActions.getDescrition());
				roleActionsMap.put(roleActions.getType(), hashMap);
			}
		}
		// generating role actionDto list using role action map
		List<RoleActionsDTO> roleActionDTOList = new ArrayList<>();
		for (Entry<String, LinkedHashMap<String, String>> roleActions : roleActionsMap.entrySet()) {
			RoleActionsDTO roleAction = new RoleActionsDTO();
			roleAction.setMenuName(roleActions.getKey());
			List<MenuActionDTO> menuActions = new ArrayList<>();
			for (Entry<String, String> action : roleActions.getValue().entrySet()) {
				MenuActionDTO menuAction = new MenuActionDTO();
				menuAction.setActionName(action.getKey());
				menuAction.setActionDescription(action.getValue());
				menuAction.setActionValue(actionType);
				menuActions.add(menuAction);
			}
			roleAction.setMenuActions(menuActions);
			roleActionDTOList.add(roleAction);
		}
		return roleActionDTOList;

	}

}
