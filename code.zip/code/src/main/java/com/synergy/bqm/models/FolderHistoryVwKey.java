package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class FolderHistoryVwKey implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Column(name = "parent_folder_id")
	private Long parentFolderId;
	
	@Column(name = "REVISION_TYPE")
	private Long revisionType;
	
	@Column(name = "LAST_UPD_DT")
	private Date lastUpdateDt;

	
	//getters and setters
	
	public Long getParentFolderId() {
		return parentFolderId;
	}

	public void setParentFolderId(Long parentFolderId) {
		this.parentFolderId = parentFolderId;
	}

	public Long getRevisionType() {
		return revisionType;
	}

	public void setRevisionType(Long revisionType) {
		this.revisionType = revisionType;
	}

	public Date getLastUpdateDt() {
		return lastUpdateDt;
	}

	public void setLastUpdateDt(Date lastUpdateDt) {
		this.lastUpdateDt = lastUpdateDt;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((parentFolderId == null) ? 0 : parentFolderId.hashCode());
		result = prime * result + ((lastUpdateDt == null) ? 0 : lastUpdateDt.hashCode());
		result = prime * result + ((revisionType == null) ? 0 : revisionType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FolderHistoryVwKey other = (FolderHistoryVwKey) obj;
		if (parentFolderId == null) {
			if (other.parentFolderId != null)
				return false;
		} else if (!parentFolderId.equals(other.parentFolderId))
			return false;
		if (lastUpdateDt == null) {
			if (other.lastUpdateDt != null)
				return false;
		} else if (!lastUpdateDt.equals(other.lastUpdateDt))
			return false;
		if (revisionType == null) {
			if (other.revisionType != null)
				return false;
		} else if (!revisionType.equals(other.revisionType))
			return false;
		return true;
	}
	
	
	
}
