package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.ActivityWorkflowMapping;

@Repository
public class ActivityWorkflowMappingDAOImpl extends BaseDAOImpl<ActivityWorkflowMapping, Integer>
		implements ActivityWorkflowMappingDAO {

	public ActivityWorkflowMappingDAOImpl() {
		super(ActivityWorkflowMapping.class);

	}

	public String getChecklistId(Integer indexId, Integer stateId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);
		Root<ActivityWorkflowMapping> root = criteriaQuery.from(ActivityWorkflowMapping.class);
		criteriaQuery.select(root.get("checklistId"));
		criteriaQuery.where(
				builder.and(builder.equal(root.get("indexId"), indexId), builder.equal(root.get("stateId"), stateId)));
		List<String> states = entityManager.createQuery(criteriaQuery).getResultList();
		if (!states.isEmpty()) {
			return states.get(0);
		}
		return null;

	}

	public ActivityWorkflowMapping getActivityWorkflowMapping(Integer indexId, Integer stateId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ActivityWorkflowMapping> criteriaQuery = builder.createQuery(ActivityWorkflowMapping.class);
		Root<ActivityWorkflowMapping> root = criteriaQuery.from(ActivityWorkflowMapping.class);
		criteriaQuery.select(root);
		criteriaQuery.where(
				builder.and(builder.equal(root.get("indexId"), indexId), builder.equal(root.get("stateId"), stateId)));
		List<ActivityWorkflowMapping> states = entityManager.createQuery(criteriaQuery).getResultList();
		if (!states.isEmpty()) {
			return states.get(0);
		}
		return null;

	}

	public ActivityWorkflowMapping getActivityWorkflowMappingByChecklistId(String checklistId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ActivityWorkflowMapping> criteriaQuery = builder.createQuery(ActivityWorkflowMapping.class);
		Root<ActivityWorkflowMapping> root = criteriaQuery.from(ActivityWorkflowMapping.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.equal(root.get("checklistId"), checklistId));
		List<ActivityWorkflowMapping> states = entityManager.createQuery(criteriaQuery).getResultList();
		if (!states.isEmpty()) {
			return states.get(0);
		}
		return null;

	}

	public List<ActivityWorkflowMapping> getActivityWorkflowMappingObjListByIndexId(Integer indexId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ActivityWorkflowMapping> criteriaQuery = builder.createQuery(ActivityWorkflowMapping.class);
		Root<ActivityWorkflowMapping> root = criteriaQuery.from(ActivityWorkflowMapping.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(builder.equal(root.get("indexId"), indexId)));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
}
