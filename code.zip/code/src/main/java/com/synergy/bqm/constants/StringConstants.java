package com.synergy.bqm.constants;

public class StringConstants {

	public static final String BLANK_SPACE = " ";
	public static final String EMPTY_STRING = "";
	public static final String AMPERSAND = "&";
	public static final String INTERSECT = "Intersect";
	public static final String HYPHEN = "-";
}
