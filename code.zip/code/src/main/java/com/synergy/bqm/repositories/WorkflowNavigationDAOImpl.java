package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.WorkflowNavigation;
import com.synergy.bqm.models.WorkflowNavigationKey;
@Repository
public class WorkflowNavigationDAOImpl extends BaseDAOImpl<WorkflowNavigation, WorkflowNavigationKey>implements  WorkflowNavigationDAO{

	public WorkflowNavigationDAOImpl() {
		super(WorkflowNavigation.class);
		// TODO Auto-generated constructor stub
	}
	
	
	
	public List<WorkflowNavigation> getworkFlowNavigationBysourceId(Integer sourceId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<WorkflowNavigation> criteriaQuery = builder.createQuery(WorkflowNavigation.class);
		Root<WorkflowNavigation> root = criteriaQuery.from(WorkflowNavigation.class);
		criteriaQuery.select(root)
				.where(builder.equal(root.get("workflowNavigationKey").get("workflowStateId"), sourceId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	
	public List<Integer> getworkFlowNavigationIdsBysourceId(Integer sourceId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<WorkflowNavigation> root = criteriaQuery.from(WorkflowNavigation.class);
		criteriaQuery.select(root.get("workflowNavigationKey").get("nextWorkflowStateId"))
				.where(builder.equal(root.get("workflowNavigationKey").get("workflowStateId"), sourceId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

}
