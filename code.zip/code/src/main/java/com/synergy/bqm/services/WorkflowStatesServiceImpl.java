package com.synergy.bqm.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.models.Workflow;
import com.synergy.bqm.models.WorkflowNavigation;
import com.synergy.bqm.models.WorkflowNavigationKey;
import com.synergy.bqm.models.WorkflowStates;
import com.synergy.bqm.mongoRepositories.CheckListTemplateRepository;
import com.synergy.bqm.mongoRepositories.DocumentChecklistRepository;
import com.synergy.bqm.repositories.QuestionOptionDAO;
import com.synergy.bqm.repositories.WorkFlowDAO;
import com.synergy.bqm.repositories.WorkflowNavigationDAO;
import com.synergy.bqm.repositories.WorkflowStatesDAO;

@Service
public class WorkflowStatesServiceImpl implements WorkflowStatesService {
	@Autowired
	WorkflowStatesDAO workflowStatesDAO;

	@Autowired
	WorkFlowDAO workFlowDAO;

	@Autowired
	WorkflowNavigationDAO workflowNavigationDAO;

	@Autowired
	DocumentChecklistRepository documentChecklistRepository;

	@Autowired
	QuestionOptionDAO questionOptionDAO;

	@Autowired
	CheckListTemplateRepository checkListTemplateRepository;

	@Transactional
	public List<WorkflowStates> saveWorkflowStates(Integer workFlowId, List<Integer> deleteStateIdsList,
			List<WorkflowStates> workflowStates) {
		Workflow workflow = workFlowDAO.findOne(workFlowId);
		if (!deleteStateIdsList.isEmpty()) {
			deleteWorkFlowStates(deleteStateIdsList);
		}
		int i = 1;
		for (WorkflowStates workflowState : workflowStates) {
			workflowState.setWorkflow(workflow);
			// workflowState.setSeqId(workflowState.getName().equals("ReCheck")
			// ? -1 : (i));
			workflowState.setSeqId((i));
			if (workflowState.getId() != null && workflowState.getId() != 0) {
				workflowStatesDAO.update(workflowState);
			} else {
				workflowState.setId(null);

				workflowStatesDAO.create(workflowState);
			}
			i++;
		}
		return getWorkflowStates(workFlowId);

	}

	private List<WorkflowStates> getWorkflowStates(Integer workflowId) {

		List<WorkflowStates> workflowStates = workflowStatesDAO.getWorkflowStatesById(workflowId);
		for (WorkflowStates state : workflowStates) {
			List<Integer> navigationIds = workflowNavigationDAO.getworkFlowNavigationIdsBysourceId(state.getId());
			if (!navigationIds.isEmpty()) {
				state.setTargetStates(workflowStatesDAO.getWorkflowStates(navigationIds));
			}
		}
		return workflowStates;

	}

	@Transactional
	public List<WorkflowStates> getWorkflowStatesById(Integer workflowId) {
		return workflowStatesDAO.getWorkflowStatesById(workflowId);
	}

	public void deleteWorkFlowStates(List<Integer> workflowIds) {
		workflowStatesDAO.deleteWorkFlowStatesByIds(workflowIds);

	}

	@Transactional
	public void saveWorkflowNavigation(List<WorkflowStates> workflowStates) {
		for (WorkflowStates states : workflowStates) {

			List<WorkflowNavigation> list = workflowNavigationDAO.getworkFlowNavigationBysourceId(states.getId());
			if (!list.isEmpty()) {
				for (WorkflowNavigation deleteObj : list) {
					if (!workflowStates.contains(deleteObj.getWorkflowNavigationKey().getNextWorkflowStateId())) {
						workflowNavigationDAO.delete(deleteObj);
					}
				}
			}
			if (states.getTargetStates() != null && !states.getTargetStates().isEmpty()) {
				for (WorkflowStates tgtId : states.getTargetStates()) {
					WorkflowNavigation navigation = new WorkflowNavigation();
					WorkflowNavigationKey key = new WorkflowNavigationKey();
					key.setWorkflowStateId(states.getId());
					key.setNextWorkflowStateId(tgtId.getId());
					navigation.setWorkflowNavigationKey(key);

					workflowNavigationDAO.create(navigation);
				}
			}
		}
	}

	@Transactional
	public List<Integer> getTargetIdsByStateId(Integer Id) {
		List<WorkflowNavigation> list = workflowNavigationDAO.getworkFlowNavigationBysourceId(Id);
		List<Integer> listOfTgtIds = list.stream()
				.map((WorkflowNavigation) -> WorkflowNavigation.getWorkflowNavigationKey().getNextWorkflowStateId())
				.collect(Collectors.toList());
		return listOfTgtIds;
	}

}
