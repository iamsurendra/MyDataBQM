package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.json.ProjectTypeDTO;
import com.synergy.bqm.models.ProjectType;

public interface ProjectTypeService {

	public List<String> getprojectTypes();

	public List<String> getSubTypesByTypes(String type);

	public List<ProjectType> getSubTypesByProjectType(String projectType);

	public void createOrUpdateProjectTypes(ProjectTypeDTO projectTypeDTO);

	public void deleteProjectSubType(Integer Id);
}
