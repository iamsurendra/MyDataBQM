package com.synergy.bqm.services;

import java.io.IOException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.guvvala.framework.errorHandler.AppException;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.models.Client;
import com.synergy.bqm.models.Project;
import com.synergy.bqm.repositories.ClientDAO;
import com.synergy.bqm.repositories.ProjectDAO;

@Service("clientService")
public class ClientServiceImpl implements ClientService {

	@Autowired
	ClientDAO clientDAO;
	
	@Autowired
	ProjectDAO projectDAO;

	@Transactional
	public List<String> getClientNameList() {
		return clientDAO.getClientNameList();
	}

	@Transactional
	public List<Client> findAllClients() {
		return clientDAO.findAll();
	}

	@Transactional
	public Client createClients(Client client) {
		Long count=clientDAO.clienttNameExists(client.getClientName());
		if(count>0 || count!=0){
			
			throw new AppException(MessagesEnum.CLIENT_NAME_EXIST);
		}
		return clientDAO.create(client);
	}

	@Transactional
	public Client upDateClient(Client client) {
		return clientDAO.update(client);
	}

	@Transactional
	public void deleteClientInfo(Integer clientId) {
		List<Project> projects = projectDAO.getProjectInfoByClientId(clientId);
		for(Project project:projects){
			project.setProjectClient(null);
			projectDAO.update(project);
		}
		Client client = clientDAO.findOne(clientId);
		clientDAO.delete(client);
	}

	@Transactional
	public Client getClientInfoByClientId(Integer clientId) {
		return clientDAO.getClientInfoByClientId(clientId);
	}

	@Transactional
	public void uploadLogo(Integer Id, MultipartFile logo) throws IOException {
		Client client = clientDAO.findOne(Id);
		client.setLogo(logo.getBytes());
		clientDAO.update(client);

	}

}
