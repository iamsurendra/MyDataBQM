package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.ProjectHierarchy;

public interface ProjectHierarchyService {

	List<ProjectHierarchy> createProjectHierarchy(ProjectHierarchy project);

	ProjectHierarchy getProjectHierarchyByHierarchyId(Integer id);

	List<ProjectHierarchy> getProjectHierarchyByProjectId(Integer projectId);
	
	public void deleteHierarchyById(Integer Id);
	
	public List<String> getHierarchyList(Integer hierarchyId);
	
	public void updateHierarchy(ProjectHierarchy projectHierarchy);
	

}
