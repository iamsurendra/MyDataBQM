package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.ActivityHistory;

public interface ActivityHistoryDAO extends BaseDAO<ActivityHistory, Integer>{

	public List<ActivityHistory> getActivityHistoryByIndexId(Integer  indexId);
	
	
}
