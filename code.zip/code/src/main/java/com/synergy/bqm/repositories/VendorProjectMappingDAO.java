package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.VendorProjectMapping;

public interface VendorProjectMappingDAO extends BaseDAO<VendorProjectMapping, Integer>{
	
	public List<VendorProjectMapping> getVendorProjectMappingInfoById(List<Long> Ids);
	
	public List<VendorProjectMapping> getVendorProjectMappingInfoByVendorId(Long Id);
	
	public List<VendorProjectMapping> getVendorProjectMappingInfoByServiceId(List<Long> Id);
}
