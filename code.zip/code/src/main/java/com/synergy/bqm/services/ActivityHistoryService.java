package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.ActivityHistory;

public interface ActivityHistoryService {

	
	public List<ActivityHistory> getActivityHistoryByIndexId(Integer indexId);
	
	public void createActivityHistory(ActivityHistory activityHistory);
}
