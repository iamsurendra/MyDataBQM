package com.synergy.bqm.mongoRepositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.synergy.bqm.models.User;



public interface UserRepository extends MongoRepository<User, String> {

}