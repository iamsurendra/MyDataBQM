package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.FolderDocument;

public interface FolderDocumentDAO extends BaseDAO<FolderDocument, Integer> {

	public Long checkDocumentNameExisit(Integer documentfolderid, String documentName, Double version);

	public FolderDocument getfolderDocumentObjcet(Integer documentfolderid, String documentName);
	
	List<FolderDocument> getFolderDocumentInfo(Integer Id);
	
	public FolderDocument getlistOfDocumentUrls(Integer Ids);
	
	public List<String> getListOfDocumentIds(List<Integer> Ids);
	
	public List<Double> getVersion(Integer documentfolderid, String documentName);
	
	public List<FolderDocument> listOfFolderDocuments(Integer documentfolderid, String documentName);
	
	public List<Integer> getFolderDocumentIds(Integer Id);

}
