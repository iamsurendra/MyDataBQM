package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.ActivityTypes;
@Repository
public class ActivityTypesDAOImpl extends BaseDAOImpl<ActivityTypes, Integer>implements ActivityTypesDAO {

	public ActivityTypesDAOImpl() {
		super(ActivityTypes.class);
		// TODO Auto-generated constructor stub
	}
	
	
	public List<ActivityTypes> getActivityTypesById(List<Integer> Ids) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ActivityTypes> criteriaQuery = criteriaBuilder.createQuery(ActivityTypes.class);
		Root<ActivityTypes> root = criteriaQuery.from(ActivityTypes.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.in(root.get("id")).value(Ids));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	

	public void deleteActivitesByIds(List<Integer> Ids) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaDelete delete = criteriaBuilder.createCriteriaDelete(ActivityTypes.class);
		Root root = delete.from(ActivityTypes.class);
		delete.where(criteriaBuilder.in(root.get("id")).value(Ids));
		Query query = entityManager.createQuery(delete);
		query.executeUpdate();
	}

}
