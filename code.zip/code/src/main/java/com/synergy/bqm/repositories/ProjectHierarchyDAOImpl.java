package com.synergy.bqm.repositories;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.ProjectHierarchy;

@Repository
public class ProjectHierarchyDAOImpl extends BaseDAOImpl<ProjectHierarchy, Integer> implements ProjectHierarchyDAO {

	public ProjectHierarchyDAOImpl() {
		super(ProjectHierarchy.class);
		// TODO Auto-generated constructor stub
	}

	public List<ProjectHierarchy> getProjectHierarchyInfoByProjectId(Integer projectId) {
		TypedQuery<ProjectHierarchy> query = entityManager
				.createQuery("SELECT f from ProjectHierarchy f where project_id ='" + projectId
						+ "' and hierarchy_parent_id is null  ", ProjectHierarchy.class);

		return query.getResultList();
	}

	public List<ProjectHierarchy> findExistingHierarchyName(String name, Integer id, Integer projectId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ProjectHierarchy> criteriaQuery = criteriaBuilder.createQuery(ProjectHierarchy.class);
		Root<ProjectHierarchy> root = criteriaQuery.from(ProjectHierarchy.class);
		List<Predicate> predicates = getPredicates(name, id, projectId, criteriaBuilder, root);
		Predicate[] conditions = predicates.toArray(new Predicate[] {});
		criteriaQuery.select(root).where(criteriaBuilder.and(conditions));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	private List<Predicate> getPredicates(String name, Integer id, Integer projectId, CriteriaBuilder criteriaBuilder,
			Root<ProjectHierarchy> root) {
		List<Predicate> predicates = new ArrayList<>();

		predicates.add(criteriaBuilder.equal(root.get("hierarchyName"), name));

		predicates.add(criteriaBuilder.equal(root.get("project").get("projectId"), projectId));
		if (id != null) {
			predicates.add(criteriaBuilder.equal(root.get("projectHierarchy").get("projectHierarchyId"), id));
		} else {
			predicates.add(criteriaBuilder.isNull(root.get("projectHierarchy").get("projectHierarchyId")));

		}
		return predicates;

	}

	public List<ProjectHierarchy> getHierarchyIfo(String name, Integer id, Integer projectId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ProjectHierarchy> criteriaQuery = criteriaBuilder.createQuery(ProjectHierarchy.class);
		Root<ProjectHierarchy> root = criteriaQuery.from(ProjectHierarchy.class);
		List<Predicate> predicates = getPredicatesforHierarchyInfo(name, id, projectId, criteriaBuilder, root);
		Predicate[] conditions = predicates.toArray(new Predicate[] {});
		criteriaQuery.select(root).where(criteriaBuilder.and(conditions));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	private List<Predicate> getPredicatesforHierarchyInfo(String name, Integer id, Integer projectId,
			CriteriaBuilder criteriaBuilder, Root<ProjectHierarchy> root) {
		List<Predicate> predicates = new ArrayList<>();

		predicates.add(criteriaBuilder.equal(root.get("hierarchyType"), name));

		predicates.add(criteriaBuilder.equal(root.get("project").get("projectId"), projectId));

		if (id != null) {
			predicates.add(criteriaBuilder.equal(root.get("projectHierarchy").get("projectHierarchyId"), id));
		} else {
			predicates.add(criteriaBuilder.isNull(root.get("projectHierarchy").get("projectHierarchyId")));

		}
		return predicates;

	}

}
