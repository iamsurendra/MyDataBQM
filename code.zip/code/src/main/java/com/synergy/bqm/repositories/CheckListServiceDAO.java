package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.ChecklistService;

public interface CheckListServiceDAO extends BaseDAO<ChecklistService, Integer>{
	
	public List<String> getCheckListServices();
	
	public List<ChecklistService> getCheckListServicesInfoById(List<Integer> Ids);

}
