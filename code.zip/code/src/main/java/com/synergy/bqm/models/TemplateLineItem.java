package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.guvvala.framework.model.BaseModel;

/**
 * The persistent class for the template_line_item database table.
 * 
 */
@Entity
@Table(name = "template_line_item")
@NamedQuery(name = "TemplateLineItem.findAll", query = "SELECT t FROM TemplateLineItem t")
public class TemplateLineItem extends BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "template_line_item_id")
	private int templateLineItemId;

	@Column(name = "template_line_item_image")
	private String templateLineItemImage;

	@Column(name = "template_line_item_info")
	private String templateLineItemInfo;

	@Column(name = "template_line_item_label")
	private String templateLineItemLabel;

	@Column(name = "template_line_item_notes")
	private String templateLineItemNotes;

	@Column(name = "template_line_item_result")
	private String templateLineItemResult;

	@Column(name = "template_line_item_type")
	private String templateLineItemType;

	// bi-directional many-to-one association to Template
	@ManyToOne
	@JoinColumn(name = "template_line_item_parent_id")
	private Template template;

	// bi-directional many-to-one association to TemplateLineItem
	@ManyToOne
	@JoinColumn(name = "template_line_item_parent_line_item_id")
	private TemplateLineItem templateLineItem;

	// bi-directional many-to-one association to TemplateLineItem
	@OneToMany(mappedBy = "templateLineItem")
	private List<TemplateLineItem> templateLineItems;

	public TemplateLineItem() {
	}

	public int getTemplateLineItemId() {
		return this.templateLineItemId;
	}

	public void setTemplateLineItemId(int templateLineItemId) {
		this.templateLineItemId = templateLineItemId;
	}

	public String getTemplateLineItemImage() {
		return this.templateLineItemImage;
	}

	public void setTemplateLineItemImage(String templateLineItemImage) {
		this.templateLineItemImage = templateLineItemImage;
	}

	public String getTemplateLineItemInfo() {
		return this.templateLineItemInfo;
	}

	public void setTemplateLineItemInfo(String templateLineItemInfo) {
		this.templateLineItemInfo = templateLineItemInfo;
	}

	public String getTemplateLineItemLabel() {
		return this.templateLineItemLabel;
	}

	public void setTemplateLineItemLabel(String templateLineItemLabel) {
		this.templateLineItemLabel = templateLineItemLabel;
	}

	public String getTemplateLineItemNotes() {
		return this.templateLineItemNotes;
	}

	public void setTemplateLineItemNotes(String templateLineItemNotes) {
		this.templateLineItemNotes = templateLineItemNotes;
	}

	public String getTemplateLineItemResult() {
		return this.templateLineItemResult;
	}

	public void setTemplateLineItemResult(String templateLineItemResult) {
		this.templateLineItemResult = templateLineItemResult;
	}

	public String getTemplateLineItemType() {
		return this.templateLineItemType;
	}

	public void setTemplateLineItemType(String templateLineItemType) {
		this.templateLineItemType = templateLineItemType;
	}

	public Template getTemplate() {
		return this.template;
	}

	public void setTemplate(Template template) {
		this.template = template;
	}

	public TemplateLineItem getTemplateLineItem() {
		return this.templateLineItem;
	}

	public void setTemplateLineItem(TemplateLineItem templateLineItem) {
		this.templateLineItem = templateLineItem;
	}

	public List<TemplateLineItem> getTemplateLineItems() {
		return this.templateLineItems;
	}

	public void setTemplateLineItems(List<TemplateLineItem> templateLineItems) {
		this.templateLineItems = templateLineItems;
	}

	public TemplateLineItem addTemplateLineItem(TemplateLineItem templateLineItem) {
		getTemplateLineItems().add(templateLineItem);
		templateLineItem.setTemplateLineItem(this);

		return templateLineItem;
	}

	public TemplateLineItem removeTemplateLineItem(TemplateLineItem templateLineItem) {
		getTemplateLineItems().remove(templateLineItem);
		templateLineItem.setTemplateLineItem(null);

		return templateLineItem;
	}

}