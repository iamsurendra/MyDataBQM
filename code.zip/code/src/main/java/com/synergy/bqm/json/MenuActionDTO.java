package com.synergy.bqm.json;

public class MenuActionDTO {

	private String actionName;
	private String actionDescription;

	private Boolean actionValue;

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public Boolean getActionValue() {
		return actionValue;
	}

	public void setActionValue(Boolean actionValue) {
		this.actionValue = actionValue;
	}

	public String getActionDescription() {
		return actionDescription;
	}

	public void setActionDescription(String actionDescription) {
		this.actionDescription = actionDescription;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actionDescription == null) ? 0 : actionDescription.hashCode());
		result = prime * result + ((actionName == null) ? 0 : actionName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MenuActionDTO other = (MenuActionDTO) obj;
		if (actionDescription == null) {
			if (other.actionDescription != null)
				return false;
		} else if (!actionDescription.equals(other.actionDescription))
			return false;
		if (actionName == null) {
			if (other.actionName != null)
				return false;
		} else if (!actionName.equals(other.actionName))
			return false;
		return true;
	}

	
}
