package com.synergy.bqm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.models.FolderHistoryVw;
import com.synergy.bqm.repositories.FolderHistoryVwDAO;

@Service(" FolderHistoryVwService")
public class FolderHistoryVwServiceImpl implements FolderHistoryVwService {

	@Autowired
	FolderHistoryVwDAO folderHistoryVwDAO;

	@Transactional
	@Override
	public List<FolderHistoryVw> getFolderHistoryByFolderId(Integer folderId) {
		
		return folderHistoryVwDAO.getFolderHistoryByFolderId(folderId);
	}
	
	@Transactional
	public List<FolderHistoryVw> getFolderHistoryByParentId(Integer parentId){
		return folderHistoryVwDAO.getFolderHistoryByParentId(parentId);
		
	}
}
