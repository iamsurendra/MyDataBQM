package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.Project;

@Repository
public class ProjectDAOImpl extends BaseDAOImpl<Project, Integer> implements ProjectDAO {

	public ProjectDAOImpl() {
		super(Project.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Project> getAllArchiveProjects(){
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Project> criteriaQuery = criteriaBuilder.createQuery(Project.class);
		Root<Project> root = criteriaQuery.from(Project.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("archive"), 1));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<Project> getProjectInfoByClientId(Integer id){
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Project> criteriaQuery = criteriaBuilder.createQuery(Project.class);
		Root<Project> root = criteriaQuery.from(Project.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("projectClient"), id));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	public String getProjectNameById(Integer id){
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Project> root = criteriaQuery.from(Project.class);
		criteriaQuery.select(root.get("projectName")).where(criteriaBuilder.equal(root.get("projectId"), id));
		return entityManager.createQuery(criteriaQuery).getSingleResult();

	}

	public Long projectNameExists(String projectName){
		TypedQuery<Long> query = entityManager
				.createQuery("select count(*) from Project where projectName = :projectName", Long.class);
		query.setParameter("projectName", projectName);
		return query.getSingleResult();

	}
	
	public Long countOfProjects(){
		TypedQuery<Long> query = entityManager
				.createQuery("select count(*) from Project", Long.class);
		return query.getSingleResult();
	}

	public List<Project> getProjectInfoByStageName(List<String> Names) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Project> criteriaQuery = builder.createQuery(Project.class);
		Root<Project> root = criteriaQuery.from(Project.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(builder.in(root.get("stage")).value(Names));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	public List<Project> getProjectInfoByStatus(List<String> statusNames) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Project> criteriaQuery = builder.createQuery(Project.class);
		Root<Project> root = criteriaQuery.from(Project.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(builder.in(root.get("status")).value(statusNames));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	public List<Project> getProjectInfoByTypes(List<String> types) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Project> criteriaQuery = builder.createQuery(Project.class);
		Root<Project> root = criteriaQuery.from(Project.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(builder.in(root.get("type")).value(types));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
}