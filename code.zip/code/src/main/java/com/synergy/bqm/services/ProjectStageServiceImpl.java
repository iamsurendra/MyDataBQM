package com.synergy.bqm.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synergy.bqm.models.Project;
import com.synergy.bqm.models.ProjectStage;
import com.synergy.bqm.repositories.ProjectDAO;
import com.synergy.bqm.repositories.ProjectStageDAO;

@Service("ProjectStageService")
public class ProjectStageServiceImpl implements ProjectStageService {

	@Autowired
	ProjectStageDAO projectStageDAO;

	@Autowired
	ProjectDAO projectDAO;

	@Override
	@Transactional
	public List<String> getprojectStageNamesList() {
		return projectStageDAO.getprojectStageNamesList();

	}

	@Transactional
	public List<ProjectStage> getAllProjectStages() {
		return projectStageDAO.findAll();

	}

	@Transactional
	public void deleteProjectStage(Integer Id) {
		ProjectStage deletedStage = projectStageDAO.findOne(Id);
		projectStageDAO.delete(deletedStage);
	}

	@Transactional
	public void createOrUpdateProjectStages(List<ProjectStage> projectStages,List<Integer> deletedIds) {
		
		if(!deletedIds.isEmpty()){
			List<String> stages= projectStageDAO.getProjectStageInfoById(deletedIds);
			List<Project> projects = projectDAO.getProjectInfoByStageName(stages);
			for(Project project:projects){
				project.setStage(null);
			}
			for(Integer id:deletedIds){
				deleteProjectStage(id);
			}
		}
		if(!projectStages.isEmpty()){
			for(ProjectStage projectStage:projectStages){
				if(projectStage.getProjectStageId()==null){
					projectStageDAO.create(projectStage);
				}else{
					projectStageDAO.update(projectStage);
				}
			}
		}
	}
}
