package com.synergy.bqm.services;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.mongodb.gridfs.GridFSDBFile;
import com.synergy.bqm.models.Project;

public interface ProjectService {

	Project createProject(Project project);

	Project getProjectByProjectId(Integer projectId);

	List<Project> getAllProjects();

	public void deleteProject(Integer projectId);

	public void updateProject(Project project);

	List<Project> getAllArchiveProjects();

	public void applyTemplateFlagForProject(Integer projectId);

	public void UpdateLogo(MultipartFile file, Integer Id) throws IOException;

	public Project getProjectInfoById(Integer projectId);

	public Long countOfProjects();
	
	public void deleteProjectLogo(Integer projectId);
	
	public GridFSDBFile downloadProjectLogo(Integer projectId);

}