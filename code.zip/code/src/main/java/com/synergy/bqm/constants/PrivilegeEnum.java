package com.synergy.bqm.constants;

public enum PrivilegeEnum {

	READ;
}
