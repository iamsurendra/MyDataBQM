package com.synergy.bqm.json;

import java.util.ArrayList;
import java.util.List;

import com.synergy.bqm.models.FolderDocument;

public class DocumentIndexDTO {

	private List<FolderDocument> indexFiles = new ArrayList<>();

	private List<FolderDocument> nonIndexFiles = new ArrayList<>();

	public List<FolderDocument> getIndexFiles() {
		return indexFiles;
	}

	public void setIndexFiles(List<FolderDocument> indexFiles) {
		this.indexFiles = indexFiles;
	}

	public List<FolderDocument> getNonIndexFiles() {
		return nonIndexFiles;
	}

	public void setNonIndexFiles(List<FolderDocument> nonIndexFiles) {
		this.nonIndexFiles = nonIndexFiles;
	}

}
