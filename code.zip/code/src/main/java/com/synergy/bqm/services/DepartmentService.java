package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.json.DepartmentDTO;
import com.synergy.bqm.models.Department;

public interface DepartmentService {
	public void createDepartment(Department department);

	public List<Department> findAllDepartments();

	public List<String> getAlldepartmentNames();

	public void updateDepartment(Department department);

	public void deleteDepartmentById(Integer Id);
	
	public void createAndUpdateDepartments(DepartmentDTO departmentDTO);
	
	public List<Department> getAllDepartmentsByTemplateId(Integer folderTemplateId);

}
