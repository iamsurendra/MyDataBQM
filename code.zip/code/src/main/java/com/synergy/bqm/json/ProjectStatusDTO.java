package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.ProjectStatus;

public class ProjectStatusDTO {

	List<ProjectStatus> projectStatus;
	
	List<Integer> deletedIds;

	
	//Getters && Setters
	public List<ProjectStatus> getProjectStatus() {
		return projectStatus;
	}

	public void setProjectStatus(List<ProjectStatus> projectStatus) {
		this.projectStatus = projectStatus;
	}

	public List<Integer> getDeletedIds() {
		return deletedIds;
	}

	public void setDeletedIds(List<Integer> deletedIds) {
		this.deletedIds = deletedIds;
	}
	
	
	
	
}
