package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.FolderDepartmentMapping;

@Repository
public class FolderDepartmentMappingDAOImpl extends BaseDAOImpl<FolderDepartmentMapping, Integer> implements FolderDepartmentMappingDAO {

	public FolderDepartmentMappingDAOImpl() {
		super(FolderDepartmentMapping.class);
	}
	
	public List<Integer> getFolderIds(Integer departmentId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = criteriaBuilder.createQuery(Integer.class);
		Root<FolderDepartmentMapping> root = criteriaQuery.from(FolderDepartmentMapping.class);
		criteriaQuery.select(root.get("folderId")).where(criteriaBuilder.equal(root.get("departmentId"), departmentId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public FolderDepartmentMapping getDeletedFolder(Integer folderId,Integer departmentId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderDepartmentMapping> criteriaQuery = criteriaBuilder.createQuery(FolderDepartmentMapping.class);
		Root<FolderDepartmentMapping> root = criteriaQuery.from(FolderDepartmentMapping.class);
		criteriaQuery.select(root).where(criteriaBuilder.and(criteriaBuilder.equal(root.get("folderId"), folderId),criteriaBuilder.equal(root.get("departmentId"), departmentId)));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}
	
	public List<Integer> getDepartmentIds(Integer folderId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = criteriaBuilder.createQuery(Integer.class);
		Root<FolderDepartmentMapping> root = criteriaQuery.from(FolderDepartmentMapping.class);
		criteriaQuery.select(root.get("departmentId")).where(criteriaBuilder.equal(root.get("folderId"), folderId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
}
