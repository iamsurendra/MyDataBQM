package com.synergy.bqm.controllers;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.guvvala.framework.logging.AppLogger;
import com.guvvala.framework.logging.Log;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.synergy.bqm.models.User;
import com.synergy.bqm.services.UserService;

@RestController
@RequestMapping("/api/user")
public class LoginController {

	private static @Log AppLogger logger;

	@Autowired
	UserService userService;

	@Resource(name = "tokenServices")
	ConsumerTokenServices tokenServices;

	/*
	 * Creating New User
	 */
	@RequestMapping(value = "/create", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Integer createUser(@RequestBody User user) {
		return userService.createNewUser(user);
	}

	/*
	 * Retrieving user object by userName
	 */
	@RequestMapping(value = "/{userName}", method = RequestMethod.GET)
	public User getUser(@PathVariable("userName") String userName) {
		return userService.getUserForLogin(userName);
	}

	/*
	 * validating the userName and password
	 */

	@RequestMapping(value = "/validatePassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public User validatePassword() {
		return ThreadLocalUtil.getUser().getUserObject();

	}

	/*
	 * update the password
	 */
	@RequestMapping(value = "/updatePassword", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public void updatePassword(@RequestParam("password") String password, @RequestParam("userName") String userName) {
		userService.resetpwd(password, userName);

	}

	/*
	 * update User profile
	 */
	@RequestMapping(value = "/updateProfile", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateProfile(@RequestBody User user) {
		userService.updateUser(user);

	}

	@RequestMapping(value = "/updateProfileImage", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public void UpdateUserImage(@RequestParam("Id") Integer Id, @RequestParam("file") MultipartFile file)
			throws IOException {
		userService.updateUserImage(Id, file);
	}

	@RequestMapping(value = "/deleteProfileImage/{userId}", method = RequestMethod.GET)
	public void deleteUserImage(@PathVariable("userId") Integer userId) {
		userService.deleteUserImage(userId);
	}

	/*
	 * find all user list for Admin Screen
	 */
	@RequestMapping(value = "/findAlluserList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<User> findAllusers() {
		return userService.findAllUsers();
	}

	@RequestMapping(value = "/findAllNormalUsers", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<User> findAllNormalUsers() {
		return userService.findAllNormalUsers();
	}

	/*
	 * MakeUserActive or InActive
	 */
	@RequestMapping(value = "makeUserActiveOrInActive/{UserId}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Integer makeUserActiveOrInActive(@PathVariable("UserId") Long UserId) {
		return userService.makeUserActiveOrInActive(UserId);
	}

	/*
	 * Get User Info By UserId
	 */
	@RequestMapping(value = "userInfoByUserId/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public User getUserInfoByUserId(@PathVariable("userId") Long userId) {
		return userService.getUserInfoByUserId(userId);
	}

	@RequestMapping(value = "/logout", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void logout(@RequestBody Map<String, String> token) {
		String tokenId = token.get("access_token");
		tokenServices.revokeToken(tokenId);
	}

	@RequestMapping(value = "/UserLockedOrUnlocked/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Integer makeUserLockedOrUnlocked(@PathVariable("userId") Long userId) {
		return userService.makeUserLockedOrUnlocked(userId);
	}
}
