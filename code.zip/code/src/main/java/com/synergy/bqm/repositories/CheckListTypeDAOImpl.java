package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.CheckListType;

@Repository
public class CheckListTypeDAOImpl extends BaseDAOImpl<CheckListType, Integer> implements CheckListTypeDAO {

	public CheckListTypeDAOImpl() {
		super(CheckListType.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<String> getCheckListTypeNames() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<CheckListType> root = criteriaQuery.from(CheckListType.class);
		criteriaQuery.select(root.get("checkListTypeName")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
		
	}

	@Override
	public List<CheckListType> getCheckListTypeInfoById(List<Integer> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CheckListType> criteriaQuery = builder.createQuery(CheckListType.class);
		Root<CheckListType> root = criteriaQuery.from(CheckListType.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where((builder.in(root.get("checkListTypeId")).value(Ids)));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

}
