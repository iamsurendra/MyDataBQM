package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.util.DateUtils;

/**
 * The persistent class for the client database table.
 * 
 */
@Entity
@Table(name = "client")
@NamedQuery(name = "Client.findAll", query = "SELECT c FROM Client c")
public class Client extends BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "client_id")
	private int clientId;

	@Column(name = "client_name")
	private String clientName;

	@Column(name = "client_company")
	private String clientCompany;

	@Column(name = "client_designation")
	private String clientDesignation;

	@Column(name = "client_email")
	private String clientEmail;

	@Column(name = "client_business")
	private String clientBusiness;

	@Column(name = "client_ext_no")
	private String clientExtNo;

	@Column(name = "client_home_contact_no")
	private String clientHomeContactNo;

	@Column(name = "client_mobile_no")
	private String clientMobileNo;

	@Column(name = "client_fax_no")
	private String clientFaxNo;

	@Column(name = "client_address")
	private String clientAddress;

	@Column(name = "client_category")
	private String clientCategory;

	@Transient
	private String clientOfficeContactNo;

	@Transient
	private String createdDt;

	@Transient
	private String updatedDt;

	@Column(name = "client_logo")
	private byte[] logo;

	@Transient
	private String projectMngr;

	public Client() {
	}

	public int getClientId() {
		return clientId;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClientCompany() {
		return clientCompany;
	}

	public void setClientCompany(String clientCompany) {
		this.clientCompany = clientCompany;
	}

	public String getClientDesignation() {
		return clientDesignation;
	}

	public void setClientDesignation(String clientDesignation) {
		this.clientDesignation = clientDesignation;
	}

	public String getClientEmail() {
		return clientEmail;
	}

	public void setClientEmail(String clientEmail) {
		this.clientEmail = clientEmail;
	}

	public String getClientBusiness() {
		return clientBusiness;
	}

	public void setClientBusiness(String clientBusiness) {
		this.clientBusiness = clientBusiness;
	}

	public String getClientExtNo() {
		return clientExtNo;
	}

	public void setClientExtNo(String clientExtNo) {
		this.clientExtNo = clientExtNo;
	}

	public String getClientHomeContactNo() {
		return clientHomeContactNo;
	}

	public void setClientHomeContactNo(String clientHomeContactNo) {
		this.clientHomeContactNo = clientHomeContactNo;
	}

	public String getClientMobileNo() {
		return clientMobileNo;
	}

	public void setClientMobileNo(String clientMobileNo) {
		this.clientMobileNo = clientMobileNo;
	}

	public String getClientFaxNo() {
		return clientFaxNo;
	}

	public void setClientFaxNo(String clientFaxNo) {
		this.clientFaxNo = clientFaxNo;
	}

	public String getClientAddress() {
		return clientAddress;
	}

	public void setClientAddress(String clientAddress) {
		this.clientAddress = clientAddress;
	}

	public String getClientCategory() {
		return clientCategory;
	}

	public void setClientCategory(String clientCategory) {
		this.clientCategory = clientCategory;
	}

	public String getClientOfficeContactNo() {
		return clientOfficeContactNo;
	}

	public void setClientOfficeContactNo(String clientOfficeContactNo) {
		this.clientOfficeContactNo = clientOfficeContactNo;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getProjectMngr() {
		return projectMngr;
	}

	public void setProjectMngr(String projectMngr) {
		this.projectMngr = projectMngr;
	}

	public byte[] getLogo() {
		return logo;
	}

	public void setLogo(byte[] logo) {
		this.logo = logo;
	}

	@PostLoad
	void postload() {
		setCreatedDt(DateUtils.convertToSimpleDateTimeFormat(getCreatedDate()));
		setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(getUpdatedDate()));

	}

}