package com.synergy.bqm.controllers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.synergy.bqm.constants.BqmConstants;
import com.synergy.bqm.constants.MailTemplateEnum;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.constants.PDFTemplateEnum;
import com.synergy.bqm.documents.Checklist;
import com.synergy.bqm.documents.ChecklistTemplate;
import com.synergy.bqm.exporter.PDFExporter;
import com.synergy.bqm.json.CheckListPDFDTO;
import com.synergy.bqm.json.CheckListTemplateTreeDTO;
import com.synergy.bqm.mongoRepositories.CheckListRepository;
import com.synergy.bqm.mongoRepositories.CheckListTemplateRepository;
import com.synergy.bqm.services.CheckListServicesService;
import com.synergy.bqm.services.CheckListTypeService;
import com.synergy.bqm.services.MailService;
import com.synergy.bqm.services.ProjectMemberService;
import com.synergy.bqm.services.UserService;

@RestController
@RequestMapping("/api/checkListTemplate")
public class CheckListTemplateController {

	@Autowired
	CheckListTemplateRepository checkListTemplateRepository;

	@Autowired
	CheckListRepository checkListRepository;

	@Autowired
	private PDFExporter pdfExporter;

	@Autowired
	MailService mailService;

	@Autowired
	ProjectMemberService projectMemberService;

	@Autowired
	UserService userService;

	@Autowired
	CheckListTypeService checkListTypeService;

	@Autowired
	CheckListServicesService checkListServicesService;

	/*
	 * Find All ChecklistTemplates
	 */
	@RequestMapping(value = "/findAllCheckListTemplates", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ChecklistTemplate> findAllchecklist() {
		List<ChecklistTemplate> checkList = checkListTemplateRepository.findAll();
		return checkList;

	}

	/*
	 * Get CheckList Info
	 */
	@RequestMapping(value = "/getChecklistNames", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<CheckListTemplateTreeDTO> getAllCheckListInfo(
			@RequestParam("isRootSelectable") Boolean isRootSelectable,
			@RequestParam(value = "hierarchyId", required = false) Integer herarchyId) {
		List<ChecklistTemplate> checklist = new ArrayList<>();

		// checking is any template is imported into project
		if (herarchyId != null) {
			List<ChecklistTemplate> templateList = checkListTemplateRepository.getChecklistTypeandService();
			// if imported fetching those checklists
			List<Checklist> importedProjectCheckList = checkListRepository.getChecklistByHierarchy(herarchyId);

			/*
			 * List<Checklist> importedProjectCheckList =
			 * checkListRepository.getCheckListByProjectId(projectId);
			 */
			// if any checklist is imported to project removing the
			// corresponding checklist from the template list
			if (!importedProjectCheckList.isEmpty()) {
				for (ChecklistTemplate checklistTemplate : templateList) {
					Boolean isTemplateFound = false;
					for (Checklist importedChecklist : importedProjectCheckList) {
						if (checklistTemplate.getChecklistName().equals(importedChecklist.getChecklistName())
								&& checklistTemplate.getChecklistService()
										.equals(importedChecklist.getChecklistService())
								&& checklistTemplate.getChecklistType().equals(importedChecklist.getChecklistType())) {
							isTemplateFound = true;
						}

					}
					if (!isTemplateFound) {
						checklist.add(checklistTemplate);
					}
				}
			}
			// if imported list is empty adding all templates to the list
			else {
				checklist.addAll(checkListTemplateRepository.getChecklistTypeandService());
			}

		}
		// if project id not provided add all template to the list
		else {
			checklist.addAll(checkListTemplateRepository.getChecklistTypeandService());
		}
		return getChecklist(checklist, isRootSelectable);
	}

	/*
	 * Get All DesignCheckLists 
	 */
	@RequestMapping(value = "/getDesignChecklistNames", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<CheckListTemplateTreeDTO> getAllCheckListInfo(@RequestParam("isRootSelectable") Boolean isRootSelectable) {
		List<ChecklistTemplate> checklist = checkListTemplateRepository.getDesignCheckLists();
		return getChecklist(checklist, isRootSelectable);
	}

	private List<CheckListTemplateTreeDTO> getChecklist(List<ChecklistTemplate> checklist, Boolean isRootSelectable) {
		Map<String, Map<String, List<ChecklistTemplate>>> mainMap = new LinkedHashMap<>();
		for (ChecklistTemplate checklistTemplate : checklist) {
			Map<String, List<ChecklistTemplate>> type = mainMap.get(checklistTemplate.getChecklistService());
			if (type == null) {
				type = new HashMap<>();
			}
			List<ChecklistTemplate> name = type.get(checklistTemplate.getChecklistType());
			if (name == null) {
				name = new ArrayList<>();
			}
			name.add(checklistTemplate);
			type.put(checklistTemplate.getChecklistType(), name);
			mainMap.put(checklistTemplate.getChecklistService(), type);

		}
		// Setting map value to CheckListTemplateTreeDTO
		List<CheckListTemplateTreeDTO> list = new ArrayList<>();
		for (Map.Entry<String, Map<String, List<ChecklistTemplate>>> serviceMap : mainMap.entrySet()) {
			List<String> serviceLevelIds = new ArrayList<>();

			CheckListTemplateTreeDTO serviceDTO = new CheckListTemplateTreeDTO();
			serviceDTO.setLabel(serviceMap.getKey());
			serviceDTO.setLeaf(false);
			serviceDTO.setHierarchyType("SERVICE");
			serviceDTO.setIcon("fa fa-folder");
			serviceDTO.setSelectable(isRootSelectable);
			serviceDTO.setExpanded(true);
			List<CheckListTemplateTreeDTO> typeDTOList = new ArrayList<>();
			for (Map.Entry<String, List<ChecklistTemplate>> typeMap : serviceMap.getValue().entrySet()) {
				CheckListTemplateTreeDTO typeDTO = new CheckListTemplateTreeDTO();
				typeDTO.setLabel(typeMap.getKey());
				typeDTO.setLeaf(false);
				typeDTO.setHierarchyType("TYPE");
				typeDTO.setIcon("fa fa-folder");
				typeDTO.setSelectable(isRootSelectable);
				typeDTO.setExpanded(true);
				typeDTO.setChildren(new ArrayList<>());
				ChecklistTemplate data = new ChecklistTemplate();
				for (ChecklistTemplate template : typeMap.getValue()) {
					serviceLevelIds.add(template.getId());
					data.getDeletedIds().add(template.getId());
					template.getDeletedIds().add(template.getId());
					CheckListTemplateTreeDTO templateDTO = new CheckListTemplateTreeDTO();
					templateDTO.setLabel(template.getChecklistName());
					templateDTO.setData(template);
					templateDTO.setHierarchyType("TEMPLATE");
					templateDTO.setIcon("fa fa-file");
					templateDTO.setLeaf(true);
					templateDTO.setSelectable(true);
					templateDTO.setExpanded(true);
					typeDTO.getChildren().add(templateDTO);
				}
				data.setChecklistService(serviceMap.getKey());
				data.setChecklistType(typeMap.getKey());
				typeDTO.setData(data);
				typeDTOList.add(typeDTO);
			}
			serviceDTO.setChildren(typeDTOList);
			ChecklistTemplate data = new ChecklistTemplate();
			data.setDeletedIds(serviceLevelIds);
			data.setChecklistService(serviceMap.getKey());
			serviceDTO.setData(data);
			list.add(serviceDTO);
		}

		return list;
	}

	/*
	 * Create New Checklist Template
	 */
	@RequestMapping(value = "/createCheckListTemplate", method = RequestMethod.POST)
	public String createCheckListTemplate(@RequestBody ChecklistTemplate checklistTemplate) {
		List<String> checklistTypes = checkListTypeService.getCheckListTypeName();
		//List<String> checkListServices = checkListServicesService.getCheckListServices();
		/*if (!checkListServices.contains(checklistTemplate.getChecklistService())) {
			throw new AppException(MessagesEnum.INVALID_CHECKLIST_SERVICE);

		}*/
		if (!checklistTypes.contains(checklistTemplate.getChecklistType())) {
			throw new AppException(MessagesEnum.INVALID_CHECKLIST_TYPE);

		}
		ChecklistTemplate checkListObj = checkListTemplateRepository.checkDuplicateCheckList(
				checklistTemplate.getChecklistName(), checklistTemplate.getChecklistType(),
				checklistTemplate.getChecklistService());
		if (checkListObj != null) {
			throw new AppException(MessagesEnum.DUPLICATCHECKLISTTEMPLATE);
		} else {
			ChecklistTemplate checkListTemplate = new ChecklistTemplate();
			checkListTemplate.setChecklistName(checklistTemplate.getChecklistName());
			checkListTemplate.setChecklistType(checklistTemplate.getChecklistType());
			checkListTemplate.setChecklistService(checklistTemplate.getChecklistService());
			ChecklistTemplate template = checkListTemplateRepository.save(checkListTemplate);
			return template.getId();
		}
	}

	/*
	 * Duplicate Checklist Template
	 */
	@RequestMapping(value = "/duplicateCheckList", method = RequestMethod.POST)
	public void duplicateCheckList(@RequestBody ChecklistTemplate template) {

		ChecklistTemplate checkListObj = checkListTemplateRepository.checkDuplicateCheckList(
				template.getChecklistName(), template.getChecklistType(), template.getChecklistService());
		if (checkListObj != null) {
			throw new AppException(MessagesEnum.DUPLICATCHECKLISTTEMPLATE);
		} else {
			ChecklistTemplate checkList = checkListTemplateRepository.findOne(template.getId());
			checkList.setChecklistName(template.getChecklistName());
			checkList.setChecklistType(template.getChecklistType());
			checkList.setChecklistService(template.getChecklistService());
			checkList.setId(null);
			checkListTemplateRepository.save(checkList);
		}

	}

	/*
	 * Delete Checklist By Id
	 */
	@RequestMapping(value = "/deleteTemplateById/{Id}", method = RequestMethod.GET)
	public void deletechecklist(@PathVariable("Id") String Id) {
		ChecklistTemplate list = checkListTemplateRepository.findOne(Id);
		checkListTemplateRepository.delete(list);
	}

	/*
	 * Find checklist By Id
	 */
	@RequestMapping(value = "/getChecklistById/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ChecklistTemplate getcheckListByName(@PathVariable("id") String id) {
		ChecklistTemplate checklist = checkListTemplateRepository.findOne(id);
		return checklist;
	}
	/*
	 * Update Checklist
	 */

	@RequestMapping(value = "/updateCheckList", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void UpdatecheckList(@RequestBody ChecklistTemplate list) {

		checkListTemplateRepository.save(list);
	}
	/*
	 * Download Checklist PDF BY ChecklistId
	 */

	@RequestMapping(value = "/downloadCheckListTemplatePdf/{checkListId}", method = RequestMethod.GET)
	public void getCheckListPdf(HttpServletResponse response, @PathVariable("checkListId") String checkListId) {
		try {
			ChecklistTemplate checklist = checkListTemplateRepository.findOne(checkListId);

			response.setContentType(MediaType.APPLICATION_PDF_VALUE);
			response.setHeader("Content-Disposition", "attachment; filename=" + checklist.getChecklistName() + ".pdf");
			ByteArrayOutputStream baos = pdfExporter.export(
					PDFTemplateEnum.CHECKLIST_TEMPLATE, Arrays.asList(PDFTemplateEnum.SECTION_TEMPLATE_LIST,
							PDFTemplateEnum.QUESTION_TEMPLATE_LIST, PDFTemplateEnum.SUB_SECTION_TEMPLATE_LIST),
					Arrays.asList(checklist));
			ByteArrayInputStream ini = new ByteArrayInputStream(baos.toByteArray());
			// OutputStream oos = new FileOutputStream("D:\\CheckList.pdf");
			ServletOutputStream oos = response.getOutputStream();

			byte[] buf = new byte[8192];
			int c = 0;
			while ((c = ini.read(buf, 0, buf.length)) > 0) {
				oos.write(buf, 0, c);
				oos.flush();
			}

			oos.close();
			ini.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Attach PDF To mail
	@RequestMapping(value = "/mailCheckListTemplatePDF", method = RequestMethod.POST)
	public void mailPDF(HttpServletResponse response, @RequestBody CheckListPDFDTO checkLListPDFDTO) {
		try {
			/*
			 * List<Long>userIds =
			 * projectMemberService.getUserIdsByProjectId(checkLListPDFDTO.
			 * getProjectId()); List<String>emails =
			 * userService.getMailIdsByUserIds(userIds);
			 */
			ChecklistTemplate checklist = checkListTemplateRepository.findOne(checkLListPDFDTO.getChecklistId());

			ByteArrayOutputStream baos = pdfExporter.export(
					PDFTemplateEnum.CHECKLIST_TEMPLATE, Arrays.asList(PDFTemplateEnum.SECTION_TEMPLATE_LIST,
							PDFTemplateEnum.QUESTION_TEMPLATE_LIST, PDFTemplateEnum.SUB_SECTION_TEMPLATE_LIST),
					Arrays.asList(checklist));
			ByteArrayInputStream ini = new ByteArrayInputStream(baos.toByteArray());
			// FileOutputStream oos = new FileOutputStream("D:\\CheckList.pdf");
			ServletOutputStream oos = response.getOutputStream();
			byte[] buf = new byte[8192];
			int c = 0;
			while ((c = ini.read(buf, 0, buf.length)) > 0) {
				oos.write(buf, 0, c);
				oos.flush();
			}

			oos.close();
			ini.close();
			List<String> toMails = checkLListPDFDTO.getEmails();
			List<String> ccMail = checkLListPDFDTO.getCcMails();
			String[] to = toMails.toArray(new String[toMails.size()]);
			String[] cc = ccMail.toArray(new String[ccMail.size()]);
			String subject = checkLListPDFDTO.getSubject();

			Map<String, Object> values = new HashMap<String, Object>();
			values.put(BqmConstants.MESSAGE, checkLListPDFDTO.getMessage());
			values.put(BqmConstants.FNAME, ThreadLocalUtil.getUserName());

			Map<String, InputStreamSource> pdf = new HashMap<>();

			pdf.put("checklist" + checklist.getChecklistName() + BqmConstants.PDF_TEMPLATE_TYPE,
					new ByteArrayResource(baos.toByteArray()));
			mailService.sendEmailWithAttachments(MailTemplateEnum.CHECKLIST_TEMPLATE, values, to, cc, subject, pdf,
					checklist.getChecklistName(), checklist.getChecklistType());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * ReName ChecklistTemplate Name
	 */
	@RequestMapping(value = "/renameCheckListTemplate", method = RequestMethod.POST)
	public void renameCheckListTemplate(@RequestBody ChecklistTemplate checklistTemplate) {

		ChecklistTemplate checkListObj = checkListTemplateRepository
				.getCheckListByName(checklistTemplate.getChecklistName());
		if (checkListObj != null) {
			throw new AppException(MessagesEnum.DUPLICATCHECKLISTTEMPLATE);
		} else {
			ChecklistTemplate checkListTemplate = checkListTemplateRepository.findOne(checklistTemplate.getId());
			checkListTemplate.setChecklistName(checklistTemplate.getChecklistName());
			checkListTemplate.setChecklistType(checklistTemplate.getChecklistType());
			checkListTemplate.setChecklistService(checklistTemplate.getChecklistService());
			checkListTemplateRepository.save(checkListTemplate);

		}
	}

}
