package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.RoleActions;

public interface RoleActionService {

	public List<RoleActions> findAll();

}
