package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.Workflow;

public interface WorkFlowDAO extends BaseDAO<Workflow ,Integer> {
	
  public Long workflowNameExists(String WorkflowName);
  
  public List<String> getWorkFlowNamesList();
  
  public List<Workflow> getAllDesignWorkFlows();
  
  
}
