package com.synergy.bqm.controllers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.guvvala.framework.util.ThreadLocalUtil;
import com.synergy.bqm.json.FolderTreeDTO;
import com.synergy.bqm.models.FolderTemplate;
import com.synergy.bqm.models.FolderTemplateNames;
import com.synergy.bqm.models.ProjectMember;
import com.synergy.bqm.services.FolderTemplateDeptMappingService;
import com.synergy.bqm.services.FolderTemplateNamesService;
import com.synergy.bqm.services.FolderTemplateService;
import com.synergy.bqm.services.ProjectMemberService;

@RestController
@RequestMapping("/api/folderTemplate")
public class FolderTemplateController {

	@Autowired
	FolderTemplateService folderTemplateService;

	@Autowired
	FolderTemplateNamesService folderTemplateNamesService;

	@Autowired
	ProjectMemberService projectMemberService;

	@Autowired
	FolderTemplateDeptMappingService folderTemplateDeptMappingService;

	/*
	 * Retrieving Distinct TemplateList
	 */
	@RequestMapping(value = "/distinctTemplateList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FolderTemplateNames> getDistinctTemplateNameList() {
		return folderTemplateNamesService.findAllTemplates();

	}

	/*
	 * Retrieving folder template as tree dto
	 */
	@RequestMapping(value = "/getTemplateTreeDetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FolderTreeDTO> getTemplateTreeDetails() {
		List<FolderTreeDTO> templateTreeDTO = new ArrayList<>();
		List<FolderTemplateNames> templateList = folderTemplateNamesService.findAllTemplates();
		for (FolderTemplateNames template : templateList) {
			FolderTreeDTO templateDTO = new FolderTreeDTO();
			FolderTemplate folderTemplate = new FolderTemplate();
			folderTemplate.setTemplateId(template.getTemplateId());
			templateDTO.setLabel(template.getTemplateName());
			templateDTO.setIcon("fa fa-folder");
			templateDTO.setSelectable(true);
			templateDTO.setData(folderTemplate);
			if (template.getFolderTemplates().isEmpty()) {
				templateDTO.setLeaf(Boolean.TRUE);
			} else {
				templateDTO.setLeaf(Boolean.FALSE);
			}
			templateTreeDTO.add(templateDTO);

		}

		return templateTreeDTO;

	}

	/*
	 * Retrieving folder template as tree dto
	 */
	@RequestMapping(value = "/getFolderTemplateTreeDetails/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FolderTreeDTO> getTemplateTreeDetailsByUser(@PathVariable("projectId") Integer projectId) {
		Long userId = ThreadLocalUtil.getUserId();
		ProjectMember member = projectMemberService.getProjectMember(projectId, userId.intValue());
		List<FolderTemplateNames> templateList = new ArrayList<>();
		if (member.getCompleteAccess()) {
			List<Integer> templateIds = folderTemplateDeptMappingService.getFolderTemplateIds();
			templateList.addAll(folderTemplateNamesService.getFoldersInfoByFolderIds(templateIds));
		} else {
			List<Integer> templateIds = folderTemplateDeptMappingService.getTemplateIds(member.getDepartmentId());
			if (!templateIds.isEmpty()) {
				templateList.addAll(folderTemplateNamesService.getFoldersInfoByFolderIds(templateIds));
			}
		}
		List<FolderTreeDTO> templateTreeDTO = new ArrayList<>();

		for (FolderTemplateNames template : templateList) {
			FolderTreeDTO templateDTO = new FolderTreeDTO();
			FolderTemplate folderTemplate = new FolderTemplate();
			folderTemplate.setTemplateId(template.getTemplateId());
			templateDTO.setLabel(template.getTemplateName());
			templateDTO.setIcon("fa fa-folder");
			templateDTO.setSelectable(true);
			templateDTO.setData(folderTemplate);
			if (template.getFolderTemplates().isEmpty()) {
				templateDTO.setLeaf(Boolean.TRUE);
			} else {
				templateDTO.setLeaf(Boolean.FALSE);
			}
			templateTreeDTO.add(templateDTO);

		}

		return templateTreeDTO;

	}

	/*
	 * Create New Template
	 */
	@RequestMapping(value = "/createTemplate/{templateName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public FolderTemplateNames createTemplate(@PathVariable("templateName") String templateName) {
		return folderTemplateNamesService.createTemplate(templateName);

	}

	@RequestMapping(value = "/getFolderTemplateInfoById/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public FolderTemplateNames getFolderTemplateNamesById(@PathVariable("Id") Integer Id) {
		return folderTemplateNamesService.getFolderTemplateInfoById(Id);

	}

	/*
	 * Update Template
	 */
	@RequestMapping(value = "/updateTemplate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void updateTemplate(@RequestBody FolderTemplateNames folderTemplateNames) {
		folderTemplateNamesService.updateTemplate(folderTemplateNames);
	}

	/*
	 * Duplicate Template
	 */
	@RequestMapping(value = "/duplicateTemplate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void reCreatFolderTemplate(@RequestParam("templateId") Integer templateId,
			@RequestParam("templateName") String templateName) {
		folderTemplateService.reCreatFolderTemplate(templateId, templateName);
	}

	/*
	 * Delete Template
	 */
	@RequestMapping(value = "/deleteTemplate/{templateId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void deleteFolderTemplates(@PathVariable("templateId") Integer templateId) {
		folderTemplateNamesService.deleteTemplate(templateId);
	}

	/*
	 * Add Folder to Template
	 */
	@RequestMapping(value = "/createFolder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public FolderTemplate createFolder(@RequestBody FolderTemplate folderTemplate) {
		return folderTemplateService.createFolder(folderTemplate);

	}

	/*
	 * Rename Folder
	 */
	@RequestMapping(value = "/updateFolder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public FolderTemplate updateFolder(@RequestBody FolderTemplate folderTemplate) {
		return folderTemplateService.updateFolder(folderTemplate);
	}

	/*
	 * Move Folder
	 */
	@RequestMapping(value = "/moveChildFolder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public FolderTemplate folderMoving(@RequestBody FolderTemplate folderTemplate) {
		return folderTemplateService.folderMoving(folderTemplate);

	}

	/*
	 * Delete Folder By FolderId
	 */
	@RequestMapping(value = "/deleteFolder/{folderId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void deleteFolder(@PathVariable("folderId") Integer folderId) {
		folderTemplateService.deleteFolder(folderId);
	}

	/*
	 * 
	 * load subFolders of folder By TemplateId/FolderId
	 */
	@RequestMapping(value = "/folderInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FolderTreeDTO> getFolderNameByTemplateId(@RequestBody FolderTemplate folderTemplate) {
		if (folderTemplate.getTemplateId() != null && folderTemplate.getFolderId() == null) {
			List<FolderTemplate> templateList = folderTemplateService
					.getFolderNameByTemplateId(folderTemplate.getTemplateId());
			if (!templateList.isEmpty()) {
				if (templateList.get(0).getFolderName() != null) {
					List<FolderTreeDTO> dto = new ArrayList<>();
					for (FolderTemplate treeDTO : templateList) {
						FolderTreeDTO folderTreeDTO = new FolderTreeDTO();
						FolderTemplate template = new FolderTemplate();
						template.setFolderId(treeDTO.getFolderId());
						template.setTemplateId(treeDTO.getTemplateId());
						template.setUpdatedDt(treeDTO.getUpdatedDt());
						template.setUpdatedBy(treeDTO.getUpdatedBy());
						folderTreeDTO.setLabel(treeDTO.getFolderName());
						folderTreeDTO.setIcon("fa fa-folder");
						folderTreeDTO.setData(template);
						if (treeDTO.getFolderTemplates().isEmpty()) {
							folderTreeDTO.setLeaf(true);

						} else {
							folderTreeDTO.setLeaf(false);
						}
						dto.add(folderTreeDTO);
					}
					return dto;
				}
			}
			return new ArrayList<>();
		} else {
			List<FolderTemplate> childFolder = folderTemplateService
					.getChildFolderByFolderId(folderTemplate.getFolderId());
			if (!childFolder.isEmpty()) {
				List<FolderTreeDTO> dto = new ArrayList<>();
				for (FolderTemplate treeDTO : childFolder) {
					FolderTreeDTO folderTreeDTO = new FolderTreeDTO();
					FolderTemplate template = new FolderTemplate();
					template.setFolderId(treeDTO.getFolderId());
					template.setTemplateId(treeDTO.getTemplateId());
					template.setUpdatedDt(treeDTO.getUpdatedDt());
					template.setUpdatedBy(treeDTO.getUpdatedBy());
					folderTreeDTO.setLabel(treeDTO.getFolderName());
					folderTreeDTO.setData(treeDTO);
					folderTreeDTO.setIcon("fa fa-folder");
					folderTreeDTO.setData(template);
					if (treeDTO.getFolderTemplates().isEmpty()) {
						folderTreeDTO.setLeaf(true);

					} else {
						folderTreeDTO.setLeaf(false);
					}
					dto.add(folderTreeDTO);
				}
				return dto;
			}

			return new ArrayList<>();

		}
	}

	/*
	 * 
	 * retrieve all folders with children corresponding to the template if
	 * folder id not provided (or) retrieve given folder id info corresponding
	 * to template if folder id provided
	 */

	@RequestMapping(value = "/getTemplateWithChildFolders/{isNodeExpanded}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FolderTreeDTO> getAllTemplatesWithChildFolders(@RequestBody List<FolderTemplate> folderTemplates,
			@PathVariable("isNodeExpanded") boolean isNodeExpanded) {
		List<FolderTreeDTO> templateTreeDTO = new ArrayList<>();
		List<FolderTemplateNames> templateList = new ArrayList<>();
		// check folder template list is empty
		if (!folderTemplates.isEmpty()) {
			// get template info
			for (FolderTemplate template : folderTemplates) {
				// get template object
				FolderTemplateNames tempTemplate = folderTemplateNamesService
						.getFolderTemplateInfoById(template.getTemplateId());
				// if FolderId List is Not Empty then Attach Selected Folder To
				// Template
				if (!template.getFolderIdList().isEmpty()) {
					// new folder list
					Set<FolderTemplate> folders = new HashSet<>();

					for (FolderTemplate folder : tempTemplate.getFolderTemplates()) {

						// if folder id exists
						if (template.getFolderIdList().contains(folder.getFolderId())) {
							folders.add(folder);
						}
					}
					// set folders to template
					tempTemplate.setFolderTemplates(folders);
				}

				// add template to template list
				templateList.add(tempTemplate);
			}
		}
		// else get all templates
		else {
			templateList.addAll(folderTemplateNamesService.findAllTemplates());
		}

		// generating tree dto for each template
		for (FolderTemplateNames template : templateList) {
			FolderTreeDTO templateDTO = new FolderTreeDTO();
			FolderTemplate folderTemplate = new FolderTemplate();
			folderTemplate.setTemplateId(template.getTemplateId());
			folderTemplate.setUpdatedDt(template.getUpdatedDt());
			folderTemplate.setUpdatedBy(template.getUpdatedBy());
			templateDTO.setLabel(template.getTemplateName());
			templateDTO.setIcon("fa fa-folder");
			templateDTO.setSelectable(true);
			templateDTO.setData(folderTemplate);

			/*
			 * // getting child folders by template id List<FolderTemplate>
			 * foldersList = folderTemplateService
			 * .getFolderNameByTemplateId(template.getTemplateId());
			 */

			Set<FolderTreeDTO> children = new HashSet<>();
			// generating tree dto for each folder along with children
			for (FolderTemplate folder : template.getFolderTemplates()) {
				Set<FolderTreeDTO> tree = parentFolders(folder.getFolderId(),
						isNodeExpanded ? Boolean.TRUE : Boolean.FALSE);
				children.addAll(tree);
			}
			if (children.isEmpty()) {
				templateDTO.setLeaf(Boolean.TRUE);
			} else {
				templateDTO.setLeaf(Boolean.FALSE);
				templateDTO.setSelectable(true);
				templateDTO.setExpanded(isNodeExpanded ? Boolean.TRUE : Boolean.FALSE);
			}

			// adding all folders to template
			templateDTO.setChildren(children);

			// adding generated tree template dto to list
			templateTreeDTO.add(templateDTO);
		}

		return templateTreeDTO;

	}

	/*
	 * 
	 * Constructing Tree DTO For FirstLevel Folders
	 */

	private Set<FolderTreeDTO> parentFolders(Integer folderId, boolean isNodeExpanded) {
		List<FolderTemplate> folderInfo = folderTemplateService.getFolderInfoListByFolderId(folderId);
		Set<FolderTreeDTO> dto = new HashSet<>();
		for (FolderTemplate template : folderInfo) {
			FolderTreeDTO folderTreeDTO = new FolderTreeDTO();
			FolderTemplate folderTemplate = new FolderTemplate();
			folderTemplate.setFolderId(template.getFolderId());
			folderTemplate.setFolderName(template.getFolderName());
			folderTemplate.setUpdatedDt(template.getUpdatedDt());
			folderTemplate.setUpdatedBy(template.getUpdatedBy());
			folderTreeDTO.setLabel(template.getFolderName());
			folderTreeDTO.setIcon("fa fa-folder");
			folderTreeDTO.setSelectable(true);
			folderTreeDTO.setData(folderTemplate);
			if (template.getFolderTemplates().isEmpty()) {
				folderTreeDTO.setChildren(new HashSet<>());
				folderTreeDTO.setLeaf(true);
			} else {
				folderTreeDTO.setExpanded(isNodeExpanded ? Boolean.TRUE : Boolean.FALSE);
				Set<FolderTreeDTO> children = childrenFolders(template.getFolderTemplates(), isNodeExpanded);
				folderTreeDTO.setChildren(children);
			}
			dto.add(folderTreeDTO);

		}

		return dto;
	}

	/*
	 * 
	 * Constructing Tree DTO For subLevel Folders
	 */
	private Set<FolderTreeDTO> childrenFolders(List<FolderTemplate> templates, boolean isNodeExpanded) {

		Set<FolderTreeDTO> dto = new HashSet<>();
		for (FolderTemplate folderTemplate : templates) {
			FolderTemplate childTemplate = new FolderTemplate();
			childTemplate.setFolderId(folderTemplate.getFolderId());
			childTemplate.setFolderName(folderTemplate.getFolderName());
			childTemplate.setUpdatedDt(folderTemplate.getUpdatedDt());
			childTemplate.setUpdatedBy(folderTemplate.getUpdatedBy());
			// Tree DTO
			FolderTreeDTO childrenTree = new FolderTreeDTO();
			childrenTree.setLabel(folderTemplate.getFolderName());
			childrenTree.setData(childTemplate);
			childrenTree.setSelectable(true);
			childrenTree.setIcon("fa fa-folder");
			if (folderTemplate.getFolderTemplates().isEmpty()) {
				childrenTree.setChildren(new HashSet<>());
				childrenTree.setLeaf(true);
			} else {
				childrenTree.setExpanded(isNodeExpanded ? Boolean.TRUE : Boolean.FALSE);
				childrenTree.setChildren(childrenFolders(folderTemplate.getFolderTemplates(), isNodeExpanded));
				childrenTree.setLeaf(false);
			}
			dto.add(childrenTree);
		}
		return dto;
	}
}
