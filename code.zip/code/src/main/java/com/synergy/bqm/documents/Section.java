package com.synergy.bqm.documents;

import java.util.ArrayList;
import java.util.List;

public class Section {

	private String sectionName;
	private String sectionInfo;
	private String reference;
	private String answerType;
	private List<Subsection> subsectionList = new ArrayList<Subsection>();
	private List<BaseAnswerType> questionList = new ArrayList<BaseAnswerType>();

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public List<Subsection> getSubsectionList() {
		return subsectionList;
	}

	public void setSubsectionList(List<Subsection> subsectionList) {
		this.subsectionList = subsectionList;
	}

	public String getSectionInfo() {
		return sectionInfo;
	}

	public void setSectionInfo(String sectionInfo) {
		this.sectionInfo = sectionInfo;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getAnswerType() {
		return answerType;
	}

	public void setAnswerType(String answerType) {
		this.answerType = answerType;
	}

	public List<BaseAnswerType> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<BaseAnswerType> questionList) {
		this.questionList = questionList;
	}

}
