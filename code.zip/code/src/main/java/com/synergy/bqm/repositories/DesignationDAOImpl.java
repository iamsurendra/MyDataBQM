package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.Department;
import com.synergy.bqm.models.Designation;

@Repository
public class DesignationDAOImpl extends BaseDAOImpl<Designation, Integer> implements DesignationDAO {

	public DesignationDAOImpl() {
		super(Designation.class);
		// TODO Auto-generated constructor stub
	}

	public List<String> getDesignationNames() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Department> root = criteriaQuery.from(Department.class);
		criteriaQuery.select(root.get("designationName")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public void deleteDesignationIds(List<Integer> designationIds) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaDelete delete = criteriaBuilder.createCriteriaDelete(Designation.class);
		Root root = delete.from(Designation.class);
		delete.where(criteriaBuilder.in(root.get("designationId")).value(designationIds));
		Query query = entityManager.createQuery(delete);
		query.executeUpdate();
	}

}
