package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.QuestionOption;

public class QuestionOptionDTO {

	private List<QuestionOption> questionOption;
	
	private List<Long> ids;

	
	//getters and setters
	
	public List<QuestionOption> getQuestionOption() {
		return questionOption;
	}

	public void setQuestionOption(List<QuestionOption> questionOption) {
		this.questionOption = questionOption;
	}

	public List<Long> getIds() {
		return ids;
	}

	public void setIds(List<Long> ids) {
		this.ids = ids;
	}
	
	
	
	
}
