package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.ProjectMember;

public interface ProjectMemberService {

	
	public ProjectMember createProjectMember(ProjectMember projectMember);
	
	public ProjectMember getProjectMemberInfoById(Integer Id);
	
	public ProjectMember upDateProjectMember(ProjectMember member);
	
	public void deleteProjectMember(ProjectMember projectMember);
	
	public List<Long> getUserIdsByProjectId(Integer projectId);
	
	public Integer getProjectMemberInfo(Integer projectId, Integer userId);
	
	public ProjectMember getProjectMember(Integer projectId, Integer userId);
}
