package com.synergy.bqm.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.models.VendorProjectMapping;
import com.synergy.bqm.models.VendorServices;
import com.synergy.bqm.repositories.VendorProjectMappingDAO;
import com.synergy.bqm.repositories.VendorServicesDAO;

@Service("vendorServicesService")
public class VendorServicesServiceImpl implements VendorServicesService {

	@Autowired
	VendorServicesDAO vendorServicesDAO;

	@Autowired
	VendorProjectMappingDAO vendorProjectMappingDAO;

	@Transactional
	public List<VendorServices> getAllVendorServices() {
		return vendorServicesDAO.findAll();

	}

	@Transactional
	public void createOrUpdateOrDeleteVendorService(List<VendorServices> vendorServices) {
		if (vendorServices.isEmpty()) {
			List<VendorServices> vendorServicesList = vendorServicesDAO.findAll();
			List<Long> vendorServiceIds = new ArrayList<>();

			for (VendorServices services : vendorServicesList) {
				vendorServiceIds.add(services.getVendorServiceId());
			}
			List<VendorProjectMapping>	mapping = vendorProjectMappingDAO.getVendorProjectMappingInfoByServiceId(vendorServiceIds);
			//vendorProjectMappingDAO.deleteAll(mapping);
			for(VendorProjectMapping projectMapping:mapping){
				projectMapping.setServiceId(null);
			}
				vendorServicesDAO.deleteAll(vendorServicesList);
			

		} else {
			List<Long> vendorServiceIds = new ArrayList<>();

			for (VendorServices newVendors : vendorServices) {
				if (newVendors.getVendorServiceId() != null) {
					vendorServiceIds.add(newVendors.getVendorServiceId());
				}
			}
			if (!vendorServiceIds.isEmpty()) {
				List<VendorProjectMapping> deletedVendorServices = vendorProjectMappingDAO
						.getVendorProjectMappingInfoById(vendorServiceIds);
				if (!deletedVendorServices.isEmpty()) {
					for (VendorProjectMapping projectMapping : deletedVendorServices) {
						projectMapping.setServiceId(null);
					}
				}
				List<VendorServices> deletedVendors = vendorServicesDAO.getVendorServiceInfoById(vendorServiceIds);
				if (!deletedVendors.isEmpty()) {
					for (VendorServices vendorObject : deletedVendors) {
						vendorServicesDAO.delete(vendorObject);
					}
				}
			}
			for (VendorServices services : vendorServices) {
				if (services.getVendorServiceId() == null) {
					vendorServicesDAO.create(services);
				} else {
					vendorServicesDAO.update(services);
				}
			}
		}
	}

}
