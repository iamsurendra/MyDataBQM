package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.ProjectListVw;

public interface ProjectListVwService {

	
	public List<ProjectListVw> getProjectListVwInfo(Integer userId);
	
}
