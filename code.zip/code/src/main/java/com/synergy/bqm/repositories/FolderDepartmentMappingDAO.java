package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.FolderDepartmentMapping;

public interface FolderDepartmentMappingDAO extends BaseDAO<FolderDepartmentMapping, Integer>{
	
	public List<Integer> getFolderIds(Integer departmentId);
	
	public FolderDepartmentMapping getDeletedFolder(Integer folderId,Integer departmentId);
	
	public List<Integer> getDepartmentIds(Integer folderId);

}
