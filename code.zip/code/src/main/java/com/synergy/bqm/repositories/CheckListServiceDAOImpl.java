package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.ChecklistService;

@Repository
public class CheckListServiceDAOImpl extends BaseDAOImpl<ChecklistService, Integer> implements CheckListServiceDAO{

	public CheckListServiceDAOImpl() {
		super(ChecklistService.class);
		// TODO Auto-generated constructor stub
	}

	public List<String> getCheckListServices() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<ChecklistService> root = criteriaQuery.from(ChecklistService.class);
		criteriaQuery.select(root.get("service")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
		
	}
	
	public List<ChecklistService> getCheckListServicesInfoById(List<Integer> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ChecklistService> criteriaQuery = builder.createQuery(ChecklistService.class);
		Root<ChecklistService> root = criteriaQuery.from(ChecklistService.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where((builder.in(root.get("checkListServiceId")).value(Ids)));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

}
