package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;

import com.synergy.bqm.models.ProjectStage;

@Repository
public class ProjectStageDAOImpl extends BaseDAOImpl<ProjectStage, Integer> implements ProjectStageDAO {

	public ProjectStageDAOImpl() {
		super(ProjectStage.class);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public List<String> getprojectStageNamesList() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<ProjectStage> root = criteriaQuery.from(ProjectStage.class);
		criteriaQuery.select(root.get("projectStageName")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
	@Override
	public List<String> getProjectStageInfoById(List<Integer> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);
		Root<ProjectStage> root = criteriaQuery.from(ProjectStage.class);
		criteriaQuery.select(root.get("projectStageName")).distinct(true);
		criteriaQuery.where(builder.in(root.get("projectStageId")).value(Ids));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}


}
