package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.ProjectHierarchy;

public interface ProjectHierarchyDAO extends BaseDAO<ProjectHierarchy, Integer>{
	
	public List<ProjectHierarchy> getProjectHierarchyInfoByProjectId(Integer projectId);
	
	public List<ProjectHierarchy> findExistingHierarchyName(String name, Integer id,Integer projectId);
	
	public List<ProjectHierarchy> getHierarchyIfo(String name, Integer id, Integer projectId);
	


}
