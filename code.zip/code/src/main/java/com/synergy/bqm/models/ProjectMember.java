package com.synergy.bqm.models;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The persistent class for the project_members database table.
 * 
 */
@Entity
@Table(name = "project_members")
@NamedQuery(name = "ProjectMember.findAll", query = "SELECT p FROM ProjectMember p")
public class ProjectMember implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private Integer id;

	@Type(type = "boolean")
	@Column(name = "complete_access")
	private Boolean completeAccess;

	@Column(name = "department_id")
	private Integer departmentId;

	@Column(name = "designation_id")
	private Integer designationId;

	@Column(name = "role_id")
	private Integer roleId;

	@Column(name = "user_id")
	private Long userId;

	// bi-directional many-to-one association to Project
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name = "project_id")
	private Project project;

	public ProjectMember() {
	}

	// getters and setters

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public Boolean getCompleteAccess() {
		return completeAccess;
	}

	public void setCompleteAccess(Boolean completeAccess) {
		this.completeAccess = completeAccess;
	}

	public Integer getDesignationId() {
		return designationId;
	}

	public void setDesignationId(Integer designationId) {
		this.designationId = designationId;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

}