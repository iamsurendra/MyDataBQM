package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.Workflow;

@Repository
public class WorkFlowDAOImpl extends BaseDAOImpl<Workflow ,Integer> implements WorkFlowDAO {
	public WorkFlowDAOImpl (){
		super(Workflow.class);
}
	
	  public Long workflowNameExists(String WorkflowName){
		TypedQuery<Long> query = entityManager
				.createQuery("select count(*) from Workflow where name = :workflowName", Long.class);
		query.setParameter("workflowName", WorkflowName);
		return query.getSingleResult();
	}

	  public List<String> getWorkFlowNamesList() {
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
			Root<Workflow> root = criteriaQuery.from(Workflow.class);
			criteriaQuery.select(root.get("name")).distinct(true);
			return entityManager.createQuery(criteriaQuery).getResultList();
		}
	  
	  public List<Workflow> getAllDesignWorkFlows() {
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaQuery<Workflow> criteriaQuery = criteriaBuilder.createQuery(Workflow.class);
			Root<Workflow> root = criteriaQuery.from(Workflow.class);
			criteriaQuery.select(root);
			criteriaQuery.where(criteriaBuilder.equal(root.get("workflowType"), "Design"));
			return entityManager.createQuery(criteriaQuery).getResultList();
		}
	  
}