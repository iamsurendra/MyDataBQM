package com.synergy.bqm.documents;

import java.util.ArrayList;
import java.util.List;

public class SectionTemplate {

	private String sectionName;
	private String sectionInfo;
	private String reference;
	private String questionType;
	private List<SubsectionTemplate> subsectionList = new ArrayList<SubsectionTemplate>();
	private List<BaseQuestionTypeTemplate> questionList = new ArrayList<BaseQuestionTypeTemplate>();
	
	public List<BaseQuestionTypeTemplate> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<BaseQuestionTypeTemplate> questionList) {
		this.questionList = questionList;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	public List<SubsectionTemplate> getSubsectionList() {
		return subsectionList;
	}
	public void setSubsectionList(List<SubsectionTemplate> subsectionList) {
		this.subsectionList = subsectionList;
	}
	public String getSectionInfo() {
		return sectionInfo;
	}
	public void setSectionInfo(String sectionInfo) {
		this.sectionInfo = sectionInfo;
	}
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getQuestionType() {
		return questionType;
	}
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}
	
	
	
}
