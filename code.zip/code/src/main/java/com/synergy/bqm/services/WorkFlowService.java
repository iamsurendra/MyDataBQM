package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.Workflow;
import com.synergy.bqm.models.WorkflowStates;

public interface WorkFlowService {

	public Workflow saveWorkflow(Workflow workflow);

	public void deleteworkflowBYId(Integer Id);
	
	public List<Workflow> findAll();
	
	public List<WorkflowStates> getWorkflowsInfo(Integer workFlowId);
	
	public List<WorkflowStates> getTargetStates(Integer stateId);
	
	public List<Workflow> getAllDesignWorkFlows();
	
	public Workflow findOne(Integer id);
}