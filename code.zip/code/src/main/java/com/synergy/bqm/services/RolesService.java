package com.synergy.bqm.services;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.synergy.bqm.json.RoleActionsDTO;
import com.synergy.bqm.models.Role;

public interface RolesService {

	

	public void createRole(String name);

	public List<String> getRoleNames();

	List<Role> findAllRoles();

	public void updateRole(Role role);

	public Role findOne(Integer roleId);

	public void deleteRoleById(Integer Id);

	public List<RoleActionsDTO> getRoleJson(Integer projectId, Integer roleId)
			throws JsonParseException, JsonMappingException, IOException;

	public void updateRoleJson(Integer roleId, List<RoleActionsDTO> roleActionsDTOs);
	
	public List<RoleActionsDTO> getMenuActionByRoleId(Integer roleId);
	
	public List<Role> findAllRolesWithRights();

}
