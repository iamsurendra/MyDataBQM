package com.synergy.bqm.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.RevisionNumber;
import org.hibernate.envers.RevisionTimestamp;

import com.guvvala.framework.envers.AuditListener;

@Entity
@Table(name = "revisionhistory")
@RevisionEntity(AuditListener.class)
public class RevisionHistory {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@RevisionNumber
	@Column(name = "REV_ID")
	private Long revId;

	@RevisionTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_UPD_DT")
	private Date revDate;

	@Column(name = "LAST_UPD_BY")
	private String userId;

	public Long getRevId() {
		return revId;
	}

	public void setRevId(Long revId) {
		this.revId = revId;
	}

	public Date getRevDate() {
		return revDate;
	}

	public void setRevDate(Date revDate) {
		this.revDate = revDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	

}
