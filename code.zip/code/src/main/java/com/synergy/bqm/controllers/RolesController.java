package com.synergy.bqm.controllers;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.synergy.bqm.json.RoleActionsDTO;
import com.synergy.bqm.models.Role;
import com.synergy.bqm.services.RolesService;

@RestController
@RequestMapping("/api/roles")
public class RolesController {

	@Autowired
	RolesService rolesService;

	@RequestMapping(value = "/createRole/{roleName}", method = RequestMethod.GET)
	public void createRole(@PathVariable("roleName") String roleName) {
		rolesService.createRole(roleName);
	}

	@RequestMapping(value = "/findAllRolesWithRights", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Role> findAllRolesWithRights() {
		return rolesService.findAllRolesWithRights();

	}

	/*
	 * /* Find All Roles
	 */
	@RequestMapping(value = "/findAllRoles", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Role> findAllRoles() {
		return rolesService.findAllRoles();
	}

	@RequestMapping(value = "/getRoleInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<RoleActionsDTO> getRoleInfo(@RequestParam("projectId") Integer projectId,
			@RequestParam("userId") Integer userId) throws JsonParseException, JsonMappingException, IOException {
		return rolesService.getRoleJson(projectId, userId);
	}

	@RequestMapping(value = "/getMenuActionByRoleId/{roleId}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<RoleActionsDTO> getMenuActionByRoleId(@PathVariable("roleId") Integer roleId) {
		return rolesService.getMenuActionByRoleId(roleId);

	}

	/*
	 * UpdateRole Actions
	 */
	@RequestMapping(value = "/updateRoleJson/{roleId}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateRoleJson(@PathVariable("roleId") Integer roleId,
			@RequestBody List<RoleActionsDTO> roleActionsDTOs) {
		rolesService.updateRoleJson(roleId, roleActionsDTOs);
	}

	/*
	 * Update Role Info
	 */
	@RequestMapping(value = "/updateRole", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateRole(@RequestBody Role role) {
		rolesService.updateRole(role);
	}

	/*
	 * Delete Role BY Id
	 */
	@RequestMapping(value = "/deleteRoleById/{Id}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void deleteRoleById(@PathVariable("Id") Integer Id) {
		rolesService.deleteRoleById(Id);
	}

}
