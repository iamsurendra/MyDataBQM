package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the checklists database table.
 * 
 */
@Entity
@Table(name="checklists")
@NamedQuery(name="Checklist.findAll", query="SELECT c FROM Checklist c")
public class Checklist extends com.guvvala.framework.model.BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="checklist_id")
	private int checklistId;

	@Column(name="checklist_name")
	private String checklistName;

	@Column(name="checklist_project_hierarchy_id")
	private int checklistProjectHierarchyId;

	@Column(name="checklist_project_id")
	private int checklistProjectId;

	@Column(name="checklist_type")
	private String checklistType;

	/*@Column(name="created_by")
	private int createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_dt")
	private Date createdDt;

	@Column(name="updated_by")
	private int updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_dt")
	private Date updatedDt;*/

	//bi-directional many-to-one association to ChecklistLineItem
	@OneToMany(mappedBy="checklist")
	private List<ChecklistLineItem> checklistLineItems;

	public Checklist() {
	}

	public int getChecklistId() {
		return this.checklistId;
	}

	public void setChecklistId(int checklistId) {
		this.checklistId = checklistId;
	}

	public String getChecklistName() {
		return this.checklistName;
	}

	public void setChecklistName(String checklistName) {
		this.checklistName = checklistName;
	}

	public int getChecklistProjectHierarchyId() {
		return this.checklistProjectHierarchyId;
	}

	public void setChecklistProjectHierarchyId(int checklistProjectHierarchyId) {
		this.checklistProjectHierarchyId = checklistProjectHierarchyId;
	}

	public int getChecklistProjectId() {
		return this.checklistProjectId;
	}

	public void setChecklistProjectId(int checklistProjectId) {
		this.checklistProjectId = checklistProjectId;
	}

	public String getChecklistType() {
		return this.checklistType;
	}

	public void setChecklistType(String checklistType) {
		this.checklistType = checklistType;
	}

	/*public int getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDt() {
		return this.createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public int getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDt() {
		return this.updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}*/

	public List<ChecklistLineItem> getChecklistLineItems() {
		return this.checklistLineItems;
	}

	public void setChecklistLineItems(List<ChecklistLineItem> checklistLineItems) {
		this.checklistLineItems = checklistLineItems;
	}

	public ChecklistLineItem addChecklistLineItem(ChecklistLineItem checklistLineItem) {
		getChecklistLineItems().add(checklistLineItem);
		checklistLineItem.setChecklist(this);

		return checklistLineItem;
	}

	public ChecklistLineItem removeChecklistLineItem(ChecklistLineItem checklistLineItem) {
		getChecklistLineItems().remove(checklistLineItem);
		checklistLineItem.setChecklist(null);

		return checklistLineItem;
	}

}