package com.synergy.bqm.mongoRepositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.synergy.bqm.documents.ChecklistTemplate;

public interface CheckListTemplateRepository extends MongoRepository<ChecklistTemplate, String> {

	@Query(value = "{}", fields = "{checklistName: 1, _id : 1,checklistType: 1}")
	List<ChecklistTemplate> getChecklistNames();

	@Query(value = "{}", fields = "{checklistType: 1, _id : 0}")
	List<ChecklistTemplate> getChecklistTypes();

	@Query("{ 'checklistName' : ?0 }")
	ChecklistTemplate getCheckListByName(String Name);
		
	@Query("{'checklistName' : ?0, 'checklistType' : ?1, 'checklistService' : ?2}")
	ChecklistTemplate checkDuplicateCheckList(String Name,String type,String service);
	
	@Query(value = "{}", fields="{checklistService:1,checklistType:1,checklistName:1}")
	List<ChecklistTemplate> getChecklistTypeandService();
	
	@Query(value = "{'checklistType':'Design'}", fields="{checklistService:1,checklistType:1,checklistName:1}")
	List<ChecklistTemplate> getDesignCheckLists();
	
	@Query("{ 'checklistType' : ?0 }")
	List<ChecklistTemplate> getCheckListByType(String Types);

}