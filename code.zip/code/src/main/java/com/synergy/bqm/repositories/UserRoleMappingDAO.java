package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.UserRoleMapping;

public interface UserRoleMappingDAO extends BaseDAO<UserRoleMapping, Integer>{
	
	public List<Integer> getRoleIdsByProjectIdsAndUserIds(Integer projectId, Integer userId);

}
