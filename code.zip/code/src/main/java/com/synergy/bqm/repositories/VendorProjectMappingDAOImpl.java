package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.VendorProjectMapping;

@Repository
public class VendorProjectMappingDAOImpl extends BaseDAOImpl<VendorProjectMapping, Integer>
		implements VendorProjectMappingDAO {

	public VendorProjectMappingDAOImpl() {
		super(VendorProjectMapping.class);
		// TODO Auto-generated constructor stub
	}

	public List<VendorProjectMapping> getVendorProjectMappingInfoById(List<Long> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<VendorProjectMapping> criteriaQuery = builder.createQuery(VendorProjectMapping.class);
		Root<VendorProjectMapping> root = criteriaQuery.from(VendorProjectMapping.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(builder.not(builder.in(root.get("serviceId")).value(Ids)));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	public List<VendorProjectMapping> getVendorProjectMappingInfoByServiceId(List<Long> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<VendorProjectMapping> criteriaQuery = builder.createQuery(VendorProjectMapping.class);
		Root<VendorProjectMapping> root = criteriaQuery.from(VendorProjectMapping.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(builder.in(root.get("serviceId")).value(Ids));
	    return entityManager.createQuery(criteriaQuery).getResultList();

		
	}

	public List<VendorProjectMapping> getVendorProjectMappingInfoByVendorId(Long Id) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<VendorProjectMapping> criteriaQuery = builder.createQuery(VendorProjectMapping.class);
		Root<VendorProjectMapping> root = criteriaQuery.from(VendorProjectMapping.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(builder.equal(root.get("vendorId"), Id));
	    return entityManager.createQuery(criteriaQuery).getResultList();

		
	}
}
