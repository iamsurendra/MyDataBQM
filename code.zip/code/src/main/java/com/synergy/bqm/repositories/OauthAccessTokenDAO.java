package com.synergy.bqm.repositories;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.OauthAccessToken;

public interface OauthAccessTokenDAO extends BaseDAO<OauthAccessToken, String>{
	
	public void deleteOauthTokenName(String userName);

}
