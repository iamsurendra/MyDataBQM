package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.json.ActivityTypesDTO;
import com.synergy.bqm.models.ActivityTypes;

public interface ActivityTypesService {
	
	public void createAndUpdateActivityTypes(ActivityTypesDTO activityTypesDTO);
		
	public List<ActivityTypes>findAllActivities();

}
