package com.synergy.bqm.models;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

/**
 * The persistent class for the folder_download_history database table.
 * 
 */
@Entity
@Table(name = "folder_download_history")
@NamedQuery(name = "FolderDownloadHistory.findAll", query = "SELECT f FROM FolderDownloadHistory f")
public class FolderDownloadHistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "document_description")
	private String documentDescription;

	@Column(name = "document_folder_id")
	private Integer documentFolderId;

	@Column(name = "document_id")
	private Integer documentId;

	@Column(name = "document_link")
	private String documentLink;

	@Column(name = "document_name")
	private String documentName;

	@Column(name = "downloaded_by")
	private String downloadedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "downloaded_date")
	private Date downloadedDate;

	@Column(name = "file_type")
	private String fileType;

	private double version;

	public FolderDownloadHistory() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocumentDescription() {
		return documentDescription;
	}

	public void setDocumentDescription(String documentDescription) {
		this.documentDescription = documentDescription;
	}

	public Integer getDocumentFolderId() {
		return documentFolderId;
	}

	public void setDocumentFolderId(Integer documentFolderId) {
		this.documentFolderId = documentFolderId;
	}

	public Integer getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	public String getDocumentLink() {
		return documentLink;
	}

	public void setDocumentLink(String documentLink) {
		this.documentLink = documentLink;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDownloadedBy() {
		return downloadedBy;
	}

	public void setDownloadedBy(String downloadedBy) {
		this.downloadedBy = downloadedBy;
	}

	public Date getDownloadedDate() {
		return downloadedDate;
	}

	public void setDownloadedDate(Date downloadedDate) {
		this.downloadedDate = downloadedDate;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public double getVersion() {
		return version;
	}

	public void setVersion(double version) {
		this.version = version;
	}

}