package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.Client;

@Repository
public class ClientDAOImpl extends BaseDAOImpl<Client, Integer> implements ClientDAO {

	public ClientDAOImpl() {
		super(Client.class);
		// TODO Auto-generated constructor stub
	}

	@Transactional
	public List<String> getClientNameList() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Client> root = criteriaQuery.from(Client.class);
		criteriaQuery.select(root.get("clientName")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public Client getClientInfoByClientId(Integer clientId) {
		TypedQuery<Client> query = entityManager
				.createQuery("SELECT f from Client f where clientId ='" + clientId + "'", Client.class);
		return query.getSingleResult();
	}
	
	public Long clienttNameExists(String ClientName){
		TypedQuery<Long> query = entityManager
				.createQuery("select count(*) from Client where clientName = :clientName", Long.class);
		query.setParameter("clientName", ClientName);
		return query.getSingleResult();

	}

}
