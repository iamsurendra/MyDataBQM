package com.synergy.bqm.documents;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@JsonTypeInfo(use = Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "answerType", visible = true)
@JsonSubTypes({ @Type(value = SelectionQuestionType.class, name = SelectionQuestionType.ANSWERTYPE),
		@Type(value = TextQuestionType.class, name = TextQuestionType.ANSWERTYPE),
		@Type(value = InfoQuestionType.class, name = InfoQuestionType.ANSWERTYPE), })
public abstract class BaseAnswerType {

	private String lineItemQuestion;
	private String lineItemToolTip;
	private String answer;
	private String remark;
	private String submittedDate;
	private List<String> image = new ArrayList<>();
	private String answerType;

	private ByteArrayInputStream firstImage;
	private ByteArrayInputStream secondImage;
	private ByteArrayInputStream thirdImage;
	private ByteArrayInputStream fourthImage;
	private ByteArrayInputStream fifthImage;

	public BaseAnswerType() {
		super();

	}

	public BaseAnswerType(String lineItemQuestion, String lineItemToolTip, String answerType) {
		super();
		this.lineItemQuestion = lineItemQuestion;
		this.lineItemToolTip = lineItemToolTip;
		this.answerType = answerType;
	}

	public String getLineItemQuestion() {
		return lineItemQuestion;
	}

	public void setLineItemQuestion(String lineItemQuestion) {
		this.lineItemQuestion = lineItemQuestion;
	}

	public String getLineItemToolTip() {
		return lineItemToolTip;
	}

	public void setLineItemToolTip(String lineItemToolTip) {
		this.lineItemToolTip = lineItemToolTip;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public List<String> getImage() {
		return image;
	}

	public void setImage(List<String> image) {
		this.image = image;
	}

	public String getAnswerType() {
		return answerType;
	}

	public void setAnswerType(String answerType) {
		this.answerType = answerType;
	}

	public String getSubmittedDate() {
		return submittedDate;
	}

	public void setSubmittedDate(String submittedDate) {
		this.submittedDate = submittedDate;
	}

	public ByteArrayInputStream getFirstImage() {
		return firstImage;
	}

	public void setFirstImage(ByteArrayInputStream firstImage) {
		this.firstImage = firstImage;
	}

	public ByteArrayInputStream getSecondImage() {
		return secondImage;
	}

	public void setSecondImage(ByteArrayInputStream secondImage) {
		this.secondImage = secondImage;
	}

	public ByteArrayInputStream getThirdImage() {
		return thirdImage;
	}

	public void setThirdImage(ByteArrayInputStream thirdImage) {
		this.thirdImage = thirdImage;
	}

	public ByteArrayInputStream getFourthImage() {
		return fourthImage;
	}

	public void setFourthImage(ByteArrayInputStream fourthImage) {
		this.fourthImage = fourthImage;
	}

	public ByteArrayInputStream getFifthImage() {
		return fifthImage;
	}

	public void setFifthImage(ByteArrayInputStream fifthImage) {
		this.fifthImage = fifthImage;
	}

}
