package com.sgsystems.motor.services;

import org.junit.Test;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableTransactionManagement
public class UserServiceTest extends BaseServiceTest {



	@Test
	public void findAll() {
	}

}
