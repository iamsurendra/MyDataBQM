package com.sgsystems.motor.staticTest;

import com.guvvala.framework.util.AppWebUtils;

public class DealerCode {

	public static void main(String args[]) {
		String code = "Dea";
		System.out.println(AppWebUtils.generateCode(code));
	}

}
