package com.sgsystems.motor.services;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.commons.dbcp2.BasicDataSource;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.guvvala.framework.util.ThreadLocalUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/applicationContext.xml" })
public abstract class BaseServiceTest extends AbstractTransactionalJUnit4SpringContextTests  {
	

	@BeforeClass
	public static void setUp() {
		ThreadLocalUtil.setThreadVariable(ThreadLocalUtil.CURRENT_USER, "SUNITHAP");
		try {
			System.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.naming.java.javaURLContextFactory");
			System.setProperty(Context.URL_PKG_PREFIXES, "org.apache.naming");
			InitialContext ic = new InitialContext();
			ic.createSubcontext("java:");
			ic.createSubcontext("java:comp");
			ic.createSubcontext("java:comp/env");
			ic.createSubcontext("java:comp/env/jdbc");
			BasicDataSource dataSource = new BasicDataSource();
			dataSource.setDriverClassName("com.mysql.jdbc.Driver");
			dataSource.setUrl("jdbc:mysql://192.168.1.135:3306/motor");
			dataSource.setUsername("salesrebates");
			dataSource.setPassword("rebates@123");
			ic.rebind("java:comp/env/jdbc/motor", dataSource);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}
