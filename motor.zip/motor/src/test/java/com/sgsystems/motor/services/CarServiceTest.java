package com.sgsystems.motor.services;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.sgsystems.motor.models.Car;
import com.sgsystems.motor.models.CarEngineDetails;
import com.sgsystems.motor.models.CarExterior;
import com.sgsystems.motor.models.CarInterior;
import com.sgsystems.motor.models.Image;

@EnableTransactionManagement
@Rollback(false)
public class CarServiceTest extends BaseServiceTest {

	@Autowired
	CarService carService;

	@Autowired
	ImageService imageService;

	@Test
	public void create() {
		try {
			Car car = carService.createInactiveCar(142l);
			createCarImages(car);
			loadCarDetails(car);
			car.setCarInterior(loadCarInteriorDetails(car));
			car.setCarEngineDetails(loadCarEngineDetails(car));
			// carService.updateCarDetails(car);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	public void update() {
		try {
			Car car = new Car();
			car.setId(79l);
			loadCarDetails(car);
			car.setCarInterior(loadCarInteriorDetails(car));
			car.setCarEngineDetails(loadCarEngineDetails(car));
			// carService.updateCarDetails(car);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void createCarImages(Car car) throws IOException {
		saveImage("D:\\Motor\\data\\1.jpg", true, car.getId());
		saveImage("D:\\Motor\\data\\A3 _convertible.jpg", false, car.getId());
		saveImage("D:\\Motor\\data\\Abarth-500_cros.jpg", false, car.getId());
		saveImage("D:\\Motor\\data\\acura_ilx.jpg", false, car.getId());
		saveImage("D:\\Motor\\data\\acura_mdx.jpg", false, car.getId());
		saveImage("D:\\Motor\\data\\acuramdx_suv.jpg", false, car.getId());
	}

	/**
	 * @param carDetailsView
	 * @param carObj
	 * @return
	 */
	private CarInterior loadCarInteriorDetails(Car car) {
		CarInterior carInterior = new CarInterior();
		carInterior.setCar(car);
		carInterior.setAcFront(true);
		carInterior.setAlarm(true);
		
		carInterior.setKeyLessStart(false);
		return carInterior;
	}

	/**
	 * @param carDetailsView
	 * @param carObj
	 */
	private CarExterior loadCarExteriorDetails(Car car) {
		CarExterior carExterior = new CarExterior();
		carExterior.setCar(car);
		carExterior.setAllowWheels(false);
		carExterior.setSpoiler(false);
		carExterior.setHeadLights(true);
		carExterior.setProjectLamps(true);
		carExterior.setSunMoonRoof(true);
		carExterior.setAllowWheels(true);
		return carExterior;
	}

	/**
	 * @param carDetailsView
	 * @param carObj
	 * @param carEngineDetails
	 */
	private CarEngineDetails loadCarEngineDetails(Car car) {
		CarEngineDetails carEngineDetails = new CarEngineDetails();
		carEngineDetails.setCar(car);
		carEngineDetails.setBhpId(2l);
		carEngineDetails.setCcId(1l);
		carEngineDetails.setFuelType("PETROL");
		carEngineDetails.setTransmission("AUTOMATIC");
		carEngineDetails.setNoOfCylinder("3");
		carEngineDetails.setDriveType("AWD");
		return carEngineDetails;
	}

	/**
	 * @param carDetailsView
	 * @param car
	 */
	private void loadCarDetails(Car car) {

		car.setVin("HU002345J23423");
		car.setMakeId(1l);
		car.setNewCar(true);
		car.setYear(2017);
		car.setColor(1l);
		car.setPrice(new BigDecimal("10000"));
		car.setReducedPrice(new BigDecimal("9000"));
		car.setMileage(45000l);
		car.setTankCapacity("45");
	}

	private void saveImage(String path, boolean first, Long carId) throws IOException {
		String extention = FilenameUtils.getExtension(path);
		File file = new File(path);
		Image image = new Image();
		image.setFirst(first);
		image.setCarId(carId);
		image.setName(UUID.randomUUID().toString() + "." + extention);
		imageService.create(image);
	}

}