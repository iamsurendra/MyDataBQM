package com.sgsystems.motor.services;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.sgsystems.motor.models.Image;

@EnableTransactionManagement
@Rollback(false)
public class ImageServiceTest extends BaseServiceTest {

	@Autowired
	ImageService imageService;

	@Test
	public void createCarImages() throws IOException {
		saveImage("D:\\Motor\\data\\1.jpg", true, 87l);
		saveImage("D:\\Motor\\data\\A3 _convertible.jpg", false, 87l);
		saveImage("D:\\Motor\\data\\Abarth-500_cros.jpg", false, 87l);
		saveImage("D:\\Motor\\data\\acura_ilx.jpg", false, 87l);
		saveImage("D:\\Motor\\data\\acura_mdx.jpg", false, 87l);
		saveImage("D:\\Motor\\data\\acuramdx_suv.jpg", false, 87l);
	}

	private void saveImage(String path, boolean first, Long carId) throws IOException {
		String extention = FilenameUtils.getExtension(path);
		File file = new File(path);
		Image image = new Image();
		image.setFirst(first);
		image.setCarId(carId);
		image.setName(UUID.randomUUID().toString() + "." + extention);
		imageService.create(image);
	}

}