package com.guvvala.framework.util;

import java.util.Enumeration;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.guvvala.framework.logging.AppLogger;
import com.guvvala.framework.logging.Log;

public class ControllerInterceptors extends HandlerInterceptorAdapter {

	private static @Log AppLogger logger;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		loadThreadLocalUtils(request);
		if (handler instanceof HandlerMethod) {
			HandlerMethod method = (HandlerMethod) handler;
			if (method.getMethod().isAnnotationPresent(AuthorizationPrivilege.class)) {

			}
		}
		return true;
	}

	private void loadThreadLocalUtils(HttpServletRequest request) {
		Enumeration<String> headerNames = request.getHeaderNames();
		ThreadLocalUtil.setThreadVariable(ThreadLocalUtil.LOCALE, Locale.ENGLISH.getLanguage());
		ThreadLocalUtil.setThreadVariable(ThreadLocalUtil.LOCALE_OBJ, Locale.ENGLISH);
		while (headerNames.hasMoreElements()) {
			String key = (String) headerNames.nextElement();
			if (key.equals(ThreadLocalUtil.CURRENT_USER)) {
				ThreadLocalUtil.setThreadVariable(ThreadLocalUtil.CURRENT_USER, request.getHeader(key));
				break;
			}
		}

	}

}