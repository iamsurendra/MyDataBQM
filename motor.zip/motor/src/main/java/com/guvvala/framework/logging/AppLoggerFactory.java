package com.guvvala.framework.logging;

import org.slf4j.LoggerFactory;

/**
 * 
 * @author Guvala
 *
 */
public class AppLoggerFactory {

	public static AppLogger getLogger(String name) {
		AppLogger logger = new AppLogger(LoggerFactory.getLogger(name));
		return logger;
	}

}
