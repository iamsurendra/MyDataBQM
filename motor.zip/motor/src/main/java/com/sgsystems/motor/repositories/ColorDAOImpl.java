package com.sgsystems.motor.repositories;



import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.Color;
/**
 * @author Guvvala
 *
 */
@Repository
public class ColorDAOImpl extends BaseDAOImpl<Color, Long> implements ColorDAO {

	public ColorDAOImpl() {
		super(Color.class);
	}

	
}
