package com.sgsystems.motor.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "user_dealer_view")
@NamedQuery(name = "FIND_DEALER_CODE", query = "SELECT udv.dealerCode FROM UserDealerView udv where udv.userId=:userId")
public class UserDealerView implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "USER_ID")
	private Long userId;

	@Column(name = "MAX_VEHICLES")
	private Integer maxVehicles;

	@Column(name = "DEALER_CODE")
	private String dealerCode;

	@Column(name = "USER_STATUS")
	private int userStatus;

	public static final String FIND_DEALER_CODE = "FIND_DEALER_CODE";

	// getter and Setters

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Integer getMaxVehicles() {
		return maxVehicles;
	}

	public void setMaxVehicles(Integer maxVehicles) {
		this.maxVehicles = maxVehicles;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public int getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(int userStatus) {
		this.userStatus = userStatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserDealerView other = (UserDealerView) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}

}
