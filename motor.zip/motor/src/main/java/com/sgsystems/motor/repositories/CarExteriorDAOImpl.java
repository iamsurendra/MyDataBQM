package com.sgsystems.motor.repositories;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.CarExterior;

@Repository
public class CarExteriorDAOImpl extends BaseDAOImpl<CarExterior, Long> implements CarExteriorDAO {

	public CarExteriorDAOImpl() {
		super(CarExterior.class);
		// TODO Auto-generated constructor stub
	}

}
