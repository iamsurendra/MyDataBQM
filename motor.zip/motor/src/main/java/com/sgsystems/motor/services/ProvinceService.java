package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.Province;

public interface ProvinceService {

	public List<Province> findAllProvinceDetails();
}
