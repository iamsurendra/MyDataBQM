package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.springframework.stereotype.Repository;
import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.CarEngineDetails;

@Repository
public class CarEngineDetailsDAOImpl extends BaseDAOImpl<CarEngineDetails, Long> implements CarEngineDetailsDAO {

	public CarEngineDetailsDAOImpl() {

		super(CarEngineDetails.class);
		// TODO Auto-generated constructor stub
	}

	public List<String> getCarsFuelTypes() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<CarEngineDetails> carenginedetails = criteriaQuery.from(CarEngineDetails.class);
		criteriaQuery.select(carenginedetails.get("fuelType")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

}
