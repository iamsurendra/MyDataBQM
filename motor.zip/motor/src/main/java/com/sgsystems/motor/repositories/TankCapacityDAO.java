package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.TankCapacity;

public interface TankCapacityDAO extends BaseDAO<TankCapacity, Long> {

	public List<String> getTankCapacityList();
}
