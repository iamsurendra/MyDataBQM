package com.sgsystems.motor.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgsystems.motor.constants.CarImageStatus;
import com.sgsystems.motor.models.Image;
import com.sgsystems.motor.models.ImageKey;
import com.sgsystems.motor.repositories.ImageDAO;

@Service
public class ImageServiceImpl implements ImageService {

	@Autowired
	ImageDAO imageDAO;

	@Transactional
	public void create(Image image) {
		CarImageStatus carStatusService = CarImageStatus.fromString(image.getProfileName());
		if(carStatusService!=null){
			image.setProfileId(carStatusService.value);
			imageDAO.create(image);
		}
		
		

	}

	@Transactional
	public void update(Image image) {
		imageDAO.update(image);

	}

	@Transactional
	public void delete(Image image) {
		imageDAO.delete(image);

	}
	
	@Transactional
	public Image findOneImage(Long carId,String imageProfile){
		ImageKey key = new ImageKey();
		key.setCarId(carId);
		key.setProfileName(imageProfile);
		return imageDAO.findOne(key);
	}
	
	
	@Transactional
	public List<String> getImgelistByID(Long Id) {
		return imageDAO.getImgelistByID(Id);

	}

	@Transactional
	public Image findById(Image image) {
		return imageDAO.findOne(image.getImageKey());
	}

	public List<Image> getImageInfolistByID(Long Id) {
		return imageDAO.getImageInfolistByID(Id);
	}

}
