package com.sgsystems.motor.models;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.model.BaseModelListener;

@Entity
@Table(name = "car")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EntityListeners(BaseModelListener.class)
public class Car extends BaseModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	@Column(name = "USER_ID")
	private Long userId;

	@Column(name = "DEALER_CODE")
	private String dealerCode;

	@Column(name = "VIN")
	private String vin;

	@Column(name = "MAKE_ID")
	private Long makeId;

	@Column(name = "NEW")
	@Type(type = "boolean")
	private Boolean newCar;

	@Column(name = "CERTIFIED")
	@Type(type = "boolean")
	private Boolean certified;
	
	@Column(name = "DRIVING_SEAT")
	@Type(type = "boolean")
	private Boolean drivingSeat;

	@Column(name = "YEAR")
	private Integer year;

	@Column(name = "PRICE")
	private BigDecimal price;

	@Column(name = "REDUCED_PRICE")
	private BigDecimal reducedPrice;

	@Column(name = "MILEAGE")
	private Long mileage;

	@Column(name = "SEATING_ID")
	private Long seatingId;

	@Column(name = "TANK_CAPACITY")
	private String tankCapacity;

	@Column(name = "COLOR_ID")
	private Long color;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "STATUS")
	private Integer status;

	@Transient
	private String range;

	@Transient
	private Long count;

	// Getters and setters //

	@OneToOne(mappedBy = "car", cascade = CascadeType.ALL)
	private CarInterior carInterior;

	@OneToOne(mappedBy = "car", cascade = CascadeType.ALL)
	private CarEngineDetails carEngineDetails;

	@Transient
	private List<Image> images = new ArrayList<>();

	public Car() {

	}

	public Car(String range, Long count) {
		super();
		this.range = range;
		this.count = count;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public Long getMakeId() {
		return makeId;
	}

	public void setMakeId(Long makeId) {
		this.makeId = makeId;
	}

	public Boolean getNewCar() {
		return newCar;
	}

	public void setNewCar(Boolean newCar) {
		this.newCar = newCar;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getReducedPrice() {
		return reducedPrice;
	}

	public void setReducedPrice(BigDecimal reducedPrice) {
		this.reducedPrice = reducedPrice;
	}

	public Long getMileage() {
		return mileage;
	}

	public void setMileage(Long mileage) {
		this.mileage = mileage;
	}

	public Long getSeatingId() {
		return seatingId;
	}

	public void setSeatingId(Long seatingId) {
		this.seatingId = seatingId;
	}

	public String getTankCapacity() {
		return tankCapacity;
	}

	public void setTankCapacity(String tankCapacity) {
		this.tankCapacity = tankCapacity;
	}

	public Long getColor() {
		return color;
	}

	public void setColor(Long color) {
		this.color = color;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public CarInterior getCarInterior() {
		return carInterior;
	}

	public void setCarInterior(CarInterior carInterior) {
		this.carInterior = carInterior;
	}

	public CarEngineDetails getCarEngineDetails() {
		return carEngineDetails;
	}

	public void setCarEngineDetails(CarEngineDetails carEngineDetails) {
		this.carEngineDetails = carEngineDetails;
	}

	public String getRange() {
		return range;
	}

	public void setRange(String range) {
		this.range = range;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public Boolean getCertified() {
		return certified;
	}

	public void setCertified(Boolean certified) {
		this.certified = certified;
	}
	
	
	public Boolean getDrivingSeat() {
		return drivingSeat;
	}

	public void setDrivingSeat(Boolean drivingSeat) {
		this.drivingSeat = drivingSeat;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
