
package com.sgsystems.motor.repositories;

import java.util.List;
import java.util.Map;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.Make;

/**
 * @author Guvvala
 *
 */
public interface MakeDAO extends BaseDAO<Make, Long> {

	List<String> getAllCarMakes();

	List<String> getModelsByCarMake(String make);

	List<String> getBodyTypeList();

	Make getMakeInfoByID(Long id);

	Map<String, Long> getCarsBodyTypeCount();

	Map<String, Long> getCarMakesCount();

	 Long getMakersId(String Name, String Model, String bodyType);

	List<Make> getMakeInfoByIDs(List<Long> ids);

	List<String> getBodyStyleByMakeAndModel(String Name, String Model);
	
	List<String> getBodyStyles();
}
