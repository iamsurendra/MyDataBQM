package com.sgsystems.motor.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tank_capacity")
public class TankCapacity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	private Long id;

	@Column(name = "TANK_CAPACITY")
	private String tankCapacity;

	// Getters and setters //

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTankCapacity() {
		return tankCapacity;
	}

	public void setTankCapacity(String tankCapacity) {
		this.tankCapacity = tankCapacity;
	}

}
