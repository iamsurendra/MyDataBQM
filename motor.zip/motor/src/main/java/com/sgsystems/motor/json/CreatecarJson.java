package com.sgsystems.motor.json;

import java.math.BigDecimal;

import com.sgsystems.motor.models.CarEngineDetails;
import com.sgsystems.motor.models.CarExterior;
import com.sgsystems.motor.models.CarInterior;

public class CreatecarJson {

	private Long id;
	private Long userId;
	private String dealerCode;
	private String vin;
	private Long makeId;
	private Boolean newCar;
	private Integer year;
	private String zipCode;
	private BigDecimal price;
	private BigDecimal reducedPrice;
	private Long mileage;
	private Long seatingId;
	private String tankCapacity;
	private Long color;
	private String description;
	private boolean active;

	private CarInterior carInterior = new CarInterior();
	private CarExterior carExterior = new CarExterior();
	private CarEngineDetails carEngineDetails = new CarEngineDetails();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public Long getMakeId() {
		return makeId;
	}

	public void setMakeId(Long makeId) {
		this.makeId = makeId;
	}

	public Boolean getNewCar() {
		return newCar;
	}

	public void setNewCar(Boolean newCar) {
		this.newCar = newCar;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getReducedPrice() {
		return reducedPrice;
	}

	public void setReducedPrice(BigDecimal reducedPrice) {
		this.reducedPrice = reducedPrice;
	}

	public Long getMileage() {
		return mileage;
	}

	public void setMileage(Long mileage) {
		this.mileage = mileage;
	}

	public Long getSeatingId() {
		return seatingId;
	}

	public void setSeatingId(Long seatingId) {
		this.seatingId = seatingId;
	}

	public String getTankCapacity() {
		return tankCapacity;
	}

	public void setTankCapacity(String tankCapacity) {
		this.tankCapacity = tankCapacity;
	}

	public Long getColor() {
		return color;
	}

	public void setColor(Long color) {
		this.color = color;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public CarInterior getCarInterior() {
		return carInterior;
	}

	public void setCarInterior(CarInterior carInterior) {
		this.carInterior = carInterior;
	}

	public CarExterior getCarExterior() {
		return carExterior;
	}

	public void setCarExterior(CarExterior carExterior) {
		this.carExterior = carExterior;
	}

	public CarEngineDetails getCarEngineDetails() {
		return carEngineDetails;
	}

	public void setCarEngineDetails(CarEngineDetails carEngineDetails) {
		this.carEngineDetails = carEngineDetails;
	}

}
