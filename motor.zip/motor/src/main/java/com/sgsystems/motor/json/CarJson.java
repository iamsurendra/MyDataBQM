package com.sgsystems.motor.json;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author VIKAS
 *
 */
public class CarJson {

	private Boolean newCar;
	private Boolean certified;
	private String make;
	private String model;
	private BigDecimal minPrice;
	private BigDecimal maxPrice;
	private Integer toYear;
	private Integer fromYear;
	private Integer rangeMinYear;
	private Integer rangeMaxYear;
	private Long minKiloMeters;
	private Long maxKiloMeters;
	private String bodyType;
	private String engineCc;
	private String engineBhp;
	private String seatingName;
	private String dealerName;
	private Integer sortDetails;
	private Boolean drivingSeat;
	private String vin;
	private Long location;
	private String email;
	private Long province;
	private List<String> cylinders;
	private List<String> transmissions;
	private List<String> fuelTypes;
	private List<String> driveTypes;
	private List<String> features;
	private List<String> interiors;
	private List<String> exteriorColorNames;
	private List<Long> interiorColorIds;
	private List<Long> exteriorColorIds;
	private List<String> trims;
	private Boolean condition;
	private int page = 0;
	private Long userId;
	private Long localFlg;
	private Long languageId;
	private Long cityArea;

	// Getters && Setters

	public Boolean getNewCar() {
		return newCar;
	}

	public void setNewCar(Boolean newCar) {
		this.newCar = newCar;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public BigDecimal getMinPrice() {
		return minPrice;
	}

	public void setMinPrice(BigDecimal minPrice) {
		this.minPrice = minPrice;
	}

	public BigDecimal getMaxPrice() {
		return maxPrice;
	}

	public void setMaxPrice(BigDecimal maxPrice) {
		this.maxPrice = maxPrice;
	}

	public Integer getToYear() {
		return toYear;
	}

	public void setToYear(Integer toYear) {
		this.toYear = toYear;
	}

	public Integer getFromYear() {
		return fromYear;
	}

	public void setFromYear(Integer fromYear) {
		this.fromYear = fromYear;
	}

	public Long getMinKiloMeters() {
		return minKiloMeters;
	}

	public void setMinKiloMeters(Long minKiloMeters) {
		this.minKiloMeters = minKiloMeters;
	}

	public Long getMaxKiloMeters() {
		return maxKiloMeters;
	}

	public void setMaxKiloMeters(Long maxKiloMeters) {
		this.maxKiloMeters = maxKiloMeters;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}

	public List<String> getFeatures() {
		return features;
	}

	public void setFeatures(List<String> features) {
		this.features = features;
	}

	public Boolean getCondition() {
		return condition;
	}

	public void setCondition(Boolean condition) {
		this.condition = condition;
	}

	public List<String> getExteriorColorNames() {
		return exteriorColorNames;
	}

	public void setExteriorColorNames(List<String> exteriorColorNames) {
		this.exteriorColorNames = exteriorColorNames;
	}

	public List<String> getTrims() {
		return trims;
	}

	public void setTrims(List<String> trims) {
		this.trims = trims;
	}

	public Integer getRangeMinYear() {
		return rangeMinYear;
	}

	public void setRangeMinYear(Integer rangeMinYear) {
		this.rangeMinYear = rangeMinYear;
	}

	public Integer getRangeMaxYear() {
		return rangeMaxYear;
	}

	public void setRangeMaxYear(Integer rangeMaxYear) {
		this.rangeMaxYear = rangeMaxYear;
	}

	public String getEngineCc() {
		return engineCc;
	}

	public void setEngineCc(String engineCc) {
		this.engineCc = engineCc;
	}

	public String getEngineBhp() {
		return engineBhp;
	}

	public void setEngineBhp(String engineBhp) {
		this.engineBhp = engineBhp;
	}

	public List<String> getInteriors() {
		return interiors;
	}

	public void setInteriors(List<String> interiors) {
		this.interiors = interiors;
	}

	public String getSeatingName() {
		return seatingName;
	}

	public void setSeatingName(String seatingName) {
		this.seatingName = seatingName;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public Integer getSortDetails() {
		return sortDetails;
	}

	public void setSortDetails(Integer sortDetails) {
		this.sortDetails = sortDetails;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public List<Long> getInteriorColorIds() {
		return interiorColorIds;
	}

	public void setInteriorColorIds(List<Long> interiorColorIds) {
		this.interiorColorIds = interiorColorIds;
	}

	public List<Long> getExteriorColorIds() {
		return exteriorColorIds;
	}

	public void setExteriorColorIds(List<Long> exteriorColorIds) {
		this.exteriorColorIds = exteriorColorIds;
	}

	public Boolean getDrivingSeat() {
		return drivingSeat;
	}

	public void setDrivingSeat(Boolean drivingSeat) {
		this.drivingSeat = drivingSeat;
	}

	public Boolean getCertified() {
		return certified;
	}

	public void setCertified(Boolean certified) {
		this.certified = certified;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public List<String> getCylinders() {
		return cylinders;
	}

	public void setCylinders(List<String> cylinders) {
		this.cylinders = cylinders;
	}

	public List<String> getTransmissions() {
		return transmissions;
	}

	public void setTransmissions(List<String> transmissions) {
		this.transmissions = transmissions;
	}

	public List<String> getFuelTypes() {
		return fuelTypes;
	}

	public void setFuelTypes(List<String> fuelTypes) {
		this.fuelTypes = fuelTypes;
	}

	public List<String> getDriveTypes() {
		return driveTypes;
	}

	public void setDriveTypes(List<String> driveTypes) {
		this.driveTypes = driveTypes;
	}

	public Long getProvince() {
		return province;
	}

	public void setProvince(Long province) {
		this.province = province;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getLocalFlg() {
		return localFlg;
	}

	public void setLocalFlg(Long localFlg) {
		this.localFlg = localFlg;
	}

	public Long getLanguageId() {
		return languageId;
	}

	public void setLanguageId(Long languageId) {
		this.languageId = languageId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getCityArea() {
		return cityArea;
	}

	public void setCityArea(Long cityArea) {
		this.cityArea = cityArea;
	}

	public Long getLocation() {
		return location;
	}

	public void setLocation(Long location) {
		this.location = location;
	}

}