package com.sgsystems.motor.services;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgsystems.motor.models.RecentViewCars;
import com.sgsystems.motor.models.RecentViewCarsKey;
import com.sgsystems.motor.repositories.RecentViewCarsDAO;

@Service
public class RecentViewCarsServiceImpl implements RecentViewCarsService {

	@Autowired
	RecentViewCarsDAO recentViewCarsDAO;

	@Transactional
	@Override
	public void createRecentviews(RecentViewCars RecentViewCars) {
		RecentViewCarsKey key = new RecentViewCarsKey();
		key.setCarId(RecentViewCars.getCarId());
		key.setUserId(RecentViewCars.getUserId());
		RecentViewCars recentcars = new RecentViewCars();
		recentcars.setRecentViewCarsKey(key);
		recentcars.setHistory(RecentViewCars.getHistory());
		recentcars.setCreatedDate(new Date());
		recentcars.setHistory(true);
		if (recentViewCarsDAO.findOne(key) == null) {
			recentViewCarsDAO.create(recentcars);
		} else {

		}
	}

	@Transactional
	public List<RecentViewCars> getRecentViewCars(Long Id) {
		return recentViewCarsDAO.getRecenViewCars(Id);
	}

	@Transactional
	public List<String> getCarIdByuserID(Long id) {
		return recentViewCarsDAO.getCarIdByuserID(id);
	}
}
