package com.sgsystems.motor.services;

import org.springframework.stereotype.Service;

@Service
public class UserDealerViewServiceImpl implements UserDealerViewService {

}
