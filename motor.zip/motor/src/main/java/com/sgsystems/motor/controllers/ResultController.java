package com.sgsystems.motor.controllers;

import java.lang.reflect.Field;
import java.util.List;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.guvvala.framework.util.Interior;
import com.sgsystems.motor.models.CarAlerts;
import com.sgsystems.motor.models.CarDetailsView;
import com.sgsystems.motor.models.UserActivities;
import com.sgsystems.motor.models.UserDetailsView;
import com.sgsystems.motor.services.CarAlertService;
import com.sgsystems.motor.services.CarDetailsViewService;
import com.sgsystems.motor.services.CarService;
import com.sgsystems.motor.services.UserActivitesService;
import com.sgsystems.motor.services.UserDetailsViewService;
import com.sgsystems.motor.services.UserLocaleDetailsViewService;
import com.sgsystems.motor.services.UserService;

@RestController
@RequestMapping("result")
public class ResultController {

	@Autowired
	UserActivitesService userActivitesService;

	@Autowired
	CarDetailsViewService cardetailsViewService;

	@Autowired
	CarAlertService carAlertService;

	@Autowired
	UserService userService;

	@Autowired
	CarService carService;

	@Autowired
	UserLocaleDetailsViewService userLocaleDetailsViewService;

	@Autowired
	UserDetailsViewService userDetailsViewService;

	/*
	 * Adding Car as favorite to the user
	 */

	@RequestMapping(value = "/addToFavorites", method = RequestMethod.POST)
	public List<Long> addFavorites(@RequestBody UserActivities userActivities) {
		userActivitesService.createFavoriteCar(userActivities);
		return userActivitesService.findAllFavioritesByUser(userActivities.getUserId());
	}

	/**
	 * Removing car as favorites from user
	 * 
	 * @param userActivities
	 * @return
	 */
	@RequestMapping(value = "/removeFromFavorites", method = RequestMethod.POST)
	public List<Long> removeFavorites(@RequestBody UserActivities userActivities) {
		userActivitesService.deleteCarfromFavorite(userActivities);
		return userActivitesService.findAllFavioritesByUser(userActivities.getUserId());

	}

	/*
	 * Retrieving the favorites by passing userId
	 */
	@RequestMapping(value = "findAllFavorites/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Long> findAllFavioritesByUser(@PathVariable("userId") Long userId) {
		return userActivitesService.findAllFavioritesByUser(userId);

	}

	/*
	 * Retrieving the carInfo by passing user List of carIds
	 */

	@RequestMapping(value = "/compare", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<CarDetailsView> carViewDetailsById(@RequestBody CarDetailsView carDetailsView) throws IllegalAccessException {
		
		List<CarDetailsView> carDetails = cardetailsViewService.getCarInfoByID(carDetailsView.getCarIds(),carDetailsView.getLanguageId());
		for (CarDetailsView carDetail : carDetails) {
			Field[] fields = FieldUtils.getFieldsWithAnnotation(carDetail.getClass(), Interior.class);
			for (Field field : fields) {
				field.setAccessible(true);
				Object value = field.get(carDetail);
				Interior interior = field.getAnnotation(Interior.class);
				if (value != null && value instanceof Boolean && (Boolean) value) {
					if (carDetail.getInteriorCols().size() >= 5) {
						break;
					} else {
						carDetail.getInteriorCols().add(interior.name());
					}
				}
			}
		}
		return carDetails;
	}

	/**
	 * create Alert
	 */
	@RequestMapping(value = "/createCarAlerts", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public CarAlerts createcarAlert(@RequestBody CarAlerts carAlerts) {
		return carAlertService.createAlert(carAlerts);
	}

	/*
	 * count of car by UserId
	 */
	@RequestMapping(value = "carCount/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Long countOfCarByUserId(@PathVariable("id") Long userId) {
		return carService.countOfCarsByUserId(userId);
	}

	@RequestMapping(value = "checkDealercarsCount/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean checkDealerMaxcars(@PathVariable("id") Long userId) {
		return carService.checkDealerMaxcars(userId);
	}

	@RequestMapping(value = "getAllEnglishDetailsUsers", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<UserDetailsView> getAllEnglishUserDetails() {
		return userDetailsViewService.getAllEnglishUserDetails();
	}
}
