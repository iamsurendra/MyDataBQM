package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.UserDetailsView;
import com.sgsystems.motor.models.UserDetailsViewKey;

public interface UserDetailsViewDAO extends BaseDAO<UserDetailsView, UserDetailsViewKey>{

	UserDetailsView getUserDetailsInfoByUserId(Long userId,Long laguageId);
	 
	List<UserDetailsView> getAllEnglishUserDetails();
}
