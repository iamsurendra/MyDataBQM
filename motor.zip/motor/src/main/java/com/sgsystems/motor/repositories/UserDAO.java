package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.User;

public interface UserDAO extends BaseDAO<User, Long> {

	public User getUser(Long userId);

	boolean uniqueUserName(String userName);

	boolean validateEmail(String email);

	public User getuserInfoByUserId(Long UserId);

	User getEmail(String eMail);

}
