package com.sgsystems.motor.services;

import java.util.List;
import java.util.Map;

import com.sgsystems.motor.models.Make;

public interface MakeService {

	List<String> getAllCarMakes();

	List<String> getModelsByCarMake(String make);

	public Map<String, Long> getCarsBodyTypeCount();

	public Map<String, Long> getCarMakesCount();

	List<String> getBodyTypeList();

	Long getMakersId(String Name, String Model, String bodyType);

	Make getMakeInfoByID(Long id);
	
	List<String> getBodyStyleByMakeAndModel(String Name, String Model);
	
	List<String> getBodyStyles();



}
