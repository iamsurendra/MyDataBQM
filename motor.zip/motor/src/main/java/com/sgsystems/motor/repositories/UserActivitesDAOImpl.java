package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;

import com.sgsystems.motor.models.UserActivities;
import com.sgsystems.motor.models.UserActivityKey;

@Repository
public class UserActivitesDAOImpl extends BaseDAOImpl<UserActivities, UserActivityKey> implements UserActivitesDAO {

	public UserActivitesDAOImpl() {
		super(UserActivities.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Long> findAllFavioritesByUser(Long userId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
		Root<UserActivities> favoritesRoot = criteriaQuery.from(UserActivities.class);
		criteriaQuery.select(favoritesRoot.get("carId")).distinct(true);
		criteriaQuery.where(criteriaBuilder.and(criteriaBuilder.equal(favoritesRoot.get("userId"), userId),
				criteriaBuilder.equal(favoritesRoot.get("status"), Boolean.TRUE)));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public UserActivities getCarCountByUserID(Long Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserActivities> query = criteriaBuilder.createQuery(UserActivities.class);
		Root<UserActivities> root = query.from(UserActivities.class);
		query.select(criteriaBuilder.construct(UserActivities.class, criteriaBuilder.count(root.get("carId"))));
		query.where(criteriaBuilder.and(criteriaBuilder.equal(root.get("userId"), Id),
				criteriaBuilder.equal(root.get("status"), Boolean.TRUE)));

		return entityManager.createQuery(query).getSingleResult();
	}


	public List<UserActivities> getCarInfoById(Long Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserActivities> query = criteriaBuilder.createQuery(UserActivities.class);
		Root<UserActivities> root = query.from(UserActivities.class);
		query.select(root);
		query.where(criteriaBuilder.and(criteriaBuilder.equal(root.get("userId"), Id),criteriaBuilder.equal(root.get("status"), Boolean.TRUE)));

		return entityManager.createQuery(query).getResultList();
	}
	
	public List<UserActivities> getCarInfoByCarId(Long Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserActivities> query = criteriaBuilder.createQuery(UserActivities.class);
		Root<UserActivities> root = query.from(UserActivities.class);
		query.select(root);
		query.where((criteriaBuilder.equal(root.get("carId"), Id)));

		return entityManager.createQuery(query).getResultList();
	}
	
	public List<UserActivities> getCarInfoByCarIds(List<Long> Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserActivities> query = criteriaBuilder.createQuery(UserActivities.class);
		Root<UserActivities> root = query.from(UserActivities.class);
		query.select(root);
		query.where(root.get("carId").in(Id));

		return entityManager.createQuery(query).getResultList();
	}

}
