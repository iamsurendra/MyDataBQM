package com.sgsystems.motor.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "car_exterior")
public class CarExterior implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CAR_ID")
	private Long carId;

	@Column(name = "ALLOY_WHEELS")
	@Type(type = "boolean")
	private Boolean allowWheels;

	@Column(name = "SPOILER")
	@Type(type = "boolean")
	private Boolean spoiler;

	@Column(name = "HEAD_LIGHTS")
	@Type(type = "boolean")
	private Boolean headLights;

	@Column(name = "PROJECTOR_LAMPS")
	@Type(type = "boolean")
	private Boolean projectLamps;

	@Column(name = "SUNROOF_MOONROOF")
	@Type(type = "boolean")
	private Boolean sunMoonRoof;

	@Column(name = "AMBIENT_LIGHTING")
	@Type(type = "boolean")
	private Boolean ambientLight;

	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "car_id", referencedColumnName = "id")
	@MapsId
	private Car car;

	// Getters and Setters //

	public Long getCarId() {
		return carId;
	}

	public void setCarId(Long carId) {
		this.carId = carId;
	}

	public Boolean getAllowWheels() {
		return allowWheels;
	}

	public void setAllowWheels(Boolean allowWheels) {
		this.allowWheels = allowWheels;
	}

	public Boolean getSpoiler() {
		return spoiler;
	}

	public void setSpoiler(Boolean spoiler) {
		this.spoiler = spoiler;
	}

	public Boolean getHeadLights() {
		return headLights;
	}

	public void setHeadLights(Boolean headLights) {
		this.headLights = headLights;
	}

	public Boolean getProjectLamps() {
		return projectLamps;
	}

	public void setProjectLamps(Boolean projectLamps) {
		this.projectLamps = projectLamps;
	}

	public Boolean getSunMoonRoof() {
		return sunMoonRoof;
	}

	public void setSunMoonRoof(Boolean sunMoonRoof) {
		this.sunMoonRoof = sunMoonRoof;
	}

	public Boolean getAmbientLight() {
		return ambientLight;
	}

	public void setAmbientLight(Boolean ambientLight) {
		this.ambientLight = ambientLight;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((carId == null) ? 0 : carId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CarExterior other = (CarExterior) obj;
		if (carId == null) {
			if (other.carId != null)
				return false;
		} else if (!carId.equals(other.carId))
			return false;
		return true;
	}

}
