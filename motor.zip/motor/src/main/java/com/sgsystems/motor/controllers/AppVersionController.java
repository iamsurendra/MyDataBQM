
package com.sgsystems.motor.controllers;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.guvvala.framework.logging.AppLogger;
import com.guvvala.framework.logging.Log;

/**
 * @author Guvvala
 *
 */
@RestController
@RequestMapping("app")
public class AppVersionController {

	private final static String RELEASE_KEY = "release";
	private final static String TIMESTAMP_KEY = "timeStamp";
	private final static String RELEASE_INFO = "releaseInfo";
	private static @Log AppLogger logger;
	@Autowired
	ServletContext context;

	/**
	 * Adding New Car
	 */
	@RequestMapping(value = "/version", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, String> getBuildVersion() {
		Map<String, String> versionMap = null;
		try {
			versionMap = (Map<String, String>) context.getAttribute(RELEASE_INFO);
			if (versionMap != null) {
				return versionMap;
			}
			versionMap = new HashMap<>();
			InputStream manifestStream = context.getResourceAsStream("/META-INF/MANIFEST.MF");
			Manifest manifest = new Manifest(manifestStream);
			Attributes attributes = manifest.getMainAttributes();
			versionMap.put(RELEASE_KEY, attributes.getValue(RELEASE_KEY));
			versionMap.put(TIMESTAMP_KEY, attributes.getValue(TIMESTAMP_KEY));
			context.setAttribute(RELEASE_INFO, versionMap);
		} catch (Exception e) {
			logger.error(e);
		}
		return versionMap;
	}

}
