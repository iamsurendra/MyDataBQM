package com.sgsystems.motor.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "area_city")
public class AreaCity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long Id;

	@Column(name = "PROVINCE_ID")
	private Long provinceId;

	@Column(name = "CITY_AREA")
	private String cityArea;

	@Column(name = "CITY_AREA_DARI")
	private String cityAreaDari;

	@Column(name = "CITY_AREA_PASHTO")
	private String cityAreaPashto;

	// getters and setters
	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public Long getProvinceId() {
		return provinceId;
	}

	public void setProvinceId(Long provinceId) {
		this.provinceId = provinceId;
	}

	public String getCityArea() {
		return cityArea;
	}

	public void setCityArea(String cityArea) {
		this.cityArea = cityArea;
	}

	public String getCityAreaDari() {
		return cityAreaDari;
	}

	public void setCityAreaDari(String cityAreaDari) {
		this.cityAreaDari = cityAreaDari;
	}

	public String getCityAreaPashto() {
		return cityAreaPashto;
	}

	public void setCityAreaPashto(String cityAreaPashto) {
		this.cityAreaPashto = cityAreaPashto;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Id == null) ? 0 : Id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AreaCity other = (AreaCity) obj;
		if (Id == null) {
			if (other.Id != null)
				return false;
		} else if (!Id.equals(other.Id))
			return false;
		return true;
	}

}
