package com.sgsystems.motor.constants;

import com.guvvala.framework.util.BasePropertyEnum;

public enum MailTemplateEnum implements BasePropertyEnum {

	FORGOT_PASSWORD("forgetPassword", "forgetPassword"),
	CREATE_USER("createUser", "createUser"),
	UPDATE_USER("updateUser", "updateUser"),
	MAIL_TO_OWNER("mailToOwner","mailToOwner"),
	MAIL_FOR_CAR_ALERTS("mailForCarAlerts","mailForCarAlerts"),
	MAIL_TO_USER_CONFORMATION("mailToUserConformation", "mailToUserConformation"),
	RESET_PASSWORD("resetPassword","resetPassword"),
	CREATE_DEALER("createDealer","createDealer");
	
	public String subject;
	public String filename;
	public String bundleName = "com.sgsystems.motor.mails";

	private MailTemplateEnum(String subject, String filename) {
		this.subject = subject;
		this.filename = filename;
	}

	@Override
	public String getBundle() {
		return bundleName;
	}

	@Override
	public String getKey() {
		return subject;
	}

	@Override
	public Integer getStatusCode() {
		return 200;
	}

}
