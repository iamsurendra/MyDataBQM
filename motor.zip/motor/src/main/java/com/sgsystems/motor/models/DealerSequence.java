package com.sgsystems.motor.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

@Entity
@Table(name = "dealer_sequence")
public class DealerSequence {

	public static final String CURRENT_SEQUENCE = "select dealerSeq(?1) as sequence";

	@Id
	@Column(name = "name")
	private String name;

	@Column(name = "increment")
	private Long increment;

	@Column(name = "min_value")
	private Long minValue;

	@Column(name = "max_value")
	private Long maxValue;

	@Column(name = "cur_value")
	private Long curValue;

	@Column(name = "dealer_cur_code")
	private String currentCode;

	public DealerSequence(String name) {
		super();
		this.name = name;
		this.currentCode = name + " " + 1;
	}
	@PrePersist
	public void prePersist(){
		this.increment=1l;	
		this.minValue=0l;
		this.maxValue=10000l;
		this.curValue=1l;
	}

	public DealerSequence() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getIncrement() {
		return increment;
	}

	public void setIncrement(long increment) {
		this.increment = increment;
	}

	public long getMinValue() {
		return minValue;
	}

	public void setMinValue(long minValue) {
		this.minValue = minValue;
	}

	public long getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(long maxValue) {
		this.maxValue = maxValue;
	}

	public long getCurValue() {
		return curValue;
	}

	public void setCurValue(long curValue) {
		this.curValue = curValue;
	}

	public String getCurrentCode() {
		return currentCode;
	}

	public void setCurrentCode(String currentCode) {
		this.currentCode = currentCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DealerSequence other = (DealerSequence) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}
