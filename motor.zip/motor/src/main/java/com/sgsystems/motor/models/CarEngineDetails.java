package com.sgsystems.motor.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "car_engine_details")
public class CarEngineDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "CAR_ID")
	private Long id;

	@Column(name = "CC_ID")
	private Long ccId;

	@Column(name = "BHP_ID")
	private Long bhpId;

	@Column(name = "FUEL_TYPE")
	private String fuelType;

	@Column(name = "TRANSMISSION")
	private String transmission;

	@Column(name = "NO_OF_CYLINDERS")
	private String noOfCylinder;

	@Column(name = "DRIVE_TYPE")
	private String driveType;

	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "car_id", referencedColumnName = "id")
	@MapsId
	private Car car;

	// Getters and Setters //

	public Long getCcId() {
		return ccId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setCcId(Long ccId) {
		this.ccId = ccId;
	}

	public Long getBhpId() {
		return bhpId;
	}

	public void setBhpId(Long bhpId) {
		this.bhpId = bhpId;
	}

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public String getTransmission() {
		return transmission;
	}

	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}

	public String getNoOfCylinder() {
		return noOfCylinder;
	}

	public void setNoOfCylinder(String noOfCylinder) {
		this.noOfCylinder = noOfCylinder;
	}

	public String getDriveType() {
		return driveType;
	}

	public void setDriveType(String driveType) {
		this.driveType = driveType;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CarEngineDetails other = (CarEngineDetails) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
