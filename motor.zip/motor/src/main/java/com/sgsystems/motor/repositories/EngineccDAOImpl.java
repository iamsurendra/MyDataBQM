package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.Enginecc;

/**
 * @author Guvvala
 *
 */
@Repository
public class EngineccDAOImpl extends BaseDAOImpl<Enginecc, Long> implements EngineccDAO {

	public EngineccDAOImpl() {
		super(Enginecc.class);
	}

	public List<String> getEngineccList() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> cQuery = criteriaBuilder.createQuery(String.class);
		Root<Enginecc> root = cQuery.from(Enginecc.class);
		cQuery.select(root.get("name")).distinct(true).orderBy(criteriaBuilder.asc(root.get("name")));
		return entityManager.createQuery(cQuery).getResultList();
	}

}
