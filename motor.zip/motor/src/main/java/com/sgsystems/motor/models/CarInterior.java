package com.sgsystems.motor.models;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "car_interior")
public class CarInterior implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CAR_ID")
	private Long id;

	@Column(name = "AC_FRONT")
	@Type(type = "boolean")
	private Boolean acFront;

	@Column(name = "AC_REAR")
	@Type(type = "boolean")
	private Boolean acRear;

	@Column(name = "NAVIGATION")
	@Type(type = "boolean")
	private Boolean navigation;

	@Column(name = "POWER_LOCKS")
	@Type(type = "boolean")
	private Boolean powerLocks;

	@Column(name = "KEYLESS_ENTRY")
	@Type(type = "boolean")
	private Boolean keylessEntry;

	@Column(name = "CRUISE_CONTROL")
	@Type(type = "boolean")
	private Boolean cruiseControl;

	@Column(name = "POWER_STEERING")
	@Type(type = "boolean")
	private Boolean powerSteering;

	@Column(name = "INTEGRATED_PHONE")
	@Type(type = "boolean")
	private Boolean integratedPhone;

	@Column(name = "BUCKET_SEAT")
	@Type(type = "boolean")
	private Boolean bucketSeat;

	@Column(name = "LEATHER_INTERIOR")
	@Type(type = "boolean")
	private Boolean leatherSeats;

	@Column(name = "AIRBAG_DRIVER")
	@Type(type = "boolean")
	private Boolean airbagDriver;

	@Column(name = "AIRBAG_PASSENGER")
	@Type(type = "boolean")
	private Boolean airbagPassenger;

	@Column(name = "AIRBAG_SIDE")
	@Type(type = "boolean")
	private Boolean airbagSide;

	@Column(name = "ANTI_LOCK_BRAKES")
	@Type(type = "boolean")
	private Boolean antiLockBrakes;

	@Column(name = "FOG_LIGHTS")
	@Type(type = "boolean")
	private Boolean fogLights;

	@Column(name = "REAR_WINDOW_DEFROSTER")
	@Type(type = "boolean")
	private Boolean rearWindowDefroster;

	@Column(name = "REAR_WINDOW_WIPER")
	@Type(type = "boolean")
	private Boolean rearWindowWiper;

	@Column(name = "TINTED_GLASS")
	@Type(type = "boolean")
	private Boolean tintedGlass;

	@Column(name = "FM_STEREO")
	@Type(type = "boolean")
	private Boolean fmStereo;

	@Column(name = "CASSETTE_PLAYER")
	@Type(type = "boolean")
	private Boolean cassettePlayer;

	@Column(name = "CD_SINGLE_DISC")
	@Type(type = "boolean")
	private Boolean cdSingleDisc;

	@Column(name = "CD_MULTI_DISC")
	@Type(type = "boolean")
	private Boolean cdMultiDisc;

	@Column(name = "MP3_SINGLE_DISC")
	@Type(type = "boolean")
	private Boolean mp3SingleDisc;

	@Column(name = "PREMIUM_SOUND")
	@Type(type = "boolean")
	private Boolean premiumSound;

	@Column(name = "DVD_SYSTEM")
	@Type(type = "boolean")
	private Boolean dvdSystem;

	@Column(name = "BACKUP_CAMERA")
	@Type(type = "boolean")
	private Boolean backUpCamera;

	@Column(name = "ALLOY_WHEELS")
	@Type(type = "boolean")
	private Boolean alloyWheels;

	@Column(name = "KEYLESS_START")
	@Type(type = "boolean")
	private Boolean keyLessStart;

	@Column(name = "MOONROOF_SUNROOF")
	@Type(type = "boolean")
	private Boolean moonroofSunroof;

	@Column(name = "THIRD_ROW_SEATS")
	@Type(type = "boolean")
	private Boolean thirdRowSeats;
	
	@Column(name = "ALARM")
	@Type(type = "boolean")
	private Boolean alarm;
	
	@Column(name = "POWER_SEATS")
	@Type(type = "boolean")
	private Boolean powerSeats;
	
	@Column(name = "MEMORY_SEATS")
	@Type(type = "boolean")
	private Boolean memorySeats;
	
	@Column(name = "POWER_WINDOWS")
	@Type(type = "boolean")
	private Boolean powerWindows;
	
	@Column(name = "COLOR_ID")
	private Long color;
	

	@JsonIgnore
	@OneToOne(cascade = CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "CAR_ID", referencedColumnName = "ID")
	@MapsId
	private Car car;

	// Getters and Setters //

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

		
	public Boolean getAcFront() {
		return acFront;
	}

	public void setAcFront(Boolean acFront) {
		this.acFront = acFront;
	}

	public Boolean getAcRear() {
		return acRear;
	}

	public void setAcRear(Boolean acRear) {
		this.acRear = acRear;
	}

	public Boolean getNavigation() {
		return navigation;
	}

	public void setNavigation(Boolean navigation) {
		this.navigation = navigation;
	}

	public Boolean getPowerLocks() {
		return powerLocks;
	}

	public void setPowerLocks(Boolean powerLocks) {
		this.powerLocks = powerLocks;
	}

	public Boolean getKeylessEntry() {
		return keylessEntry;
	}

	public void setKeylessEntry(Boolean keylessEntry) {
		this.keylessEntry = keylessEntry;
	}

	public Boolean getCruiseControl() {
		return cruiseControl;
	}

	public void setCruiseControl(Boolean cruiseControl) {
		this.cruiseControl = cruiseControl;
	}

	public Boolean getPowerSteering() {
		return powerSteering;
	}

	public void setPowerSteering(Boolean powerSteering) {
		this.powerSteering = powerSteering;
	}

	public Boolean getIntegratedPhone() {
		return integratedPhone;
	}

	public void setIntegratedPhone(Boolean integratedPhone) {
		this.integratedPhone = integratedPhone;
	}

	public Boolean getBucketSeat() {
		return bucketSeat;
	}

	public void setBucketSeat(Boolean bucketSeat) {
		this.bucketSeat = bucketSeat;
	}

	
	public Boolean getLeatherSeats() {
		return leatherSeats;
	}

	public void setLeatherSeats(Boolean leatherSeats) {
		this.leatherSeats = leatherSeats;
	}

	public Boolean getAirbagDriver() {
		return airbagDriver;
	}

	public void setAirbagDriver(Boolean airbagDriver) {
		this.airbagDriver = airbagDriver;
	}

	public Boolean getAirbagPassenger() {
		return airbagPassenger;
	}

	public void setAirbagPassenger(Boolean airbagPassenger) {
		this.airbagPassenger = airbagPassenger;
	}

	public Boolean getAirbagSide() {
		return airbagSide;
	}

	public void setAirbagSide(Boolean airbagSide) {
		this.airbagSide = airbagSide;
	}

	public Boolean getAntiLockBrakes() {
		return antiLockBrakes;
	}

	public void setAntiLockBrakes(Boolean antiLockBrakes) {
		this.antiLockBrakes = antiLockBrakes;
	}

	public Boolean getFogLights() {
		return fogLights;
	}

	public void setFogLights(Boolean fogLights) {
		this.fogLights = fogLights;
	}

	public Boolean getRearWindowDefroster() {
		return rearWindowDefroster;
	}

	public void setRearWindowDefroster(Boolean rearWindowDefroster) {
		this.rearWindowDefroster = rearWindowDefroster;
	}

	public Boolean getRearWindowWiper() {
		return rearWindowWiper;
	}

	public void setRearWindowWiper(Boolean rearWindowWiper) {
		this.rearWindowWiper = rearWindowWiper;
	}

	public Boolean getTintedGlass() {
		return tintedGlass;
	}

	public void setTintedGlass(Boolean tintedGlass) {
		this.tintedGlass = tintedGlass;
	}

	public Boolean getFmStereo() {
		return fmStereo;
	}

	public void setFmStereo(Boolean fmStereo) {
		this.fmStereo = fmStereo;
	}

	public Boolean getCassettePlayer() {
		return cassettePlayer;
	}

	public void setCassettePlayer(Boolean cassettePlayer) {
		this.cassettePlayer = cassettePlayer;
	}

	public Boolean getCdSingleDisc() {
		return cdSingleDisc;
	}

	public void setCdSingleDisc(Boolean cdSingleDisc) {
		this.cdSingleDisc = cdSingleDisc;
	}

	public Boolean getCdMultiDisc() {
		return cdMultiDisc;
	}

	public void setCdMultiDisc(Boolean cdMultiDisc) {
		this.cdMultiDisc = cdMultiDisc;
	}

	public Boolean getMp3SingleDisc() {
		return mp3SingleDisc;
	}

	public void setMp3SingleDisc(Boolean mp3SingleDisc) {
		this.mp3SingleDisc = mp3SingleDisc;
	}

	public Boolean getPremiumSound() {
		return premiumSound;
	}

	public void setPremiumSound(Boolean premiumSound) {
		this.premiumSound = premiumSound;
	}

	public Boolean getDvdSystem() {
		return dvdSystem;
	}

	public void setDvdSystem(Boolean dvdSystem) {
		this.dvdSystem = dvdSystem;
	}

	public Boolean getBackUpCamera() {
		return backUpCamera;
	}

	public void setBackUpCamera(Boolean backUpCamera) {
		this.backUpCamera = backUpCamera;
	}

	public Boolean getAlloyWheels() {
		return alloyWheels;
	}

	public void setAlloyWheels(Boolean alloyWheels) {
		this.alloyWheels = alloyWheels;
	}

	public Boolean getKeyLessStart() {
		return keyLessStart;
	}

	public void setKeyLessStart(Boolean keyLessStart) {
		this.keyLessStart = keyLessStart;
	}

	public Boolean getMoonroofSunroof() {
		return moonroofSunroof;
	}

	public void setMoonroofSunroof(Boolean moonroofSunroof) {
		this.moonroofSunroof = moonroofSunroof;
	}

	public Boolean getThirdRowSeats() {
		return thirdRowSeats;
	}

	public void setThirdRowSeats(Boolean thirdRowSeats) {
		this.thirdRowSeats = thirdRowSeats;
	}

	public Boolean getAlarm() {
		return alarm;
	}

	public void setAlarm(Boolean alarm) {
		this.alarm = alarm;
	}

	public Boolean getPowerSeats() {
		return powerSeats;
	}

	public void setPowerSeats(Boolean powerSeats) {
		this.powerSeats = powerSeats;
	}

	public Boolean getMemorySeats() {
		return memorySeats;
	}

	public void setMemorySeats(Boolean memorySeats) {
		this.memorySeats = memorySeats;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public Long getColor() {
		return color;
	}

	public void setColor(Long color) {
		this.color = color;
	}
	
	

	public Boolean getPowerWindows() {
		return powerWindows;
	}

	public void setPowerWindows(Boolean powerWindows) {
		this.powerWindows = powerWindows;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CarInterior other = (CarInterior) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
