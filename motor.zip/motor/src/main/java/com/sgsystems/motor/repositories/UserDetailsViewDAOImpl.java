package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.constants.LanguageEnum;
import com.sgsystems.motor.models.UserDetailsView;
import com.sgsystems.motor.models.UserDetailsViewKey;

@Repository
public class UserDetailsViewDAOImpl extends BaseDAOImpl<UserDetailsView, UserDetailsViewKey> implements UserDetailsViewDAO {

	public UserDetailsViewDAOImpl() {
		super(UserDetailsView.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public UserDetailsView getUserDetailsInfoByUserId(Long userId ,Long laguageId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserDetailsView> criteriaQuery = criteriaBuilder.createQuery(UserDetailsView.class);
		Root<UserDetailsView> root = criteriaQuery.from(UserDetailsView.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal(root.get("userId"), userId),
				criteriaBuilder.equal(root.get("languageId"), laguageId));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}

	@Override
	public List<UserDetailsView> getAllEnglishUserDetails() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserDetailsView> criteriaQuery = criteriaBuilder.createQuery(UserDetailsView.class);
		Root<UserDetailsView> root = criteriaQuery.from(UserDetailsView.class);
		/*criteriaQuery.select(root)
				.where(criteriaBuilder.and(criteriaBuilder.equal(root.get("languageId"), LanguageEnum.EN.value),
						criteriaBuilder.isNotNull(root.get("dealerId"))));*/
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal(root.get("languageId"), LanguageEnum.EN.value));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

}
