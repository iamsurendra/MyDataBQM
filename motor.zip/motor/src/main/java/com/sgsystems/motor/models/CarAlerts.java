package com.sgsystems.motor.models;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "user_car_alerts")
public class CarAlerts implements Serializable {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID", insertable = false, updatable = false)
	private Long id;

	@Column(name = "MAKE")
	private String make;

	@Column(name = "MODEL")
	private String model;

	@Column(name = "FROM_YEAR")
	private Long fromYear;

	@Column(name = "TO_YEAR")
	private Long toYear;

	@Column(name = "MIN_PRICE")
	private Long minPrice;

	@Column(name = "MAX_PRICE")
	private Long maxPrice;

	@Column(name = "MIN_MILEAGE")
	private Long minMileage;

	@Column(name = "MAX_MILEAGE")
	private Long maxMileage;

	@Column(name = "CITY_AREA")
	private String cityArea;

	@Column(name = "USER_ID")
	private Long userId;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "STATUS")
	private Long status;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "PROVINCE")
	private String province;

	@Transient
	private Long count;

	public CarAlerts(Long userId, String model, String make) {

		this.userId = userId;
		this.model = model;
		this.make = make;
	}

	public CarAlerts() {

	}

	// getters and setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Long getMinPrice() {
		return minPrice;
	}

	public void setMinPrice(Long minPrice) {
		this.minPrice = minPrice;
	}

	public Long getMaxPrice() {
		return maxPrice;
	}

	public void setMaxPrice(Long maxPrice) {
		this.maxPrice = maxPrice;
	}

	public Long getMinMileage() {
		return minMileage;
	}

	public void setMinMileage(Long minMileage) {
		this.minMileage = minMileage;
	}

	public Long getMaxMileage() {
		return maxMileage;
	}

	public void setMaxMileage(Long maxMileage) {
		this.maxMileage = maxMileage;
	}

	public String getCityArea() {
		return cityArea;
	}

	public void setCityArea(String cityArea) {
		this.cityArea = cityArea;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public Long getFromYear() {
		return fromYear;
	}

	public void setFromYear(Long fromYear) {
		this.fromYear = fromYear;
	}

	public Long getToYear() {
		return toYear;
	}

	public void setToYear(Long toYear) {
		this.toYear = toYear;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

}
