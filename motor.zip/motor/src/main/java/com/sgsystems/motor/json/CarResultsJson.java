package com.sgsystems.motor.json;

import java.util.List;

import com.sgsystems.motor.models.CarDetailsView;

public class CarResultsJson {

	private long total;

	private List<CarDetailsView> carDetails;

	public CarResultsJson(long total, List<CarDetailsView> carDetails) {
		super();
		this.total = total;
		this.carDetails = carDetails;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	public List<CarDetailsView> getCarDetails() {
		return carDetails;
	}

	public void setCarDetails(List<CarDetailsView> carDetails) {
		this.carDetails = carDetails;
	}

}
