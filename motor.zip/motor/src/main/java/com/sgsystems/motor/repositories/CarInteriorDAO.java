package com.sgsystems.motor.repositories;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.CarInterior;

public interface CarInteriorDAO extends BaseDAO<CarInterior,Long>{

}
