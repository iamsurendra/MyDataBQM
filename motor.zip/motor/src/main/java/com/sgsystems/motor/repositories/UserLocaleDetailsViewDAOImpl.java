package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.constants.LanguageEnum;
import com.sgsystems.motor.models.UserLocaleDetailsView;
import com.sgsystems.motor.models.UserLocaleDetailsViewKey;

@Repository
public class UserLocaleDetailsViewDAOImpl extends BaseDAOImpl<UserLocaleDetailsView, UserLocaleDetailsViewKey> implements UserLocaleDetailsViewDAO{

	public UserLocaleDetailsViewDAOImpl() {
		super(UserLocaleDetailsView.class);
		
	}
	
	public List<UserLocaleDetailsView> getAllEnglishLocalUser() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserLocaleDetailsView> criteriaQuery = criteriaBuilder.createQuery(UserLocaleDetailsView.class);
		Root<UserLocaleDetailsView> root = criteriaQuery.from(UserLocaleDetailsView.class);
		criteriaQuery.select(root).where(criteriaBuilder.and(criteriaBuilder.equal(root.get("languageId"), LanguageEnum.EN.value),
				criteriaBuilder.isNotNull(root.get("dealerId"))));
		return entityManager.createQuery(criteriaQuery).getResultList();

}
	
	public UserLocaleDetailsView getUserLocalInfoByUserId(Long userId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserLocaleDetailsView> criteriaQuery = criteriaBuilder.createQuery(UserLocaleDetailsView.class);
		Root<UserLocaleDetailsView> root = criteriaQuery.from(UserLocaleDetailsView.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal(root.get("userId"), userId),
				criteriaBuilder.equal(root.get("languageId"), 100));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}


}
