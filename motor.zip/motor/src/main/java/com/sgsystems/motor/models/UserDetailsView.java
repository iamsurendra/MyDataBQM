package com.sgsystems.motor.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "user_details_view")
public class UserDetailsView implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	UserDetailsViewKey userDetailsViewKey;

	@Column(name = "USER_ID", insertable = false, updatable = false)
	private Long userId;

	@Column(name = "LANGUAGE_ID", insertable = false, updatable = false)
	private int languageId;

	@Column(name = "DEALER_ID")
	private Integer dealerId;

	@Column(name = "EMAIL")
	private String eMail;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "LAST_NAME")
	private String lastName;

	@Column(name = "DEALER_NAME")
	private String dealerName;

	@Column(name = "MAX_VEHICLES")
	private Integer maxVehicles;

	@Column(name = "DEALER_CODE")
	private String dealerCode;

	@Column(name = "USER_STATUS")
	private int userStatus;

	@Column(name = "CITY_AREA")
	private String cityArea;

	@Column(name = "PROVINCE")
	private String province;

	@Column(name = "PHONE_NO")
	private String phoneNo;

	@Column(name = "ADMIN")
	private Integer admin;

	@Column(name = "NEW_PHONE_NUMBER")
	private String newPhoneNumber;

	@Column(name = "ADDRESS")
	private String address;

	@Column(name = "PROFILE_IMAGE")
	private String profileImage;

	// getters and setters

	public UserDetailsViewKey getUserDetailsViewKey() {
		return userDetailsViewKey;
	}

	public void setUserDetailsViewKey(UserDetailsViewKey userDetailsViewKey) {
		this.userDetailsViewKey = userDetailsViewKey;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public int getLanguageId() {
		return languageId;
	}

	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}

	public Integer getDealerId() {
		return dealerId;
	}

	public void setDealerId(Integer dealerId) {
		this.dealerId = dealerId;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public Integer getMaxVehicles() {
		return maxVehicles;
	}

	public void setMaxVehicles(Integer maxVehicles) {
		this.maxVehicles = maxVehicles;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public int getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(int userStatus) {
		this.userStatus = userStatus;
	}

	public String getCityArea() {
		return cityArea;
	}

	public void setCityArea(String cityArea) {
		this.cityArea = cityArea;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Integer getAdmin() {
		return admin;
	}

	public void setAdmin(Integer admin) {
		this.admin = admin;
	}

	public String getNewPhoneNumber() {
		return newPhoneNumber;
	}

	public void setNewPhoneNumber(String newPhoneNumber) {
		this.newPhoneNumber = newPhoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userDetailsViewKey == null) ? 0 : userDetailsViewKey.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserDetailsView other = (UserDetailsView) obj;
		if (userDetailsViewKey == null) {
			if (other.userDetailsViewKey != null)
				return false;
		} else if (!userDetailsViewKey.equals(other.userDetailsViewKey))
			return false;
		return true;
	}

}
