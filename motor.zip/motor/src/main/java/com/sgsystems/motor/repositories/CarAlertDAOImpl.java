package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.CarAlerts;

@Repository
public class CarAlertDAOImpl extends BaseDAOImpl<CarAlerts, Long> implements CarAlertDAO {

	public CarAlertDAOImpl() {
		super(CarAlerts.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<CarAlerts> getcarAlerts(Long UserId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CarAlerts> criteriaQuery = criteriaBuilder.createQuery(CarAlerts.class);
		Root<CarAlerts> root = criteriaQuery.from(CarAlerts.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("userId"), UserId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<CarAlerts> getcarAlertByAlertID(Long Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CarAlerts> criteriaQuery = criteriaBuilder.createQuery(CarAlerts.class);
		Root<CarAlerts> root = criteriaQuery.from(CarAlerts.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("id"), Id));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<CarAlerts> getcarAlertsforMail() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CarAlerts> criteriaQuery = criteriaBuilder.createQuery(CarAlerts.class);
		Root<CarAlerts> root = criteriaQuery.from(CarAlerts.class);
		criteriaQuery.select(
				criteriaBuilder.construct(CarAlerts.class, root.get("userId"),  root.get("model"),root.get("make")));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
