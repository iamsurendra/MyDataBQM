package com.sgsystems.motor.repositories;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.DealerSequence;

@Repository
public class DealerSequenceDAOImpl extends BaseDAOImpl<DealerSequence, String> implements DealerSequenceDAO {

	public DealerSequenceDAOImpl() {
		super(DealerSequence.class);
	}

	@Override
	public String getDealerSequence(String dealerCode) {
		String sequence = (String) entityManager.createNativeQuery(DealerSequence.CURRENT_SEQUENCE)
				.setParameter(1, dealerCode).getSingleResult();
		return sequence;

	}

}
