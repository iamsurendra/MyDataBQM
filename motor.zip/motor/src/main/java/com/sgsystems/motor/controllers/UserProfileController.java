package com.sgsystems.motor.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sgsystems.motor.models.CarAlerts;
import com.sgsystems.motor.services.CarAlertService;

@RestController
@RequestMapping("profile")
public class UserProfileController {

	@Autowired
	CarAlertService carAlertService;

	// -------------------------display carAlert by userId--------------
	@RequestMapping(value = "/carAlertDetails/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<CarAlerts> getCarAlerts(@PathVariable("userId") Long Id) {
		return carAlertService.getcarAlerts(Id);

	}

	@RequestMapping(value = "/editCarAlert", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void editCar(@RequestBody CarAlerts carAlert) {
		carAlertService.editCarAlert(carAlert);

	}

	@RequestMapping(value = "/deleteCarAlert", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void deleteCarAlert(@RequestBody CarAlerts carAlerts) {
		carAlertService.deleteAlert(carAlerts);

	}

	// --------------display carAlert by AlertId--------------
	@RequestMapping(value = "/displayCarAlertByAlertId/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<CarAlerts> getcarAlertByAlertID(@PathVariable("Id") Long Id) {
		return carAlertService.getcarAlertByAlertID(Id);
	}
}
