package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.Enginebhp;

@Repository
public class EnginebhpDAOImpl extends BaseDAOImpl<Enginebhp, Long>  implements EnginebhpDAO{

	public EnginebhpDAOImpl() {
		super(Enginebhp.class);
		// TODO Auto-generated constructor stub
	}
	
	public List<String> getEngineBhpList(){
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> cQuery = criteriaBuilder.createQuery(String.class);
		Root<Enginebhp> root = cQuery.from(Enginebhp.class);
		cQuery.select(root.get("name")).distinct(true).orderBy(criteriaBuilder.asc(root.get("name")));
		return entityManager.createQuery(cQuery).getResultList();
		
	}

}
