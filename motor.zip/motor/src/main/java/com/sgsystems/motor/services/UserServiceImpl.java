package com.sgsystems.motor.services;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppWebUtils;
import com.guvvala.framework.util.PasswordEncryptor;
import com.guvvala.framework.util.PasswordGenerator;
import com.guvvala.framework.util.StringUtils;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.sgsystems.motor.constants.LanguageEnum;
import com.sgsystems.motor.constants.MailTemplateEnum;
import com.sgsystems.motor.constants.MessagesEnum;
import com.sgsystems.motor.constants.MotarConstants;
import com.sgsystems.motor.constants.UserStatus;
import com.sgsystems.motor.json.UserJson;
import com.sgsystems.motor.models.CarDetailsView;
import com.sgsystems.motor.models.Dealer;
import com.sgsystems.motor.models.DealerLocaleDetails;
import com.sgsystems.motor.models.DealerLocaleDetailsKey;
import com.sgsystems.motor.models.DealerSequence;
import com.sgsystems.motor.models.User;
import com.sgsystems.motor.models.UserActivities;
import com.sgsystems.motor.models.UserDetailsView;
import com.sgsystems.motor.models.UserLocaleDetails;
import com.sgsystems.motor.repositories.CarDAO;
import com.sgsystems.motor.repositories.CarDetailsViewDAO;
import com.sgsystems.motor.repositories.DealerDAO;
import com.sgsystems.motor.repositories.DealerSequenceDAO;
import com.sgsystems.motor.repositories.UserActivitesDAO;
import com.sgsystems.motor.repositories.UserDAO;
import com.sgsystems.motor.repositories.UserLocaleDetailsDAO;

/**
 * @author Guvvala
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userDAO;

	@Autowired
	DealerDAO dealerDAO;

	@Autowired
	CarDAO carDao;

	@Autowired
	UserLocaleDetailsDAO userLocaleDetailsDAO;

	@Autowired
	DealerSequenceDAO dealerSequenceDAO;
	
	@Autowired
	CarDAO carDAO;
	
	@Autowired
	UserActivitesDAO userActivitesDAO;

	@Autowired
	private MailService ms;

	@Autowired
	UserDetailsViewService userDetailsViewService;

	@Transactional
	public User getUser(Long userId) {
		return userDAO.getUser(userId);
	}

	@Transactional
	public boolean uniqueUserName(String userName) {
		return userDAO.uniqueUserName(userName);
	}

	public User getUserForLogin(Long userId) {
		User user = userDAO.getUser(userId);
		return user;
	}

	// create new user
	@Transactional
	public Long createNewUser(User user) {
		if (validateEmail(user.geteMail())) {
			throw new AppException(MessagesEnum.EMAIL_ALREADY_EXISTS);
		}
		String password = user.getPassword();
		String salt = PasswordEncryptor.generateSalt();
		String hash = PasswordEncryptor.applySHA256(password + salt);
		user.setUserSalt(salt);
		user.setPwdHash(hash);
		user.setUserStatus(UserStatus.USER_ENABLED.value);
		user.setUserName(StringUtils.extractUserName(user.geteMail()));
		UserLocaleDetails uld = createUserLocaleDetails(user);
		createDealer(user);
		userDAO.create(user);
		sendUserCreateMail(user, uld, password);
		Long userId = user.getUserId();
		return userId;
	}

	@Transactional
	public void updateDealer(User user) {
		User updateprofile = userDAO.findOne(user.getUserId());
		updateprofile.setPhoneNo(user.getPhoneNo());
		updateprofile.setNewPhoneNumber(user.getNewPhoneNumber());
		updateprofile.setCityAreaId(user.getCityAreaId());
		updateprofile.setProvinceId(user.getProvinceId());
		for (UserLocaleDetails uld : user.getUserLocaleDetails()) {
			for (UserLocaleDetails ulddb : updateprofile.getUserLocaleDetails()) {
				if (ulddb.getLanguageId() == uld.getLanguageId()) {
					ulddb.setFirstName(uld.getFirstName());
					ulddb.setLastName(uld.getLastName());
					ulddb.setAddress(uld.getAddress());
				}
			}
		}
		if (user.getDealerId() == null) {
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(MotarConstants.FNAME, updateprofile.getUserName());
			values.put(MotarConstants.EMAIL, updateprofile.geteMail());
			String[] to = { user.geteMail() };
			ms.sendEmail(MailTemplateEnum.UPDATE_USER, values, to);
		}
		userDAO.update(updateprofile);
		updateDealerInfo(user);
	}

	private void updateDealerInfo(User user) {

		Dealer dealerInfo = user.getDealeru();
		if (dealerInfo == null) {
			return;
		}

		Dealer dealer = dealerDAO.findOne(user.getDealerId());
		dealer.setMaxVehicles(user.getDealeru().getMaxVehicles());
		for (DealerLocaleDetails dld : user.getDealeru().getDealerLocaleDetails()) {
			for (DealerLocaleDetails dlddb : dealer.getDealerLocaleDetails()) {
				if (dlddb.getDealerLocaleDetailsKey().getLanguageId() == dld.getLanguageId()) {
					dlddb.setName(dld.getName());
				}
			}
		}
		dealerDAO.update(dealer);
	}

	private void sendUserCreateMail(User user, UserLocaleDetails uld, String password) {
		Map<String, Object> values = new HashMap<String, Object>();
		values.put(MotarConstants.PASSWORD, password);
		values.put(MotarConstants.FNAME, user.getUserName());
		values.put(MotarConstants.EMAIL, user.geteMail());
		String[] to = { user.geteMail() };
		Object[] subject = { user.getUserName() };
		if (user.getDealeru() == null) {
			ms.sendEmail(MailTemplateEnum.CREATE_USER, values, to, subject);
		} else {
			ms.sendEmail(MailTemplateEnum.CREATE_DEALER, values, to, subject);
		}
	}

	private void createDealer(User user) {
		Dealer dealer = user.getDealeru();
		if (dealer == null) {
			return;
		}
		DealerLocaleDetails enDld = null;
		for (DealerLocaleDetails dld : dealer.getDealerLocaleDetails()) {
			dld.setDealer(dealer);
			dld.setDealerLocaleDetailsKey(new DealerLocaleDetailsKey(dld.getLanguageId()));
			if (dld.getLanguageId() == LanguageEnum.EN.value) {
				enDld = dld;
			}
		}
		Long dealerCount = dealerDAO.uniqueDealerName(AppWebUtils.generateCode(enDld.getName()));
		if (dealerCount > 0) {
			throw new AppException(MessagesEnum.DEALER_NAME_EXISTED);
		}
		Long regNumberCount = dealerDAO.validateRegistrationNumber(dealer.getRegNo());
		if (regNumberCount > 0) {
			throw new AppException(MessagesEnum.DUPLICATE_REG_NUMBER);
		}

		user.getDealeru().setCode(AppWebUtils.generateCode(enDld.getName()));
		dealerDAO.create(user.getDealeru());
		dealerSequenceDAO.create(new DealerSequence(dealer.getCode()));
	}

	private UserLocaleDetails createUserLocaleDetails(User user) {
		UserLocaleDetails enUld = null;
		for (UserLocaleDetails uld : user.getUserLocaleDetails()) {
			uld.setUser(user);
			if (uld.getLanguageId() == LanguageEnum.EN.value) {
				enUld = uld;
			}
		}
		return enUld;
	}

	@Transactional
	public User resetpwd(UserJson userjson) {
		User user = userDAO.getEmail(userjson.geteMail());
		String salt = PasswordEncryptor.generateSalt();
		String hash = PasswordEncryptor.applySHA256(userjson.getPassword() + salt);
		user.setUserSalt(salt);
		user.setPwdHash(hash);
		user.setUserStatus(UserStatus.USER_ENABLED.value);
		user.setLastLoginDate(new Date());
		user = userDAO.update(user);
		Map<String, Object> values = new HashMap<String, Object>();
		values.put(MotarConstants.PASSWORD, userjson.getPassword());
		values.put(MotarConstants.EMAIL, user.geteMail());
		values.put(MotarConstants.FNAME, user.getUserName());
		String[] to = { user.geteMail() };
		ms.sendEmail(MailTemplateEnum.RESET_PASSWORD, values, to);
		return user;
	}

	public boolean isValidPassword(User user, String password) {
		return PasswordEncryptor.isValidPassword(password + user.getUserSalt(), user.getPwdHash());
	}

	@Transactional
	@Override
	public User validatePassword(UserJson userJson) {
		User user = userDAO.getEmail(userJson.geteMail());
		if ((user != null) && (isValidPassword(user, userJson.getPassword()))) {
			if (user.getUserStatus() == UserStatus.USER_INACTIVE.value) {
				throw new AppException(MessagesEnum.USER_DEACTIVATED);
			} else {
				ThreadLocalUtil.setThreadVariable(ThreadLocalUtil.CURRENT_USER, user);
				return user;
			}

		}
		return new User();
	}

	@Transactional
	public void updateUser(User user) {
		User updateUser = userDAO.findOne(user.getUserId());
		updateUser.seteMail(user.geteMail());
		updateUser.setPhoneNo(user.getPhoneNo());
		updateUser.setNewPhoneNumber(user.getNewPhoneNumber());
		userDAO.update(updateUser);
		Map<String, Object> values = new HashMap<String, Object>();
		values.put(MotarConstants.FNAME, updateUser.getUserName());
		values.put(MotarConstants.EMAIL, updateUser.geteMail());
		String[] to = { user.geteMail() };
		ms.sendEmail(MailTemplateEnum.UPDATE_USER, values, to);

	}

	@Transactional
	public void updateUserProfile(User user) {
		userDAO.update(user);
	}

	@Transactional
	public User forgotPassword(UserJson userJson) {
		User user = userDAO.getEmail(userJson.geteMail());

		if (user != null) {

			if (user.getUserStatus() == UserStatus.USER_DISABLED.value
					|| user.getUserStatus() == UserStatus.USER_INACTIVE.value) {
				throw new AppException(MessagesEnum.USER_DEACTIVATED);

			}

		} else {
			throw new AppException(MessagesEnum.EMAIL_VALIDATION);

		}
		String password = String.valueOf(PasswordGenerator.generatePassword());
		String salt = PasswordEncryptor.generateSalt();
		String hash = PasswordEncryptor.applySHA256(password + salt);
		user.setUserSalt(salt);
		user.setPwdHash(hash);
		user.setUserStatus(UserStatus.USER_DISABLED.value);
		userDAO.update(user);

		Map<String, Object> values = new HashMap<String, Object>();
		values.put(MotarConstants.PASSWORD, password);
		values.put(MotarConstants.EMAIL, user.geteMail());
		values.put(MotarConstants.FNAME, user.getUserName());
		String[] to = { user.geteMail() };
		Object[] subject = { user.getUserName() };
		ms.sendEmail(MailTemplateEnum.FORGOT_PASSWORD, values, to, subject);

		return user;
	}

	@Transactional
	public void makeActiveOrInactive(Long userId) {
		User user = userDAO.getUser(userId);
		
		List<Long> carIds = carDAO.getIdsByUserId(userId);
		if(!carIds.isEmpty()){
		List<UserActivities> userActivities = userActivitesDAO.getCarInfoByCarIds(carIds);
		if (user.getUserStatus() == 0){
		for(UserActivities userActivitie:userActivities){
			userActivitie.setStatus(true);
		}}else{
			for(UserActivities userActivitie:userActivities){
				userActivitie.setStatus(false);
		}}
		
		}
		if (user.getUserStatus() == 0){
			user.setUserStatus(UserStatus.USER_ENABLED.value);
			
		}else {
			user.setUserStatus(UserStatus.USER_INACTIVE.value);
			
		}
		//userDAO.update(user);
	}

	@Transactional
	public User updateImageProfile(Long userId) {
		return userDAO.getuserInfoByUserId(userId);

	}

	@Transactional
	public boolean validateEmail(String email) {
		return userDAO.validateEmail(email);
	}

	@Transactional
	public UserDetailsView getUserDetailsInfoByUserId(Long userId, Long languageId) {

		return userDetailsViewService.getUserDetailsInfoByUserId(userId, languageId);

	}

}
