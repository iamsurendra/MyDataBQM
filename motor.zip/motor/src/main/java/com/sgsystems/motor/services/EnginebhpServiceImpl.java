package com.sgsystems.motor.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgsystems.motor.models.Enginebhp;
import com.sgsystems.motor.repositories.EnginebhpDAO;

@Service
public class EnginebhpServiceImpl implements EnginebhpService {

	@Autowired
	EnginebhpDAO enginebhpDAO;
	
	@Transactional(readOnly = true)
	public List<String> getEngineBhpList(){
		return enginebhpDAO.getEngineBhpList();
	}
	@Transactional(readOnly = true)
	public List<Enginebhp>getEnginBhpInfo()
	{
		return enginebhpDAO.findAll();
		
	}
	
}
