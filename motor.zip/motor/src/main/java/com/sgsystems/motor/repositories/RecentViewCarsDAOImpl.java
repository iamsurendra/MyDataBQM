package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.RecentViewCars;
import com.sgsystems.motor.models.RecentViewCarsKey;

@Repository
public class RecentViewCarsDAOImpl extends BaseDAOImpl<RecentViewCars, RecentViewCarsKey> implements RecentViewCarsDAO {

	public RecentViewCarsDAOImpl() {
		super(RecentViewCars.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<RecentViewCars> getRecenViewCars(Long Id) {

		CriteriaBuilder criteriabuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<RecentViewCars> criteriaQuery = criteriabuilder.createQuery(RecentViewCars.class);
		Root<RecentViewCars> root = criteriaQuery.from(RecentViewCars.class);
		criteriaQuery.select(root).where(criteriabuilder.equal(root.get("userId"), Id));
		criteriaQuery.orderBy(criteriabuilder.desc(root.get("createdDate")));

		return entityManager.createQuery(criteriaQuery).setMaxResults(10).getResultList();
	}
	
	
	public List<RecentViewCars> getCarInfoByCarId(Long Id) {

		CriteriaBuilder criteriabuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<RecentViewCars> criteriaQuery = criteriabuilder.createQuery(RecentViewCars.class);
		Root<RecentViewCars> root = criteriaQuery.from(RecentViewCars.class);
		criteriaQuery.select(root).where(criteriabuilder.equal(root.get("carId"), Id));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	

	public List<String> getCarIdByuserID(Long id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<RecentViewCars> root = criteriaQuery.from(RecentViewCars.class);
		criteriaQuery.select(root.get("carId")).distinct(true);
		criteriaQuery.where(criteriaBuilder.equal(root.get("userId"), id));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
	
}
