package com.sgsystems.motor.repositories;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.Car;
import com.sgsystems.motor.models.CarDetailsView;

/**
 * @author Guvvala
 *
 */
@Repository
public class CarDAOImpl extends BaseDAOImpl<Car, Long> implements CarDAO {

	public CarDAOImpl() {
		super(Car.class);

	}

	public List<String> getCarPrice() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);
		Root<Car> root = criteriaQuery.from(Car.class);
		criteriaQuery.select(root.get("price")).distinct(true);
		criteriaQuery.orderBy(builder.asc(root.get("price")));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<Car> getCarInfoByPrice(BigDecimal price1, BigDecimal price2) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Car> criteriaQuery = criteriaBuilder.createQuery(Car.class);
		Root<Car> root = criteriaQuery.from(Car.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(criteriaBuilder.between(root.<BigDecimal> get("price"), price1, price2));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<Car> getCountOfPrice() {
		Query q = entityManager.createNativeQuery(
				"select t.range, count(*) as num  from (select case " + "when price between 0 and 10000 then '0-10,000' "
						+ "when price between 10001 and 20000 then '10,001-20,000' "
						+ "when price between 20001 and 30000 then '20,001-30,000' "
						+ "when price between 30001 and 40000 then '30,001-40,000' "
						+ "when price between 40001 and 50000 then '40,001-50,000'"
						+ "when price between 50001 and 60000 then '50,001-60,000'"
						+ "when price between 60001 and 70000 then '60,001-70,000'"
						+ "when price between 70001 and 80000 then '70,001-80,000'"
						+ "when price between 80001 and 90000 then '80,001-90,000'"
						+ "when price between 90001 and 100000 then '90,001-100,000'"

						+ "else '100,001-Above' end as 'range' from car where status=1) t group by t.range");
		List<Car> priceCountList = new ArrayList<>();
		List<Object[]> results = q.getResultList();
		Map<String, Long> priceCount = new HashMap<>();
		for (Object[] row : results) {
			priceCount.put((String) row[0], ((BigInteger) row[1]).longValue());
			// priceCountList.add(new Car((String) row[0], ((BigInteger)
			// row[1]).longValue()));
		}
		List<String> priceList = new ArrayList<>();
		priceList.add("0-10,000");
		priceList.add("10,001-20,000");
		priceList.add("20,001-30,000");
		priceList.add("30,001-40,000");
		priceList.add("40,001-50,000");
		priceList.add("50,001-60,000");
		priceList.add("60,001-70,000");
		priceList.add("70,001-80,000");
		priceList.add("80,001-90,000");
		priceList.add("90,001-100,000");
		priceList.add("100,001-Above");
		for (String range : priceList) {
			priceCountList.add(new Car(range, priceCount.get(range) != null ? priceCount.get(range) : 0L));
		}

		return priceCountList;
	}

	public boolean uniqueVehicleNumber(String vin,Long carId) {

		TypedQuery<Long> query = entityManager.createQuery("SELECT count(c) from Car c where vin ='" + vin + "' and id !=" + carId ,
				Long.class);
		if (query.getSingleResult() == 0) {
			return false;
		} else {
			return true;
		}

	}

	public Car getCarInfoById(Long id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Car> criteriaQuery = criteriaBuilder.createQuery(Car.class);
		Root<Car> root = criteriaQuery.from(Car.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(criteriaBuilder.equal(root.get("id"), id));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}

	public List<Long> getCarInfoByID(List<Long> ids) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
		Root<Car> root = criteriaQuery.from(Car.class);
		criteriaQuery.select(root.get("makeId")).distinct(true);
		criteriaQuery.where(root.get("id").in(ids));

		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
	public List<Car> getcarInfoByuserID(Long userId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Car> criteriaQuery = criteriaBuilder.createQuery(Car.class);
		Root<Car> root = criteriaQuery.from(Car.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(root.get("userId").in(userId));

		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
  public Long countOfCarsByUserId(Long userId){
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
		Root<Car> root = criteriaQuery.from(Car.class);
		criteriaQuery.multiselect(criteriaBuilder.count(root));
		criteriaQuery.where(criteriaBuilder.and(criteriaBuilder.equal(root.get("userId"), userId)),criteriaBuilder.equal(root.get("languageId"), 100));
	return entityManager.createQuery(criteriaQuery).getSingleResult();
	  
  }
  
  public List<Long> getIdsByUserId(Long userId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
		Root<Car> root = criteriaQuery.from(Car.class);
		criteriaQuery.select(root.get("id"));
		criteriaQuery.where(criteriaBuilder.equal(root.get("userId"), userId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
}
