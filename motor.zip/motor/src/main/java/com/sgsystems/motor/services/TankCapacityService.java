package com.sgsystems.motor.services;

import java.util.List;

public interface TankCapacityService {
	
	public List<String> getTankCapacityList();
}
