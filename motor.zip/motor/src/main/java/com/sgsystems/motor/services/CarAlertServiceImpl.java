package com.sgsystems.motor.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgsystems.motor.constants.MailTemplateEnum;
import com.sgsystems.motor.constants.MotarConstants;
import com.sgsystems.motor.models.CarAlerts;
import com.sgsystems.motor.models.carsAlertsView;
import com.sgsystems.motor.repositories.CarAlertDAO;
import com.sgsystems.motor.repositories.CarDetailsViewDAO;
import com.sgsystems.motor.repositories.CarsAlertsViewDAO;
import com.sgsystems.motor.repositories.UserDAO;

@Service
public class CarAlertServiceImpl implements CarAlertService {

	@Autowired
	CarAlertDAO carAlertDAO;
	@Autowired
	CarDetailsViewDAO carDetailsViewDAO;

	@Autowired
	UserDAO userDAO;

	@Autowired
	private MailService ms;
	
	@Autowired
    private CarsAlertsViewDAO carsAlertsViewDAO;
	

	@Transactional
	public CarAlerts createAlert(CarAlerts carAlerts) {
		carAlerts.setStatus(1l);
		return carAlertDAO.create(carAlerts);
	}

	@Transactional
	public void deleteAlert(CarAlerts removeAlert) {
		carAlertDAO.delete(removeAlert);
	}

	@Transactional
	public List<CarAlerts> getcarAlerts(Long UserId) {

		return carAlertDAO.getcarAlerts(UserId);

	}

	@Transactional
	public void editCarAlert(CarAlerts carAlert) {
		carAlertDAO.update(carAlert);

	}

	@Transactional
	public List<CarAlerts> getcarAlertByAlertID(Long Id) {
		return carAlertDAO.getcarAlertByAlertID(Id);
	}

	@Transactional
	public void sendMailForCarAlerts() throws AddressException, MessagingException {
		Map<String, List<carsAlertsView>> carAlerts = new HashMap<>();
	List<carsAlertsView> carsAlertsView = carsAlertsViewDAO.getcarAlertsList();
		for (carsAlertsView list : carsAlertsView) {
		
				if (!carAlerts.containsKey(list.getEmail())) {
					carAlerts.put(list.getEmail(), new ArrayList<carsAlertsView>());
				}
				carAlerts.get(list.getEmail()).add(list);
			
		}

		for (Map.Entry<String, List<carsAlertsView>> entry : carAlerts.entrySet()) {
			List<carsAlertsView> carAlert = entry.getValue();
			Map<String, Object> values = new HashMap<String, Object>();
			if (carAlert.get(0).getFirstName() == null) {
				values.put(MotarConstants.FIRSTNAME, "");
			} else {
				values.put(MotarConstants.FIRSTNAME, carAlert.get(0).getFirstName());
			}
			for (carsAlertsView carAlerts1 : carAlert) {
				if (carAlerts1.getMake() == null) {
					values.put(MotarConstants.MAKE, "");
				} else {
					values.put(MotarConstants.MAKE, carAlerts1.getMake());
				}
				if (carAlerts1.getModel() == null) {
					values.put(MotarConstants.MODEL, "");
				} else {
					values.put(MotarConstants.MODEL, carAlerts1.getModel());
				}
				values.put(MotarConstants.COUNT, carAlerts1.getCount());
				if (carAlerts1.getFromYear() == null) {
					values.put(MotarConstants.FROM_YEAR, "");
				} else {
					values.put(MotarConstants.FROM_YEAR, carAlerts1.getFromYear());
				}
				if (carAlerts1.getToYear() == null) {
					values.put(MotarConstants.TO_YEAR, "");
				} else {
					values.put(MotarConstants.TO_YEAR, carAlerts1.getToYear());
				}
				if (carAlerts1.getMaxMileage() == null) {
					values.put(MotarConstants.MAX_MILEAGE, "");
				} else {
					values.put(MotarConstants.MAX_MILEAGE, carAlerts1.getMaxMileage());
				}
				if (carAlerts1.getMaxPrice() == null) {
					values.put(MotarConstants.MAX_PRICE, "");
				} else {
					values.put(MotarConstants.MAX_PRICE, carAlerts1.getMaxPrice());
				}
			}
			String[] to = { entry.getKey() };
			ms.sendEmail(MailTemplateEnum.MAIL_FOR_CAR_ALERTS, values, to);
		}
	}
}
