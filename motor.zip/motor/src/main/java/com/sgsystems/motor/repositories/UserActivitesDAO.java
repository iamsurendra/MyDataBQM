package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;

import com.sgsystems.motor.models.UserActivities;
import com.sgsystems.motor.models.UserActivityKey;

public interface UserActivitesDAO extends BaseDAO<UserActivities, UserActivityKey> {
	
	List<Long> findAllFavioritesByUser(Long userId);

	public UserActivities getCarCountByUserID(Long Id);

	public List<UserActivities> getCarInfoById(Long Id);
	
	public List<UserActivities> getCarInfoByCarId(Long Id);
	
	public List<UserActivities> getCarInfoByCarIds(List<Long> Id);

}
