package com.sgsystems.motor.controllers;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.guvvala.framework.errorHandler.AppException;
import com.sgsystems.motor.constants.MessagesEnum;
import com.sgsystems.motor.externals.ImageUploader;
import com.sgsystems.motor.models.Image;
import com.sgsystems.motor.models.ImageKey;
import com.sgsystems.motor.services.ImageService;

/**
 * @author Guvvala
 *
 */
@RestController
@RequestMapping("image")
public class ImageController {

	@Autowired
	ImageService imageService;

	@Autowired
	ImageUploader imageUploader;

	@RequestMapping(value = "/upload", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public void saveImage(@RequestParam("file") MultipartFile uploadfile, @RequestParam(value = "carId") Long carId,
			@RequestParam(value = "first") boolean first, @RequestParam(value = "imageProfile") String imageProfile)
			throws IOException {
		Image imageObj = imageService.findOneImage(carId, imageProfile);
		if (imageObj == null) {
			Map<String, Object> uploadResult = imageUploader.uploadFile(uploadfile);
			Image image = new Image();
			image.setFirst(first);
			image.setCarId(carId);
			image.setProfileName(imageProfile);
			image.setName((String) uploadResult.get("public_id"));
			image.setUrl((String) uploadResult.get("url"));
			ImageKey keyObj = new ImageKey();
			keyObj.setCarId(carId);
			keyObj.setProfileName(imageProfile);
			image.setImageKey(keyObj);
			imageService.create(image);
		} else {
			Map<String, Object> uploadResult = imageUploader.updateImage(uploadfile, imageObj.getName());
			imageObj.setUrl((String) uploadResult.get("url"));
			imageObj.setName((String) uploadResult.get("public_id"));
			imageService.update(imageObj);
		}
	}

	// image deletion
	@RequestMapping(value = "/deleteImage", method = RequestMethod.GET)
	public void deleteImages(@RequestParam(value = "carId") Long carId,
			@RequestParam(value = "profileName") String profileName) throws Exception {
		Image imageObj = imageService.findOneImage(carId, profileName);
		if (imageObj != null) {
			Map<String, Object> deleteList = imageUploader.deleteImage(Arrays.asList(imageObj.getName()));
			if (deleteList.get("deleted") != null && deleteList.get("deleted").toString().contains("deleted")) {
				imageService.delete(imageObj);
			} else {
				throw new AppException(MessagesEnum.IMAGE_NOT_FOUND);
			}
		}

	}

}
