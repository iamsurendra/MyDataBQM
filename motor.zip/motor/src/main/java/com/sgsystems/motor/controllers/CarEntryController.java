
package com.sgsystems.motor.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sgsystems.motor.models.Car;
import com.sgsystems.motor.models.RecentViewCars;
import com.sgsystems.motor.services.CarService;
import com.sgsystems.motor.services.ImageService;
import com.sgsystems.motor.services.RecentViewCarsService;
import com.sgsystems.motor.services.UserService;

/**
 * @author Guvvala
 *
 */
@RestController
@RequestMapping("car")
public class CarEntryController {

	@Autowired
	CarService carService;

	@Autowired
	ImageService imageService;

	@Autowired
	UserService userService;

	@Autowired
	RecentViewCarsService recentViewCarsService;

	/**
	 * Adding New Car
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void saveCarDetails(@RequestBody Car car) {
		carService.updateCarDetails(car);
	}

	/**
	 * Creating new car with Inactive Status
	 */
	@RequestMapping(value = "/createCar/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Car createInactiveCar(@PathVariable("userId") Long userId) {
		return carService.createInactiveCar(userId);
	}

	/**
	 * InActive the CarRecord
	 */
	@RequestMapping(value = "/makeCarAsInactive/{carId}", method = RequestMethod.GET)
	public void makeCarAsInActive(@PathVariable("carId") Long carId) {
		carService.makeCarAsInActive(carId);
	}

	/**
	 * Car delete By CarId
	 */
	@RequestMapping(value = "/deleteCar/{carId}", method = RequestMethod.GET)
	public void deleteCar(@PathVariable("carId") Long carId) {
		carService.deleteCar(carId);
	}

	/**
	 * Retrieving carInfo By Id
	 */
	@RequestMapping(value = "carInfo/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Car getCarInfoById(@PathVariable("id") Long id) {
		Car carDetails = carService.getCarInfoById(id);
		return carDetails;
	}

	/**
	 * Create Recent carViews
	 */
	@RequestMapping(value = "/createRecentCars", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void createRecentCars(@RequestBody RecentViewCars recentViewCars) {
		recentViewCarsService.createRecentviews(recentViewCars);
	}

	/**
	 * User History
	 */
	@RequestMapping(value = "/diplayRecentcarsById/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<RecentViewCars> getRecentcarviews(@PathVariable("Id") Long Id) {
		return recentViewCarsService.getRecentViewCars(Id);
	}

	
	@RequestMapping(value = "/carIdByuserId/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getCarIdByuserID(@PathVariable("userId") Long Userid) {
		return recentViewCarsService.getCarIdByuserID(Userid);
	}

}
