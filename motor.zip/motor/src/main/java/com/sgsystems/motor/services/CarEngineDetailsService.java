package com.sgsystems.motor.services;

import java.util.List;

public interface CarEngineDetailsService {
	List<String> getCarsFuelTypes();
	
	
}
