package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.carsAlertsView;

@Repository
public class CarsAlertsViewDAOImpl extends BaseDAOImpl<carsAlertsView, Long> implements CarsAlertsViewDAO {

	public CarsAlertsViewDAOImpl() {
		super(carsAlertsView.class);
		// TODO Auto-generated constructor stub
	}

	public List<carsAlertsView> getcarAlertsList() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<carsAlertsView> criteriaQuery = criteriaBuilder.createQuery(carsAlertsView.class);
		Root<carsAlertsView> root = criteriaQuery.from(carsAlertsView.class);
		criteriaQuery.select(root).where(criteriaBuilder.greaterThan(root.get("count"), 0));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
