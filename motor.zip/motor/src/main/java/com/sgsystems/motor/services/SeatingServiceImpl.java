package com.sgsystems.motor.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgsystems.motor.models.Seating;
import com.sgsystems.motor.repositories.SeatingDAO;

@Service
public class SeatingServiceImpl implements SeatingService {
	@Autowired
	SeatingDAO SeatingDAO;

	 public List<Seating>seatingInfo(){
		return SeatingDAO.findAll();
		
	}

}
