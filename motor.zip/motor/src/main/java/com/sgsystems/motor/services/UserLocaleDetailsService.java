package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.UserLocaleDetails;

public interface UserLocaleDetailsService {
	
	public List<UserLocaleDetails> getAllEnglishLocalUser();

}
