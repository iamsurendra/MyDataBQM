package com.sgsystems.motor.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgsystems.motor.models.UserLocaleDetailsView;
import com.sgsystems.motor.repositories.UserLocaleDetailsViewDAO;

@Service
public class UserLocaleDetailsViewServiceImpl implements UserLocaleDetailsViewService {

	@Autowired
	UserLocaleDetailsViewDAO userLocaleDetailsViewDAO;

	@Transactional
	public List<UserLocaleDetailsView> getAllEnglishLocalUser() {
		return userLocaleDetailsViewDAO.getAllEnglishLocalUser();
	}

	@Transactional
	public UserLocaleDetailsView getUserLocalInfoByUserId(Long userId) {

		return userLocaleDetailsViewDAO.getUserLocalInfoByUserId(userId);

	}

}
