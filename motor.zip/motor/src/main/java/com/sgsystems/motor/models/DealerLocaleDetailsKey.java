package com.sgsystems.motor.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class DealerLocaleDetailsKey implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "DEALER_ID")
	private Long dealerId;

	@Column(name = "LANGUAGE_ID")
	private int languageId;

	public DealerLocaleDetailsKey() {
		super();
	}

	public DealerLocaleDetailsKey(int languageId) {
		super();
		this.languageId = languageId;
	}

	public Long getDealerId() {
		return dealerId;
	}

	public void setDealerId(Long dealerId) {
		this.dealerId = dealerId;
	}

	public int getLanguageId() {
		return languageId;
	}

	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dealerId == null) ? 0 : dealerId.hashCode());
		result = prime * result + languageId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DealerLocaleDetailsKey other = (DealerLocaleDetailsKey) obj;
		if (dealerId == null) {
			if (other.dealerId != null)
				return false;
		} else if (!dealerId.equals(other.dealerId))
			return false;
		if (languageId != other.languageId)
			return false;
		return true;
	}

}
