package com.sgsystems.motor.models;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "hot_deals_cars_details_view")
public class HotDealCarDetails implements Serializable{

	
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "ID")
	private Long id;

	@Column(name = "VIN")
	private String vin;

	@Column(name = "MAKE_ID")
	private Long makeId;

	@Column(name = "MAKE")
	private String make;

	@Column(name = "SEATING_ID")
	private Long seatingId;

	@Column(name = "SEATING_NAME")
	private String seatingName;

	@Column(name = "NEW")
	@Type(type = "boolean")
	private Boolean newCar;

	@Column(name = "YEAR")
	private Integer year;

	@Column(name = "ZIP_CODE")
	private String zipCode;

	@Column(name = "PRICE")
	private BigDecimal price;

	@Column(name = "REDUCED_PRICE")
	private BigDecimal reducedPrice;

	@Column(name = "MILEAGE")
	private Long mileage;

	@Column(name = "TANK_CAPACITY")
	private String tankCapacity;

	@Column(name = "MODEL")
	private String model;

	@Column(name = "TRIM")
	private String trim;

	@Column(name = "FIRST_IMAGE_ID")
	private Long firstImage;

	@Column(name = "BODY_TYPE")
	private String bodyType;

	@Column(name = "DESCRIPTION")
	private String description;

	// ___________________________//

	@Column(name = "BLUE_TOOTH")
	@Type(type = "boolean")
	private Boolean blueTooth;

	@Column(name = "ALARM")
	@Type(type = "boolean")
	private Boolean alarm;

	@Column(name = "AIRBAGS")
	@Type(type = "boolean")
	private Boolean airBags;

	@Column(name = "AUDIO")
	@Type(type = "boolean")
	private Boolean audio;

	@Column(name = "VIDEO")
	@Type(type = "boolean")
	private Boolean video;

	@Column(name = "CRUISE_CONTROL")
	@Type(type = "boolean")
	private Boolean cruiseControl;

	@Column(name = "AUTO_CLIMATE_CONTROL")
	@Type(type = "boolean")
	private Boolean autoClimateControl;

	@Column(name = "MZ_CLIMATE_CONTROL")
	@Type(type = "boolean")
	private Boolean mzClimateControl;

	@Column(name = "POWER_DRIVER_SEAT")
	@Type(type = "boolean")
	private Boolean powerDriverSeat;

	@Column(name = "REAR_BENCH_SEATS")
	@Type(type = "boolean")
	private Boolean rearBenchSeats;

	@Column(name = "STABILITY_CONTROL")
	@Type(type = "boolean")
	private Boolean stabilityControl;

	@Column(name = "PADDLE_SHIFT")
	@Type(type = "boolean")
	private Boolean paddleShift;

	@Column(name = "TRIP_COMPUTER")
	@Type(type = "boolean")
	private Boolean tripComputer;

	@Column(name = "CLIMATE_SEAT_CONTROL")
	@Type(type = "boolean")
	private Boolean climateSeatControl;

	@Column(name = "FRONT_CAMERA")
	@Type(type = "boolean")
	private Boolean frontCam;

	@Column(name = "REAR_CAMERA")
	@Type(type = "boolean")
	private Boolean rearCam;

	@Column(name = "DASHBOARD_CAMERA")
	@Type(type = "boolean")
	private Boolean dashBoardCam;

	@Column(name = "POWER_WINDOWS")
	@Type(type = "boolean")
	private Boolean powerWindows;

	@Column(name = "INTERIOR_COLOR_ID")
	private Long interiorColorId;

	@Column(name = "INTERIOR_COLOR_NAME")
	private String interiorColorName;

	/*
	 * @Column(name = "AM_FM_CD")
	 * 
	 * @Type(type = "boolean") private Boolean amFMCd;
	 */

	@Column(name = "AM_FM_CASSETE")
	@Type(type = "boolean")
	private Boolean amFMCassete;

	@Column(name = "BACKUP_CAMERA")
	@Type(type = "boolean")
	private Boolean backupCamera;

	@Column(name = "BRAKE_ASSIT")
	@Type(type = "boolean")
	private Boolean brakeAssit;

	@Column(name = "HEATED_SEATS")
	@Type(type = "boolean")
	private Boolean heatedSeats;

	@Column(name = "LEATHER_SEATS")
	@Type(type = "boolean")
	private Boolean leatherSeats;

	@Column(name = "MEMORY_SEATS")
	@Type(type = "boolean")
	private Boolean memorySeats;

	@Column(name = "NAVIGATION_SYSTEM")
	@Type(type = "boolean")
	private Boolean navigationSystem;

	@Column(name = "PASS_KEY_SECURITY")
	@Type(type = "boolean")
	private Boolean passKeySecurity;

	@Column(name = "PREMIUM_SOUND_SYSTEM")
	@Type(type = "boolean")
	private Boolean premiumSound;

	@Column(name = "TOTAL_SPEAKERS")
	private Long totalSpeakers;

	@Column(name = "KEYLESS_START")
	@Type(type = "boolean")
	private Boolean keylessStart;

	// ______________________________

	@Column(name = "ALLOY_WHEELS")
	@Type(type = "boolean")
	private Boolean allowWheels;

	@Column(name = "SPOILER")
	@Type(type = "boolean")
	private Boolean spoiler;

	@Column(name = "PROJECTOR_LAMPS")
	@Type(type = "boolean")
	private Boolean projectLamps;

	@Column(name = "SUNROOF_MOONROOF")
	@Type(type = "boolean")
	private Boolean sunMoonRoof;

	@Column(name = "AMBIENT_LIGHTING")
	@Type(type = "boolean")
	private Boolean ambientLighting;

	// ------------------------

	@Column(name = "ENGINE_CC_ID")
	private Long engineCcId;

	@Column(name = "ENGINE_CC_NAME")
	private String engineCcName;

	@Column(name = "ENGINE_BHP_ID")
	private Long engineBhpId;

	@Column(name = "ENGINE_BHP_NAME")
	private String engineBhpName;

	@Column(name = "FUEL_TYPE")
	private String fueltype;

	@Column(name = "TRANSMISSION")
	private String transmission;

	@Column(name = "NO_OF_CYLINDERS")
	private String noOfCylinder;

	@Column(name = "DRIVE_TYPE")
	private String driveType;

	// -----------------------

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "PHONE_NO")
	private String phoneNo;

	@Column(name = "USER_NAME")
	private String contactName;

	@Transient
	private List<Long> images = new ArrayList<>();
	
	@Transient
	private List<String>InteriorCols = new ArrayList<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public Long getMakeId() {
		return makeId;
	}

	public void setMakeId(Long makeId) {
		this.makeId = makeId;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public Long getSeatingId() {
		return seatingId;
	}

	public void setSeatingId(Long seatingId) {
		this.seatingId = seatingId;
	}

	public String getSeatingName() {
		return seatingName;
	}

	public void setSeatingName(String seatingName) {
		this.seatingName = seatingName;
	}

	public Boolean getNewCar() {
		return newCar;
	}

	public void setNewCar(Boolean newCar) {
		this.newCar = newCar;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getReducedPrice() {
		return reducedPrice;
	}

	public void setReducedPrice(BigDecimal reducedPrice) {
		this.reducedPrice = reducedPrice;
	}

	public Long getMileage() {
		return mileage;
	}

	public void setMileage(Long mileage) {
		this.mileage = mileage;
	}

	public String getTankCapacity() {
		return tankCapacity;
	}

	public void setTankCapacity(String tankCapacity) {
		this.tankCapacity = tankCapacity;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getTrim() {
		return trim;
	}

	public void setTrim(String trim) {
		this.trim = trim;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getBlueTooth() {
		return blueTooth;
	}

	public void setBlueTooth(Boolean blueTooth) {
		this.blueTooth = blueTooth;
	}

	public Boolean getAlarm() {
		return alarm;
	}

	public void setAlarm(Boolean alarm) {
		this.alarm = alarm;
	}

	public Boolean getAirBags() {
		return airBags;
	}

	public void setAirBags(Boolean airBags) {
		this.airBags = airBags;
	}

	public Boolean getAudio() {
		return audio;
	}

	public void setAudio(Boolean audio) {
		this.audio = audio;
	}

	public Boolean getVideo() {
		return video;
	}

	public void setVideo(Boolean video) {
		this.video = video;
	}

	public Boolean getCruiseControl() {
		return cruiseControl;
	}

	public void setCruiseControl(Boolean cruiseControl) {
		this.cruiseControl = cruiseControl;
	}

	public Boolean getAutoClimateControl() {
		return autoClimateControl;
	}

	public void setAutoClimateControl(Boolean autoClimateControl) {
		this.autoClimateControl = autoClimateControl;
	}

	public Boolean getMzClimateControl() {
		return mzClimateControl;
	}

	public void setMzClimateControl(Boolean mzClimateControl) {
		this.mzClimateControl = mzClimateControl;
	}

	public Boolean getPowerDriverSeat() {
		return powerDriverSeat;
	}

	public void setPowerDriverSeat(Boolean powerDriverSeat) {
		this.powerDriverSeat = powerDriverSeat;
	}

	public Boolean getRearBenchSeats() {
		return rearBenchSeats;
	}

	public void setRearBenchSeats(Boolean rearBenchSeats) {
		this.rearBenchSeats = rearBenchSeats;
	}

	public Boolean getStabilityControl() {
		return stabilityControl;
	}

	public void setStabilityControl(Boolean stabilityControl) {
		this.stabilityControl = stabilityControl;
	}

	public Boolean getPaddleShift() {
		return paddleShift;
	}

	public void setPaddleShift(Boolean paddleShift) {
		this.paddleShift = paddleShift;
	}

	public Boolean getTripComputer() {
		return tripComputer;
	}

	public void setTripComputer(Boolean tripComputer) {
		this.tripComputer = tripComputer;
	}

	public Boolean getClimateSeatControl() {
		return climateSeatControl;
	}

	public void setClimateSeatControl(Boolean climateSeatControl) {
		this.climateSeatControl = climateSeatControl;
	}

	public Boolean getFrontCam() {
		return frontCam;
	}

	public void setFrontCam(Boolean frontCam) {
		this.frontCam = frontCam;
	}

	public Boolean getRearCam() {
		return rearCam;
	}

	public void setRearCam(Boolean rearCam) {
		this.rearCam = rearCam;
	}

	public Boolean getDashBoardCam() {
		return dashBoardCam;
	}

	public void setDashBoardCam(Boolean dashBoardCam) {
		this.dashBoardCam = dashBoardCam;
	}

	public Boolean getPowerWindows() {
		return powerWindows;
	}

	public void setPowerWindows(Boolean powerWindows) {
		this.powerWindows = powerWindows;
	}

	public Long getInteriorColorId() {
		return interiorColorId;
	}

	public void setInteriorColorId(Long interiorColorId) {
		this.interiorColorId = interiorColorId;
	}

	public String getInteriorColorName() {
		return interiorColorName;
	}

	public void setInteriorColorName(String interiorColorName) {
		this.interiorColorName = interiorColorName;
	}

	public Boolean getAmFMCassete() {
		return amFMCassete;
	}

	public void setAmFMCassete(Boolean amFMCassete) {
		this.amFMCassete = amFMCassete;
	}

	public Boolean getBackupCamera() {
		return backupCamera;
	}

	public void setBackupCamera(Boolean backupCamera) {
		this.backupCamera = backupCamera;
	}

	public Boolean getBrakeAssit() {
		return brakeAssit;
	}

	public void setBrakeAssit(Boolean brakeAssit) {
		this.brakeAssit = brakeAssit;
	}

	public Boolean getHeatedSeats() {
		return heatedSeats;
	}

	public void setHeatedSeats(Boolean heatedSeats) {
		this.heatedSeats = heatedSeats;
	}

	public Boolean getLeatherSeats() {
		return leatherSeats;
	}

	public void setLeatherSeats(Boolean leatherSeats) {
		this.leatherSeats = leatherSeats;
	}

	public Boolean getMemorySeats() {
		return memorySeats;
	}

	public void setMemorySeats(Boolean memorySeats) {
		this.memorySeats = memorySeats;
	}

	public Boolean getNavigationSystem() {
		return navigationSystem;
	}

	public void setNavigationSystem(Boolean navigationSystem) {
		this.navigationSystem = navigationSystem;
	}

	public Boolean getPassKeySecurity() {
		return passKeySecurity;
	}

	public void setPassKeySecurity(Boolean passKeySecurity) {
		this.passKeySecurity = passKeySecurity;
	}

	public Boolean getPremiumSound() {
		return premiumSound;
	}

	public void setPremiumSound(Boolean premiumSound) {
		this.premiumSound = premiumSound;
	}

	public Long getTotalSpeakers() {
		return totalSpeakers;
	}

	public void setTotalSpeakers(Long totalSpeakers) {
		this.totalSpeakers = totalSpeakers;
	}

	public Boolean getKeylessStart() {
		return keylessStart;
	}

	public void setKeylessStart(Boolean keylessStart) {
		this.keylessStart = keylessStart;
	}

	public Boolean getAllowWheels() {
		return allowWheels;
	}

	public void setAllowWheels(Boolean allowWheels) {
		this.allowWheels = allowWheels;
	}

	public Boolean getSpoiler() {
		return spoiler;
	}

	public void setSpoiler(Boolean spoiler) {
		this.spoiler = spoiler;
	}

	public Boolean getProjectLamps() {
		return projectLamps;
	}

	public void setProjectLamps(Boolean projectLamps) {
		this.projectLamps = projectLamps;
	}

	public Boolean getSunMoonRoof() {
		return sunMoonRoof;
	}

	public void setSunMoonRoof(Boolean sunMoonRoof) {
		this.sunMoonRoof = sunMoonRoof;
	}

	public Long getEngineCcId() {
		return engineCcId;
	}

	public void setEngineCcId(Long engineCcId) {
		this.engineCcId = engineCcId;
	}

	public String getEngineCcName() {
		return engineCcName;
	}

	public void setEngineCcName(String engineCcName) {
		this.engineCcName = engineCcName;
	}

	public Long getEngineBhpId() {
		return engineBhpId;
	}

	public void setEngineBhpId(Long engineBhpId) {
		this.engineBhpId = engineBhpId;
	}

	public String getEngineBhpName() {
		return engineBhpName;
	}

	public void setEngineBhpName(String engineBhpName) {
		this.engineBhpName = engineBhpName;
	}

	public String getFueltype() {
		return fueltype;
	}

	public void setFueltype(String fueltype) {
		this.fueltype = fueltype;
	}

	public String getTransmission() {
		return transmission;
	}

	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}

	public String getNoOfCylinder() {
		return noOfCylinder;
	}

	public void setNoOfCylinder(String noOfCylinder) {
		this.noOfCylinder = noOfCylinder;
	}

	public String getDriveType() {
		return driveType;
	}

	public void setDriveType(String driveType) {
		this.driveType = driveType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public Boolean getAmbientLighting() {
		return ambientLighting;
	}

	public void setAmbientLighting(Boolean ambientLighting) {
		this.ambientLighting = ambientLighting;
	}

	public Long getFirstImage() {
		return firstImage;
	}

	public void setFirstImage(Long firstImage) {
		this.firstImage = firstImage;
	}

	public List<Long> getImages() {
		return images;
	}

	public void setImages(List<Long> images) {
		this.images = images;
	}

	
	public List<String> getInteriorCols() {
		return InteriorCols;
	}

	public void setInteriorCols(List<String> interiorCols) {
		InteriorCols = interiorCols;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HotDealCarDetails other = (HotDealCarDetails) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	
	
}
