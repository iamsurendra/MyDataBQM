package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.Image;
import com.sgsystems.motor.models.ImageKey;

@Repository
public class ImageDAOImpl extends BaseDAOImpl<Image, ImageKey> implements ImageDAO {

	public ImageDAOImpl() {
		super(Image.class);

	}

	@Override
	public List<String> getImgelistByID(Long Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Image> root = criteriaQuery.from(Image.class);
		criteriaQuery.select(root.get("url")).where(criteriaBuilder.equal(root.get("carId"), Id)).orderBy(criteriaBuilder.asc(root.get("profileId")));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
	public List<Image> getImageInfolistByID(Long Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Image> criteriaQuery = criteriaBuilder.createQuery(Image.class);
		Root<Image> root = criteriaQuery.from(Image.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("carId"), Id));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
}
