
package com.sgsystems.motor.repositories;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.Car;
import com.sgsystems.motor.models.Make;

/**
 * @author Guvvala
 *
 */
@Repository
public class MakeDAOImpl extends BaseDAOImpl<Make, Long> implements MakeDAO {

	public MakeDAOImpl() {
		super(Make.class);
	}

	@Override
	public Map<String, Long> getCarsBodyTypeCount() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Make> query = criteriaBuilder.createQuery(Make.class);
		Root<Make> root = query.from(Make.class);
		Root<Car> carRoot = query.from(Car.class);
		query.select(criteriaBuilder.construct(Make.class, criteriaBuilder.count(root.get("bodyType")),
				root.get("bodyType")));
		query.where(criteriaBuilder.and(criteriaBuilder.equal(carRoot.get("makeId"), root.get("id")),criteriaBuilder.equal(carRoot.get("status"), 1)));
		query.groupBy(root.get("bodyType"));
		List<Make> bodyCount = entityManager.createQuery(query).getResultList();
		return bodyCount.stream().collect(Collectors.toMap(Make::getBodyType, Make::getCount));
	}

	@Override
	public Map<String, Long> getCarMakesCount() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Make> criteriaQuery = criteriaBuilder.createQuery(Make.class);
		Root<Car> carRoot = criteriaQuery.from(Car.class);
		Root<Make> makeRoot = criteriaQuery.from(Make.class);
		criteriaQuery
				.select(criteriaBuilder.construct(Make.class, makeRoot.get("name"), criteriaBuilder.count(makeRoot)));
				criteriaQuery.where(criteriaBuilder.and(criteriaBuilder.equal(carRoot.get("status"), 1)), 
				criteriaBuilder.equal(carRoot.get("makeId"), makeRoot.get("id")));
		criteriaQuery.groupBy(makeRoot.get("name"));
		List<Make> makeCount = entityManager.createQuery(criteriaQuery).getResultList();
		return makeCount.stream().collect(Collectors.toMap(Make::getName, Make::getCount));
	}

	@Override
	public List<String> getAllCarMakes() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Make> makeRoot = criteriaQuery.from(Make.class);
		criteriaQuery.select(makeRoot.get("name")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	@Override
	public List<String> getModelsByCarMake(String make) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Make> makeRoot = criteriaQuery.from(Make.class);
		criteriaQuery.select(makeRoot.get("model")).distinct(true);
		criteriaQuery.where(criteriaBuilder.equal(makeRoot.get("name"), make));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
	@Override
	public List<String> getBodyStyles() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Make> makeRoot = criteriaQuery.from(Make.class);
		criteriaQuery.select(makeRoot.get("bodyType")).distinct(true);
		criteriaQuery.orderBy(criteriaBuilder.asc(makeRoot.get("bodyType")));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	@Override
	public List<String> getBodyStyleByMakeAndModel(String Name, String Model) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Make> makeRoot = criteriaQuery.from(Make.class);
		criteriaQuery.select(makeRoot.get("bodyType")).distinct(true);
		criteriaQuery.where(criteriaBuilder.and(criteriaBuilder.equal(makeRoot.get("name"), Name),
				criteriaBuilder.equal(makeRoot.get("model"), Model)));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	@Override
	public Long getMakersId(String Name, String Model,  String bodyType) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
		Root<Make> makeRoot = criteriaQuery.from(Make.class);
		criteriaQuery.select(makeRoot.get("id")).distinct(true);
		criteriaQuery.where(criteriaBuilder.and(criteriaBuilder.equal(makeRoot.get("name"), Name),
				criteriaBuilder.equal(makeRoot.get("model"), Model), criteriaBuilder.equal(makeRoot.get("bodyType"), bodyType)));
		List<Long> makeIds = entityManager.createQuery(criteriaQuery).getResultList();
		return makeIds.stream().findFirst().orElse(null);
	}

	@Override
	public List<String> getBodyTypeList() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Make> root = criteriaQuery.from(Make.class);
		criteriaQuery.select(root.get("bodyType")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	@Override
	public Make getMakeInfoByID(Long id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Make> criteriaQuery = criteriaBuilder.createQuery(Make.class);
		Root<Make> root = criteriaQuery.from(Make.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("id"), id));
		return entityManager.createQuery(criteriaQuery).getSingleResult();

	}
	@Override
	  public List<Make>getMakeInfoByIDs(List<Long> ids) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Make> criteriaQuery = criteriaBuilder.createQuery(Make.class);
		Root<Make> root = criteriaQuery.from(Make.class);
		criteriaQuery.select(root);
		criteriaQuery.where(root.get("id").in(ids));

		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
	

}