package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.Enginebhp;

public interface EnginebhpService {

	public List<String> getEngineBhpList();

	List<Enginebhp> getEnginBhpInfo();

}
