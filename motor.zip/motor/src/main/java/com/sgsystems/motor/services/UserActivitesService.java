package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.UserActivities;

public interface UserActivitesService {

	public UserActivities createFavoriteCar(UserActivities userActivities);
	
	public void deleteCarfromFavorite(UserActivities userActivities);

	List<Long> findAllFavioritesByUser(Long userId);

	public List<UserActivities> getCarInfoById(Long Id);
	/*
	public Favorites getCarCountByUserID(Long Id);*/
	
}
