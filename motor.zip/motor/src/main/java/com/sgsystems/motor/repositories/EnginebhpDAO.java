package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.Enginebhp;

public interface EnginebhpDAO extends BaseDAO<Enginebhp, Long> {

	public List<String> getEngineBhpList();
}
