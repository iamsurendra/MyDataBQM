package com.sgsystems.motor.controllers;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.guvvala.framework.util.Interior;
import com.sgsystems.motor.json.CarJson;
import com.sgsystems.motor.json.CarResultsJson;
import com.sgsystems.motor.json.CommentJson;
import com.sgsystems.motor.models.Car;
import com.sgsystems.motor.models.CarDetailsView;
import com.sgsystems.motor.models.Make;
import com.sgsystems.motor.models.UserDetailsView;
import com.sgsystems.motor.services.CarAlertService;
import com.sgsystems.motor.services.CarDetailsViewService;
import com.sgsystems.motor.services.CarService;
import com.sgsystems.motor.services.ImageService;
import com.sgsystems.motor.services.MakeService;
import com.sgsystems.motor.services.UserDetailsViewService;

@RestController
@RequestMapping("index")
public class IndexController {

	@Autowired
	CarDetailsViewService cardetailsViewService;

	@Autowired
	MakeService makeService;

	@Autowired
	ImageService imageService;

	@Autowired
	CarService carService;
	
	@Autowired
	UserDetailsViewService userDetailsViewService;
	
	@Autowired
    CarAlertService carAlertService;
	

	/**
	 * 
	 * Retrieving the search result
	 */
	// -------------- ----------------------------
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public CarResultsJson searchInfo(@RequestBody CarJson carJson) throws IllegalAccessException {
		CarResultsJson carResultsJson = cardetailsViewService.search(carJson);
		for (CarDetailsView carDetail : carResultsJson.getCarDetails()) {
			Field[] fields = FieldUtils.getFieldsWithAnnotation(carDetail.getClass(), Interior.class);
			for (Field field : fields) {
				field.setAccessible(true);
				Object value = field.get(carDetail);
				Interior interior = field.getAnnotation(Interior.class);
				if (value != null && value instanceof Boolean && (Boolean) value) {
					if (carDetail.getInteriorCols().size() >= 5) {
						break;
					} else {
						carDetail.getInteriorCols().add(interior.name());
					}
				}
			}

		}
		return carResultsJson;
	}

	/**
	 * 
	 * Retrieving the search result By Id
	 */
	@RequestMapping(value = "searchById/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public CarDetailsView carViewDetailsById(@PathVariable("id") Long id) {
		return cardetailsViewService.getCarInfoByID(id);
	}

	/**
	 * 
	 * Retrieving the BodyType Count
	 */

	@RequestMapping(value = "/bodyTypeCount", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Make> getCarsBodyTypeCount() {
		//Map<String, Long> bodyTypeCount = makeService.getCarsBodyTypeCount();
		List<String> bodyTypes = makeService.getBodyTypeList();
		List<Make> bodyTypeCounts = new ArrayList<>();
		for (String bodyType : bodyTypes) {
			/*Long count = bodyTypeCount.get(bodyType);
			bodyTypeCounts.add(new Make(count != null ? count : 0, bodyType));*/
			Make carBodyType= new Make();
			carBodyType.setBodyType(bodyType);
			bodyTypeCounts.add(carBodyType);
		}
		return bodyTypeCounts;
	}

	/**
	 * 
	 * Retrieving the Make Count
	 */
	@RequestMapping(value = "/makersCount", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Make> getCarMakeCount() {
		//Map<String, Long> makeCount = makeService.getCarMakesCount();
		List<String> makeList = makeService.getAllCarMakes();
		List<Make> makeCounts = new ArrayList<>();
		for (String make : makeList) {
		//	Long count = makeCount.get(make);
			//makeCounts.add(new Make(make, count != null ? count : 0));
			Make carMake= new Make();
			carMake.setName(make);
			makeCounts.add(carMake);
		}
		return makeCounts;
	}

	@RequestMapping(value = "priceCount", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Car> getCountOfPrice() {
		return carService.getCountOfPrice();
	}

	@RequestMapping(value = "/message", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void sendMessageToCarOwner(@RequestBody CommentJson comment) throws AddressException, MessagingException {
		carService.sendMessageCarOwner(comment);
	}

	@RequestMapping(value = "/userLocalInfoById", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public UserDetailsView getUserLocalInfoByUserId(@RequestParam("userId") Long userId,@RequestParam("languageId")Long languageId) {
		return userDetailsViewService.getUserDetailsInfoByUserId(userId,languageId);

	}
	
	@RequestMapping(value = "/carInfoById/{carId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)	
	public CarDetailsView carInfoById(@RequestParam("languageId") Long languageId,@PathVariable("carId") Long carId) {
		return cardetailsViewService.carInfoById(languageId,carId);
	}
	
	
}
