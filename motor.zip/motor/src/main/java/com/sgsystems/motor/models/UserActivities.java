package com.sgsystems.motor.models;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "user_activities")
public class UserActivities {

	@EmbeddedId
	private UserActivityKey userCarMappingKey;

	@Column(name = "USER_ID", insertable = false, updatable = false)
	private Long userId;

	@Column(name = "CAR_ID", insertable = false, updatable = false)
	private Long carId;

	@Column(name = "FAVORITE")
	@Type(type = "boolean")
	private Boolean favorite;

	@Column(name = "STATUS")
	@Type(type = "boolean")
	private Boolean status;

	// Getters and setters //

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getCarId() {
		return carId;
	}

	public void setCarId(Long carId) {
		this.carId = carId;
	}

	public UserActivityKey getUserCarMappingKey() {
		return userCarMappingKey;
	}

	public void setUserCarMappingKey(UserActivityKey userCarMappingKey) {
		this.userCarMappingKey = userCarMappingKey;
	}

	public Boolean getFavorite() {
		return favorite;
	}

	public void setFavorite(Boolean favorite) {
		this.favorite = favorite;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userCarMappingKey == null) ? 0 : userCarMappingKey.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserActivities other = (UserActivities) obj;
		if (userCarMappingKey == null) {
			if (other.userCarMappingKey != null)
				return false;
		} else if (!userCarMappingKey.equals(other.userCarMappingKey))
			return false;
		return true;
	}

}
