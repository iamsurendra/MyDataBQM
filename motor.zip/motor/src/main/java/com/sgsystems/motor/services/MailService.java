package com.sgsystems.motor.services;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.sgsystems.motor.constants.MailTemplateEnum;

@Component
public interface MailService {

	void sendEmail(MailTemplateEnum mailTemplate, Map<String, Object> values, String[] to, Object... subject);

	

	

	

	

}
