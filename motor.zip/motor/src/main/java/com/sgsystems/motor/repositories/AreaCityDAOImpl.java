package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.AreaCity;


@Repository
public class AreaCityDAOImpl extends BaseDAOImpl<AreaCity, Long> implements AreaCityDAO{

	public AreaCityDAOImpl() {
		super(AreaCity.class);
	}
	
	@Override
	public List<AreaCity> getAreaCityByProvinceId(Long provinceId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<AreaCity> criteriaQuery = criteriaBuilder.createQuery(AreaCity.class);
		Root<AreaCity> root = criteriaQuery.from(AreaCity.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(criteriaBuilder.equal(root.get("provinceId"), provinceId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

}
