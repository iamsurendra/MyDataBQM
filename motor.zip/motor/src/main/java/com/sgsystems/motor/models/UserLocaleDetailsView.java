package com.sgsystems.motor.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "user_local_detail_view")

public class UserLocaleDetailsView implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	UserLocaleDetailsViewKey userLocaleDetailsViewKey;

	@Column(name = "USER_ID", insertable = false, updatable = false)
	private Long userId;

	@Column(name = "LANGUAGE_ID", insertable = false, updatable = false)
	private int languageId;

	@Column(name = "EMAIL")
	private String eMail;

	@Column(name = "PHONE_NO")
	private String phoneNo;

	@Column(name = "NEW_PHONE_NUMBER")
	private String newPhoneNumber;

	@Column(name = "DEALER_ID")
	private Integer dealerId;

	@Column(name = "ADMIN")
	@Type(type = "boolean")
	private Boolean admin;

	@Column(name = "DEALER_NAME")
	private String dealerName;

	@Column(name = "MAX_VEHICLES")
	private Integer maxVehicles;

	@Column(name = "USER_STATUS")
	private int userStatus;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "LAST_NAME")
	private String lastName;

	@Column(name = "ADDRESS")
	private String address;

	@Column(name = "PROVINCE")
	private String province;

	@Column(name = "AREA")
	private String area;

	@Column(name = "DEALER_CODE")
	private String dealerCode;

	// getters and setters

	public UserLocaleDetailsViewKey getUserLocaleDetailsViewKey() {
		return userLocaleDetailsViewKey;
	}

	public void setUserLocaleDetailsViewKey(UserLocaleDetailsViewKey userLocaleDetailsViewKey) {
		this.userLocaleDetailsViewKey = userLocaleDetailsViewKey;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public int getLanguageId() {
		return languageId;
	}

	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getNewPhoneNumber() {
		return newPhoneNumber;
	}

	public void setNewPhoneNumber(String newPhoneNumber) {
		this.newPhoneNumber = newPhoneNumber;
	}

	public Integer getDealerId() {
		return dealerId;
	}

	public void setDealerId(Integer dealerId) {
		this.dealerId = dealerId;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public Integer getMaxVehicles() {
		return maxVehicles;
	}

	public void setMaxVehicles(Integer maxVehicles) {
		this.maxVehicles = maxVehicles;
	}

	public int getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(int userStatus) {
		this.userStatus = userStatus;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public Boolean getAdmin() {
		return admin;
	}

	public void setAdmin(Boolean admin) {
		this.admin = admin;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userLocaleDetailsViewKey == null) ? 0 : userLocaleDetailsViewKey.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserLocaleDetailsView other = (UserLocaleDetailsView) obj;
		if (userLocaleDetailsViewKey == null) {
			if (other.userLocaleDetailsViewKey != null)
				return false;
		} else if (!userLocaleDetailsViewKey.equals(other.userLocaleDetailsViewKey))
			return false;
		return true;
	}

}
