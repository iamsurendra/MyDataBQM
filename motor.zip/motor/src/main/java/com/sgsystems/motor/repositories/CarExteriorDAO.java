package com.sgsystems.motor.repositories;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.CarExterior;

public interface CarExteriorDAO extends BaseDAO<CarExterior,Long>{

}
