package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.User;

@Repository
public class UserDAOImpl extends BaseDAOImpl<User, Long> implements UserDAO {

	public UserDAOImpl() {
		super(User.class);

	}

	public User getUser(Long userId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> user = cQuery.from(User.class);
		cQuery.select(user).where(builder.or(builder.equal(user.get("userId"), userId)));
		List<User> userList = entityManager.createQuery(cQuery).getResultList();
		if (null != userList && !userList.isEmpty()) {
			return userList.get(0);
		} else {
			return null;
		}
	}

	public boolean uniqueUserName(String userName) {
		TypedQuery<Long> query = entityManager
				.createQuery("SELECT count(u) from User u where userName ='" + userName + "'", Long.class);
		if (query.getSingleResult() == 0) {
			return false;
		} else {
			return true;
		}

	}

	public boolean validateEmail(String email) {
		TypedQuery<Long> query = entityManager.createQuery("SELECT count (e) from User e where eMail='" + email + "'",
				Long.class);
		if (query.getSingleResult() == 0) {
			return false;
		} else {
			return true;
		}
	}

	public User getuserInfoByUserId(Long UserId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> criteriaQuery = criteriaBuilder.createQuery(User.class);
		Root<User> root = criteriaQuery.from(User.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("userId"), UserId));
		return entityManager.createQuery(criteriaQuery).getSingleResult();

	}

	@Override
	public User getEmail(String eMail) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> user = cQuery.from(User.class);
		cQuery.select(user).where(builder.equal(user.get("eMail"), eMail));
		return entityManager.createQuery(cQuery).getSingleResult();
		
	}

}