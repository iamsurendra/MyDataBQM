package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.AreaCity;


public interface AreaCityDAO extends BaseDAO<AreaCity, Long>{
	
	
	
	List<AreaCity> getAreaCityByProvinceId(Long provinceId);
}
