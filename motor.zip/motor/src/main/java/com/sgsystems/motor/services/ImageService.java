package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.Image;

public interface ImageService {

	public void create(Image image);

	List<String> getImgelistByID(Long Id);

	public Image findById(Image image);

	public List<Image> getImageInfolistByID(Long Id);

	public void update(Image image);
	
	public void delete(Image image);
	
	public Image findOneImage(Long carId,String imageProfile);
}
