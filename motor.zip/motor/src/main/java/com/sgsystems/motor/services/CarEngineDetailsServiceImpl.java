package com.sgsystems.motor.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgsystems.motor.repositories.CarEngineDetailsDAO;

@Service
public class CarEngineDetailsServiceImpl implements CarEngineDetailsService {
	@Autowired
	CarEngineDetailsDAO carFuleDetailsDAO;

	@Override
	@Transactional(readOnly = true)
	public List<String> getCarsFuelTypes() {
		return carFuleDetailsDAO.getCarsFuelTypes();
	}

}
