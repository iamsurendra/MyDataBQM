package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.constants.LanguageEnum;
import com.sgsystems.motor.models.UserLocaleDetails;

@Repository
public class UserLocaleDetailsDAOImpl extends BaseDAOImpl<UserLocaleDetails, Long> implements UserLocaleDetailsDAO {

	public UserLocaleDetailsDAOImpl() {
		super(UserLocaleDetails.class);
			}
	
	public List<UserLocaleDetails> getAllEnglishLocalUser() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserLocaleDetails> criteriaQuery = criteriaBuilder.createQuery(UserLocaleDetails.class);
		Root<UserLocaleDetails> root = criteriaQuery.from(UserLocaleDetails.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("languageId"), LanguageEnum.EN.value));
		return entityManager.createQuery(criteriaQuery).getResultList();

}
	
	public List<UserLocaleDetails> getUserInfoByUserId(Long Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserLocaleDetails> criteriaQuery = criteriaBuilder.createQuery(UserLocaleDetails.class);
		Root<UserLocaleDetails> root = criteriaQuery.from(UserLocaleDetails.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("id"), Id));
		return entityManager.createQuery(criteriaQuery).getResultList();

}
		

}
