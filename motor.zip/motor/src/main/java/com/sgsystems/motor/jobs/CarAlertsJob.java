package com.sgsystems.motor.jobs;



import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.guvvala.framework.logging.AppLogger;
import com.guvvala.framework.logging.Log;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.sgsystems.motor.services.CarAlertService;

@Component
public class CarAlertsJob implements Job {

	private static @Log AppLogger logger;

	@Autowired
	CarAlertService carAlertsService;

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		try {
			ThreadLocalUtil.setThreadVariable(ThreadLocalUtil.LOCALE, "en");
			carAlertsService.sendMailForCarAlerts();
		} catch (Exception ex) {
			logger.error(ex);
		}
	}

}
