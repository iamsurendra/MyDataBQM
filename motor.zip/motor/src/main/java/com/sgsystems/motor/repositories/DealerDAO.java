package com.sgsystems.motor.repositories;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.Dealer;

public interface DealerDAO extends BaseDAO<Dealer, Long> {

	public Long uniqueDealerName(String dealerName);

	public Long getMaxVehicles(Long Id);
	
	Long validateRegistrationNumber(String regNo);
	
	;

}
