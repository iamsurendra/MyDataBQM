package com.sgsystems.motor.constants;

import java.util.HashMap;
import java.util.Map;

public enum CarImageStatus {
	frontProfile(1, "frontProfile"),
	frontRightProfile(2, "frontRightProfile"), 
	rightProfile(3, "rightProfile"),
	backLeftProfile(4, "backLeftProfile"),
	backProfile(5, "backProfile"),
	backRightProfile(6, "backRightProfile"),
	leftProfile(7, "leftProfile"),
	frontLeftProfile(8, "frontLeftProfile"),
	driverSideView(9, "driverSideView"),
	driversDoorProfile(10, "driversDoorProfile"),
	roofProfile(11, "roofProfile"),
	passengerSideProfile(12, "passengerSideProfile"),
	dashboardView(13, "dashboardView"),
	rearSeatsProfile(14, "rearSeatsProfile"),
	engineView(15, "engineView"),
	trunkView(16, "trunkView");

	

	public final int value;
	public final String stringValue;
	
	private static final Map<Integer, CarImageStatus> valueMap = new HashMap<Integer, CarImageStatus>();
	private static final Map<String, CarImageStatus> stringMap = new HashMap<String, CarImageStatus>();

	static {
		for (CarImageStatus constant : CarImageStatus.class.getEnumConstants()) {
			valueMap.put(constant.value, constant);
			stringMap.put(constant.stringValue, constant);
		}
	}

	private CarImageStatus(int value, String stringValue) {
		this.value = value;
		this.stringValue = stringValue;
	}

	public static CarImageStatus fromString(final String stringValue) {
		return stringMap.get(stringValue);
	}

	public static CarImageStatus fromInteger(final Integer intValue) {
		return valueMap.get(intValue);
	}
	    
}
