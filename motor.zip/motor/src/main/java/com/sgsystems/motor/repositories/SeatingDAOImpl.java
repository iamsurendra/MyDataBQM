package com.sgsystems.motor.repositories;


import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;

import com.sgsystems.motor.models.Seating;
@Repository
public class SeatingDAOImpl extends BaseDAOImpl<Seating, Long> implements SeatingDAO{

	public SeatingDAOImpl() {
		super(Seating.class);
		// TODO Auto-generated constructor stub
	}
	
	
}
