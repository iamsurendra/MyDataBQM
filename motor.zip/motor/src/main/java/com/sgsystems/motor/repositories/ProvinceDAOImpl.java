package com.sgsystems.motor.repositories;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.Province;

@Repository
public class ProvinceDAOImpl extends BaseDAOImpl<Province, Long> implements ProvinceDAO {

	public ProvinceDAOImpl() {
		super(Province.class);
		// TODO Auto-generated constructor stub
	}

}
