package com.sgsystems.motor.constants;

import java.util.HashMap;
import java.util.Map;

public enum ImageEnum {

	FRONT_PROFILE(0, "frontProfile"),
	FRONT_RIGHT_PROFILE(1, "frontRightProfile"), 
	RIGHT_PROFILE(2, "rightProfile"),
	BACK_LEFT_PROFILE(3, "backLeftProfile"),
	BACK_PROFILE(4, "backProfile"),
	BACK_RIGHT_PROFILE(5, "backRightProfile"),
	LEFT_PROFILE(6, "leftProfile"),
	FRONT_LEFT_PROFILE(7, "frontLeftProfile"),
	DRIVER_SIDE_VIEW(8, "driverSideView"),
	DRIVERS_DOOR_PROFILE(9, "driversDoorProfile"),
	ROOF_PROFILE(10, "roofProfile"),
	PASSEGER_SIDE_PROFILE(11, "passengerSideProfile"),
	DASH_BOARD_VIEW(12, "dashboardView"),
	REAR_SEATS_PROFILE(13, "rearSeatsProfile"),
	ENGINE_VIEW(14, "engineView"),
	TRUNK_VIEW(15, "trunkView");
	
	
	
	public final int value;
	public final String stringValue;
	
	private static final Map<Integer, ImageEnum> valueMap = new HashMap<Integer, ImageEnum>();
	private static final Map<String, ImageEnum> stringMap = new HashMap<String, ImageEnum>();
	
	static {
		for (ImageEnum constant : ImageEnum.class.getEnumConstants()) {
			valueMap.put(constant.value, constant);
			stringMap.put(constant.stringValue, constant);
		}
	}

	private ImageEnum(int value, String stringValue) {
		this.value = value;
		this.stringValue = stringValue;
	}

	public static Map<Integer, ImageEnum> getValuemap() {
		return valueMap;
	}

	public static Map<String, ImageEnum> getStringmap() {
		return stringMap;
	}


	
	
}
