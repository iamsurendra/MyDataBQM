package com.sgsystems.motor.constants;

public enum LanguageEnum {

	EN(100, "ENGLISH"), 
	DARI(101, "DARI"), 
	PASHTO(102, "PASHTO");

	public final int value;
	public final String stringValue;

	private LanguageEnum(int value, String stringValue) {
		this.value = value;
		this.stringValue = stringValue;
	}

}
