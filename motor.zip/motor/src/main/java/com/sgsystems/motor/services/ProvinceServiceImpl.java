package com.sgsystems.motor.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgsystems.motor.models.Province;
import com.sgsystems.motor.repositories.ProvinceDAO;

@Service
public class ProvinceServiceImpl implements ProvinceService {

	@Autowired
	ProvinceDAO provinceDAO;

	@Override
	@Transactional
	public List<Province> findAllProvinceDetails() {
		return provinceDAO.findAll();
	}

}
