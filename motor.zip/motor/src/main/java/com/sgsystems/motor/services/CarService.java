package com.sgsystems.motor.services;

import java.math.BigDecimal;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.sgsystems.motor.json.CommentJson;
import com.sgsystems.motor.models.Car;
import com.sgsystems.motor.models.Make;

/**
 * @author Guvvala
 *
 */
public interface CarService {

	void updateCarDetails(Car car);

	List<Car> getCarInfoById(BigDecimal price1, BigDecimal price2);

	Car createInactiveCar(Long userId);

	Car findById(Long id);

	void makeCarAsInActive(Long carId);

	List<Car> getCountOfPrice();

	public void deleteCar(Long carId);

	public Car getCarInfoById(Long id);

	List<Make> getCarInfoByID(List<Long> ids);
	
	Long countOfCarsByUserId(Long userId);
	
	public void sendMessageCarOwner(CommentJson commentJson) throws AddressException, MessagingException;
	
	public boolean checkDealerMaxcars(Long userId);
}
