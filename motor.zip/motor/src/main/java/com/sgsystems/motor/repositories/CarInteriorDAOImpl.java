package com.sgsystems.motor.repositories;



import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.CarInterior;

@Repository
public class CarInteriorDAOImpl extends BaseDAOImpl<CarInterior, Long> implements CarInteriorDAO{

	public CarInteriorDAOImpl() {
		super(CarInterior.class);
		// TODO Auto-generated constructor stub
	}


}
