package com.sgsystems.motor.repositories;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.UserDealerView;

@Repository
public class UserDealerViewDAOImpl extends BaseDAOImpl<UserDealerView, Long> implements UserDealerViewDAO {

	public UserDealerViewDAOImpl() {
		super(UserDealerView.class);
	}

	public String findDealerCode(Long userId) {
		TypedQuery<String> query = entityManager.createNamedQuery(UserDealerView.FIND_DEALER_CODE, String.class);
		return query.setParameter("userId", userId).getSingleResult();
	}
	
	
	

}
