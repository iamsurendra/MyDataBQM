package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.carsAlertsView;

public interface CarsAlertsViewDAO  extends BaseDAO<carsAlertsView, Long>{
	
	public List<carsAlertsView> getcarAlertsList();

}
