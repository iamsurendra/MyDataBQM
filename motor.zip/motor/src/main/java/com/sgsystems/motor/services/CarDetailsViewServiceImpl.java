package com.sgsystems.motor.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgsystems.motor.json.CarJson;
import com.sgsystems.motor.json.CarResultsJson;
import com.sgsystems.motor.models.CarDetailsView;
import com.sgsystems.motor.repositories.CarDetailsViewDAO;

/**
 * @author Guvvala
 *
 */
@Service
public class CarDetailsViewServiceImpl implements CarDetailsViewService {

	@Autowired
	CarDetailsViewDAO carDetailsViewDAO;

	@Autowired
	ImageService imageService;

	@Override
	@Transactional(readOnly = true)
	public CarDetailsView getCarInfoByID(Long id) {
		CarDetailsView carDetailsView = carDetailsViewDAO.getCarInfoByID(id);
		carDetailsView.setImages(imageService.getImgelistByID(id));
		return carDetailsView;
	}

	@Override
	@Transactional
	public CarResultsJson search(CarJson carJson) {
		return carDetailsViewDAO.search(carJson);
	}

	@Override
	@Transactional
	public List<CarDetailsView> getCarInfoByID(List<Long> ids,Long languageId) {
		return carDetailsViewDAO.getCarInfoByID(ids,languageId);
	}

	@Override
	@Transactional
	public List<CarDetailsView> getAllCarviewdetails() {
		return carDetailsViewDAO.findAll();
	}

	@Transactional
	public CarDetailsView carInfoById(Long languageId,Long carId) {
	CarDetailsView carDetailsView =	carDetailsViewDAO.carInfoById(languageId,carId);
	carDetailsView.setImages(imageService.getImgelistByID(carId));
		return carDetailsView;
	}
}
