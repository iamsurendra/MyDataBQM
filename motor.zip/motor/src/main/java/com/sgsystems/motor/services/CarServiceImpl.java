package com.sgsystems.motor.services;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgsystems.motor.constants.CarStatus;
import com.sgsystems.motor.constants.MailTemplateEnum;
import com.sgsystems.motor.constants.MotarConstants;
import com.sgsystems.motor.json.CommentJson;
import com.sgsystems.motor.models.Car;
import com.sgsystems.motor.models.CarEngineDetails;
import com.sgsystems.motor.models.CarInterior;
import com.sgsystems.motor.models.Image;
import com.sgsystems.motor.models.Make;
import com.sgsystems.motor.models.RecentViewCars;
import com.sgsystems.motor.models.User;
import com.sgsystems.motor.models.UserActivities;
import com.sgsystems.motor.repositories.CarDAO;
import com.sgsystems.motor.repositories.CarDetailsViewDAO;
import com.sgsystems.motor.repositories.CarEngineDetailsDAO;
import com.sgsystems.motor.repositories.CarExteriorDAO;
import com.sgsystems.motor.repositories.CarInteriorDAO;
import com.sgsystems.motor.repositories.DealerDAO;
import com.sgsystems.motor.repositories.DealerSequenceDAO;
import com.sgsystems.motor.repositories.MakeDAO;
import com.sgsystems.motor.repositories.RecentViewCarsDAO;
import com.sgsystems.motor.repositories.UserActivitesDAO;
import com.sgsystems.motor.repositories.UserDAO;
import com.sgsystems.motor.repositories.UserDealerViewDAO;

@Service
public class CarServiceImpl implements CarService {

	@Autowired
	CarDAO carDao;

	@Autowired
	private MailService ms;

	@Autowired
	CarDetailsViewDAO carDetailsViewDAO;

	@Autowired
	CarEngineDetailsDAO carEngineDetailsDAO;

	@Autowired
	CarExteriorDAO carExteriorDAO;

	@Autowired
	CarInteriorDAO carInteriorDAO;

	@Autowired
	MakeDAO makeDAO;

	@Autowired
	UserActivitesDAO userActivitesDAO;

	@Autowired
	DealerSequenceDAO dealerSequenceDAO;

	@Autowired
	RecentViewCarsDAO recentViewCarsDAO;

	@Autowired
	UserDAO userDAO;

	@Autowired
	ImageService imageService;

	@Autowired
	MailService mailService;

	@Autowired
	DealerDAO dealerDAO;

	@Autowired
	UserDealerViewDAO userDealerViewDAO;

	@Override
	@Transactional
	public Car createInactiveCar(Long userId) {
		Car carObj = new Car();
		carObj.setUserId(userId);
		String code = userDealerViewDAO.findDealerCode(userId);
		carObj.setDealerCode(dealerSequenceDAO.getDealerSequence(code));
		carObj.setStatus(CarStatus.CAR_INACTIVE.value);
		carDao.create(carObj);
		return carObj;
	}

	@Override
	@Transactional
	public void updateCarDetails(Car car) {
		Car dbCar = carDao.findOne(car.getId());
		populateCarDetails(dbCar, car);
		populateCarInterior(dbCar, car);
		populateCarEngineDetails(dbCar, car);
		carDao.update(dbCar);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Car> getCarInfoById(BigDecimal price1, BigDecimal price2) {
		return carDao.getCarInfoByPrice(price1, price2);
	}

	@Transactional(readOnly = true)
	public Car findById(Long id) {
		return carDao.findOne(id);
	}

	private void populateCarDetails(Car dbCar, Car car) {

		dbCar.setVin(car.getVin());
		dbCar.setMakeId(car.getMakeId());
		dbCar.setNewCar(car.getNewCar());
		dbCar.setCertified(car.getCertified());
		dbCar.setYear(car.getYear());
		dbCar.setColor(car.getColor());
		dbCar.setPrice(car.getPrice());
		dbCar.setReducedPrice(car.getReducedPrice());
		dbCar.setMileage(car.getMileage());
		dbCar.setTankCapacity(car.getTankCapacity());
		dbCar.setSeatingId(car.getSeatingId());
		dbCar.setDescription(car.getDescription());
		dbCar.setStatus(CarStatus.CAR_ACTIVE.value);
		dbCar.setDrivingSeat(car.getDrivingSeat());
	}

	private void populateCarInterior(Car dbCar, Car car) {
		CarInterior dbCarInterior = dbCar.getCarInterior();
		if (dbCarInterior == null) {
			dbCar.setCarInterior(car.getCarInterior());
			dbCar.getCarInterior().setCar(dbCar);
			return;
		}
		dbCarInterior.setAcFront(car.getCarInterior().getAcFront());
		dbCarInterior.setAcRear(car.getCarInterior().getAcRear());
		dbCarInterior.setAirbagDriver(car.getCarInterior().getAirbagDriver());
		dbCarInterior.setAirbagPassenger(car.getCarInterior().getAirbagPassenger());
		dbCarInterior.setAirbagSide(car.getCarInterior().getAirbagSide());
		dbCarInterior.setAlarm(car.getCarInterior().getAlarm());
		dbCarInterior.setAlloyWheels(car.getCarInterior().getAlloyWheels());
		dbCarInterior.setAntiLockBrakes(car.getCarInterior().getAntiLockBrakes());
		dbCarInterior.setBackUpCamera(car.getCarInterior().getBackUpCamera());
		dbCarInterior.setBucketSeat(car.getCarInterior().getBucketSeat());
		dbCarInterior.setCassettePlayer(car.getCarInterior().getCassettePlayer());
		dbCarInterior.setCdMultiDisc(car.getCarInterior().getCdMultiDisc());
		dbCarInterior.setCdSingleDisc(car.getCarInterior().getCdSingleDisc());
		dbCarInterior.setCruiseControl(car.getCarInterior().getCruiseControl());
		dbCarInterior.setDvdSystem(car.getCarInterior().getDvdSystem());
		dbCarInterior.setFmStereo(car.getCarInterior().getFmStereo());
		dbCarInterior.setFogLights(car.getCarInterior().getFogLights());
		dbCarInterior.setIntegratedPhone(car.getCarInterior().getIntegratedPhone());
		dbCarInterior.setKeylessEntry(car.getCarInterior().getKeylessEntry());
		dbCarInterior.setKeyLessStart(car.getCarInterior().getKeyLessStart());
		dbCarInterior.setLeatherSeats(car.getCarInterior().getLeatherSeats());
		dbCarInterior.setMemorySeats(car.getCarInterior().getMemorySeats());
		dbCarInterior.setMoonroofSunroof(car.getCarInterior().getMoonroofSunroof());
		dbCarInterior.setMp3SingleDisc(car.getCarInterior().getMp3SingleDisc());
		dbCarInterior.setNavigation(car.getCarInterior().getNavigation());
		dbCarInterior.setPowerLocks(car.getCarInterior().getPowerLocks());
		dbCarInterior.setPowerSeats(car.getCarInterior().getPowerSeats());
		dbCarInterior.setPowerSteering(car.getCarInterior().getPowerSteering());
		dbCarInterior.setPremiumSound(car.getCarInterior().getPremiumSound());
		dbCarInterior.setRearWindowDefroster(car.getCarInterior().getRearWindowDefroster());
		dbCarInterior.setRearWindowWiper(car.getCarInterior().getRearWindowWiper());
		dbCarInterior.setThirdRowSeats(car.getCarInterior().getThirdRowSeats());
		dbCarInterior.setTintedGlass(car.getCarInterior().getTintedGlass());
		dbCarInterior.setColor(car.getCarInterior().getColor());
		dbCarInterior.setPowerWindows(car.getCarInterior().getPowerWindows());
	}

	/**
	 * @param carDetailsView
	 * @param carObj
	 * @param carEngineDetails
	 */
	private void populateCarEngineDetails(Car dbCar, Car car) {
		CarEngineDetails dbCarEngineDetails = dbCar.getCarEngineDetails();
		if (dbCarEngineDetails == null) {
			dbCar.setCarEngineDetails(car.getCarEngineDetails());
			dbCar.getCarEngineDetails().setCar(dbCar);
			return;
		}
		dbCarEngineDetails.setBhpId(car.getCarEngineDetails().getBhpId());
		dbCarEngineDetails.setCcId(car.getCarEngineDetails().getCcId());
		dbCarEngineDetails.setFuelType(car.getCarEngineDetails().getFuelType());
		dbCarEngineDetails.setTransmission(car.getCarEngineDetails().getTransmission());
		dbCarEngineDetails.setNoOfCylinder(car.getCarEngineDetails().getNoOfCylinder());
		dbCarEngineDetails.setDriveType(car.getCarEngineDetails().getDriveType());

	}

	/**
	 * InActiveing the CarRecord
	 * 
	 * @param userId
	 */

	@Override
	public List<Car> getCountOfPrice() {
		return carDao.getCountOfPrice();
	}

	@Transactional
	public void makeCarAsInActive(Long carId) {
		Car dbCar = carDao.findOne(carId);
		List<UserActivities> userActivities = userActivitesDAO.getCarInfoByCarId(carId);
		if (dbCar != null && dbCar.getStatus() == CarStatus.CAR_INACTIVE.value) {
			for (UserActivities activitie : userActivities) {
				activitie.setStatus(Boolean.TRUE);
				// userActivitesDAO.update(activitie);
			}
			dbCar.setStatus(CarStatus.CAR_ACTIVE.value);

		} else {
			dbCar.setStatus(CarStatus.CAR_INACTIVE.value);
			for (UserActivities activities : userActivities) {
				activities.setStatus(Boolean.FALSE);
			}
		}
		carDao.update(dbCar);
	}

	// Delete the cars in UserActivities
	public void deleteFavoriteCars(Long carId) {
		List<UserActivities> favorite = userActivitesDAO.getCarInfoByCarId(carId);
		if (!favorite.isEmpty()) {
			for (UserActivities activity : favorite) {
				userActivitesDAO.delete(activity);
			}
		}
	}

	// Delete the Cars in HistoryTable
	public void deleteHistoryCars(Long carId) {
		List<RecentViewCars> recetCars = recentViewCarsDAO.getCarInfoByCarId(carId);
		if (!recetCars.isEmpty()) {
			for (RecentViewCars history : recetCars) {
				recentViewCarsDAO.delete(history);
			}
		}
	}

	// safe delete
	@Transactional
	public void deleteCar(Long carId) {
		Car dbCar = carDao.findOne(carId);
		if (dbCar != null) {
			dbCar.setStatus(CarStatus.CAR_DELETED.value);
			carDao.update(dbCar);
		}
		deleteFavoriteCars(carId);
	}

	@Transactional
	public Car getCarInfoById(Long id) {
		List<Image> images = imageService.getImageInfolistByID(id);
		Car car = carDao.getCarInfoById(id);
		car.setImages(images);
		return car;
	}

	@Transactional
	public List<Make> getCarInfoByID(List<Long> ids) {
		if (ids != null) {
			List<Long> listofmakeIds = carDao.getCarInfoByID(ids);
			return makeDAO.getMakeInfoByIDs(listofmakeIds);
		} else {
			return null;
		}
	}

	@Transactional
	public Long countOfCarsByUserId(Long userId) {
		return carDetailsViewDAO.countOfCarsByUserId(userId);
	}

	@Transactional
	public void sendMessageCarOwner(CommentJson commentJson) throws AddressException, MessagingException {
		Map<String, Object> values = new HashMap<String, Object>();
		values.put(MotarConstants.MAKE, commentJson.getMake());
		values.put(MotarConstants.MODEL, commentJson.getModel());
		values.put(MotarConstants.FIRSTNAME, commentJson.getFirstName());
		values.put(MotarConstants.LASTNAME, commentJson.getLastName());
		values.put(MotarConstants.YEAR, commentJson.getYear());
		String phoneNum = commentJson.getPhoneNo();
		if (phoneNum.length() == 10) {
			String telephoneNumber = "" + phoneNum.substring(0, 4) + " " + phoneNum.substring(4, 6)
					+ phoneNum.substring(6, 10);
			values.put(MotarConstants.PHONENO, telephoneNumber);
		} else {
			values.put(MotarConstants.PHONENO, phoneNum);
		}
		values.put(MotarConstants.COMMENT, commentJson.getComment());
		String[] to = { commentJson.getOwnerMailId() };
		String[] touser = { commentJson.getEmail() };
		Object[] subject = { commentJson.getFirstName() };
		ms.sendEmail(MailTemplateEnum.MAIL_TO_OWNER, values, to, subject);
		ms.sendEmail(MailTemplateEnum.MAIL_TO_USER_CONFORMATION, values, touser, subject);
	}

	@Transactional
	public boolean checkDealerMaxcars(Long userId) {
		User user = userDAO.findOne(userId);
		Long carsCount = carDetailsViewDAO.countOfCarsByUserId(userId);
		Long dealerCarsCount = dealerDAO.getMaxVehicles(user.getDealerId());
		if (carsCount <= dealerCarsCount-1) {
			return true;
		} else {
			return false;
		}
	}

}
