package com.sgsystems.motor.constants;

public class MotarConstants {

	public static final String PASSWORD = "password";
	public static final String LOGIN_NAME = "loginname";
	public static final String FNAME = "fname";
	public static final String EMAIL = "email";
	public static final String YEAR = "year";
	public static final String MAKE = "make";
	public static final String MODEL = "model";
	public static final String COMMENT = "comment";
	public static final String FIRSTNAME = "firstName";
	public static final String COUNT = "count";
	public static final String PHONENO = "phoneNe";
	public static final String LASTNAME = "lastName";
	public static final String FROM_YEAR = "fromYear";
	public static final String TO_YEAR = "toYear";
	public static final String MAX_PRICE = "maxPrice";
	public static final String MAX_MILEAGE = "maxMileage";
}
