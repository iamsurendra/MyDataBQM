package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.CarAlerts;

public interface CarAlertDAO extends BaseDAO<CarAlerts, Long> {
	
	List<CarAlerts> getcarAlerts(Long UserId);
	
	public List<CarAlerts> getcarAlertByAlertID(Long Id) ;
	
	public List<CarAlerts>getcarAlertsforMail();
}
