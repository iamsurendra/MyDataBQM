package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.Seating;

public interface SeatingService {

	List<Seating>seatingInfo();
	
	
}
