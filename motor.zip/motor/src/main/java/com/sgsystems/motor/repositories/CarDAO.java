package com.sgsystems.motor.repositories;



import java.math.BigDecimal;
import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.Car;

/**
 * @author Guvvala
 *
 */
public interface CarDAO extends BaseDAO<Car, Long> {

	List<String> getCarPrice();

	List<Car> getCarInfoByPrice(BigDecimal price1, BigDecimal price2);

	List<Car> getCountOfPrice();

	boolean uniqueVehicleNumber(String vin, Long carId);

	public Car getCarInfoById(Long id);

	List<Long> getCarInfoByID(List<Long> ids);

	List<Car> getcarInfoByuserID(Long userId);

	public Long countOfCarsByUserId(Long userId);
	
	public List<Long> getIdsByUserId(Long userId);
}
