package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.json.CarJson;
import com.sgsystems.motor.json.CarResultsJson;
import com.sgsystems.motor.models.CarDetailsView;

/**
 * @author Guvvala
 *
 */

public interface CarDetailsViewDAO extends BaseDAO<CarDetailsView, Long> {

	public CarDetailsView getCarInfoByID(Long id);

	CarResultsJson search(CarJson carJson);

	List<CarDetailsView> getCarInfoByID(List<Long> ids,Long languageId);

	public Long findCarByAlerts(String make, String model, Long minPrice, Long maxPrice, Long minMileage,
			Long maxMileage, Long fromYear, Long toYer);
	
	public Long countOfCarsByUserId(Long userId);
	
	public CarDetailsView carInfoById(Long languageId,Long carId);
	
	public List<Long> getIdsByUserId(Long userId);
}
