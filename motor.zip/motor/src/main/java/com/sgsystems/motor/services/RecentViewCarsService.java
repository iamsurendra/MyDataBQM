package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.RecentViewCars;

public interface RecentViewCarsService {
	public void createRecentviews(RecentViewCars RecentViewCars);
	public List<RecentViewCars>getRecentViewCars(Long Id);
	public List<String> getCarIdByuserID(Long id);
}
