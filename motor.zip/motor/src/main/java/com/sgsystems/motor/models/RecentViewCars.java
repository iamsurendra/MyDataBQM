package com.sgsystems.motor.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "user_car_history")
public class RecentViewCars {

	@EmbeddedId
	RecentViewCarsKey recentViewCarsKey;

	@Column(name = "USER_ID", insertable = false, updatable = false)
	private Long userId;

	@Column(name = "CAR_ID", insertable = false, updatable = false)
	private Long carId;

	@Column(name = "HISTORY")
	@Type(type = "boolean")
	private Boolean history;

	@Column(name = "CREATED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	@JsonIgnore
	private Date createdDate;

	@Transient
	private String cratedDateString;

	@PostLoad
	public void postLoad() {
		this.cratedDateString = DateUtils.convertToSimpleDateFormat(getCreatedDate());
	}

	public String getCratedDateString() {
		return cratedDateString;
	}

	public void setCratedDateString(String cratedDateString) {
		this.cratedDateString = cratedDateString;
	}

	public RecentViewCarsKey getRecentViewCarsKey() {
		return recentViewCarsKey;
	}

	public void setRecentViewCarsKey(RecentViewCarsKey recentViewCarsKey) {
		this.recentViewCarsKey = recentViewCarsKey;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getCarId() {
		return carId;
	}

	public void setCarId(Long carId) {
		this.carId = carId;
	}

	public Boolean getHistory() {
		return history;
	}

	public void setHistory(Boolean history) {
		this.history = history;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((recentViewCarsKey == null) ? 0 : recentViewCarsKey.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RecentViewCars other = (RecentViewCars) obj;
		if (recentViewCarsKey == null) {
			if (other.recentViewCarsKey != null)
				return false;
		} else if (!recentViewCarsKey.equals(other.recentViewCarsKey))
			return false;
		return true;
	}

}
