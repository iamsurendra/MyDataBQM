package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.json.UserJson;
import com.sgsystems.motor.models.User;
import com.sgsystems.motor.models.UserDetailsView;

public interface UserService {

	User getUser(Long userId);

	boolean uniqueUserName(String userName);

	Long createNewUser(User user);

	User getUserForLogin(Long user);

	public User validatePassword(UserJson userJson);

	public User resetpwd(UserJson userjson);

	public void updateUser(User user);

	public User forgotPassword(UserJson userjson);

	public void makeActiveOrInactive(Long userId);

	User updateImageProfile(Long userId);

	public void updateUserProfile(User user);

	boolean validateEmail(String email);

	public void updateDealer(User user);

	public UserDetailsView getUserDetailsInfoByUserId(Long userId, Long languageId);

}
