package com.sgsystems.motor.constants;

public enum PrivilegeEnum {

	READ;
}
