package com.sgsystems.motor.externals;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import com.sgsystems.motor.constants.EnvProperties;

@Component
public class ImageUploader implements InitializingBean {

	private Cloudinary cloudinary;

	@Override
	public void afterPropertiesSet() throws Exception {
		cloudinary = new Cloudinary(ObjectUtils.asMap("cloud_name", EnvProperties.findProperty(EnvProperties.CLOUDNAME),
				"api_key", EnvProperties.findProperty(EnvProperties.CLOUDINARYAPIKEY), "api_secret",
				EnvProperties.findProperty(EnvProperties.CLOUDINARYAPISECRET), "secure", true));
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> uploadFile(MultipartFile uploadfile) throws IOException {
		return cloudinary.uploader().upload(uploadfile.getBytes(), ObjectUtils.asMap("invalidate", true));
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> updateImage(MultipartFile uploadfile, String publicId) throws IOException {
		return cloudinary.uploader().upload(uploadfile.getBytes(),
				ObjectUtils.asMap("public_id", publicId, "invalidate", true));
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> deleteImage(List<String> publicid) throws Exception {
		return cloudinary.api().deleteResources(publicid, ObjectUtils.emptyMap());
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> profileUpload(MultipartFile uploadfile) throws IOException {
		return cloudinary.uploader().upload(uploadfile.getBytes(), ObjectUtils.asMap("invalidate", true));
	}
}
