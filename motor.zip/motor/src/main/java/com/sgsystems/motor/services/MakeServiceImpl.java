package com.sgsystems.motor.services;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgsystems.motor.models.Make;
import com.sgsystems.motor.repositories.MakeDAO;

@Service
public class MakeServiceImpl implements MakeService {
	@Autowired
	MakeDAO makeDAO;

	@Transactional
	public List<String> getAllCarMakes() {

		return makeDAO.getAllCarMakes();
	}

	@Transactional
	public List<String> getModelsByCarMake(String make) {

		return makeDAO.getModelsByCarMake(make);
	}

	public Map<String, Long> getCarsBodyTypeCount() {

		return makeDAO.getCarsBodyTypeCount();
	}

	public Map<String, Long> getCarMakesCount() {

		return makeDAO.getCarMakesCount();

	}

	public List<String> getBodyTypeList() {

		return makeDAO.getBodyTypeList();
	}

	@Transactional
	 public Long getMakersId(String Name, String Model, String bodyType){

		return makeDAO.getMakersId(Name, Model, bodyType);

	}
	
	@Transactional
	@Override
	public Make getMakeInfoByID(Long id){
		return makeDAO.getMakeInfoByID(id);
	}
	
	@Transactional
	public List<String> getBodyStyleByMakeAndModel(String Name, String Model){
		return makeDAO.getBodyStyleByMakeAndModel(Name, Model);
	}
	
	@Transactional
	public List<String> getBodyStyles(){
		return makeDAO.getBodyStyles();
	}

}
