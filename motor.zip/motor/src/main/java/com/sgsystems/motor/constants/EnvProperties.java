package com.sgsystems.motor.constants;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;
import java.util.ResourceBundle;

import com.guvvala.framework.util.AppBundle;
import com.guvvala.framework.util.StringUtils;

public enum EnvProperties {

	CRONTRIGGERTIME("cronTriggerTime"), ENABLECRON("enableCron"), CLOUDNAME("cloudName"), CLOUDINARYAPIKEY(
			"cloudinaryApiKey"), CLOUDINARYAPISECRET("cloudinaryApiSecret");

	public String value;

	private static final Properties properties = loadProperties();

	EnvProperties(String value) {
		this.value = value;
	}

	public static String findProperty(EnvProperties key) {
		return properties.getProperty(key.value);
	}

	private static Properties loadProperties() {
		InputStream is = null;
		Properties property = new Properties();
		String env = System.getProperty("environment");
		String envConfig = System.getProperty("configPath");
		try {
			if (StringUtils.isEmpty(env)) {
				ResourceBundle resource = AppBundle.getBundle("com.sgsystems.motor.envConfig");
				property=convertResourceBundleToProperties(resource);
			} else {
				StringBuilder filePath = new StringBuilder(envConfig);
				filePath.append("envConfig.properties");
				File configFile = new File(filePath.toString());
				is = new FileInputStream(configFile);
				property.load(is);
			}
		} catch (Exception th) {
			th.printStackTrace();
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return property;
	}

	private static Properties convertResourceBundleToProperties(ResourceBundle resource) {
		Properties properties = new Properties();
		Enumeration<String> keys = resource.getKeys();
		while (keys.hasMoreElements()) {
			String key = keys.nextElement();
			properties.put(key, resource.getString(key));
		}
		return properties;
	}

}
