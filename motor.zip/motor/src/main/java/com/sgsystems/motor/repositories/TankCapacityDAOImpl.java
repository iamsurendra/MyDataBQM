package com.sgsystems.motor.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.TankCapacity;

@Repository
public class TankCapacityDAOImpl extends BaseDAOImpl<TankCapacity, Long> implements TankCapacityDAO {

	public TankCapacityDAOImpl() {
		super(TankCapacity.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<String> getTankCapacityList() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> tQuery = criteriaBuilder.createQuery(String.class);
		Root<TankCapacity> root = tQuery.from(TankCapacity.class);
		tQuery.select(root.get("tankCapacity")).distinct(true).orderBy(criteriaBuilder.asc(root.get("tankCapacity")));
		return entityManager.createQuery(tQuery).getResultList();
	}

}
