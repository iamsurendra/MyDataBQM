package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.UserLocaleDetailsView;
import com.sgsystems.motor.models.UserLocaleDetailsViewKey;


public interface UserLocaleDetailsViewDAO extends BaseDAO<UserLocaleDetailsView, UserLocaleDetailsViewKey>{
	
	public UserLocaleDetailsView getUserLocalInfoByUserId(Long userId);
	
	public List<UserLocaleDetailsView> getAllEnglishLocalUser();

}
