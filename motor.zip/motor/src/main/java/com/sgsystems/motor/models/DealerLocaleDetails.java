package com.sgsystems.motor.models;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sgsystems.motor.constants.LanguageEnum;

@Entity
@Table(name = "dealer_locale_details")
public class DealerLocaleDetails {

	@EmbeddedId
	@JsonIgnore
	DealerLocaleDetailsKey dealerLocaleDetailsKey;

	@Column(name = "NAME")
	private String name;

	@MapsId("dealerId")
	@ManyToOne
	@JoinColumn(name = "DEALER_ID", nullable = false)
	@JsonIgnore
	private Dealer dealer;

	@Transient
	private int languageId;

	public DealerLocaleDetails() {
		super();
	}

	public DealerLocaleDetails(LanguageEnum lEnum, String name, Dealer dealer) {
		super();
		this.dealerLocaleDetailsKey = new DealerLocaleDetailsKey(lEnum.value);
		this.name = name;
		this.dealer = dealer;
	}

	public DealerLocaleDetailsKey getDealerLocaleDetailsKey() {
		return dealerLocaleDetailsKey;
	}

	public void setDealerLocaleDetailsKey(DealerLocaleDetailsKey dealerLocaleDetailsKey) {
		this.dealerLocaleDetailsKey = dealerLocaleDetailsKey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Dealer getDealer() {
		return dealer;
	}

	public void setDealer(Dealer dealer) {
		this.dealer = dealer;
	}

	public int getLanguageId() {
		return languageId;
	}

	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dealerLocaleDetailsKey == null) ? 0 : dealerLocaleDetailsKey.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DealerLocaleDetails other = (DealerLocaleDetails) obj;
		if (dealerLocaleDetailsKey == null) {
			if (other.dealerLocaleDetailsKey != null)
				return false;
		} else if (!dealerLocaleDetailsKey.equals(other.dealerLocaleDetailsKey))
			return false;
		return true;
	}

}
