package com.sgsystems.motor.constants;

import java.util.HashMap;
import java.util.Map;

public enum CarAlertStatus {
	CAR_ALERT_ACTIVE(1, "Active"),
	CAR_ALERT_INACTIVE(2, "Inactive"),
	CAR_ALERT_EXPIRED(0, "Expired");

	public final int value;
	public final String stringValue;

	private static final Map<Integer, CarAlertStatus> valueMap = new HashMap<Integer, CarAlertStatus>();
	private static final Map<String, CarAlertStatus> stringMap = new HashMap<String, CarAlertStatus>();

	static {
		for (CarAlertStatus constant : CarAlertStatus.class.getEnumConstants()) {
			valueMap.put(constant.value, constant);
			stringMap.put(constant.stringValue, constant);
		}
	}

	private CarAlertStatus(int value, String stringValue) {
		this.value = value;
		this.stringValue = stringValue;
	}

	public int getValue() {
		return value;
	}

	public String getStringValue() {
		return stringValue;
	}

}
