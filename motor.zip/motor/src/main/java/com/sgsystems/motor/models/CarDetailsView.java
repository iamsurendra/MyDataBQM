package com.sgsystems.motor.models;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.guvvala.framework.util.Interior;

/**
 * @author Guvvala
 *
 */

@Entity
@Table(name = "cars_details_view")
public class CarDetailsView implements Serializable {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "ID")
	private Long id;

	@Column(name = "VIN")
	private String vin;

	@Column(name = "MAKE_ID")
	private Long makeId;

	@Column(name = "MAKE")
	private String make;

	@Column(name = "SEATING_ID")
	private Long seatingId;

	@Column(name = "SEATING_NAME")
	private String seatingName;

	@Column(name = "NEW")
	@Type(type = "boolean")
	private Boolean newCar;

	@Column(name = "LOCALE_FLG")
	@Type(type = "boolean")
	private Boolean localFlg;;

	@Column(name = "YEAR")
	private Integer year;

	@Column(name = "PRICE")
	private BigDecimal price;

	@Column(name = "REDUCED_PRICE")
	private BigDecimal reducedPrice;

	@Column(name = "MILEAGE")
	private Long mileage;

	@Column(name = "TANK_CAPACITY")
	private String tankCapacity;

	@Column(name = "MODEL")
	private String model;

	@Column(name = "TRIM")
	private String trim;

	@Column(name = "BODY_TYPE")
	private String bodyType;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "UPDATED_DT", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedDate;

	@Column(name = "DRIVING_SEAT")
	@Type(type = "boolean")
	private Boolean drivingSeat;

	// __________interior_________________//

	@Column(name = "AC_FRONT")
	@Interior(name = "AC_FRONT")
	@Type(type = "boolean")
	private Boolean acFront;

	@Column(name = "AC_REAR")
	@Interior(name = "AC_REAR")
	@Type(type = "boolean")
	private Boolean acRear;

	@Column(name = "NAVIGATION")
	@Interior(name = "NAVIGATION")
	@Type(type = "boolean")
	private Boolean navigation;

	@Column(name = "POWER_LOCKS")
	@Interior(name = "POWER_LOCKS")
	@Type(type = "boolean")
	private Boolean powerLocks;

	@Column(name = "KEYLESS_ENTRY")
	@Interior(name = "KEYLESS_ENTRY")
	@Type(type = "boolean")
	private Boolean keylessEntry;

	@Column(name = "CRUISE_CONTROL")
	@Interior(name = "CRUISE_CONTROL")
	@Type(type = "boolean")
	private Boolean cruiseControl;

	@Column(name = "POWER_STEERING")
	@Interior(name = "POWER_STEERING")
	@Type(type = "boolean")
	private Boolean powerSteering;

	@Column(name = "INTEGRATED_PHONE")
	@Interior(name = "INTEGRATED_PHONE")
	@Type(type = "boolean")
	private Boolean integratedPhone;

	@Column(name = "BUCKET_SEAT")
	@Interior(name = "BUCKET_SEAT")
	@Type(type = "boolean")
	private Boolean bucketSeat;

	@Column(name = "LEATHER_INTERIOR")
	@Interior(name = "LEATHER_SEATS")
	@Type(type = "boolean")
	private Boolean leatherSeats;

	@Column(name = "AIRBAG_DRIVER")
	@Interior(name = "AIRBAG_DRIVER")
	@Type(type = "boolean")
	private Boolean airbagDriver;

	@Column(name = "AIRBAG_PASSENGER")
	@Interior(name = "AIRBAG_PASSENGER")
	@Type(type = "boolean")
	private Boolean airbagPassenger;

	@Column(name = "AIRBAG_SIDE")
	@Interior(name = "AIRBAG_SIDE")
	@Type(type = "boolean")
	private Boolean airbagSide;

	@Column(name = "ANTI_LOCK_BRAKES")
	@Interior(name = "ANTI_LOCK_BRAKES")
	@Type(type = "boolean")
	private Boolean antiLockBrakes;

	@Column(name = "FOG_LIGHTS")
	@Interior(name = "FOG_LIGHTS")
	@Type(type = "boolean")
	private Boolean fogLights;

	@Column(name = "REAR_WINDOW_DEFROSTER")
	@Interior(name = "REAR_WINDOW_DEFROSTER")
	@Type(type = "boolean")
	private Boolean rearWindowDefroster;

	@Column(name = "REAR_WINDOW_WIPER")
	@Interior(name = "REAR_WINDOW_WIPER")
	@Type(type = "boolean")
	private Boolean rearWindowWiper;

	@Column(name = "TINTED_GLASS")
	@Interior(name = "TINTED_GLASS")
	@Type(type = "boolean")
	private Boolean tintedGlass;

	@Column(name = "POWER_WINDOWS")
	@Interior(name = "POWER_WINDOWS")
	@Type(type = "boolean")
	private Boolean powerWindows;

	@Column(name = "CASSETTE_PLAYER")
	@Interior(name = "CASSETTE_PLAYER")
	@Type(type = "boolean")
	private Boolean cassettePlayer;

	@Column(name = "CD_SINGLE_DISC")
	@Interior(name = "CD_SINGLE_DISC")
	@Type(type = "boolean")
	private Boolean cdSingleDisc;

	@Column(name = "CD_MULTI_DISC")
	@Interior(name = "CD_MULTI_DISC")
	@Type(type = "boolean")
	private Boolean cdMultiDisc;

	@Column(name = "MP3_SINGLE_DISC")
	@Interior(name = "MP3_SINGLE_DISC")
	@Type(type = "boolean")
	private Boolean mp3SingleDisc;

	@Column(name = "DVD_SYSTEM")
	@Interior(name = "DVD_SYSTEM")
	@Type(type = "boolean")
	private Boolean dvdSystem;

	@Column(name = "ALLOY_WHEELS")
	@Interior(name = "ALLOY_WHEELS")
	@Type(type = "boolean")
	private Boolean alloyWheels;

	@Column(name = "MOONROOF_SUNROOF")
	@Interior(name = "MOONROOF_SUNROOF")
	@Type(type = "boolean")
	private Boolean moonroofSunroof;

	@Column(name = "THIRD_ROW_SEATS")
	@Interior(name = "THIRD_ROW_SEATS")
	@Type(type = "boolean")
	private Boolean thirdRowSeats;

	@Column(name = "ALARM")
	@Interior(name = "ALARM")
	@Type(type = "boolean")
	private Boolean alarm;

	@Column(name = "POWER_SEATS")
	@Interior(name = "POWER_SEATS")
	@Type(type = "boolean")
	private Boolean powerSeats;

	@Column(name = "BACKUP_CAMERA")
	@Interior(name = "BACKUP_CAMERA")
	@Type(type = "boolean")
	private Boolean backupCamera;

	@Column(name = "MEMORY_SEATS")
	@Interior(name = "MEMORY_SEATS")
	@Type(type = "boolean")
	private Boolean memorySeats;

	@Column(name = "KEYLESS_START")
	@Interior(name = "KEYLESS_START")
	@Type(type = "boolean")
	private Boolean keylessStart;

	@Column(name = "PREMIUM_SOUND")
	@Interior(name = "PREMIUM_SOUND")
	@Type(type = "boolean")
	private Boolean premiumSound;

	@Column(name = "FM_STEREO")
	@Interior(name = "FM_STEREO")
	@Type(type = "boolean")
	private Boolean fmStereo;

	// ______________________________

	// ------------------------

	@Column(name = "ENGINE_CC_ID")
	private Long engineCcId;

	@Column(name = "ENGINE_CC_NAME")
	private String engineCcName;

	@Column(name = "ENGINE_BHP_ID")
	private Long engineBhpId;

	@Column(name = "ENGINE_BHP_NAME")
	private String engineBhpName;

	@Column(name = "FUEL_TYPE")
	private String fueltype;

	@Column(name = "TRANSMISSION")
	private String transmission;

	@Column(name = "NO_OF_CYLINDERS")
	private String noOfCylinder;

	@Column(name = "DRIVE_TYPE")
	private String driveType;

	// -----------------------

	@Column(name = "USER_STATUS")
	@Type(type = "boolean")
	private Boolean status;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "PHONE_NO")
	private String phoneNo;

	@Column(name = "NEW_PHONE_NUMBER")
	private String newPhoneNumber;

	@Column(name = "FIRST_IMAGE")
	private String firstImage;

	@Column(name = "ADDRESS")
	private String address;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "LAST_NAME")
	private String lastName;

	@Column(name = "CITY_AREA")
	private String cityArea;

	@Column(name = "PROVINCE")
	private String province;

	@Column(name = "DEALER_NAME")
	private String dealerName;

	@Column(name = "USER_ID")
	private Long userId;

	@Column(name = "LANGUAGE_ID")
	private Long languageId;

	@Column(name = "PROVINCE_ID")
	private Long provinceId;

	@Column(name = "CITY_AREA_ID")
	private Long cityAreaId;

	@Column(name = "CERTIFIED")
	@Type(type = "boolean")
	private Boolean certified;

	@Column(name = "INTERIOR_COLOR_NAME")
	private String interiorColorName;

	@Column(name = "EXTERIOR_COLOR_NAME")
	private String exteriorColorName;

	@Column(name = "EXTERIOR_COLOR_ID")
	private Long exteriorColorId;

	@Column(name = "STATUS")
	private Integer carStatus;

	@Transient
	private Long count;

	@Transient
	private List<String> images = new ArrayList<>();

	@Transient
	private List<String> InteriorCols = new ArrayList<>();

	@Transient
	private List<Long> carIds = new ArrayList<>();

	// Getters and Setters //

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public Long getMakeId() {
		return makeId;
	}

	public void setMakeId(Long makeId) {
		this.makeId = makeId;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public Long getSeatingId() {
		return seatingId;
	}

	public void setSeatingId(Long seatingId) {
		this.seatingId = seatingId;
	}

	public String getSeatingName() {
		return seatingName;
	}

	public void setSeatingName(String seatingName) {
		this.seatingName = seatingName;
	}

	public Boolean getNewCar() {
		return newCar;
	}

	public void setNewCar(Boolean newCar) {
		this.newCar = newCar;
	}

	public Boolean getLocalFlg() {
		return localFlg;
	}

	public void setLocalFlg(Boolean localFlg) {
		this.localFlg = localFlg;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getReducedPrice() {
		return reducedPrice;
	}

	public void setReducedPrice(BigDecimal reducedPrice) {
		this.reducedPrice = reducedPrice;
	}

	public Long getMileage() {
		return mileage;
	}

	public void setMileage(Long mileage) {
		this.mileage = mileage;
	}

	public String getTankCapacity() {
		return tankCapacity;
	}

	public void setTankCapacity(String tankCapacity) {
		this.tankCapacity = tankCapacity;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getTrim() {
		return trim;
	}

	public void setTrim(String trim) {
		this.trim = trim;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Boolean getDrivingSeat() {
		return drivingSeat;
	}

	public void setDrivingSeat(Boolean drivingSeat) {
		this.drivingSeat = drivingSeat;
	}

	public Boolean getAcFront() {
		return acFront;
	}

	public void setAcFront(Boolean acFront) {
		this.acFront = acFront;
	}

	public Boolean getAcRear() {
		return acRear;
	}

	public void setAcRear(Boolean acRear) {
		this.acRear = acRear;
	}

	public Boolean getNavigation() {
		return navigation;
	}

	public void setNavigation(Boolean navigation) {
		this.navigation = navigation;
	}

	public Boolean getPowerLocks() {
		return powerLocks;
	}

	public void setPowerLocks(Boolean powerLocks) {
		this.powerLocks = powerLocks;
	}

	public Boolean getKeylessEntry() {
		return keylessEntry;
	}

	public void setKeylessEntry(Boolean keylessEntry) {
		this.keylessEntry = keylessEntry;
	}

	public Boolean getCruiseControl() {
		return cruiseControl;
	}

	public void setCruiseControl(Boolean cruiseControl) {
		this.cruiseControl = cruiseControl;
	}

	public Boolean getPowerSteering() {
		return powerSteering;
	}

	public void setPowerSteering(Boolean powerSteering) {
		this.powerSteering = powerSteering;
	}

	public Boolean getIntegratedPhone() {
		return integratedPhone;
	}

	public void setIntegratedPhone(Boolean integratedPhone) {
		this.integratedPhone = integratedPhone;
	}

	public Boolean getBucketSeat() {
		return bucketSeat;
	}

	public void setBucketSeat(Boolean bucketSeat) {
		this.bucketSeat = bucketSeat;
	}

	public Boolean getLeatherSeats() {
		return leatherSeats;
	}

	public void setLeatherSeats(Boolean leatherSeats) {
		this.leatherSeats = leatherSeats;
	}

	public Boolean getAirbagDriver() {
		return airbagDriver;
	}

	public void setAirbagDriver(Boolean airbagDriver) {
		this.airbagDriver = airbagDriver;
	}

	public Boolean getAirbagPassenger() {
		return airbagPassenger;
	}

	public void setAirbagPassenger(Boolean airbagPassenger) {
		this.airbagPassenger = airbagPassenger;
	}

	public Boolean getAirbagSide() {
		return airbagSide;
	}

	public void setAirbagSide(Boolean airbagSide) {
		this.airbagSide = airbagSide;
	}

	public Boolean getAntiLockBrakes() {
		return antiLockBrakes;
	}

	public void setAntiLockBrakes(Boolean antiLockBrakes) {
		this.antiLockBrakes = antiLockBrakes;
	}

	public Boolean getFogLights() {
		return fogLights;
	}

	public void setFogLights(Boolean fogLights) {
		this.fogLights = fogLights;
	}

	public Boolean getRearWindowDefroster() {
		return rearWindowDefroster;
	}

	public void setRearWindowDefroster(Boolean rearWindowDefroster) {
		this.rearWindowDefroster = rearWindowDefroster;
	}

	public Boolean getRearWindowWiper() {
		return rearWindowWiper;
	}

	public void setRearWindowWiper(Boolean rearWindowWiper) {
		this.rearWindowWiper = rearWindowWiper;
	}

	public Boolean getTintedGlass() {
		return tintedGlass;
	}

	public void setTintedGlass(Boolean tintedGlass) {
		this.tintedGlass = tintedGlass;
	}

	public Boolean getPowerWindows() {
		return powerWindows;
	}

	public void setPowerWindows(Boolean powerWindows) {
		this.powerWindows = powerWindows;
	}

	public Boolean getCassettePlayer() {
		return cassettePlayer;
	}

	public void setCassettePlayer(Boolean cassettePlayer) {
		this.cassettePlayer = cassettePlayer;
	}

	public Boolean getCdSingleDisc() {
		return cdSingleDisc;
	}

	public void setCdSingleDisc(Boolean cdSingleDisc) {
		this.cdSingleDisc = cdSingleDisc;
	}

	public Boolean getCdMultiDisc() {
		return cdMultiDisc;
	}

	public void setCdMultiDisc(Boolean cdMultiDisc) {
		this.cdMultiDisc = cdMultiDisc;
	}

	public Boolean getMp3SingleDisc() {
		return mp3SingleDisc;
	}

	public void setMp3SingleDisc(Boolean mp3SingleDisc) {
		this.mp3SingleDisc = mp3SingleDisc;
	}

	public Boolean getDvdSystem() {
		return dvdSystem;
	}

	public void setDvdSystem(Boolean dvdSystem) {
		this.dvdSystem = dvdSystem;
	}

	public Boolean getAlloyWheels() {
		return alloyWheels;
	}

	public void setAlloyWheels(Boolean alloyWheels) {
		this.alloyWheels = alloyWheels;
	}

	public Boolean getMoonroofSunroof() {
		return moonroofSunroof;
	}

	public void setMoonroofSunroof(Boolean moonroofSunroof) {
		this.moonroofSunroof = moonroofSunroof;
	}

	public Boolean getThirdRowSeats() {
		return thirdRowSeats;
	}

	public void setThirdRowSeats(Boolean thirdRowSeats) {
		this.thirdRowSeats = thirdRowSeats;
	}

	public Boolean getAlarm() {
		return alarm;
	}

	public void setAlarm(Boolean alarm) {
		this.alarm = alarm;
	}

	public Boolean getPowerSeats() {
		return powerSeats;
	}

	public void setPowerSeats(Boolean powerSeats) {
		this.powerSeats = powerSeats;
	}

	public Boolean getBackupCamera() {
		return backupCamera;
	}

	public void setBackupCamera(Boolean backupCamera) {
		this.backupCamera = backupCamera;
	}

	public Boolean getMemorySeats() {
		return memorySeats;
	}

	public void setMemorySeats(Boolean memorySeats) {
		this.memorySeats = memorySeats;
	}

	public Boolean getKeylessStart() {
		return keylessStart;
	}

	public void setKeylessStart(Boolean keylessStart) {
		this.keylessStart = keylessStart;
	}

	public Boolean getPremiumSound() {
		return premiumSound;
	}

	public void setPremiumSound(Boolean premiumSound) {
		this.premiumSound = premiumSound;
	}

	public Boolean getFmStereo() {
		return fmStereo;
	}

	public void setFmStereo(Boolean fmStereo) {
		this.fmStereo = fmStereo;
	}

	public Long getEngineCcId() {
		return engineCcId;
	}

	public void setEngineCcId(Long engineCcId) {
		this.engineCcId = engineCcId;
	}

	public String getEngineCcName() {
		return engineCcName;
	}

	public void setEngineCcName(String engineCcName) {
		this.engineCcName = engineCcName;
	}

	public Long getEngineBhpId() {
		return engineBhpId;
	}

	public void setEngineBhpId(Long engineBhpId) {
		this.engineBhpId = engineBhpId;
	}

	public String getEngineBhpName() {
		return engineBhpName;
	}

	public void setEngineBhpName(String engineBhpName) {
		this.engineBhpName = engineBhpName;
	}

	public String getFueltype() {
		return fueltype;
	}

	public void setFueltype(String fueltype) {
		this.fueltype = fueltype;
	}

	public String getTransmission() {
		return transmission;
	}

	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}

	public String getNoOfCylinder() {
		return noOfCylinder;
	}

	public void setNoOfCylinder(String noOfCylinder) {
		this.noOfCylinder = noOfCylinder;
	}

	public String getDriveType() {
		return driveType;
	}

	public void setDriveType(String driveType) {
		this.driveType = driveType;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getNewPhoneNumber() {
		return newPhoneNumber;
	}

	public void setNewPhoneNumber(String newPhoneNumber) {
		this.newPhoneNumber = newPhoneNumber;
	}

	public String getFirstImage() {
		return firstImage;
	}

	public void setFirstImage(String firstImage) {
		this.firstImage = firstImage;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCityArea() {
		return cityArea;
	}

	public void setCityArea(String cityArea) {
		this.cityArea = cityArea;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getLanguageId() {
		return languageId;
	}

	public void setLanguageId(Long languageId) {
		this.languageId = languageId;
	}

	public List<Long> getCarIds() {
		return carIds;
	}

	public void setCarIds(List<Long> carIds) {
		this.carIds = carIds;
	}

	public Long getProvinceId() {
		return provinceId;
	}

	public void setProvinceId(Long provinceId) {
		this.provinceId = provinceId;
	}

	public Long getCityAreaId() {
		return cityAreaId;
	}

	public void setCityAreaId(Long cityAreaId) {
		this.cityAreaId = cityAreaId;
	}

	public Boolean getCertified() {
		return certified;
	}

	public void setCertified(Boolean certified) {
		this.certified = certified;
	}

	public String getInteriorColorName() {
		return interiorColorName;
	}

	public void setInteriorColorName(String interiorColorName) {
		this.interiorColorName = interiorColorName;
	}

	public String getExteriorColorName() {
		return exteriorColorName;
	}

	public void setExteriorColorName(String exteriorColorName) {
		this.exteriorColorName = exteriorColorName;
	}

	public Long getExteriorColorId() {
		return exteriorColorId;
	}

	public void setExteriorColorId(Long exteriorColorId) {
		this.exteriorColorId = exteriorColorId;
	}

	public Integer getCarStatus() {
		return carStatus;
	}

	public void setCarStatus(Integer carStatus) {
		this.carStatus = carStatus;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

	public List<String> getInteriorCols() {
		return InteriorCols;
	}

	public void setInteriorCols(List<String> interiorCols) {
		InteriorCols = interiorCols;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CarDetailsView other = (CarDetailsView) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
