package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.Enginecc;

/**
 * @author Guvvala
 *
 */
public interface EngineccDAO extends BaseDAO<Enginecc, Long> {

	List<String> getEngineccList();

}
