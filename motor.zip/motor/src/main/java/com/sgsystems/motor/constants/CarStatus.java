package com.sgsystems.motor.constants;

import java.util.HashMap;
import java.util.Map;

public enum CarStatus {
	CAR_INACTIVE(0, "Inactive"),
	CAR_ACTIVE(1, "Active"), 
	CAR_DELETED(2, "Delete");

	public final int value;
	public final String stringValue;
	
	private static final Map<Integer, CarStatus> valueMap = new HashMap<Integer, CarStatus>();
	private static final Map<String, CarStatus> stringMap = new HashMap<String, CarStatus>();

	static {
		for (CarStatus constant : CarStatus.class.getEnumConstants()) {
			valueMap.put(constant.value, constant);
			stringMap.put(constant.stringValue, constant);
		}
	}

	private CarStatus(int value, String stringValue) {
		this.value = value;
		this.stringValue = stringValue;
	}

	public static CarStatus fromString(final String stringValue) {
		return stringMap.get(stringValue);
	}

	public static CarStatus fromInteger(final Integer intValue) {
		return valueMap.get(intValue);
	}
	    
}
