package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.UserDetailsView;

public interface UserDetailsViewService {

	UserDetailsView getUserDetailsInfoByUserId(Long userId,Long languageId);
	 
	List<UserDetailsView> getAllEnglishUserDetails();
}
