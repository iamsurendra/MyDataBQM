package com.sgsystems.motor.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgsystems.motor.models.Enginecc;
import com.sgsystems.motor.repositories.EngineccDAO;

@Service
public class EngineccServiceImpl implements EngineccService {

	@Autowired
	EngineccDAO engineccDAO;

	@Transactional(readOnly = true)
	public List<String> getListofEngineCC() {
		return engineccDAO.getEngineccList();
	}

	public List<Enginecc> getListofEngineCCInfo() {
		return engineccDAO.findAll();
	}
}
