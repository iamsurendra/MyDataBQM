package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.Color;

/**
 * @author Guvvala
 *
 */
public interface ColorService {

	List<Color> getColorInfo();
}
