package com.sgsystems.motor.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgsystems.motor.models.AreaCity;
import com.sgsystems.motor.models.Color;
import com.sgsystems.motor.models.Enginebhp;
import com.sgsystems.motor.models.Enginecc;
import com.sgsystems.motor.models.Make;
import com.sgsystems.motor.models.Province;
import com.sgsystems.motor.models.Seating;
import com.sgsystems.motor.services.AreaCityService;
import com.sgsystems.motor.services.ColorService;
import com.sgsystems.motor.services.EnginebhpService;
import com.sgsystems.motor.services.EngineccService;
import com.sgsystems.motor.services.MakeService;
import com.sgsystems.motor.services.ProvinceService;
import com.sgsystems.motor.services.SeatingService;
import com.sgsystems.motor.services.TankCapacityService;

@RestController
@RequestMapping("motorLookups")
public class MotorLookupsController {

	@Autowired
	MakeService makeService;

	@Autowired
	ColorService colorService;

	@Autowired
	SeatingService seatingService;

	@Autowired
	EnginebhpService enginebhpService;

	@Autowired
	EngineccService engineccService;

	@Autowired
	TankCapacityService tankCapacityService;

	@Autowired
	AreaCityService areaCityService;

	@Autowired
	ProvinceService provinceService;

	/**
	 * Retrieving the makeInfo
	 * 
	 */
	@RequestMapping(value = "/makers", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> AllMakes() {
		return makeService.getAllCarMakes();
	}

	/**
	 * Retrieving the makeInfo By Name
	 * 
	 */
	@RequestMapping(value = "/modelbymake/{name}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getModelsByCarMake(@PathVariable("name") String make) {
		return makeService.getModelsByCarMake(make);
	}

	@RequestMapping(value = "/bodyStyle", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getBodyStyle() {
		return makeService.getBodyStyles();
	}

	/**
	 * Retrieving Make Id by Mode and Make
	 * 
	 */
	@RequestMapping(value = "/makersIdByName", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Long getMakeIds(@RequestParam("name") String Name, @RequestParam("model") String Model,
			@RequestParam("bodyType") String bodyType) {
		return makeService.getMakersId(Name, Model, bodyType);
	}

	@RequestMapping(value = "/bodyStyleByMakeModel", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	List<String> getBodyStyleByMakeAndModel(@RequestParam("name") String name, @RequestParam("model") String model) {
		return makeService.getBodyStyleByMakeAndModel(name, model);
	}

	/**
	 * Retrieving Make by ID
	 * 
	 */
	@RequestMapping(value = "/makeInfoByid/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Make getMakeIfobyId(@PathVariable("id") Long Id) {
		return makeService.getMakeInfoByID(Id);

	}

	/**
	 * Retrieving color info
	 * 
	 */
	@RequestMapping(value = "/colorInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Color> getColorInfo() {
		return colorService.getColorInfo();
	}

	/**
	 * Retrieving Seating info
	 * 
	 */

	@RequestMapping(value = "/seatingInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Seating> getseatingInfo() {
		return seatingService.seatingInfo();
	}

	/**
	 * Retrieving Engine Bhp Info
	 * 
	 */

	@RequestMapping(value = "/engineBhpInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Enginebhp> getEngineBhpInfo() {
		return enginebhpService.getEnginBhpInfo();

	}

	/**
	 * Retrieving Engine cc Info
	 * 
	 */
	@RequestMapping(value = "/engineccInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Enginecc> getEngineccInfo() {
		return engineccService.getListofEngineCCInfo();

	}

	/**
	 * Retrieving Tank Capacity
	 * 
	 */

	@RequestMapping(value = "/tankCapacity", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getTankCapacityList() {
		return tankCapacityService.getTankCapacityList();
	}

	
	// ---------------find all Province Names ---------------------

	@RequestMapping(value = "/findAllProvinceDetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Province> findAllProvinceDetails() {
		return provinceService.findAllProvinceDetails();
	}

	/**
	 * Retrieving AreaCity by ID
	 * 
	 */
	@RequestMapping(value = "/getAreaCityByProvinceId/{provinceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<AreaCity> getAreaCityByProvinceId(@PathVariable("provinceId") Long provinceId) {
		return areaCityService.getAreaCityByProvinceId(provinceId);

	}
}