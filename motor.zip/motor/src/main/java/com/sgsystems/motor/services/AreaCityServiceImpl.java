package com.sgsystems.motor.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgsystems.motor.models.AreaCity;

import com.sgsystems.motor.repositories.AreaCityDAO;


@Service("areaCityService")
public class AreaCityServiceImpl implements AreaCityService {

	@Autowired
	AreaCityDAO areaCityDAO;

	

	@Transactional
	@Override
	public List<AreaCity> getAreaCityByProvinceId(Long provinceId) {
		return areaCityDAO.getAreaCityByProvinceId(provinceId);
	}

}
