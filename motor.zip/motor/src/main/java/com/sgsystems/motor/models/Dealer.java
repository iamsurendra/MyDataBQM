package com.sgsystems.motor.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "dealer")
public class Dealer implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	@Column(name = "REG_NO")
	private String regNo;

	@Column(name = "DEALER_NAME")
	private String dealerName;

	@Column(name = "DEALER_CODE")
	private String code;

	@Column(name = "MAX_VEHICLES")
	private Long maxVehicles;

	@OneToMany(mappedBy = "dealer", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<DealerLocaleDetails> dealerLocaleDetails = new ArrayList<>();

	// getter and Setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Long getMaxVehicles() {
		return maxVehicles;
	}

	public void setMaxVehicles(Long maxVehicles) {
		this.maxVehicles = maxVehicles;
	}

	public List<DealerLocaleDetails> getDealerLocaleDetails() {
		return dealerLocaleDetails;
	}

	public void setDealerLocaleDetails(List<DealerLocaleDetails> dealerLocaleDetails) {
		this.dealerLocaleDetails = dealerLocaleDetails;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dealer other = (Dealer) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
