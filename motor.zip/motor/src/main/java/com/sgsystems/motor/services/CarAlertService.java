package com.sgsystems.motor.services;

import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.sgsystems.motor.models.CarAlerts;

public interface CarAlertService {
	CarAlerts createAlert(CarAlerts carAlerts);

	void deleteAlert(CarAlerts removeAlert);

	List<CarAlerts> getcarAlerts(Long UserId);

	void editCarAlert(CarAlerts carAlert);

	List<CarAlerts> getcarAlertByAlertID(Long Id);

	void sendMailForCarAlerts() throws AddressException, MessagingException;

}
