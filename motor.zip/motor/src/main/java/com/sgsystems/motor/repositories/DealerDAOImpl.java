package com.sgsystems.motor.repositories;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.sgsystems.motor.models.Dealer;

@Repository
public class DealerDAOImpl extends BaseDAOImpl<Dealer, Long> implements DealerDAO {

	public DealerDAOImpl() {
		super(Dealer.class);
		// TODO Auto-generated constructor stub
	}

	public Long uniqueDealerName(String code) {
		TypedQuery<Long> query = entityManager
				.createQuery("SELECT count(*) from Dealer  where code = :code", Long.class);
		query.setParameter("code", code);
		return query.getSingleResult();
	}

	public Long getMaxVehicles(Long Id) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<Dealer> root = criteriaQuery.from(Dealer.class);
		criteriaQuery.select(root.get("maxVehicles"));
		criteriaQuery.where(builder.equal(root.get("id"), Id));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}

	@Override
	public Long validateRegistrationNumber(String regNo) {
		TypedQuery<Long> query = entityManager
				.createQuery("SELECT count(*) from Dealer  where regNo = :regNo", Long.class);
		query.setParameter("regNo", regNo);
		return query.getSingleResult();
	}
	

	}

