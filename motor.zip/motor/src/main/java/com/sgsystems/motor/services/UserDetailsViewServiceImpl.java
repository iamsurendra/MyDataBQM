package com.sgsystems.motor.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgsystems.motor.models.UserDetailsView;
import com.sgsystems.motor.repositories.UserDetailsViewDAO;

@Service
public class UserDetailsViewServiceImpl implements UserDetailsViewService {

	@Autowired
	UserDetailsViewDAO userDetailsViewDAO;

	@Override
	public UserDetailsView getUserDetailsInfoByUserId(Long userId,Long languageId) {
		return userDetailsViewDAO.getUserDetailsInfoByUserId(userId,languageId);
	}

	@Override
	public List<UserDetailsView> getAllEnglishUserDetails() {
		return userDetailsViewDAO.getAllEnglishUserDetails();
	}

}
