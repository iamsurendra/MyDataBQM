package com.sgsystems.motor.repositories;

import com.guvvala.framework.dao.BaseDAO;

import com.sgsystems.motor.models.Seating;

public interface SeatingDAO extends BaseDAO<Seating, Long>{


}
