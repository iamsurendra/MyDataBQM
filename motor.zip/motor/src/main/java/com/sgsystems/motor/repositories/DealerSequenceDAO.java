package com.sgsystems.motor.repositories;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.DealerSequence;

public interface DealerSequenceDAO extends BaseDAO<DealerSequence, String> {

	public String getDealerSequence(String dealerCode);

}
