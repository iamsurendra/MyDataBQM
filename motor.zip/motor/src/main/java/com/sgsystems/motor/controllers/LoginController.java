package com.sgsystems.motor.controllers;

import java.io.IOException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.guvvala.framework.logging.AppLogger;
import com.guvvala.framework.logging.Log;
import com.sgsystems.motor.externals.ImageUploader;
import com.sgsystems.motor.json.UserJson;
import com.sgsystems.motor.models.User;
import com.sgsystems.motor.services.UserDetailsViewService;
import com.sgsystems.motor.services.UserLocaleDetailsViewService;
import com.sgsystems.motor.services.UserService;

@RestController
@RequestMapping("user")
public class LoginController {

	private static @Log AppLogger logger;

	@Autowired
	UserService userService;

	@Autowired
	ImageUploader imageUploader;
	@Autowired
	UserLocaleDetailsViewService userLocaleDetailsViewService;

	@Autowired
	UserDetailsViewService userDetailsViewService;

	// -------------------- Creating New User------------------------------
	@RequestMapping(value = "/create", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Long createUser(@RequestBody User user) {
		return userService.createNewUser(user);

	}

	// update UserProfile
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void updateDealer(@RequestBody User user) {
		userService.updateDealer(user);
	}

	// ----------------------------------- validating the userName and
	// password-----------------------

	@RequestMapping(value = "/validatePassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public User getvalidatePassword(@RequestBody UserJson userjson) {
		return userService.validatePassword(userjson);

	}

	// --------------------------- update the
	// password---------------------------------
	@RequestMapping(value = "/updatePassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public User updatePassword(@RequestBody UserJson userjson) {
		return userService.resetpwd(userjson);

	}

	// -------------------------- update User profile---------------------------
	@RequestMapping(value = "/updateProfile", method = RequestMethod.POST, produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public void updateProfile(@RequestBody User user) {
		userService.updateUser(user);

	}

	// -------------------------- update User profile
	// Image---------------------------
	@RequestMapping(value = "/uploadProfileImage", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public void saveImage(@RequestParam("file") MultipartFile uploadfile, @RequestParam(value = "userId") Long userId)
			throws IOException {
		Map<String, Object> uploadResult = imageUploader.profileUpload(uploadfile);
		User user = userService.updateImageProfile(userId);
		user.setProfileImage((String) uploadResult.get("url"));
		userService.updateUserProfile(user);

	}

	// --------forgot password------------------
	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public User forgotPassword(@RequestBody UserJson userJson) {
		return userService.forgotPassword(userJson);

	}

	// -------- validate Email------------------
	@RequestMapping(value = "/validateEmail", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean validateEmail(@RequestParam(value = "email") String email) {
		return userService.validateEmail(email);

	}

	// ----------deActivate User for Admin Screen--------------
	@RequestMapping(value = "activateOrDeactivateUser/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void deActivateUser(@PathVariable("userId") Long userId) {
		userService.makeActiveOrInactive(userId);

	}

	@RequestMapping(value = "/userInfo/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public User getUserinfo(@PathVariable("userId") Long userId) {
		return userService.getUser(userId);

	}

}
