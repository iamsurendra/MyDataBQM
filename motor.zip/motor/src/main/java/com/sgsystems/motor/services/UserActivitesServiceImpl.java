package com.sgsystems.motor.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.sgsystems.motor.models.UserActivities;
import com.sgsystems.motor.models.UserActivityKey;
import com.sgsystems.motor.repositories.UserActivitesDAO;


@Service
public class UserActivitesServiceImpl implements UserActivitesService {

	@Autowired
	UserActivitesDAO userActivitesDAO;

	@Transactional
	public UserActivities createFavoriteCar(UserActivities userActivities) {
		
		UserActivityKey activityKey = new UserActivityKey();
		activityKey.setCarId(userActivities.getCarId());
		activityKey.setUserId(userActivities.getUserId());
		UserActivities activities = new UserActivities();
		activities.setUserCarMappingKey(activityKey);
		activities.setFavorite(userActivities.getFavorite());
		activities.setStatus(Boolean.TRUE);
		
		
		return userActivitesDAO.create(activities);
	}

	public List<Long> findAllFavioritesByUser(Long userId) {
		return userActivitesDAO.findAllFavioritesByUser(userId);
	}

	@Transactional
	public List<UserActivities> getCarInfoById(Long Id) {
		return userActivitesDAO.getCarInfoById(Id);
	}
	
	@Transactional
	public UserActivities getCarCountByUserID(Long Id){
		return userActivitesDAO.getCarCountByUserID(Id);
	}

	@Transactional
	public void deleteCarfromFavorite(UserActivities userActivities) {
		UserActivityKey activityKey = new UserActivityKey();
		activityKey.setCarId(userActivities.getCarId());
		activityKey.setUserId(userActivities.getUserId());
		UserActivities activities = new UserActivities();
		activities.setUserCarMappingKey(activityKey);
		userActivitesDAO.delete(activities);
	}
	


}
