package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.UserLocaleDetails;

public interface UserLocaleDetailsDAO extends BaseDAO<UserLocaleDetails, Long>{
	
	public List<UserLocaleDetails> getAllEnglishLocalUser();
	
	List<UserLocaleDetails> getUserInfoByUserId(Long Id);

}
