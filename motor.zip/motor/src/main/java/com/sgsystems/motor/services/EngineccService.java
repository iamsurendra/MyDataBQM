package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.Enginecc;

/**
 * @author Guvvala
 *
 */
public interface EngineccService {

	List<String> getListofEngineCC();

	List<Enginecc> getListofEngineCCInfo();
}
