package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;

import com.sgsystems.motor.models.CarEngineDetails;

public interface CarEngineDetailsDAO extends BaseDAO<CarEngineDetails, Long> {

	List<String> getCarsFuelTypes();

}
