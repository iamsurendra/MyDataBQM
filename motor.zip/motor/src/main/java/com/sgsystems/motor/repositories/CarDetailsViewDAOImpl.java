package com.sgsystems.motor.repositories;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.guvvala.framework.util.StringUtils;
import com.sgsystems.motor.json.CarJson;
import com.sgsystems.motor.json.CarResultsJson;
import com.sgsystems.motor.models.CarDetailsView;

/**
 * @author Guvvala
 *
 */
@Repository
public class CarDetailsViewDAOImpl extends BaseDAOImpl<CarDetailsView, Long> implements CarDetailsViewDAO {

	public CarDetailsViewDAOImpl() {
		super(CarDetailsView.class);
	}

	@Override
	public CarDetailsView getCarInfoByID(Long id) {

		return findOne(id);
	}

	@Override
	public List<CarDetailsView> getCarInfoByID(List<Long> ids,Long languageId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CarDetailsView> criteriaQuery = criteriaBuilder.createQuery(CarDetailsView.class);
		Root<CarDetailsView> root = criteriaQuery.from(CarDetailsView.class);
		criteriaQuery.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBuilder.in(root.get("id")).value(ids));
		predicates.add(criteriaBuilder.equal(root.get("carStatus"), 1));
		predicates.add(criteriaBuilder.or(criteriaBuilder.equal(root.get("languageId"),languageId),criteriaBuilder.equal(root.get("localFlg"), 1)));

		criteriaQuery.where(predicates.toArray(new Predicate[] {}));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	@Override
	public CarResultsJson search(CarJson carJson) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CarDetailsView> criteriaQuery = criteriaBuilder.createQuery(CarDetailsView.class);
		Root<CarDetailsView> root = criteriaQuery.from(CarDetailsView.class);
		List<Predicate> predicates = getPredicates(carJson, criteriaBuilder, root);
		Predicate[] conditions = predicates.toArray(new Predicate[] {});
		criteriaQuery.select(root).where(criteriaBuilder.and(conditions));
		if (carJson.getSortDetails() != null) {
			if (carJson.getSortDetails() == 0) {
				criteriaQuery.orderBy(criteriaBuilder.asc(root.get("price")));
			} else if (carJson.getSortDetails() == 1) {
				criteriaQuery.orderBy(criteriaBuilder.desc(root.get("price")));
			} else if (carJson.getSortDetails() == 2) {
				criteriaQuery.orderBy(criteriaBuilder.desc(root.get("updatedDate")));
			}
		}
		else{
			criteriaQuery.orderBy(criteriaBuilder.desc(root.get("updatedDate")));
		}
		Long total = findTotal(carJson);
		return new CarResultsJson(total, entityManager.createQuery(criteriaQuery).setFirstResult(carJson.getPage() * 2)
				.setMaxResults(2).getResultList());
	}

	private List<Predicate> getPredicates(CarJson carJson, CriteriaBuilder criteriaBuilder, Root<CarDetailsView> root) {
		List<Predicate> predicates = new ArrayList<>();

		if (carJson.getNewCar() != null) {
			predicates.add(criteriaBuilder.equal(root.get("newCar"), carJson.getNewCar()));
		}

		if (carJson.getCertified() != null) {
			predicates.add(criteriaBuilder.equal(root.get("certified"), carJson.getCertified()));
		}

		if (carJson.getCondition() != null) {
			predicates.add(root.get("newCar").in(carJson.getCondition()));
		}
		if (carJson.getLanguageId() != null) {
			predicates.add(criteriaBuilder.or(criteriaBuilder.equal(root.get("languageId"), carJson.getLanguageId()),
					criteriaBuilder.equal(root.get("localFlg"), 1)));
		}

		if (!StringUtils.isEmpty(carJson.getBodyType())) {
			predicates.add(criteriaBuilder.equal(root.get("bodyType"), carJson.getBodyType()));
		}
		if (!StringUtils.isEmpty(carJson.getMake())) {
			predicates.add(criteriaBuilder.equal(root.get("make"), carJson.getMake()));
		}
		if (!StringUtils.isEmpty(carJson.getModel())) {
			predicates.add(criteriaBuilder.equal(root.get("model"), carJson.getModel()));
		}
		if (!StringUtils.isEmpty(carJson.getDealerName())) {
			predicates.add(criteriaBuilder.equal(root.get("dealerName"), carJson.getDealerName()));
		}
		if (carJson.getLocation() != null) {
			predicates.add(criteriaBuilder.equal(root.get("cityAreaId"), carJson.getLocation()));
		}
		if (carJson.getProvince() != null) {
			predicates.add(criteriaBuilder.equal(root.get("provinceId"), carJson.getProvince()));
		}
		if (carJson.getMinPrice() != null && carJson.getMaxPrice() != null) {
			predicates.add(
					criteriaBuilder.between(root.get("reducedPrice"), carJson.getMinPrice(), carJson.getMaxPrice()));
		} else {
			if (carJson.getMinPrice() != null) {
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("reducedPrice"), carJson.getMinPrice()));
			}
			if (carJson.getMaxPrice() != null) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("reducedPrice"), carJson.getMaxPrice()));
			}
		}
		if (carJson.getMinKiloMeters() != null && carJson.getMaxKiloMeters() != null) {
			predicates.add(criteriaBuilder.between(root.get("mileage"), carJson.getMinKiloMeters(),
					carJson.getMaxKiloMeters()));
		} else {
			if (carJson.getMinKiloMeters() != null) {
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("mileage"), carJson.getMinKiloMeters()));
			}
			if (carJson.getMaxKiloMeters() != null) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("mileage"), carJson.getMaxKiloMeters()));
			}
		}

		if (carJson.getToYear() != null && carJson.getFromYear() != null) {
			predicates.add(criteriaBuilder.between(root.get("year"), carJson.getFromYear(), carJson.getToYear()));
		} else {
			if (carJson.getToYear() != null) {
				predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("year"), carJson.getToYear()));
			}
			if (carJson.getFromYear() != null) {
				predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("year"), carJson.getFromYear()));
			}
		}
		if (!StringUtils.isEmpty(carJson.getSeatingName())) {
			predicates.add(criteriaBuilder.equal(root.get("seatingName"), carJson.getSeatingName()));
		}
		if (carJson.getDriveTypes() != null && (!carJson.getDriveTypes().isEmpty())) {
			predicates.add(root.get("driveType").in(carJson.getDriveTypes()));
		}
		if (carJson.getFuelTypes() != null && (!carJson.getFuelTypes().isEmpty())) {
			predicates.add(root.get("fueltype").in(carJson.getFuelTypes()));
		}
		if (!StringUtils.isEmpty(carJson.getEngineBhp())) {
			predicates.add(criteriaBuilder.equal(root.get("engineBhpName"), carJson.getEngineBhp()));
		}
		if (!StringUtils.isEmpty(carJson.getEngineCc())) {
			predicates.add(criteriaBuilder.equal(root.get("engineCcName"), carJson.getEngineCc()));
		}
		if (carJson.getTransmissions() != null && (!carJson.getTransmissions().isEmpty())) {
			predicates.add(root.get("transmission").in(carJson.getTransmissions()));
		}
		if (carJson.getCylinders() != null && (!carJson.getCylinders().isEmpty())) {
			predicates.add(root.get("noOfCylinder").in(carJson.getCylinders()));
		}
		if (carJson.getInteriors() != null) {
			for (String columnProperty : carJson.getInteriors()) {
				predicates.add(criteriaBuilder.equal(root.get(columnProperty), true));
			}
		}

		if (carJson.getExteriorColorIds() != null && (!carJson.getExteriorColorIds().isEmpty())) {
			predicates.add(root.get("exteriorColorId").in(carJson.getExteriorColorIds()));
		}

		if (carJson.getVin() != null) {
			predicates.add(criteriaBuilder.equal(root.get("vin"), carJson.getVin()));
		}
		if (carJson.getDrivingSeat() != null) {
			predicates.add(criteriaBuilder.equal(root.get("drivingSeat"), carJson.getDrivingSeat()));
		}
		if (carJson.getEmail() != null) {

			predicates.add(criteriaBuilder.equal(root.get("email"), carJson.getEmail()));
		} else {
			predicates.add(criteriaBuilder.equal(root.get("carStatus"), 1));

		}
		if (carJson.getUserId() != null) {
			predicates.add(criteriaBuilder.equal(root.get("userId"), carJson.getUserId()));
		}

		return predicates;
	}

	private Long findTotal(CarJson carJson) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
		Root<CarDetailsView> root = criteriaQuery.from(CarDetailsView.class);
		List<Predicate> predicates = getPredicates(carJson, criteriaBuilder, root);

		Predicate[] conditions = predicates.toArray(new Predicate[] {});
		criteriaQuery.select(criteriaBuilder.count(root)).where(criteriaBuilder.and(conditions));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}

	public Long findCarByAlerts(String make, String model, Long minPrice, Long maxPrice, Long minMileage,
			Long maxMileage, Long fromYear, Long toYear) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<CarDetailsView> root = criteriaQuery.from(CarDetailsView.class);
		criteriaQuery.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		if (make != null) {
			predicates.add(builder.equal(root.get("make"), make));
		}
		if (model != null) {
			predicates.add(builder.equal(root.get("model"), model));
		}
		if (fromYear != null && toYear != null) {
			predicates.add(builder.between(root.get("year"), fromYear, toYear));
		} else {
			if (fromYear != null) {
				predicates.add(builder.greaterThanOrEqualTo(root.get("year"), fromYear));
			}
			if (toYear != null) {
				predicates.add(builder.lessThanOrEqualTo(root.get("year"), toYear));
			}
		}
		if (minPrice != null && maxPrice != null) {
			predicates.add(builder.between(root.get("price"), minPrice, maxPrice));
		} else {
			if (minPrice != null) {
				predicates.add(builder.greaterThanOrEqualTo(root.get("price"), minPrice));
			}
			if (maxPrice != null) {
				predicates.add(builder.lessThanOrEqualTo(root.get("price"), maxPrice));
			}
		}
		if (minMileage != null && maxMileage != null) {
			predicates.add(builder.between(root.get("mileage"), minMileage, maxMileage));
		} else {
			if (minMileage != null) {
				predicates.add(builder.greaterThanOrEqualTo(root.get("mileage"), minMileage));
			}
			if (maxMileage != null) {
				predicates.add(builder.lessThanOrEqualTo(root.get("mileage"), maxMileage));
			}
		}
		criteriaQuery.where(predicates.toArray(new Predicate[] {}));
		return entityManager.createQuery(criteriaQuery).getSingleResult();

	}

	public Long countOfCarsByUserId(Long userId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
		Root<CarDetailsView> root = criteriaQuery.from(CarDetailsView.class);
		criteriaQuery.multiselect(criteriaBuilder.count(root));
		criteriaQuery.where(criteriaBuilder.and(criteriaBuilder.equal(root.get("userId"), userId)),
				criteriaBuilder.equal(root.get("languageId"), 100));
		return entityManager.createQuery(criteriaQuery).getSingleResult();

	}
	
	public List<Long> getIdsByUserId(Long userId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
		Root<CarDetailsView> root = criteriaQuery.from(CarDetailsView.class);
		criteriaQuery.select(root.get("id"));
		criteriaQuery.where(criteriaBuilder.equal(root.get("userId"), userId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public CarDetailsView carInfoById(Long languageId,Long carId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CarDetailsView> criteriaQuery = criteriaBuilder.createQuery(CarDetailsView.class);
		Root<CarDetailsView> root = criteriaQuery.from(CarDetailsView.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.and (criteriaBuilder.or(criteriaBuilder.equal(root.get("languageId"), languageId), criteriaBuilder.equal(root.get("localFlg"), 1)),(criteriaBuilder.equal(root.get("id"), carId))));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}

}
