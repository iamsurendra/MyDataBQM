package com.sgsystems.motor.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "user")
public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "USER_ID")
	private Long userId;

	@Column(name = "DEALER_ID", insertable = false, updatable = false)
	private Long dealerId;

	@Column(name = "USER_NAME")
	private String userName;

	@Column(name = "EMAIL")
	private String eMail;

	@Column(name = "PHONE_NO")
	private String phoneNo;

	@Column(name = "USER_SALT")
	private String userSalt;

	@Column(name = "PWD_HASH")
	private String pwdHash;

	@Column(name = "USER_STATUS")
	private int userStatus;

	@Column(name = "LOGIN_ATTEMPTS")
	@Type(type = "yes_no")
	private Boolean loginAttempts;

	@Column(name = "LAST_LOGIN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastLoginDate;

	@Column(name = "ADMIN")
	@Type(type = "boolean")
	private Boolean admin;

	@Column(name = "PROFILE_IMAGE")
	private String profileImage;

	@Column(name = "NEW_PHONE_NUMBER")
	private String newPhoneNumber;

	@Column(name = "CITY_AREA_ID")
	private Long cityAreaId;

	@Column(name = "PROVINCE_ID")
	private Long provinceId;

	@ManyToOne(optional = true, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "DEALER_ID")
	private Dealer dealeru;

	@OneToMany(mappedBy = "user", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<UserLocaleDetails> userLocaleDetails = new ArrayList<>();

	@Transient
	private Boolean dealer;

	@Transient
	private String password;

	// Getters and setters //
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getUserSalt() {
		return userSalt;
	}

	public void setUserSalt(String userSalt) {
		this.userSalt = userSalt;
	}

	public String getPwdHash() {
		return pwdHash;
	}

	public void setPwdHash(String pwdHash) {
		this.pwdHash = pwdHash;
	}

	public int getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(int userStatus) {
		this.userStatus = userStatus;
	}

	public Boolean getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(Boolean loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public Boolean getDealer() {
		return dealer;
	}

	public void setDealer(Boolean dealer) {
		this.dealer = dealer;
	}

	public Date getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(Date lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getAdmin() {
		return admin;
	}

	public void setAdmin(Boolean admin) {
		this.admin = admin;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public String getNewPhoneNumber() {
		return newPhoneNumber;
	}

	public void setNewPhoneNumber(String newPhoneNumber) {
		this.newPhoneNumber = newPhoneNumber;
	}

	public Long getDealerId() {
		return dealerId;
	}

	public void setDealerId(Long dealerId) {
		this.dealerId = dealerId;
	}

	public Dealer getDealeru() {
		return dealeru;
	}

	public void setDealeru(Dealer dealeru) {
		this.dealeru = dealeru;
	}

	public Long getCityAreaId() {
		return cityAreaId;
	}

	public void setCityAreaId(Long cityAreaId) {
		this.cityAreaId = cityAreaId;
	}

	public Long getProvinceId() {
		return provinceId;
	}

	public void setProvinceId(Long provinceId) {
		this.provinceId = provinceId;
	}

	public List<UserLocaleDetails> getUserLocaleDetails() {
		return userLocaleDetails;
	}

	public void setUserLocaleDetails(List<UserLocaleDetails> userLocaleDetails) {
		this.userLocaleDetails = userLocaleDetails;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}

}
