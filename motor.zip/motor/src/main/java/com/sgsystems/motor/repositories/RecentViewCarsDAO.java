package com.sgsystems.motor.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.sgsystems.motor.models.RecentViewCars;
import com.sgsystems.motor.models.RecentViewCarsKey;

public interface RecentViewCarsDAO extends BaseDAO<RecentViewCars, RecentViewCarsKey>{
	
	public List<RecentViewCars>getRecenViewCars(Long Id);
	
	public List<RecentViewCars> getCarInfoByCarId(Long Id);
	
	public List<String> getCarIdByuserID(Long id);

}
