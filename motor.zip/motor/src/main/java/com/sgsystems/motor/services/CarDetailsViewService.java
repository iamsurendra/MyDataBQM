package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.json.CarJson;
import com.sgsystems.motor.json.CarResultsJson;
import com.sgsystems.motor.models.CarDetailsView;

/**
 * @author Guvvala
 *
 */
public interface CarDetailsViewService {

	public CarDetailsView getCarInfoByID(Long ID);

	List<CarDetailsView> getCarInfoByID(List<Long> ids,Long languageId);

	public CarResultsJson search(CarJson carJson);

	List<CarDetailsView> getAllCarviewdetails();
	
	CarDetailsView carInfoById(Long languageId,Long carId);

}
