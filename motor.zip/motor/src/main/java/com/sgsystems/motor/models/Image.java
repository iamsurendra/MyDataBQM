package com.sgsystems.motor.models;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "image")

public class Image  {

	/**
	 * 
	 */

@EmbeddedId
ImageKey imageKey;
	

	@Column(name = "CAR_ID" ,insertable = false, updatable = false)
	private Long carId;

	@Column(name = "NAME")
	private String name;

	@Column(name = "FIRST")
	@Type(type = "boolean")
	private Boolean first;

	

	@Column(name = "URL")
	private String url;
	
	@Column(name = "PROFILE_NAME",insertable = false, updatable = false)
	private String profileName;
	
	@Column(name = "PROFILE_ID")
	private Integer profileId;

	// Getters and setters //

	

	public Long getCarId() {
		return carId;
	}

	public void setCarId(Long carId) {
		this.carId = carId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getFirst() {
		return first;
	}

	public void setFirst(Boolean first) {
		this.first = first;
	}

	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	
	
	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public ImageKey getImageKey() {
		return imageKey;
	}

	public void setImageKey(ImageKey imageKey) {
		this.imageKey = imageKey;
	}

	public Integer getProfileId() {
		return profileId;
	}

	public void setProfileId(Integer profileId) {
		this.profileId = profileId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((carId == null) ? 0 : carId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Image other = (Image) obj;
		if (carId == null) {
			if (other.carId != null)
				return false;
		} else if (!carId.equals(other.carId))
			return false;
		return true;
	}

}
