package com.sgsystems.motor.services;

import java.util.List;

import com.sgsystems.motor.models.UserLocaleDetailsView;

public interface UserLocaleDetailsViewService {

	public List<UserLocaleDetailsView> getAllEnglishLocalUser();

	public UserLocaleDetailsView getUserLocalInfoByUserId(Long userId);
}
