'use strict';

module.exports = function(grunt) {

    // Project configuration.
    grunt.initConfig({
        requirejs: {
            js: {
                options: {
                    uglify2: {
                        mangle: false
                    },
                    baseUrl: "js/",
                    mainConfigFile: "js/main.js",
                    name: 'main',
                    out: "build/main.js",
                    optimize: 'uglify2'

                }
            }
        },
        cssmin: {
            options: {
                shorthandCompacting: false,
                roundingPrecision: -1
            },
            combine: {
                files: {
                    'build/styles.min.css': ['css/*.css']
                }
            }
        },
        // Replace parts in some files:
        processhtml: {
            dev: {
                options: {
                    data: {
                        message: 'This is development environment'
                    }
                },
                files: {
                    'index.html': ['index-prod.html']
                }
            },
            dist: {
                options: {
                    process: true,
                    data: {
                        title: 'Motar app',
                        message: 'This is production distribution'
                    }
                },
                files: {
                    'index.html': ['index-prod.html']
                }
            }
        }

    });

    // Actually load this plugin's task(s).
    //grunt.loadTasks('tasks');

    // These plugins provide necessary tasks.
    grunt.loadNpmTasks('grunt-contrib-requirejs');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-processhtml');


    // Whenever the "test" task is run, first clean the "tmp" dir, then run this
    // plugin's task(s), then test the result.
    grunt.registerTask('build', ['requirejs', 'processhtml:dist', 'cssmin']);
    grunt.registerTask('dev', ['processhtml:dev']);

    // By default, lint and run all tests.
    grunt.registerTask('default', ['build']);

};