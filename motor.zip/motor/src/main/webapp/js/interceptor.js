define(['./app'], function (app) {
    'use strict';
    app.factory('httpInterceptor', ['$q', '$rootScope', function ($q, $rootScope) {
        var requestCounter = 0;

        function hideLoaderIfNoCall() {
            if (requestCounter == 0)
                angular.element('.preloader').hide();
        }
        return {
            request: function (config) {
                requestCounter++;
                if (!angular.element('.preloader').is(':visible')) {
                    angular.element('.preloader').show();
                }
                if ($rootScope.user.userId != undefined) {
                    config.headers['current_user_id'] = $rootScope.user.userName;
                } else {
                    config.headers['current_user_id'] = null;
                }
                return config || $q.when(config);
            },

            requestError: function (rejection) {
                requestCounter--;
                hideLoaderIfNoCall();
                return $q.reject(rejection);
            },

            response: function (response) {
                requestCounter--;
                hideLoaderIfNoCall();
                return response || $q.when(response);
            },

            responseError: function (rejection) {
                requestCounter--;
                hideLoaderIfNoCall();
                return $q.reject(rejection);
            }
        }

    }]);
});