/**
 * loads sub modules and wraps them up into the main module
 * this should be used for top-level module definitions only
 */
define([
    'angular',
    'angular_animate',
    'angular_ui_route',
    'ngCookies',
    'angular_ui_bootstrap',
    'bootstrapper',
    'bootstrapnotify',
    'jquery',
    'ng_file_upload',
    'nglazyload',
    'ngSanitize',
    'angularStrap',
    'angularStraptlp',
    'infinite_scroll',
    'angularStorage',
    'angularValidator',
    'fontawesome',
    './controllers/index',
    './directives/index',
    './filters/index',
    './services/index'
], function(angular, pdfmake) {
    'use strict';

    return angular.module('app', [
        'app.controllers',
        'app.directives',
        'app.filters',
        'app.services',
        'ngAnimate',
        'ngCookies',
        'ui.router',
        'ui.bootstrap',
        'infinite-scroll',
        'LocalStorageModule',
        'ngSanitize',
        'angularValidator',
        'mgcrea.ngStrap',
        'ngFileUpload',
        'angular-lazy-loader'
    ]);
});