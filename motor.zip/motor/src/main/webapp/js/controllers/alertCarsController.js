define(['./module'], function(controllers) {
    'use strict';
    controllers.controller('alertCarsController', ['$scope', '$http', '$state', '$rootScope', 'alertCarsService', 'indexService', 'notificationService', 'authenticationService', 'utilityService', function($scope, $http, $state, $rootScope, alertCarsService, indexService, notificationService, authenticationService, utilityService) {

        $scope.makeList = [];
        $scope.modelList = [];
        $scope.provinceList = [];

        $scope.alertid = $state.params.id;
        $scope.onInit = true;
        $scope.alertCarList = [];
        // get make list
        $scope.getMakeData = function() {
            indexService
                .getMakeData()
                .success(
                    function(data, status) {
                        data.forEach(function(element) {
                            $scope.makeList.push({
                                "label": element,
                                "value": element
                            });
                        });
                        if ($scope.carAlertObj.make != null) {
                            $scope.selectedMake = $scope.makeList[$scope.findWithAttr($scope.makeList, 'value', $scope.carAlertObj.make)];
                            $scope.getModelDataByMakeName();
                        }
                    }).error(
                    function(data, status,
                        config) {});



        };

        // get model data on make change
        $scope.getModelDataByMakeName = function() {
            // resetting the model value and model list
            $scope.selectedModel = null;
            $scope.modelList = [];

            //getting the selected make
            var make = $scope.selectedMake != undefined ? $scope.selectedMake.value : null;
            // get model list
            if (make != null) {
                indexService
                    .getModelDataByMakeName(make)
                    .success(
                        function(data, status) {
                            data.forEach(function(element) {
                                $scope.modelList.push({
                                    "label": element,
                                    "value": element
                                });
                            });

                            if ($scope.carAlertObj.model != null && $scope.onInit) {
                                $scope.selectedModel = $scope.modelList[$scope.findWithAttr($scope.modelList, 'value', $scope.carAlertObj.model)];
                                $scope.onInit = false;
                            }

                        }).error(
                        function(data, status,
                            config) {});
            }
        };

        $rootScope.$watch('languageId', function() {
            if (!$scope.initProvince) {
                $scope.findAllProvinceDetails();
                $scope.getAreaCityByProvinceId();
            }
        });

        $scope.initProvince = true;

        $scope.findAllProvinceDetails = function() {
            authenticationService
                .findAllProvinceDetails()
                .success(
                    function(data, status) {
                        $scope.initProvince = false;
                        $scope.provinceList = [];
                        data.forEach(function(element) {
                            $scope.provinceList.push({
                                "label": element[utilityService.getPropertyNameByLocale("name")],
                                "value": element.id
                            });
                        });

                        if ($scope.carAlertObj.province != null) {
                            $scope.province = $scope.provinceList[$scope.findWithAttr($scope.provinceList, 'value', $scope.carAlertObj.province)];
                            $scope.getAreaCityByProvinceId();
                        }
                    }).error(
                    function(data, status,
                        config) {});
        }


        //get area city by province
        $scope.locationList = [];

        $scope.getAreaCityByProvinceId = function() {
            $scope.cityArea = null;
            $scope.locationList = [];
            var province = $scope.province != undefined ? $scope.province.value : null;
            if (province != null) {
                authenticationService
                    .getAreaCityByProvinceId(province)
                    .success(
                        function(data, status) {
                            data.forEach(function(element) {
                                $scope.locationList.push({
                                    "label": element[utilityService.getPropertyNameByLocale("cityArea")],
                                    "value": element.id
                                });
                            });
                            if ($scope.carAlertObj.cityArea != null && $scope.onInit) {
                                $scope.cityArea = $scope.locationList[$scope.findWithAttr($scope.locationList, 'value', $scope.carAlertObj.cityArea)];
                                $scope.onInit = false;
                            }
                        }).error(
                        function(data, status,
                            config) {});
            }
        }

        $scope.yearList = [{
            label: '2018',
            value: 2018
        }, {
            label: '2017',
            value: 2017
        }, {
            label: '2016',
            value: 2016
        }, {
            label: '2015',
            value: 2015
        }, {
            label: '2014',
            value: 2014
        }, {
            label: '2013',
            value: 2013
        }, {
            label: '2012',
            value: 2012
        }, {
            label: '2011',
            value: 2011
        }, {
            label: '2010',
            value: 2010
        }, {
            label: '2009',
            value: 2009
        }, {
            label: '2008',
            value: 2008
        }, {
            label: '2007',
            value: 2007
        }, {
            label: '2006',
            value: 2006
        }, {
            label: '2005',
            value: 2005
        }, {
            label: '2004',
            value: 2004
        }, {
            label: '2003',
            value: 2003
        }, {
            label: '2002',
            value: 2002
        }, {
            label: '2001',
            value: 2001
        }, {
            label: '2000',
            value: 2000
        }, {
            label: '1999',
            value: 1999
        }, {
            label: '1998',
            value: 1998
        }, {
            label: '1997',
            value: 1997
        }, {
            label: '1996',
            value: 1996
        }, {
            label: '1995',
            value: 1995
        }, {
            label: '1994',
            value: 1994
        }, {
            label: '1993',
            value: 1993
        }, {
            label: '1992',
            value: 1992
        }, {
            label: '1991',
            value: 1991
        }, {
            label: '1990',
            value: 1990
        }];

        $scope.priceRangeFromList = [{
            label: '$00,000',
            value: 0
        }, {
            label: '$10,001',
            value: 10001
        }, {
            label: '$20,001',
            value: 20001
        }, {
            label: '$30,001',
            value: 30001
        }, {
            label: '$40,001',
            value: 40001
        }, {
            label: '$50,001',
            value: 50001
        }, {
            label: '$60,001',
            value: 60001
        }, {
            label: '$70,001',
            value: 70001
        }, {
            label: '$80,001',
            value: 80001
        }, {
            label: '$90,001',
            value: 90001
        }, {
            label: '$100,001',
            value: 100001
        }];

        $scope.priceRangeToList = [{
            label: '$10,000',
            value: 10000
        }, {
            label: '$20,000',
            value: 20000
        }, {
            label: '$30,000',
            value: 30000
        }, {
            label: '$40,000',
            value: 40000
        }, {
            label: '$50,000',
            value: 50000
        }, {
            label: '$60,000',
            value: 60000
        }, {
            label: '$70,000',
            value: 70000
        }, {
            label: '$80,000',
            value: 80000
        }, {
            label: '$90,000',
            value: 90000
        }, {
            label: '$100,000',
            value: 100000
        }];


        $scope.mileageRangeToList = [{
            label: '10,000',
            value: 10000
        }, {
            label: '25,000',
            value: 25000
        }, {
            label: '50,000',
            value: 50000
        }, {
            label: '75,000',
            value: 75000
        }, {
            label: '100,000',
            value: 100000
        }, {
            label: '150,000',
            value: 150000
        }];

        $scope.getEmailIfUser = function() {
            if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                $scope.email = $rootScope.user.eMail;
            }
        }

        $scope.saveAlert = function() {
            var carAlerts = {
                "userId": $rootScope.user.userId,
                "make": $scope.selectedMake != undefined ? $scope.selectedMake.value : null,
                "model": $scope.selectedModel != undefined ? $scope.selectedModel.value : null,
                "fromYear": $scope.fromYear != undefined ? $scope.fromYear.value : null,
                "toYear": $scope.toYear != undefined ? $scope.toYear.value : null,
                "minPrice": $scope.minPrice != undefined ? $scope.minPrice.value : null,
                "maxPrice": $scope.maxPrice != undefined ? $scope.maxPrice.value : null,
                "maxMileage": $scope.maxKiloMeters != undefined ? $scope.maxKiloMeters.value : null,
                "cityArea": $scope.cityArea != undefined ? $scope.cityArea.value : null,
                "province": $scope.province != undefined ? $scope.province.value : null,
                "email": $scope.email != undefined ? $scope.email : null,
                "firstName": $rootScope.user.firstName
            };

            if ($scope.alertid) {
                carAlerts.id = $scope.alertid;
                alertCarsService
                    .updateAlert(carAlerts)
                    .success(
                        function(data, status) {
                            notificationService.infoNotification($rootScope.messages.ALERT_SAVED_SUCCESSFULLY);
                            $state.go('profile');
                        }).error(
                        function(data, status,
                            config) {
                            notificationService.errorNotification(data.message);
                        });

            } else if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                alertCarsService
                    .saveAlert(carAlerts)
                    .success(
                        function(data, status) {
                            notificationService.infoNotification($rootScope.messages.ALERT_SAVED_SUCCESSFULLY);
                            $state.go('profile');
                        }).error(
                        function(data, status,
                            config) {
                            notificationService.errorNotification(data.message);
                        });

            } else {
                $rootScope.alertInfo = carAlerts;
                alertCarsService
                    .validateEail(carAlerts.email)
                    .success(
                        function(data, status) {
                            if (data) {
                                notificationService.infoNotification($rootScope.messages.PLEASE_LOGIN_TO_SAVE_ALERT);
                                $state.go('login');
                            } else {
                                notificationService.infoNotification($rootScope.messages.PLEASE_REGISTER_TO_SAVE_ALERT);
                                $state.go('login');
                            }
                        }).error(
                        function(data, status,
                            config) {})
            }


        };

        $scope.carAlertObj = {};

        $scope.findWithAttr = function(array, attr,
            value) {
            for (var i = 0; i < array.length; i += 1) {
                if (array[i][attr] === value) {
                    return i;
                }
            }
        };

        $scope.initData = function() {
            if ($scope.isCreate) {
                $scope.selectedMake = null;
                $scope.selectedModel = null;
                $scope.fromYear = null;
                $scope.toYear = null;
                $scope.minPrice = null;
                $scope.maxPrice = null;
                $scope.maxKiloMeters = null;
                $scope.province = null;
                $scope.cityArea = null;
            } else {
                var carAlertObj = angular.copy($scope.carAlertObj);

                if ($scope.carAlertObj.fromYear != null) {
                    $scope.fromYear = $scope.yearList[$scope.findWithAttr($scope.yearList, 'value', parseInt($scope.carAlertObj.fromYear))];
                }
                if ($scope.carAlertObj.toYear != null) {
                    $scope.toYear = $scope.yearList[$scope.findWithAttr($scope.yearList, 'value', parseInt($scope.carAlertObj.toYear))];
                }

                if ($scope.carAlertObj.minPrice != null) {
                    $scope.minPrice = $scope.priceRangeFromList[$scope.findWithAttr($scope.priceRangeFromList, 'value', parseInt($scope.carAlertObj.minPrice))];
                }

                if ($scope.carAlertObj.maxPrice != null) {
                    $scope.maxPrice = $scope.priceRangeToList[$scope.findWithAttr($scope.priceRangeToList, 'value', parseInt($scope.carAlertObj.maxPrice))];
                }

                if ($scope.carAlertObj.maxMileage != null) {
                    $scope.maxKiloMeters = $scope.mileageRangeToList[$scope.findWithAttr($scope.mileageRangeToList, 'value', parseInt($scope.carAlertObj.maxMileage))];
                }

            }

        };

        $scope.isCreate = true;
        $scope.getCarAlertDetails = function() {
            if ($scope.alertid) {
                $scope.isCreate = false;
                alertCarsService
                    .getCarAlertDetailsById($scope.alertid)
                    .success(
                        function(data, status) {
                            $scope.carAlertObj = data[0];
                            $scope.getMakeData();
                            $scope.findAllProvinceDetails();
                            $scope.initData();
                        }).error(
                        function(data, status,
                            config) {
                            $state.go('profile');
                        });

            } else {
                $scope.getMakeData();
                $scope.findAllProvinceDetails();
            }
        };

        (function() {
            $scope.getCarAlertDetails();
            $scope.getEmailIfUser();
        })();

    }]);
});