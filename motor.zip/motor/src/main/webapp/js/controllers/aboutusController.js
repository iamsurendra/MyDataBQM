define(['./module'], function(controllers) {
    'use strict';
    controllers.controller('aboutusController', ['$scope', '$http', '$state', '$stateParams', '$rootScope', '$interval', function($scope, $http, $state, $stateParams, $rootScope, $interval) {

    }]);
});