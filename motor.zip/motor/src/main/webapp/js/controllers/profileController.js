define(['./module'], function(controllers) {
    'use strict';
    controllers.controller('profileController', ['$scope', '$http', '$state', '$stateParams', '$rootScope', 'resultsService', 'indexService', 'dealerCarsService', 'notificationService', 'alertCarsService', 'singleCarService', 'authenticationService', function($scope, $http, $state, $stateParams, $rootScope, resultsService, indexService, dealerCarsService, notificationService, alertCarsService, singleCarService, authenticationService) {

        if ($rootScope.user.userId == undefined || $rootScope.user.userId == null) {
            $state.go('index');
        } else {

            $scope.user.profileImage = $rootScope.user.profileImage || './img/noimage.jpg';
            $scope.loading = true;
            $scope.error = false;

            $scope.loadingCarData = true;
            $scope.errorCarData = false;


            $scope.isSaving = false;
            $scope.isSaving1 = false;
            $scope.isEdit = false;

            $scope.scrollDisabled = true;
            $scope.carList = [];

            $scope.filterList = [];
            $scope.makeList = [];
            $scope.modelList = [];
            $scope.displayCarData = [];

            $scope.searchJson = {
                "selectedMake": undefined,
                "selectedModel": undefined,
                "vin": null
            };

            $scope.uploadProfileImage = function() {
                if ($scope.profileImage) {
                    $scope.isSaving1 = true;
                    var uploadUrl = $rootScope.serviceurl + '/user/uploadProfileImage';
                    var fd = new FormData();
                    fd.append('file', $scope.profileImage);
                    $http.post(uploadUrl, fd, {
                            transformRequest: angular.identity,
                            headers: {
                                'Content-Type': undefined
                            },
                            params: {
                                "userId": $rootScope.user.userId
                            }
                        }).success(function() {
                            notificationService.infoNotification($rootScope.messages.PROFILE_UPDATED_SUCCESSFULLY);
                            $scope.isSaving1 = false;
                            $scope.getUserLocalInfoById();
                        })
                        .error(function() {
                            notificationService.errorNotification("Error");
                            $scope.isSaving1 = false;
                        })
                }

            }

            //update profile
            $scope.editProfile = {
                "userId": "",
                "eMail": "",
                "phoneNo": "",
                "newPhoneNumber": "",
                "provinceId": "",
                "cityAreaId": "",
                "address": "",
                "userLocaleDetails": [{
                        "id": "",
                        "languageId": 100,
                        "firstName": "",
                        "lastName": "",
                        "address": "",
                        // "dealerName": ""
                    }
                ]
            };

            $scope.findWithAttr = function(array, attr,
                value) {
                for (var i = 0; i < array.length; i += 1) {
                    if (array[i][attr] === value) {
                        return i;
                    }
                }
            };

            //get province
            $scope.provinceList = [];
            $scope.findAllProvinceDetails = function() {
                authenticationService
                    .findAllProvinceDetails()
                    .success(
                        function(data, status) {
                            data.forEach(function(element) {
                                $scope.provinceList.push({
                                    "id": element.id,
                                    "label": element.name,
                                    "labelDari": element.nameDari,
                                    "value": element.id
                                });
                            });
                        }).error(
                        function(data, status,
                            config) {});
            };

            //get area city by province
            $scope.cityAreaList = [];
            $scope.getAreaCityByProvinceId = function() {
                if ($scope.editProfile.provinceId != "") {
                    $scope.cityAreaList = [];
                    authenticationService
                        .getAreaCityByProvinceId($scope.editProfile.provinceId)
                        .success(
                            function(data, status) {
                                data.forEach(function(element) {
                                    $scope.cityAreaList.push({
                                        "id": element.id,
                                        "cityAreaId": element.id,
                                        "label": element.cityArea,
                                        "labelDari": element.cityAreaDari,
                                        "value": element.id
                                    });
                                });
                            }).error(
                            function(data, status,
                                config) {});
                }
            }


            // get make list
            $scope.getMakeData = function() {
                indexService
                    .getMakeData()
                    .success(
                        function(data, status) {
                            data.forEach(function(element) {
                                $scope.makeList.push({
                                    "label": element,
                                    "value": element
                                });
                            });

                        }).error(
                        function(data, status,
                            config) {});
            };

            // get model data on make change
            $scope.getModelDataByMakeName = function() {
                // resetting the model value and model list
                $scope.selectedModel = null;
                $scope.modelList = [];

                //getting the selected make
                var make = $scope.searchJson.selectedMake != undefined ? $scope.searchJson.selectedMake.value : null;
                // get model list
                if (make != null) {
                    indexService
                        .getModelDataByMakeName(make)
                        .success(
                            function(data, status) {
                                data.forEach(function(element) {
                                    $scope.modelList.push({
                                        "label": element,
                                        "value": element
                                    });
                                });

                            }).error(
                            function(data, status,
                                config) {});
                }



            };

            $scope.getUserLocalInfoById = function() {
            	if ($rootScope.user.dealerId == null) {
            		var languageId =100;
                indexService
                    .getUserLocalInfoById($rootScope.user.userId, languageId)
                    .success(
                        function(data, status) {
                            $rootScope.user = data;
                        }).error(
                        function(data, status,
                            config) {});
            	}
            };


            // $scope.initDetails = function () {
            //     var user = angular.copy($rootScope.user);
            //     if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
            //         $scope.editProfile.userId = user.userId;
            //         $scope.editProfile.userLocaleDetails[0].firstName = user.firstName;
            //         $scope.editProfile.userLocaleDetails[0].lastName = user.lastName;
            //         $scope.editProfile.eMail = user.eMail;
            //         $scope.editProfile.phoneNo = user.phoneNo;
            //         $scope.editProfile.newPhoneNumber = user.newPhoneNumber;
            //         $scope.editProfile.userLocaleDetails[0].address = user.address
            //         // $scope.editProfile.area = user.area;
            //         if (user.provinceId != undefined) {
            //             var index = $scope.provinceList.indexOf(user.provinceId);
            //             if (index != -1) {
            //                 $scope.editProfile.provinceId = $scope.provinceList[index];
            //                 $scope.getAreaCityByProvinceId();
            //             }
            //         }
            //     }
            // }

            $scope.toggleProfileEdit = function() {
                // $scope.initDetails();
                $scope.updateUserObjectByUserId();
                // $scope.getUserLocalInfoById();
                $scope.isEdit = !$scope.isEdit;
            };

            $scope.updateUserObjectByUserId = function() {
                authenticationService
                    .updateUserObjectByUserId($rootScope.user.userId)
                    .success(
                        function(data, status) {
                            $scope.editProfile = data;
                            $scope.getAreaCityByProvinceId();
                        }).error(
                        function(data, status,
                            config) {});
            }

            $scope.editUserDetails = function() {
                authenticationService
                    .updateUser($rootScope.user.userId)
                    .success(
                        function(data, status) {
                            $scope.editProfile = data;
                            $scope.getAreaCityByProvinceId();
                        }).error(
                        function(data, status,
                            config) {});
            }

            $scope.updateProfile = function() {
                $scope.isSaving = true;
                var message = $rootScope.messages.PROFILE_UPDATED_SUCCESSFULLY;
                authenticationService
                    .updateUser($scope.editProfile)
                    .success(
                        function(data, status) {
                            notificationService.infoNotification(message);
                            $scope.isSaving = false;
                            $scope.isEdit = false;
                            $scope.getAreaCityByProvinceId();
                            $scope.getUserLocalInfoById();
                            $scope.editProfile = data;
                            $rootScope.user = data;
                        }).error(
                        function(data, status,
                            config) {
                            $scope.isSaving = false;
                        });
            }

            $scope.initMessageSeller = function(carObj) {
                var messageCarObj = angular.copy(carObj);
                $scope.messageSeller = angular.copy(carObj);
                $scope.comment = {
                    "firstName": "",
                    "lastName": "",
                    "email": "",
                    "phoneNo": "",
                    "comment": "",
                    "make": messageCarObj.make,
                    "model": messageCarObj.model,
                    "year": messageCarObj.year,
                    "ownerMailId": messageCarObj.email
                };
                if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                    $scope.comment.firstName = $rootScope.user.firstName;
                    $scope.comment.lastName = $rootScope.user.lastName;
                    $scope.comment.email = $rootScope.user.eMail;
                    $scope.comment.phoneNo = $rootScope.user.phoneNo;
                }

            };

            $scope.initCallSeller = function(carObj) {
                var messageCarObj = angular.copy(carObj);
                $scope.callSeller = angular.copy(carObj);
            };

            $scope.saveMessageSeller = function() {

                $scope.isSaving = true;
                singleCarService
                    .saveMessageSeller($scope.comment)
                    .success(
                        function(data, status) {
                            $scope.isSaving = false;
                            notificationService.infoNotification($rootScope.messages.MAIL_SENT_TO_OWNER);
                            angular.element("#message-seller").modal('hide');
                            if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                                $scope.comment.comment = '';
                            } else {
                                $scope.comment = {};
                            }
                        }).error(
                        function(data, status,
                            config) {
                            $scope.isSaving = false;
                        });
            };

            $scope.sortByOptionsList = [{
                    "label": "Popularity",
                    "value": 3
                },
                {
                    "label": "Price -- Low to High",
                    "value": 0
                },
                {
                    "label": "Price -- High to Low",
                    "value": 1
                },
                {
                    "label": "Newest First",
                    "value": 2
                }
            ];

            $scope.searchJson.sortBy = $scope.sortByOptionsList[$scope.findWithAttr($scope.sortByOptionsList, 'value', 2)];

            $scope.filterArrIndex = ['selectedMake', 'selectedModel', 'vin', 'sortBy'];

            $scope.addToFilters = function(label, value, scopeVar, isArray) {
                if (label != undefined && label != "") {

                    var filterObj = {
                        "label": label,
                        "value": value,
                        "scopeVar": scopeVar,
                        "isArray": isArray,
                        "sortIndex": $scope.filterArrIndex.indexOf(scopeVar)
                    };

                    var filterIndex = -1;

                    angular.forEach($scope.filterList, function(value, key) {
                        var temp = angular.copy(value);
                        delete temp['id'];
                        if (angular.equals(temp, filterObj)) {
                            filterIndex = key;
                        }
                        if (value.isArray == false && value.scopeVar == filterObj.scopeVar) {
                            $scope.filterList.splice(key, 1);
                        }
                    });

                    if (filterIndex != -1) {
                        $scope.filterList.splice(filterIndex, 1);
                    } else {
                        filterObj["id"] = Math.random();
                        $scope.filterList.push(filterObj);
                    }
                } else if (label == undefined || label == "") {
                    angular.forEach($scope.filterList, function(value, key) {
                        if (angular.equals(value.scopeVar, scopeVar)) {
                            $scope.filterList.splice(key, 1);
                            if (scopeVar == 'selectedMake') {
                                $scope.searchJson.selectedModel = null;
                                var idx = -1;
                                angular.forEach($scope.filterList, function(value, keyIndex) {
                                    if (value.scopeVar == 'selectedModel') {
                                        idx = keyIndex;
                                    }
                                });
                                if (idx != -1) {
                                    $scope.filterList.splice(idx);
                                }

                            }
                        }
                    });
                }

            };

            $scope.removeFromFilters = function(id) {
                var filterObj, filterIndex;
                angular.forEach($scope.filterList, function(value, keyIndex) {
                    if (value.id == id) {
                        filterObj = $scope.filterList[keyIndex];
                        filterIndex = keyIndex;
                    }
                });

                if (filterObj.isArray) {
                    var targetIdx = $scope.searchJson[filterObj.scopeVar].indexOf(filterObj.value);
                    if (targetIdx != -1) {
                        $scope.searchJson[filterObj.scopeVar].splice(targetIdx, 1);
                    }
                } else {
                    var targetIdx = $scope.findWithAttr($scope.searchJson[filterObj.scopeVar], 'value', filterObj.value);
                    if (targetIdx != -1) {
                        $scope.searchJson[filterObj.scopeVar] = null;
                        if (filterObj.scopeVar == 'selectedMake') {
                            $scope.searchJson.selectedModel = null;
                            var idx = -1;
                            angular.forEach($scope.filterList, function(value, keyIndex) {
                                if (value.scopeVar == 'selectedModel') {
                                    idx = keyIndex;
                                }
                            });
                            if (idx != -1) {
                                $scope.filterList.splice(idx);
                            }

                        }
                    }
                }
                $scope.filterList.splice(filterIndex, 1);
                $scope.doSearch();

            };

            $scope.clearAll = function() {
                $scope.filterList = [];
                $scope.searchJson.selectedMake = null;
                $scope.searchJson.selectedModel = null;
                $scope.searchJson.vin = null;
                $scope.searchJson.sortBy = null;
                $scope.doSearch();
            };

            $scope.initSelected = function(carJson) {
                if (carJson['make'] != undefined) {
                    if ($scope.searchJson.selectedMake != undefined) {
                        $scope.addToFilters($scope.searchJson.selectedMake.label, $scope.searchJson.selectedMake.value, 'selectedMake', false);
                    }
                }

                if (carJson['model'] != undefined) {
                    if ($scope.searchJson.selectedModel != undefined) {
                        $scope.addToFilters($scope.searchJson.selectedModel.label, $scope.searchJson.selectedModel.value, 'selectedModel', false);
                    }
                }

                if (carJson['vin'] != undefined) {
                    if ($scope.searchJson.selectedModel != undefined) {
                        $scope.addToFilters($scope.searchJson.vin, $scope.searchJson.vin, 'vin', false);
                    }
                }

                $scope.getSearchData(carJson);
            };

            $scope.doSearch = function() {
                $scope.page = 0;
                var carJson = {
                    "make": $scope.searchJson.selectedMake != undefined ? $scope.searchJson.selectedMake.value : null,
                    "model": $scope.searchJson.selectedModel != undefined ? $scope.searchJson.selectedModel.value : null,
                    "sortDetails": $scope.searchJson.sortBy != undefined ? $scope.searchJson.sortBy.value : 2,
                    "contactName": $rootScope.user.userName,
                    "vin": $scope.searchJson.vin != "" ? $scope.searchJson.vin : null,
                    "page": $scope.page,
                    "userId": $rootScope.user.userId,
                    "languageId": $rootScope.languageId,
                    "email": $rootScope.user.eMail
                };
                $scope.initSelected(carJson);
            };

            $scope.getSearchData = function(carJson) {
                $scope.totalItems = 0;
                $scope.loadingCarData = true;
                $scope.scrollDisabled = true;
                $scope.displayCarData = [];
                resultsService
                    .searchInfo(carJson)
                    .success(
                        function(data, status) {
                            $scope.totalItems = data.total;
                            $scope.displayCarData = data.carDetails;
                            $scope.loadingCarData = false;
                            $scope.scrollDisabled = false;
                        }).error(
                        function(data, status,
                            config) {
                            $scope.errorCarData = false;
                            $scope.scrollDisabled = false;
                        });
            };

            $scope.loadMore = function() {
                $scope.fetching = true;
                $scope.scrollDisabled = true;

                $scope.page = $scope.page + 1;
                var carJson = {
                    "make": $scope.searchJson.selectedMake != undefined ? $scope.searchJson.selectedMake.value : null,
                    "model": $scope.searchJson.selectedModel != undefined ? $scope.searchJson.selectedModel.value : null,
                    "sortDetails": $scope.searchJson.sortBy != undefined ? $scope.searchJson.sortBy.value : 2,
                    "contactName": $rootScope.user.userName,
                    "vin": $scope.searchJson.vin,
                    "page": $scope.page,
                    "userId": $rootScope.user.userId,
                    "languageId": $rootScope.languageId,
                    "email": $rootScope.user.eMail
                };
                resultsService
                    .searchInfo(carJson)
                    .success(
                        function(data, status) {
                            if (data.carDetails.length > 0) {
                                $scope.displayCarData = $scope.displayCarData.concat(data.carDetails);
                                $scope.fetching = false;
                                $scope.scrollDisabled = false;

                            } else {
                                $scope.fetching = false;
                                $scope.scrollDisabled = true;
                            }


                        }).error(
                        function(data, status,
                            config) {
                            $scope.errorCarData = true;
                            $scope.fetching = false;
                            $scope.scrollDisabled = false;
                        });
            };

            $scope.getFavioriteCarIds = function() {
                var userId = $rootScope.user.userId;
                if (userId != null) {
                    resultsService
                        .getFavioriteCarIds(userId)
                        .success(
                            function(data, status) {
                                $rootScope.favioriteCarIdList = data;
                                $scope.getFavCarList();
                            }).error(
                            function(data, status,
                                config) {});
                } else {}
            };


            $scope.getFavCarList = function() {
                if ($rootScope.favioriteCarIdList.length > 0) {
                	var carDetailsView = {
                			"carIds": $rootScope.favioriteCarIdList,
                			"languageId": $rootScope.languageId
                	} 
                    resultsService
                        .getFavoriteCars(carDetailsView)
                        .success(
                            function(data, status) {
                                $scope.carList = data;
                                $scope.markFavioriteCar($scope.carList);
                                $scope.loading = false;
                            }).error(
                            function(data, status,
                                config) {
                                $scope.loading = false;
                                $scope.error = true;
                            });
                } else {
                    $scope.carList = [];
                    $scope.loading = false;
                }
            };

            $scope.addToFavorites = function(carId) {
                var userId = $rootScope.user.userId;
                // if the user is logged in
                if (userId != null) {
                    var favorites = {
                        "userId": userId,
                        "carId": carId,
                        "favorite": true
                    };
                    // add car to the faviorites if not added
                    if ($rootScope.favioriteCarIdList.indexOf(carId) == -1) {
                        resultsService
                            .addToFavorites(favorites)
                            .success(
                                function(data, status) {
                                    $rootScope.favioriteCarIdList = data;
                                    $scope.markFavioriteCar($scope.carList);
                                }).error(
                                function(data, status,
                                    config) {});
                    }

                    // remove the car from faviorites if already added        		
                    if ($rootScope.favioriteCarIdList.indexOf(carId) != -1) {
                        resultsService
                            .removeFromFavorites(favorites)
                            .success(
                                function(data, status) {
                                    $rootScope.favioriteCarIdList = data;
                                    $scope.getFavCarList();
                                }).error(
                                function(data, status,
                                    config) {});
                    }

                }
                // if the user not logged in
                else {
                    notificationService.errorNotification($rootScope.messages.PLEASE_LOGIN_TO_ADD_FOR_FAVORITES);
                }
            };

            $scope.deleteCarInfo = function(carId, index) {
                var carData = angular.copy($scope.displayCarData);
                dealerCarsService
                    .deleteCarInfo(carId)
                    .success(
                        function(data, status) {
                            $scope.displayCarData.splice(index, 1);
                            $scope.totalItems = $scope.totalItems - 1;
                            notificationService.infoNotification($rootScope.messages.DELETED_SUCCESSFULLY);
                            $scope.getFavioriteCarIds();
                        }).error(
                        function(data, status,
                            config) {
                            notificationService.infoNotification(data.message);
                            $scope.displayCarData = carData;
                        });
            };

            $scope.markInactiveCar = function(carId, index) {
                var carInfo = $scope.displayCarData[index];
                var message = "";
                dealerCarsService
                    .makeCarAsInactive(carId)
                    .success(
                        function(data, status) {
                            if (carInfo.carStatus == 1) {
                                $scope.displayCarData[index].carStatus = 0;
                                message = $rootScope.messages.VEHICLE_INFO_INACTIVED;
                            } else {
                                $scope.displayCarData[index].carStatus = 1;
                                message = $rootScope.messages.VEHICLE_INFO_ACTIVED;
                            }
                            notificationService.infoNotification(message);
                            $scope.getFavioriteCarIds();
                        }).error(
                        function(data, status,
                            config) {
                            notificationService.infoNotification($rootScope.messages.ERROR_PLEAE_TRY_AGAIN);
                        });

            };

            $scope.initDisplayCars = true;
            $scope.getDisplayCarsInfo = function() {
                if ($scope.initDisplayCars) {
                    $scope.initDisplayCars = false;
                    $scope.doSearch();
                }

            };



            $scope.markFavioriteCar = function(srcList) {
                $scope.carList = resultsService.markFavioriteCar(srcList);
            };

            $scope.getRecentCarsInfo = function(recentlyVisited) {
                var recentCarsdata = recentlyVisited || [];
                var idList = [];
                if (recentCarsdata.length > 0) {
                    angular.forEach(recentCarsdata, function(element) {
                        idList.push(element.carId);
                    });
                    var carDetailsView = {
                			"carIds": idList,
                			"languageId": $rootScope.languageId
                	}
                    resultsService
                        .getRecentlyViewedCars(carDetailsView)
                        .success(
                            function(data, status) {
                                if (data.length > 0) {
                                    angular.forEach(recentCarsdata, function(element, key) {
                                        var index = $scope.findWithAttr(data, 'id', element.carId);
                                        if (index != undefined) {
                                            var carInfo = data[index];
                                            recentCarsdata[key]['carName'] = carInfo.year + " " + carInfo.make + " " + carInfo.model;
                                        }

                                    });
                                }
                                $scope.recentActivityList = recentCarsdata;
                            }).error(
                            function(data, status,
                                config) {});
                }


            };

            $scope.getRecentlyViewedCars = function() {
                dealerCarsService
                    .getRecentlyViewedCars($rootScope.user.userId)
                    .success(
                        function(data, status) {
                            if (data.length > 0) {
                                $scope.getRecentCarsInfo(data);
                            }
                        }).error(
                        function(data, status,
                            config) {
                            $scope.recentActivityList = [];
                        });
            };

            $scope.getCarAlerts = function() {
                alertCarsService
                    .getCarAlerts($rootScope.user.userId)
                    .success(
                        function(data, status) {
                            $scope.dealerAlertList = data;
                        }).error(
                        function(data, status,
                            config) {
                            $scope.dealerAlertList = [];
                        });
            };

            $scope.deleteCarAlert = function(index) {
                alertCarsService
                    .deleteCarAlert($scope.dealerAlertList[index])
                    .success(
                        function(data, status) {
                            $scope.dealerAlertList.splice(index, 1);
                            notificationService.infoNotification($rootScope.messages.DELETED_SUCCESSFULLY);
                        }).error(
                        function(data, status,
                            config) {
                            notificationService.err(data.message);
                        });
            };
            
            $rootScope.$watch('languageId', function() {
            	$scope.getFavCarList();
            });

            (function() {
                $scope.getFavioriteCarIds();
                $scope.getMakeData();
                $scope.getRecentlyViewedCars();
                $scope.getCarAlerts();
                $scope.findAllProvinceDetails();
            })();
        }
    }]);
});