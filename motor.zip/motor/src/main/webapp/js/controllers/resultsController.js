define(['./module'], function(controllers) {
    'use strict';
    controllers.controller('resultsController', ['$scope', '$http', '$state', '$rootScope', '$location', '$anchorScroll', 'resultsService', 'indexService', 'notificationService', 'authenticationService', 'singleCarService', 'utilityService', function($scope, $http, $state, $rootScope, $location, $anchorScroll, resultsService, indexService, notificationService, authenticationService, singleCarService, utilityService) {

        $scope.serviceurl = $rootScope.serviceurl;

        $scope.userId = $rootScope.user.userId;

        $scope.dealerName = null;
        $scope.makeList = [];
        $scope.modelList = [];
        $scope.bodyStyleList = [];
        $scope.fuelTypeList = [];
        $scope.provinceList = [];
        $scope.locationList = [];

        $scope.fuelTypes = [];
        $scope.transmissions = [];
        $scope.cylinders = [];
        $scope.driveTypes = [];

        $scope.resultData = [];

        $scope.loading = true;
        $scope.error = false;
        $scope.scrollDisabled = true;

        $scope.initMake = true;
        $scope.initProvince = true;

        $scope.selectedExteriorColors = [];
        $scope.selectedInteriorColors = [];
        $scope.isInit = true;

        $scope.clearAll = function() {

            $scope.selectedExteriorColors = [];

            $scope.filterList = [];
            $scope.selectedConditions = null;

            $scope.bodyType = null;
            $scope.fromYear = null;
            $scope.toYear = null;
            $scope.dealerName = null;

            $scope.minPrice = null;
            $scope.maxPrice = null;

            $scope.maxKiloMeters = null;

            $scope.fuelTypes = [];
            $scope.transmissions = [];
            $scope.cylinders = [];
            $scope.driveTypes = [];


            $scope.selectedMake = undefined;
            $scope.selectedModel = null;
            $scope.drivingSeat = null;
            $scope.certified = null;
            $scope.sortBy = {
                "label": "Newest First",
                "value": 2
            };
            $scope.province = undefined;
            $scope.location = null;
            $scope.vin = null;

            angular.element('.display').each(function() {
                angular.element(this).removeClass('display');
            })
            $scope.doSearch();
        };

        $scope.showFilterDialog = function(header, filterName) {
            $scope.filterHeader = header;
            $scope.filterName = filterName;
            angular.element('#filterModal').modal('show');
        };

        $scope.filterList = [];

        $scope.filterArrIndex = [
            'selectedConditions', 'bodyType', 'selectedMake', 'selectedModel', 'drivingSeat', 'certified', 'fromYear', 'toYear', 'minPrice',
            'maxPrice', 'maxKiloMeters', 'province', 'location', 'fuelTypes', 'selectedExteriorColors', 'transmissions', 'cylinders', 'driveTypes',
            'sortBy'
        ];

        $scope.addToFilters = function(label, value, scopeVar, isArray) {
            if (label != undefined && label != "") {

                var filterObj = {
                    "label": label,
                    "value": value,
                    "scopeVar": scopeVar,
                    "isArray": isArray,
                    "sortIndex": $scope.filterArrIndex.indexOf(scopeVar)
                };

                var filterIndex = -1;

                angular.forEach($scope.filterList, function(value, key) {
                    var temp = angular.copy(value);
                    delete temp['id'];
                    if (angular.equals(temp, filterObj)) {
                        filterIndex = key;
                    }
                    if (value.isArray == false && value.scopeVar == filterObj.scopeVar) {
                        $scope.filterList.splice(key, 1);
                    }
                });

                if (filterIndex != -1) {
                    $scope.filterList.splice(filterIndex, 1);
                } else {
                    if (scopeVar == 'dealerName') {
                        $scope.dealerName = value;
                    }
                    filterObj["id"] = Math.random();
                    $scope.filterList.push(filterObj);
                }
            } else if (label == undefined || label == "") {
                angular.forEach($scope.filterList, function(value, key) {
                    if (angular.equals(value.scopeVar, scopeVar)) {
                        $scope.filterList.splice(key, 1);
                        if (scopeVar == 'selectedMake') {
                            $scope.selectedModel = null;
                            var idx = -1;
                            angular.forEach($scope.filterList, function(value, keyIndex) {
                                if (value.scopeVar == 'selectedModel') {
                                    idx = keyIndex;
                                }
                            });
                            if (idx != -1) {
                                $scope.filterList.splice(idx);
                            }

                        }
                        if (scopeVar == 'province') {
                            $scope.location = null;
                            var idx = -1;
                            angular.forEach($scope.filterList, function(value, keyIndex) {
                                if (value.scopeVar == 'location') {
                                    idx = keyIndex;
                                }
                            });
                            if (idx != -1) {
                                $scope.filterList.splice(idx);
                            }

                        }
                    }
                });
            }
        };

        $scope.removeFromFilters = function(id) {
            var filterObj, filterIndex;
            angular.forEach($scope.filterList, function(value, keyIndex) {
                if (value.id == id) {
                    filterObj = $scope.filterList[keyIndex];
                    filterIndex = keyIndex;
                }
            });

            if (filterObj.isArray) {
                if (filterObj.scopeVar == 'dealerName') {
                    $scope.dealerName = null;
                } else {
                    var targetIdx = $scope[filterObj.scopeVar].indexOf(filterObj.value);
                    if (targetIdx != -1) {
                        $scope[filterObj.scopeVar].splice(targetIdx, 1);
                    }
                }
            } else {
                var targetIdx = $scope.findWithAttr($scope[filterObj.scopeVar], 'value', filterObj.value);
                if (targetIdx != -1) {
                    $scope[filterObj.scopeVar] = null;
                    if (filterObj.scopeVar == 'selectedMake') {
                        $scope.selectedMake = null;
                        $scope.selectedModel = null;
                        var idx = -1;
                        angular.forEach($scope.filterList, function(value, keyIndex) {
                            if (value.scopeVar == 'selectedModel') {
                                idx = keyIndex;
                            }
                        });
                        if (idx != -1) {
                            $scope.filterList.splice(idx);
                        }

                    }

                    if (filterObj.scopeVar == 'province') {
                        $scope.province = null;
                        $scope.location = null;
                        var idx = -1;
                        angular.forEach($scope.filterList, function(value, keyIndex) {
                            if (value.scopeVar == 'location') {
                                idx = keyIndex;
                            }
                        });
                        if (idx != -1) {
                            $scope.filterList.splice(idx);
                        }

                    }
                }
            }
            $scope.filterList.splice(filterIndex, 1);
            $scope.doSearch();

        };

        // type head options
        $scope.modelOptions = {
            debounce: {
                'default': 500,
                'blur': 250
            },
            getterSetter: true
        };

        // get make list
        $scope.getMakeData = function() {
            indexService
                .getMakeData()
                .success(
                    function(data, status) {
                        data.forEach(function(element) {
                            $scope.makeList.push({
                                "label": element,
                                "value": element
                            });
                        });

                        if ($scope.searchJson['make'] != undefined && $scope.initMake) {
                            var index = $scope.findWithAttr($scope.makeList, 'value', $scope.searchJson['make']);
                            $scope.selectedMake = $scope.makeList[index];
                            $scope.addToFilters($scope.selectedMake.label, $scope.selectedMake.value, 'selectedMake', false);
                            $scope.getModelDataByMakeName();
                        } else {
                            $scope.initMake = false;
                        }


                    }).error(
                    function(data, status,
                        config) {
                        $scope.initMake = false;
                    });
        };

        // get model data on make change
        $scope.getModelDataByMakeName = function() {
            // resetting the model value and model list
            $scope.selectedModel = null;
            $scope.modelList = [];

            //getting the selected make
            var make = $scope.selectedMake != undefined ? $scope.selectedMake.value : null;
            // get model list
            if (make != null) {
                indexService
                    .getModelDataByMakeName(make)
                    .success(
                        function(data, status) {
                            data.forEach(function(element) {
                                $scope.modelList.push({
                                    "label": element,
                                    "value": element
                                });
                            });

                            if ($scope.searchJson['model'] != undefined && $scope.initMake) {
                                var index = $scope.findWithAttr($scope.modelList, 'value', $scope.searchJson['model']);
                                $scope.selectedModel = $scope.modelList[index];
                                $scope.addToFilters($scope.selectedModel.label, $scope.selectedModel.value, 'selectedModel', false);
                                $scope.initMake = false;
                            } else {
                                $scope.initMake = false;
                            }

                        }).error(
                        function(data, status,
                            config) {
                            $scope.initMake = false;
                        });
            }



        };

        // get body style list
        $scope.getBodyStyle = function() {
            resultsService
                .getBodyStyle()
                .success(
                    function(data, status) {
                        data.forEach(function(element) {
                            $scope.bodyStyleList.push({
                                "label": element,
                                "value": element
                            });
                        });

                        if ($scope.searchJson['bodyType'] != undefined) {
                            var index = $scope.findWithAttr($scope.bodyStyleList, 'value', $scope.searchJson['bodyType']);
                            $scope.bodyType = $scope.bodyStyleList[index];
                            $scope.addToFilters($scope.bodyType.label, $scope.bodyType.value, 'bodyType', false);
                        }

                    }).error(
                    function(data, status,
                        config) {});
        };

        $scope.clearFilterData = function() {
            if (!$scope.isInit) {
                $scope.clearAll();
            } else {
                $scope.isInit = false;
            }
        };

        $rootScope.$watch('languageId', function() {
            if (!$scope.initProvince) {
                $scope.findAllProvinceDetails();
                $scope.getAreaCityByProvinceId();
            }
            $scope.clearFilterData();

        });



        $scope.findAllProvinceDetails = function() {
            authenticationService
                .findAllProvinceDetails()
                .success(
                    function(data, status) {
                        $scope.provinceList = [];
                        data.forEach(function(element) {
                            $scope.provinceList.push({
                                "label": element[utilityService.getPropertyNameByLocale("name")],
                                "value": element.id
                            });

                        });

                        if ($scope.searchJson['province'] != undefined && $scope.initProvince) {
                            var index = $scope.findWithAttr($scope.provinceList, 'value', $scope.searchJson['province']);
                            $scope.province = $scope.provinceList[index];
                            $scope.addToFilters($scope.province.label, $scope.province.value, 'province', false);
                            $scope.getAreaCityByProvinceId();
                        } else {
                            $scope.initProvince = false;
                        }
                        //$scope.dealer.provinceId = $scope.provinceList[0].id;
                    }).error(
                    function(data, status,
                        config) {
                        $scope.initProvince = false;
                    });
        }


        $scope.getAreaCityByProvinceId = function() {
            $scope.location = null;
            $scope.locationList = [];
            var province = $scope.province != undefined ? $scope.province.value : null;
            if (province != null) {
                authenticationService
                    .getAreaCityByProvinceId(province)
                    .success(
                        function(data, status) {
                            data.forEach(function(element) {
                                $scope.locationList.push({
                                    "cityAreaId": element.id,
                                    "label": element[utilityService.getPropertyNameByLocale("cityArea")],
                                    "value": element.id
                                });

                            });
                            if ($scope.searchJson['location'] != undefined && $scope.initProvince) {
                                var index = $scope.findWithAttr($scope.locationList, 'value', $scope.searchJson['location']);
                                $scope.location = $scope.locationList[index];

                                $scope.addToFilters($scope.location.label, $scope.location.value, 'location', false);
                                $scope.initProvince = false;
                            } else {
                                $scope.initProvince = false;
                            }
                        }).error(
                        function(data, status,
                            config) {
                            $scope.initProvince = false;
                        });
            }

        };


        $scope.steeringList = [{
            label: 'Left Hand Drive',
            value: true
        }, {
            label: 'Right Hand Drive',
            value: false
        }];

        $scope.certifiedCheckList = [{
            label: 'Certified',
            value: true
        }, {
            label: 'Not-Certified',
            value: false
        }];

        $scope.yearList = [{
            label: '2018',
            value: 2018
        }, {
            label: '2017',
            value: 2017
        }, {
            label: '2016',
            value: 2016
        }, {
            label: '2015',
            value: 2015
        }, {
            label: '2014',
            value: 2014
        }, {
            label: '2013',
            value: 2013
        }, {
            label: '2012',
            value: 2012
        }, {
            label: '2011',
            value: 2011
        }, {
            label: '2010',
            value: 2010
        }, {
            label: '2009',
            value: 2009
        }, {
            label: '2008',
            value: 2008
        }, {
            label: '2007',
            value: 2007
        }, {
            label: '2006',
            value: 2006
        }, {
            label: '2005',
            value: 2005
        }, {
            label: '2004',
            value: 2004
        }, {
            label: '2003',
            value: 2003
        }, {
            label: '2002',
            value: 2002
        }, {
            label: '2001',
            value: 2001
        }, {
            label: '2000',
            value: 2000
        }, {
            label: '1999',
            value: 1999
        }, {
            label: '1998',
            value: 1998
        }, {
            label: '1997',
            value: 1997
        }, {
            label: '1996',
            value: 1996
        }, {
            label: '1995',
            value: 1995
        }, {
            label: '1994',
            value: 1994
        }, {
            label: '1993',
            value: 1993
        }, {
            label: '1992',
            value: 1992
        }, {
            label: '1991',
            value: 1991
        }, {
            label: '1990',
            value: 1990
        }];


        $scope.priceRangeFromList = [{
                label: '$00,000',
                value: 0
            }, {
                label: '$10,001',
                value: 10001
            }, {
                label: '$15,001',
                value: 15001
            }, {
                label: '$20,001',
                value: 20001
            }, {
                label: '$25,001',
                value: 25001
            }, {
                label: '$30,001',
                value: 30001
            },
            {
                label: '$35,001',
                value: 35001
            },
            {
                label: '$40,001',
                value: 40001
            },
            {
                label: '$45,001',
                value: 45001
            },
            {
                label: '$50,001',
                value: 50001
            },
            {
                label: '$55,001',
                value: 55001
            },
            {
                label: '$60,001',
                value: 60001
            },
            {
                label: '$65,001',
                value: 65001
            },
            {
                label: '$70,001',
                value: 70001
            },
            {
                label: '$75,001',
                value: 75001
            },
            {
                label: '$80,001',
                value: 80001
            },
            {
                label: '$85,001',
                value: 85001
            },
            {
                label: '$90,001',
                value: 90001
            },
            {
                label: '$95,001',
                value: 95001
            },
            {
                label: '$100,001',
                value: 100001
            }
        ];

        $scope.priceRangeToList = [{
                label: '$10,000',
                value: 10000
            }, {
                label: '$15,000',
                value: 15000
            }, {
                label: '$20,000',
                value: 20000
            }, {
                label: '$25,000',
                value: 25000
            }, {
                label: '$30,000',
                value: 30000
            },
            {
                label: '$35,000',
                value: 35000
            },
            {
                label: '$40,000',
                value: 40000
            },
            {
                label: '$45,000',
                value: 45000
            },
            {
                label: '$50,000',
                value: 50000
            },
            {
                label: '$55,000',
                value: 55000
            },
            {
                label: '$60,000',
                value: 60000
            },
            {
                label: '$65,000',
                value: 65000
            },
            {
                label: '$70,000',
                value: 70000
            },
            {
                label: '$75,000',
                value: 75000
            },
            {
                label: '$80,000',
                value: 80000
            },
            {
                label: '$85,000',
                value: 85000
            },
            {
                label: '$90,000',
                value: 90000
            },
            {
                label: '$95,000',
                value: 95000
            },
            {
                label: '$100,000',
                value: 100000
            }
        ];

        $scope.mileageRangeToList = [{
            label: '10,000',
            value: 10000
        }, {
            label: '25,000',
            value: 25000
        }, {
            label: '50,000',
            value: 50000
        }, {
            label: '75,000',
            value: 75000
        }, {
            label: '100,000',
            value: 100000
        }, {
            label: '150,000',
            value: 150000
        }];


        $scope.conditionList = [{
            "label": "New Cars",
            "value": true
        }, {
            "label": "Used Cars",
            "value": false
        }];


        $scope.transmissionList = [{
            "label": "Automatic",
            "value": "Automatic"
        }, {
            "label": "Manual",
            "value": "Manual"
        }, {
            "label": "Semi-Automatic",
            "value": "Semi-Automatic"
        }];


        $scope.cylindersTypeList = [{
            "label": "4 Cylinders",
            "value": 4
        }, {

            "label": "5 Cylinders",
            "value": 5
        }, {
            "label": "6 Cylinders",
            "value": 6
        }, {
            "label": "8 Cylinders",
            "value": 8
        }];

        $scope.driveTypeList = [{
            "label": "FWD",
            "value": "FWD"
        }, {
            "label": "RWD",
            "value": "RWD"
        }, {
            "label": "AWD",
            "value": "AWD"
        }, {
            "label": "4X4",
            "value": "4X4"
        }];


        $scope.soryByOptionsList = [{
                "label": "Popularity",
                "value": 3
            },
            {
                "label": "Price -- Low to High",
                "value": 0
            },
            {
                "label": "Price -- High to Low",
                "value": 1
            },
            {
                "label": "Newest First",
                "value": 2
            }
        ];


        $scope.fuelTypeList = [{
            "label": "PETROL",
            "value": "Petrol"
        }, {
            "label": "DIESEL",
            "value": "Diesel"
        }, {
            "label": "ELECTRIC",
            "value": "Electric"
        }, {
            "label": "HYBRID",
            "value": "Hybrid"
        }, {
            "label": "LPG",
            "value": "Lpg"
        }];

        $scope.colorsList = [{
                "label": "white",
                "value": 2
            }, {
                "label": "black",
                "value": 1
            },
            {
                "label": "purple",
                "value": 3
            },
            {
                "label": "silver",
                "value": 4
            },
            {
                "label": "red",
                "value": 5
            },
            {
                "label": "gray",
                "value": 6
            },
            {
                "label": "lightblue",
                "value": 7
            },
            {
                "label": "darkblue",
                "value": 8
            },
            {
                "label": "orange",
                "value": 9
            },
            {
                "label": "brown",
                "value": 10
            },
            {
                "label": "yellow",
                "value": 11
            },
            {
                "label": "darkgreen",
                "value": 12
            },
            {
                "label": "lightgreen",
                "value": 13
            },
            {
                "label": "gold",
                "value": 14
            },
            {
                "label": "rgb(237, 230, 185)",
                "value": 15
            }
        ];

        $scope.isSaving = false;

        $scope.initMessageSeller = function(carObj) {
            var messageCarObj = angular.copy(carObj);
            $scope.messageSeller = angular.copy(carObj);
            $scope.comment = {
                "firstName": "",
                "lastName": "",
                "email": $rootScope.user.eMail,
                "phoneNo": "",
                "comment": "",
                "make": messageCarObj.make,
                "model": messageCarObj.model,
                "year": messageCarObj.year,
                "ownerMailId": messageCarObj.email
            };
            if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                $scope.comment.firstName = $rootScope.user.firstName;
                $scope.comment.lastName = $rootScope.user.lastName;
                $scope.comment.ownerMailId = messageCarObj.email;
                $scope.comment.phoneNo = $rootScope.user.phoneNo;
            }

        };

        $scope.initCallSeller = function(carObj) {
            var messageCarObj = angular.copy(carObj);
            $scope.callSeller = angular.copy(carObj);
        };

        $scope.saveMessageSeller = function() {

            $scope.isSaving = true;
            singleCarService
                .saveMessageSeller($scope.comment)
                .success(
                    function(data, status) {
                        $scope.isSaving = false;
                        notificationService.infoNotification($rootScope.messages.MAIL_SENT_TO_OWNER);
                        angular.element("#message-seller").modal('hide');
                        if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                            $scope.comment.comment = '';
                        } else {
                            $scope.comment = {};
                        }
                    }).error(
                    function(data, status,
                        config) {
                        $scope.isSaving = false;    
                        notificationService.errorNotification(data.message);
                    });  
        };


        $scope.selectedConditions = [];
        $scope.addToCompare = function(carId) {
            if ($rootScope.isCompareEnabled) {
                var userId = $rootScope.user.userId;
                var index = $rootScope.compareCarIdList.indexOf(carId);

                if (index != -1) {
                    $rootScope.compareCarIdList.splice(index, 1);
                    $scope.markCompareCar($scope.resultData);

                } else {
                    if ($rootScope.compareCarIdList.length < 3) {
                        $rootScope.compareCarIdList.push(carId);
                        $scope.markCompareCar($scope.resultData);
                    } else {
                        notificationService.errorNotification($rootScope.messages.MAX_COMPARE_CARS_REACHED);
                    }
                }
            }
        };
        $scope.addToFavorites = function(carId) {
            var userId = $rootScope.user.userId;
            // if the user is logged in
            if (userId != null) {
                var favorites = {
                    "userId": userId,
                    "carId": carId,
                    "favorite": true
                };
                // add car to the faviorites if not added
                if ($rootScope.favioriteCarIdList.indexOf(carId) == -1) {
                    resultsService
                        .addToFavorites(favorites)
                        .success(
                            function(data, status) {
                                $rootScope.favioriteCarIdList = data;
                                $scope.markFavioriteCar($scope.resultData);
                            }).error(
                            function(data, status,
                                config) {});
                }

                // remove the car from faviorites if already added        		
                if ($rootScope.favioriteCarIdList.indexOf(carId) != -1) {
                    resultsService
                        .removeFromFavorites(favorites)
                        .success(
                            function(data, status) {
                                $rootScope.favioriteCarIdList = data;
                                $scope.markFavioriteCar($scope.resultData);
                            }).error(
                            function(data, status,
                                config) {});
                }

            }
            // if the user not logged in
            else {
                notificationService.errorNotification($rootScope.messages.PLEASE_LOGIN_TO_ADD_FOR_FAVORITES);
            }
        };


        $scope.markFavioriteCar = function(srcList) {
            $scope.resultData = resultsService.markFavioriteCar(srcList);
        };

        $scope.markCompareCar = function(srcList) {
            $scope.resultData = resultsService.markCompareCar(srcList);
        };

        $scope.markViewedCar = function(srcList) {
            $scope.resultData = resultsService.markViewedCar(srcList);
        };

        $scope.updateChangedFilterVar = function(changedVariable) {
            switch (changedVariable) {
                case 'location':
                    if (angular.isObject($scope.location) || $scope.location == "") {
                        $scope.addToFilters($scope.location.label, $scope.location.value, 'location', false)
                    }
                    break;
            }

        };

        $scope.soryByFilter = function() {
            $('#sortBy').modal('hide');
            $scope.page = 0;
            $scope.searchJson.page = 0;
            $scope.searchJson.sortDetails = $scope.sortBy != undefined ? $scope.sortBy.value : 2;
            $rootScope.searchJson = angular.copy($scope.searchJson);
            $anchorScroll('wrapper');
            $scope.getSearchData($scope.searchJson);
        };


        $scope.getSearchData = function(carJson) {
            $rootScope.filterList = angular.copy($scope.filterList);
            $scope.totalItems = 0;
            $scope.resultData = [];

            $scope.loading = true;
            $scope.error = false;
            $scope.fetching = false;
            $scope.scrollDisabled = true;

            resultsService
                .searchInfo(carJson)
                .success(
                    function(data, status) {
                        $scope.totalItems = data.total;
                        if ($scope.totalItems > 2) {
                            $scope.scrollDisabled = false;
                        }
                        $scope.resultData = data.carDetails;
                        $scope.markViewedCar($scope.resultData);
                        $scope.markFavioriteCar($scope.resultData);
                        $scope.markCompareCar($scope.resultData);
                        $scope.loading = false;
                    }).error(
                    function(data, status,
                        config) {
                        $scope.loading = false;
                        $scope.error = true;
                        $scope.scrollDisabled = false;
                    });
        };

        $scope.selectedInteriors = [];
        $scope.selectedExteriors = [];
        $scope.page = 0;
        $scope.doSearch = function() {
            $('#modified-search').modal('hide');

            $('#filterModal').modal('hide')
            $('#filterModal').on('hidden', function() {
                $('#filters').modal('show')
            })

            $scope.page = 0;
            var carJson = {
                "make": $scope.selectedMake != undefined ? $scope.selectedMake.value : null,
                "model": $scope.selectedModel != undefined ? $scope.selectedModel.value : null,
                "condition": $scope.selectedConditions != undefined ? $scope.selectedConditions.value : null,
                "fromYear": $scope.fromYear != undefined ? $scope.fromYear.value : null,
                "toYear": $scope.toYear != undefined ? $scope.toYear.value : null,
                "minPrice": $scope.minPrice != undefined ? $scope.minPrice.value : null,
                "maxPrice": $scope.maxPrice != undefined ? $scope.maxPrice.value : null,
                "maxKiloMeters": $scope.maxKiloMeters != undefined ? $scope.maxKiloMeters.value : null,
                "fuelTypes": $scope.fuelTypes,
                "transmissions": $scope.transmissions,
                'dealerName': $scope.dealerName,
                "cylinders": $scope.cylinders,
                "driveTypes": $scope.driveTypes,
                "sortDetails": $scope.sortBy != undefined ? $scope.sortBy.value : 2,
                "bodyType": $scope.bodyType != undefined ? $scope.bodyType.value : null,
                "drivingSeat": $scope.drivingSeat != undefined ? $scope.drivingSeat.value : null,
                "certified": $scope.certified != undefined ? $scope.certified.value : null,
                "province": $scope.province != undefined ? $scope.province.value : null,
                "location": $scope.location != undefined ? $scope.location.value : null,
                "exteriorColorIds": $scope.selectedExteriorColors,
                "page": $scope.page,
                "languageId": $rootScope.languageId
            };

            $rootScope.searchJson = angular.copy(carJson);
            $anchorScroll('wrapper');
            $scope.searchJson = angular.copy($rootScope.searchJson);
            $scope.initSelected();

        };



        // init selected values
        $scope.searchJson = angular.copy($rootScope.searchJson);

        $scope.findWithAttr = function(array, attr,
            value) {
            for (var i = 0; i < array.length; i += 1) {
                if (array[i][attr] === value) {
                    return i;
                }
            }
        };

        $scope.initFilters = function() {

            angular.forEach($scope.fuelTypes, function(value, key) {
                var index = $scope.findWithAttr($scope.fuelTypeList, 'value', value);
                if (index != -1) {
                    $scope.addToFilters($scope.fuelTypeList[index].label, value, 'fuelTypes', true);
                }
            });

            angular.forEach($scope.transmissions, function(value, key) {
                var index = $scope.findWithAttr($scope.transmissionList, 'value', value);
                if (index != -1) {
                    $scope.addToFilters($scope.transmissionList[index].label, value, 'transmissions', true);
                }
            });

            angular.forEach($scope.cylinders, function(value, key) {
                var index = $scope.findWithAttr($scope.cylindersTypeList, 'value', value);
                if (index != -1) {
                    $scope.addToFilters($scope.cylindersTypeList[index].label, value, 'cylinders', true);
                }
            });

            angular.forEach($scope.driveTypes, function(value, key) {
                var index = $scope.findWithAttr($scope.driveTypeList, 'value', value);
                if (index != -1) {
                    $scope.addToFilters($scope.driveTypeList[index].label, value, 'driveTypes', true);
                }
            });

            angular.forEach($scope.selectedExteriorColors, function(value, key) {
                var index = $scope.findWithAttr($scope.colorsList, 'value', value);
                if (index != -1) {
                    $scope.addToFilters($scope.colorsList[index].label, value, 'selectedExteriorColors', true);
                }
            });

            $scope.getSearchData($scope.searchJson);

        };

        $scope.initSelected = function() {
            $scope.filterList = [];

            if ($scope.searchJson['newCar'] != undefined) {
                var index = $scope.findWithAttr($scope.conditionList, 'value', $scope.searchJson['newCar']);
                $scope.selectedConditions = $scope.conditionList[index];
                if ($scope.selectedConditions != undefined) {
                    $scope.addToFilters($scope.selectedConditions.label, $scope.selectedConditions.value, 'newCar', false);
                }
            }

            if ($scope.searchJson['vin'] != undefined) {
                $scope.vin = $scope.searchJson['vin'];
                $scope.addToFilters($scope.vin, $scope.vin, 'vin', false);
            }

            if ($scope.searchJson['make'] != undefined && !$scope.initMake) {
                var index = $scope.findWithAttr($scope.makeList, 'value', $scope.searchJson['make']);
                $scope.selectedMake = $scope.makeList[index];
                if ($scope.selectedMake != undefined) {
                    $scope.addToFilters($scope.selectedMake.label, $scope.selectedMake.value, 'selectedMake', false);
                }
            }

            if ($scope.searchJson['model'] != undefined && !$scope.initMake) {
                var index = $scope.findWithAttr($scope.modelList, 'value', $scope.searchJson['model']);
                $scope.selectedModel = $scope.modelList[index];
                if ($scope.selectedModel != undefined) {
                    $scope.addToFilters($scope.selectedModel.label, $scope.selectedModel.value, 'selectedModel', false);
                }
            }

            if ($scope.searchJson['year'] != undefined) {
                var index = $scope.findWithAttr($scope.yearList, 'value', $scope.searchJson['year']);
                $scope.fromYear = $scope.yearList[index];
                if ($scope.fromYear != undefined) {
                    $scope.addToFilters($scope.fromYear.label, $scope.fromYear.value, 'fromYear', false);
                }
            }

            if ($scope.searchJson['bodyType'] != undefined) {
                var index = $scope.findWithAttr($scope.bodyStyleList, 'value', $scope.searchJson['bodyType']);
                $scope.bodyType = $scope.bodyStyleList[index];
                if ($scope.bodyType != undefined) {
                    $scope.addToFilters($scope.bodyType.label, $scope.bodyType.value, 'bodyType', false);
                }

            }

            if ($scope.searchJson['fromYear'] != undefined) {
                var index = $scope.findWithAttr($scope.yearList, 'value', $scope.searchJson['fromYear']);
                $scope.fromYear = $scope.yearList[index];
                if ($scope.fromYear != undefined) {
                    $scope.addToFilters($scope.fromYear.label, $scope.fromYear.value, 'fromYear', false);
                }
            }

            if ($scope.searchJson['toYear'] != undefined) {
                var index = $scope.findWithAttr($scope.yearList, 'value', $scope.searchJson['toYear']);
                $scope.toYear = $scope.yearList[index];
                if ($scope.toYear != undefined) {
                    $scope.addToFilters($scope.toYear.label, $scope.toYear.value, 'toYear', false);
                }
            }

            if ($scope.searchJson['minPrice'] != undefined) {
                var index = $scope.findWithAttr($scope.priceRangeFromList, 'value', $scope.searchJson['minPrice']);
                $scope.minPrice = $scope.priceRangeFromList[index];
                if ($scope.minPrice != undefined) {
                    $scope.addToFilters($scope.minPrice.label, $scope.minPrice.value, 'minPrice', false);
                }
            }

            if ($scope.searchJson['maxPrice'] != undefined) {
                var index = $scope.findWithAttr($scope.priceRangeToList, 'value', $scope.searchJson['maxPrice']);
                $scope.maxPrice = $scope.priceRangeToList[index];
                if ($scope.maxPrice != undefined) {
                    $scope.addToFilters($scope.maxPrice.label, $scope.maxPrice.value, 'maxPrice', false);
                }
            }


            if ($scope.searchJson['maxKiloMeters'] != undefined) {
                var index = $scope.findWithAttr($scope.mileageRangeToList, 'value', $scope.searchJson['maxKiloMeters']);
                $scope.maxKiloMeters = $scope.mileageRangeToList[index];
                if ($scope.maxKiloMeters != undefined) {
                    $scope.addToFilters($scope.maxKiloMeters.label, $scope.maxKiloMeters.value, 'maxKiloMeters', false);
                }
            }

            if ($scope.searchJson['condition'] != undefined) {
                var index = $scope.findWithAttr($scope.conditionList, 'value', $scope.searchJson['condition']);
                $scope.selectedConditions = $scope.conditionList[index];
                if ($scope.selectedConditions != undefined) {
                    $scope.addToFilters($scope.selectedConditions.label, $scope.selectedConditions.value, 'selectedConditions', false);
                }
            }


            if ($scope.searchJson['fuelTypes'] != undefined) {
                $scope.fuelTypes = $scope.searchJson['fuelTypes'];
            }

            if ($scope.searchJson['transmissions'] != undefined) {
                $scope.transmissions = $scope.searchJson['transmissions'];
            }

            if ($scope.searchJson['cylinders'] != undefined) {
                $scope.cylinders = $scope.searchJson['cylinders'];
            }
            if ($scope.searchJson['driveTypes'] != undefined) {
                $scope.driveTypes = $scope.searchJson['driveTypes'];
            }

            if ($scope.searchJson['dealerName'] != undefined) {
                $scope.dealerName = $scope.searchJson['dealerName'];
                $scope.addToFilters($scope.dealerName, $scope.dealerName, 'dealerName', false);
            }


            if ($scope.searchJson['exteriorColorIds'] != undefined) {
                $scope.selectedExteriorColors = $scope.searchJson['exteriorColorIds'];
            }

            if ($scope.searchJson['sortDetails'] != undefined) {
                $scope.sortBy = $scope.soryByOptionsList[$scope.findWithAttr($scope.soryByOptionsList, 'value', $scope.searchJson['sortDetails'])];
            }

            if ($scope.searchJson['sortDetails'] == undefined) {
                $scope.sortBy = $scope.soryByOptionsList[$scope.findWithAttr($scope.soryByOptionsList, 'value', 2)];
            }



            if ($scope.searchJson['drivingSeat'] != undefined) {
                var index = $scope.findWithAttr($scope.steeringList, 'value', $scope.searchJson['drivingSeat']);
                $scope.drivingSeat = $scope.steeringList[index];
                if ($scope.drivingSeat != undefined) {
                    $scope.addToFilters($scope.drivingSeat.label, $scope.drivingSeat.value, 'drivingSeat', false);
                }
            }

            if ($scope.searchJson['certified'] != undefined) {
                var index = $scope.findWithAttr($scope.certifiedCheckList, 'value', $scope.searchJson['certified']);
                $scope.certified = $scope.certifiedCheckList[index];
                if ($scope.certified != undefined) {
                    $scope.addToFilters($scope.certified.label, $scope.certified.value, 'certified', false);
                }
            }

            if ($scope.searchJson['province'] != undefined && !$scope.initProvince) {
                var index = $scope.findWithAttr($scope.provinceList, 'value', $scope.searchJson['province']);
                $scope.province = $scope.provinceList[index];
                if ($scope.province != undefined) {
                    $scope.addToFilters($scope.province.label, $scope.province.value, 'province', false);
                }
            }

            if ($scope.searchJson['location'] != undefined && !$scope.initProvince) {
                var index = $scope.findWithAttr($scope.locationList, 'value', $scope.searchJson['location']);
                $scope.location = $scope.locationList[index];
                if ($scope.location != undefined) {
                    $scope.addToFilters($scope.location.label, $scope.location.value, 'location', false);
                }
            }

            $scope.initFilters();
        };


        (function() {
            $scope.initSelected();
            $scope.getMakeData();
            $scope.getBodyStyle();
            $scope.findAllProvinceDetails();
        })();


        $scope.loadMore = function() {
            if ($scope.totalItems > 2) {
                $scope.page = $scope.page + 1;
                $scope.fetching = true;
                $scope.scrollDisabled = true;

                var carJson = {
                    "make": $scope.selectedMake != undefined ? $scope.selectedMake.value : null,
                    "model": $scope.selectedModel != undefined ? $scope.selectedModel.value : null,
                    "condition": $scope.selectedConditions != undefined ? $scope.selectedConditions.value : null,
                    "fromYear": $scope.fromYear != undefined ? $scope.fromYear.value : null,
                    "toYear": $scope.toYear != undefined ? $scope.toYear.value : null,
                    "minPrice": $scope.minPrice != undefined ? $scope.minPrice.value : null,
                    "maxPrice": $scope.maxPrice != undefined ? $scope.maxPrice.value : null,
                    "maxKiloMeters": $scope.maxKiloMeters != undefined ? $scope.maxKiloMeters.value : null,
                    "fuelTypes": $scope.fuelTypes,
                    "transmissions": $scope.transmissions,
                    "cylinders": $scope.cylinders,
                    "driveTypes": $scope.driveTypes,
                    "sortDetails": $scope.sortBy != undefined ? $scope.sortBy.value : 2,
                    "bodyType": $scope.bodyType != undefined ? $scope.bodyType.value : null,
                    "drivingSeat": $scope.drivingSeat != undefined ? $scope.drivingSeat.value : null,
                    "certified": $scope.certified != undefined ? $scope.certified.value : null,
                    "province": $scope.province != undefined ? $scope.province.value : null,
                    "location": $scope.location != undefined ? $scope.location.value : null,
                    "exteriorColorIds": $scope.selectedExteriorColors,
                    'dealerName': $scope.dealerName,
                    "page": $scope.page,
                    "languageId": $rootScope.languageId
                };

                resultsService
                    .searchInfo(carJson)
                    .success(
                        function(data, status) {
                            if (data.carDetails.length > 0) {
                                $scope.resultData = $scope.resultData.concat(data.carDetails);
                                $scope.markFavioriteCar($scope.resultData);
                                $scope.markViewedCar($scope.resultData);
                                $scope.fetching = false;
                                $scope.scrollDisabled = false;

                            } else {
                                $scope.fetching = false;
                                $scope.scrollDisabled = true;
                            }


                        }).error(
                        function(data, status,
                            config) {
                            $scope.error = true;
                            $scope.fetching = false;
                            $scope.scrollDisabled = false;
                        });
            }


        };

        $scope.compareCars = function() {
            if ($rootScope.compareCarIdList.length > 0) {
                $state.go('compareCars');
            } else {
                notificationService.errorNotification($rootScope.messages.SELECT_CARS_TO_CHOOSE_THEM_FOR_COMPARISON);
            }
        };

        $scope.createAlert = function() {
            $state.go('alerts');
        };

        $scope.cancelCompareCars = function() {
            $rootScope.isCompareEnabled = false;
            $rootScope.compareCarIdList = [];
            $scope.markCompareCar($scope.resultData);
        };

    }]);
});