define(['./module'], function (controllers) {
    'use strict';
    controllers.controller('singleCarController', ['$scope', '$http', '$state', '$stateParams', '$rootScope', '$interval', 'resultsService', 'singleCarService', 'notificationService', function ($scope, $http, $state, $stateParams, $rootScope, $interval, resultsService, singleCarService, notificationService) {

        $scope.id = JSON.parse($state.params.id);

        $scope.serviceurl = $rootScope.serviceurl;

        $scope.isSaving = false;

        $scope.carDetails = {};
        $scope.carImages = {};

        $scope.activeImageIndex = 0;
        $scope.slideInterval = 0;
        $scope.noWrapSlides = false;
        $scope.comment = {
            "firstName": "",
            "lastName": "",
            "email": $rootScope.user.eMail,
            "phoneNo": "",
            "comment": "",
            "ownerMailId": ""
        };

        $scope.saveMessageSeller = function () {

            $scope.isSaving = true;

            $scope.comment["ownerMailId"] = $scope.carDetails.email;
            $scope.comment["make"] = $scope.carDetails.make;
            $scope.comment["model"] = $scope.carDetails.model;
            $scope.comment["year"] = $scope.carDetails.year;
            console.log($scope.comment)
            singleCarService
                .saveMessageSeller($scope.comment)
                .success(
                    function (data, status) {
                        $scope.isSaving = false;
                        notificationService.infoNotification($rootScope.messages.MAIL_SENT_TO_OWNER);
                        angular.element("#message-seller").modal('hide');
                        if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                            $scope.comment.comment = '';
                        } else {
                            $scope.comment = {};
                        }
                    }).error(
                    function (data, status,
                        config) {
                        $scope.isSaving = false;
                    });
        }

        $scope.initDetails = function () {
            if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                $scope.comment.firstName = $rootScope.user.firstName;
                $scope.comment.lastName = $rootScope.user.lastName;
                $scope.comment.ownerMailId = $scope.carDetails.email;
                $scope.comment.phoneNo = $rootScope.user.phoneNo;
            }
        }


        $scope.addToViewedCars = function (carId) {
            if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                $rootScope.viewedCarIdList = [];
                if ($rootScope.viewedCarIdList.indexOf(carId) == -1) {
                    $rootScope.viewedCarIdList.push(carId);
                }
            }
        };

        $scope.getCarDetails = function () {
            var carDetails = [];
            singleCarService
                .singleCarDetails($scope.id)
                .success(
                    function (data, status) {
                        carDetails.push(data);
                        $scope.carDetails = resultsService.markFavioriteCar(carDetails)[0];
                        $scope.addToViewedCars($scope.id);
                        $scope.comment["ownerMailId"] = $scope.carDetails.email;
                        if ($scope.carDetails.images != undefined) {
                            $scope.activeImageIndex = $scope.carDetails.images.indexOf($scope.carDetails.firstImage);
                        } else {
                            $state.go('result');
                        }

                    }).error(
                    function (data, status,
                        config) {
                        $state.go('result');
                    });
        };
        
        $scope.getSingleCarDetails = function () {
            var carDetails = [];
            singleCarService
                .singleCarDetailsById($rootScope.languageId,$scope.id)
                .success(
                    function (data, status) {
                        carDetails.push(data);
                        $scope.carDetails = resultsService.markFavioriteCar(carDetails)[0];
                        $scope.addToViewedCars($scope.id);
                        $scope.comment["ownerMailId"] = $scope.carDetails.email;
                        if ($scope.carDetails.images != undefined) {
                            $scope.activeImageIndex = $scope.carDetails.images.indexOf($scope.carDetails.firstImage);
                        } else {
                            $state.go('result');
                        }

                    }).error(
                    function (data, status,
                        config) {
                        $state.go('result');
                    });
        };


        $scope.addToFavorites = function (carId) {
            var userId = $rootScope.user.userId;
            // if the user is logged in
            if (userId != null) {
                var favorites = {
                    "userId": userId,
                    "carId": carId,
                    "favorite": true
                };
                // add car to the faviorites if not added
                if ($rootScope.favioriteCarIdList.indexOf(carId) == -1) {
                    resultsService
                        .addToFavorites(favorites)
                        .success(
                            function (data, status) {
                                $rootScope.favioriteCarIdList = data;
                                $scope.carDetails['isFaviorite'] = true;
                            }).error(
                            function (data, status,
                                config) {});
                }

                // remove the car from faviorites if already added        		
                if ($rootScope.favioriteCarIdList.indexOf(carId) != -1) {
                    resultsService
                        .removeFromFavorites(favorites)
                        .success(
                            function (data, status) {
                                $rootScope.favioriteCarIdList = data;
                                $scope.carDetails['isFaviorite'] = false;
                            }).error(
                            function (data, status,
                                config) {});
                }

            }
            // if the user not logged in
            else {
                notificationService.errorNotification($rootScope.messages.PLEASE_LOGIN_TO_ADD_FOR_FAVORITES);
            }
        };

        $scope.addToViewList = function () {
            var RecentViewCars = {
                "userId": $rootScope.user.userId,
                "carId": $scope.id,
                "history": true
            }
            singleCarService
                .addToRecentlyViewed(RecentViewCars)
                .success(
                    function (data, status) {}).error(
                    function (data, status,
                        config) {});
        };
        
        $rootScope.$watch('languageId', function() {
        	$scope.getSingleCarDetails();
        });


        (function () {
            $scope.initDetails();
//            $scope.getCarDetails();
//            $scope.getSingleCarDetails();
            if ($rootScope.user.userId != undefined && $scope.id != undefined) {
                $scope.addToViewList();
            }
        })();


    }]);
});