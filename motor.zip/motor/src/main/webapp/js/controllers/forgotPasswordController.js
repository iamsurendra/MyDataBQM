define(['./module'], function (controllers) {
    'use strict';
    controllers.controller('forgotPasswordController', ['$scope', '$http', '$state', '$rootScope', 'authenticationService', 'notificationService', function ($scope, $http, $state, $rootScope, authenticationService, notificationService) {

        $scope.isSubmit = false;
        $scope.forgotPassword = function () {
            $scope.isSubmit = true;
            var userJson = {
                "eMail": $scope.eMail
            };
            authenticationService
                .forgotPassword(userJson)
                .success(
                    function (data, status) {
                        $scope.isSubmit = false;
                        if (data.dealerId != null) {
                            $state.go('dealerLogin');
                        } else {
                            $state.go('login');
                        }
                        notificationService.infoNotification($rootScope.messages.PASSWORD_SENT_TO_REGISTERED_EMAIL);
                    }).error(
                    function (data, status,
                        config) {
                        notificationService.errorNotification(data.message);
                        $scope.isSubmit = false;
                    });
        }
    }]);
});