define(['./module'], function(controllers) {
    'use strict';
    controllers.controller('indexController', ['$scope', '$http', '$state', '$rootScope', '$location', '$anchorScroll', 'indexService', 'localStorageService', 'notificationService', 'authenticationService', 'resultsService', 'utilityService', function($scope, $http, $state, $rootScope, $location, $anchorScroll, indexService, localStorageService, notificationService, authenticationService, resultsService, utilityService) {

        $scope.totalPages = ['./views/index_hotdeals.html', './views/index_browseby.html', './views/index_comingsoon.html', './views/index_sponsership.html'];
        $scope.pageList = [];
        $scope.pageNo = 0;
        $scope.loadPage = function() {
            if ($scope.pageNo < $scope.totalPages.length) {
                $scope.pageList.push($scope.totalPages[$scope.pageNo]);
            }
            $scope.pageNo = $scope.pageNo + 1;

        };
        $scope.makeList = [];
        $scope.modelList = [];
        $scope.provinceList = [];
        $scope.province = null;

        $anchorScroll.yOffset = 20;

        // init make count list
        $scope.bodyTypeCountList = [];
        $scope.makeCountList = [];
        $scope.priceCountList = [];

        $scope.conditionList = [{
            label: 'New Cars',
            value: true
        }, {
            label: 'Used Cars',
            value: false
        }];

        $scope.steeringList = [{
            label: 'Left Hand Drive',
            value: true
        }, {
            label: 'Right Hand Drive',
            value: false
        }]

        $scope.certifiedCheckList = [{
            label: 'Certified',
            value: true
        }, {
            label: 'Not-Certified',
            value: false
        }]


        $scope.priceList = [{
                label: '$00,000- $10,000',
                value: {
                    "minPrice": 0,
                    "maxPrice": 10000
                }
            },
            {
                label: '$10,001 - $20,000',
                value: {
                    "minPrice": 10001,
                    "maxPrice": 20000
                }
            },
            {
                label: '$20,001 - $30,000',
                value: {
                    "minPrice": 20001,
                    "maxPrice": 30000
                }
            }, {
                label: '$30,001 - $40,000',
                value: {
                    "minPrice": 30001,
                    "maxPrice": 40000
                }
            },
            {
                label: '$40,001 - $50,000',
                value: {
                    "minPrice": 40001,
                    "maxPrice": 50000
                }
            },
            {
                label: '$50,001 - $60,000',
                value: {
                    "minPrice": 50001,
                    "maxPrice": 60000
                }
            },
            {
                label: '$60,001 - $70,000',
                value: {
                    "minPrice": 60001,
                    "maxPrice": 70000
                }
            },
            {
                label: '$70,001 - $80,000',
                value: {
                    "minPrice": 70001,
                    "maxPrice": 80000
                }
            },
            {
                label: '$80,001 - $90,000',
                value: {
                    "minPrice": 80001,
                    "maxPrice": 90000
                }
            },
            {
                label: '$90,001 - $100,000',
                value: {
                    "minPrice": 90001,
                    "maxPrice": 100000
                }
            },
            {
                label: '$100,001 - Above',
                value: {
                    "minPrice": 100001
                        // "maxPrice": 100000
                }
            }
        ];



        $scope.indexPricelist = [{
            label: '$2,000',
            value: 2000
        }, {
            label: '$4,000',
            value: 4000
        }, {
            label: '$6,000',
            value: 6000
        }, {
            label: '$8,000',
            value: 8000
        }, {
            label: '$10,000',
            value: 10000
        }, {
            label: '$15,000',
            value: 15000
        }, {
            label: '$20,000',
            value: 20000
        }, {
            label: '$25,000',
            value: 25000
        }, {
            label: '$30,000',
            value: 30000
        }, {
            label: '$35,000',
            value: 35000
        }, {
            label: '$40,000',
            value: 40000
        }, {
            label: '$45,000',
            value: 45000
        }, {
            label: '$50,000',
            value: 50000
        }, {
            label: '$60,000',
            value: 60000
        }, {
            label: '$70,000',
            value: 70000
        }, {
            label: '$80,000',
            value: 80000
        }, {
            label: '$90,000',
            value: 90000
        }, {
            label: '$100,000',
            value: 100000
        }, {
            label: '$125,000',
            value: 125000
        }];

        $scope.priceCountList = [{
                range: "0-10,000"
            },
            {
                range: "10,001-20,000"
            },
            {
                range: "20,001-30,000"
            }, {
                range: "30,001-40,000"
            },
            {
                range: "40,001-50,000"
            },
            {
                range: "50,001-60,000"
            },
            {
                range: "60,001-70,000"
            },
            {
                range: "70,001-80,000"
            },
            {
                range: "80,001-90,000"
            },
            {
                range: "90,001-100,000"
            },
            {
                range: "100,001-Above"
            }
        ];



        $scope.yearList = [{
            label: '2010',
            value: 2010
        }, {
            label: '2011',
            value: 2011
        }, {
            label: '2012',
            value: 2012
        }, {
            label: '2013',
            value: 2013
        }, {
            label: '2014',
            value: 2014
        }, {
            label: '2015',
            value: 2015
        }, {
            label: '2016',
            value: 2016
        }, {
            label: '2017',
            value: 2017
        }, {
            label: '2018',
            value: 2018
        }];

        $scope.kilometersRunList = [{
            label: '10,000',
            value: 10000
        }, {
            label: '25,000',
            value: 25000
        }, {
            label: '50,000',
            value: 50000
        }, {
            label: '75,000',
            value: 75000
        }, {
            label: '100,000',
            value: 100000
        }, {
            label: '150,000',
            value: 150000
        }];

        $scope.getMakeData = function() {
            indexService
                .getMakeData()
                .success(
                    function(data, status) {
                        data.forEach(function(element) {
                            $scope.makeList.push({
                                "label": element,
                                "value": element
                            });
                        });
                    }).error(
                    function(data, status,
                        config) {});
        };

        $scope.getModelDataByMakeName = function() {
            // resetting the model value and model list
            $scope.selectedModel = null;
            $scope.modelList = [];

            //getting the selected make
            var make = $scope.selectedMake != undefined ? $scope.selectedMake.value : null;
            // get model list
            if (make != null) {
                indexService
                    .getModelDataByMakeName(make)
                    .success(
                        function(data, status) {
                            data.forEach(function(element) {
                                $scope.modelList.push({
                                    "label": element,
                                    "value": element
                                });
                            });
                        }).error(
                        function(data, status,
                            config) {});
            }
        };

        $rootScope.$watch('languageId', function() {
            $scope.findAllProvinceDetails();
            $scope.getAreaCityByProvinceId();
        });

        $scope.findAllProvinceDetails = function() {
            authenticationService
                .findAllProvinceDetails()
                .success(
                    function(data, status) {
                        $scope.provinceList = [];
                        data.forEach(function(element) {
                            $scope.provinceList.push({
                                "label": element[utilityService.getPropertyNameByLocale("name")],
                                "value": element.id
                            });

                        });
                    }).error(
                    function(data, status,
                        config) {});
        }

        $scope.getAreaCityByProvinceId = function() {
            $scope.location = null;
            $scope.locationList = [];
            var province = $scope.province != undefined ? $scope.province.value : null;
            if (province != null) {
                authenticationService
                    .getAreaCityByProvinceId(province)
                    .success(
                        function(data, status) {
                            data.forEach(function(element) {
                                $scope.locationList.push({
                                    "label": element[utilityService.getPropertyNameByLocale("cityArea")],
                                    "value": element.id
                                });

                            });
                        }).error(
                        function(data, status,
                            config) {});
            }
        }


        $scope.findWithAttr = function(array, attr,
            value) {
            for (var i = 0; i < array.length; i += 1) {
                if (array[i][attr] === value) {
                    return i;
                }
            }
        };

        $scope.navigateToSellMyCar = function() {

            var userId = $rootScope.user.userId;
            if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                if ($rootScope.user.dealerId == null) {

                    if ($rootScope.user.lastName == '' || $rootScope.user.phoneNo == '' ||
                        $rootScope.user.province == '' || $rootScope.user.area == '') {
                        angular.element('#profile-details').modal('show');
                    } else {
                        resultsService.
                        getCountOfCarsByUserId(userId)
                            .success(
                                function(data, status) {
                                    $scope.carcount = data;
                                    if ($scope.carcount < 1) {
                                        $state.go('dealer');
                                    } else {
                                        notificationService.infoNotification($rootScope.messages.USER_HAS_NO_ACCESS);
                                    }
                                }).error(
                                function(data, status,
                                    config) {});
                    }
                } else {
                    $scope.checkDealercarsCount();
                }
            } else {
                notificationService.errorNotification($rootScope.messages.PLEASE_LOGIN_TO_CONTINUE);
            }
        };

        $scope.checkDealercarsCount = function() {
            indexService
                .checkDealercarsCount($rootScope.user.userId)
                .success(
                    function(data, status) {
                        if (data) {
                            $state.go('dealer');
                        } else {
                            notificationService.errorNotification($rootScope.messages.DEALER_CARS_EXCEEDED);
                        }
                    }).error(
                    function(data, status,
                        config) {});
        }

        $scope.getBodyTypeCountList = function() {
            indexService
                .getBodyTypeCountList()
                .success(
                    function(data, status) {
                        var bodyTypeOrderList = ['Sedan', 'Convertible', 'SUV', 'Sports car', 'Minivan', 'Coupe', 'Crossover', 'Hatchback', 'Hybrid', 'Pick up trucks', 'Wagon'];
                        bodyTypeOrderList.forEach(function(type) {
                            var index = $scope.findWithAttr(data, 'bodyType', type);
                            if (index != undefined) {
                                $scope.bodyTypeCountList.push(data[index]);
                            }
                        });
                    }).error(
                    function(data, status,
                        config) {});
        };

        $scope.getMakeCountList = function() {
            indexService
                .getMakeCountList()
                .success(
                    function(data, status) {
                        $scope.makeCountList = data;
                    }).error(
                    function(data, status,
                        config) {});
        };

        //        $scope.getPriceCountList = function() {
        //            indexService
        //                .getPriceCountList()
        //                .success(
        //                    function(data, status) {
        //                        $scope.priceCountList = data;
        //                    }).error(
        //                    function(data, status,
        //                        config) {});
        //        };


        (function() {
            $scope.getMakeData();
            $scope.getBodyTypeCountList();
            $scope.getMakeCountList();
            //            $scope.getPriceCountList()        

            if ($rootScope.searchedBy != undefined) {
                if ($rootScope.searchedBy == 'browseby') {
                    $scope.loadPage();
                    $scope.loadPage();
                }
                setTimeout(function() {
                    $anchorScroll($rootScope.searchedBy);
                    $rootScope.searchedBy = "";
                }, 500);
            }
        })();

        $scope.conditionReset = function() {
            $scope.selectedYear = null;
            $scope.selectedKilometersRun = null;
        }

        $scope.resetData = function() {
            $scope.selectedMake = null;
            $scope.selectedModel = null;
            $scope.selectedPrice = null;
            $scope.selectedYear = null;
            $scope.selectedKilometersRun = null;
            $scope.selectedModel = null;
            $scope.modelList = [];
        };

        // search by car details
        $scope.searchVehicles = function() {
            $rootScope.searchJson = {
                "newCar": $scope.newCar != undefined ? $scope.newCar.value : null,
                "condition": $scope.selectedConditions != undefined ? $scope.selectedConditions.value : null,
                "make": $scope.selectedMake != undefined ? $scope.selectedMake.value : null,
                "model": $scope.selectedModel != undefined ? $scope.selectedModel.value : null,
                "minPrice": $scope.selectedPrice != undefined ? $scope.selectedPrice.value.minPrice : null,
                "maxPrice": $scope.selectedPrice != undefined ? $scope.selectedPrice.value.maxPrice : null,
                "year": $scope.selectedYear != undefined ? $scope.selectedYear.value : null,
                "maxKiloMeters": $scope.selectedKilometersRun != undefined ? $scope.selectedKilometersRun.value : null,
                "drivingSeat": $scope.drivingSeat != undefined ? $scope.drivingSeat.value : null,
                "certified": $scope.certified != undefined ? $scope.certified.value : null,
                "province": $scope.province != undefined ? $scope.province.value : null,
                "location": $scope.location != undefined ? $scope.location.value : null,
                "sortDetails": 2,
                "languageId": $rootScope.languageId
            };
            $rootScope.searchedBy = "wrapper";
            $rootScope.activeSearchIndex = 0;
            $rootScope.showMore = false;
            $state.go('result');

        };

        $scope.searchVehiclesByVin = function() {
            $rootScope.searchJson = {
                "vin": $scope.vin,
            };
            $rootScope.searchedBy = "wrapper";
            $rootScope.activeSearchIndex = 0;
            $rootScope.showMore = false;
            $state.go('result');
        };

        // search by body type
        $scope.searchByBodyType = function(bodyType) {
            $rootScope.searchJson = {
                "bodyType": bodyType,
                "languageId": $rootScope.languageId
            };
            $rootScope.searchedBy = "browseby";
            $rootScope.activeSearchIndex = 0;
            $state.go('result');
        };

        // search by make
        $scope.searchByMake = function(make) {
            $rootScope.searchJson = {
                "make": make,
                "languageId": $rootScope.languageId
            };
            $rootScope.searchedBy = "browseby";
            $rootScope.activeSearchIndex = 1;
            $state.go('result');
        };

        // search by price
        $scope.searchByPrice = function(price) {
            var priceList = price.split('-');
            var regex = new RegExp(',', 'g');
            var minPrice = priceList[0].replace(regex, '');
            var maxPrice = priceList[1].replace(regex, '');
            $rootScope.searchJson = {
                'minPrice': parseInt(minPrice),
                'maxPrice': isNaN(maxPrice) ? null : parseInt(maxPrice),
                "languageId": $rootScope.languageId
            };
            $rootScope.searchedBy = "browseby";
            $rootScope.activeSearchIndex = 2;
            $state.go('result');
        };

        $rootScope.searchJson = {};


    }]);
});