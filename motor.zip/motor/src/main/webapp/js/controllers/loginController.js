define(['./module'], function (controllers) {
    'use strict';
    controllers.controller('loginController', ['$scope', '$http', '$state', '$rootScope', 'authenticationService', 'notificationService', 'alertCarsService', 'indexService', function ($scope, $http, $state, $rootScope, authenticationService, notificationService, alertCarsService, indexService) {

        var vm = this;

        vm.activeindex = 0

        vm.individual = true;
        $scope.isSaving = false;
        $scope.isActiveUser = true;
        $scope.newPassword = "";
        $scope.confirmPassword = "";

        $scope.login = {
            userName: "",
            eMail: "",
            password: ""
        };

        $scope.user = {
            "userName": "",
            "firstName": "",
            "password": "",
            "confirmPassword": "",
            "lastName": "",
            "eMail": "",
            "phoneNo": "",
            "newPhoneNumber": "",
            "province": "",
            "area": "",
            "address": "",
            "dealer": !vm.individual,
            "userLocaleDetails": [{
                "languageId": 100,
                "firstName": "",
            }]
        };

        $scope.dealer = {
            "userName": "",
            "firstName": "",
            "lastName": "",
            "eMail": "",
            "dealerinfo": {
                "dealerName": "",
                "regNo": "",
            },
            "province": "",
            "area": "",
            "phoneNo": "",
            "newPhoneNumber": "",
            "address": "",
            "dealer": vm.individual
        };

        $scope.resetInput = function () {
            vm.individual = true;
            $scope.user = {
                "userName": "",
                "firstName": "",
                "password": "",
                "confirmPassword": "",
                "lastName": "",
                "eMail": "",
                "phoneNo": "",
                "newPhoneNumber": "",
                "province": "",
                "area": "",
                "address": "",
                "dealer": false
            };

            $scope.dealer = {
                "userName": "",
                "firstName": "",
                "lastName": "",
                "eMail": "",
                "dealerinfo": {
                    "dealerName": "",
                    "regNo": "",
                },
                "province": "",
                "area": "",
                "phoneNo": "",
                "newPhoneNumber": "",
                "address": "",
                "dealer": true
            };
            $scope.login = {
                userName: "",
                eMail: "",
                password: ""
            };

            $scope.newPassword = "";
            $scope.confirmPassword = "";
        }

        $scope.registerUser = function () {
            if ($scope.user.password == $scope.user.confirmPassword) {
                $scope.isSaving = true;
                var user = vm.individual == true ? $scope.user : $scope.dealer;
                var userMessage = $rootScope.messages.USER_INFORMATION_SAVED_SUCCESSFULLY_AND_PASSWORD_SENT_TO_REGISTERED_EMAIL_ID;
                var dealerMessage = $rootScope.messages.DEALER_INFORMATION_SAVED_SUCCESSFULLY_AND_OUR_REPRESENTATIVE_WILL_CONTACT_YOU_SHORTLY;
                var message = vm.individual == true ? userMessage : dealerMessage;
                authenticationService
                    .signUpUser(user)
                    .success(
                        function (data, status) {
                            notificationService.infoNotification(message);
                            $scope.resetInput();
                            $scope.isSaving = false;
                            $rootScope.user.userId = data;
                            $scope.getUserLocalInfoById($rootScope.user.userId, $rootScope.languageId);
                            $state.go('index');
                        }).error(
                        function (data, status,
                            config) {
                            if (data.message != undefined) {
                                notificationService.errorNotification(data.message);
                            } else {
                                notificationService.errorNotification($rootScope.messages.ERROR_WHILE_SAVING_INFORMATION);
                            }
                            $scope.isSaving = false;
                        });
            } else {
                notificationService.errorNotification($rootScope.messages.PASSWORD_AND_CONFIRM_PASSWORD_DOESNT_MATCH);
            }
        };

        $scope.getUserLocalInfoById = function () {
            indexService
                .getUserLocalInfoById($rootScope.user.userId, $rootScope.languageId)
                .success(
                    function (data, status) {
                        $rootScope.user = data;
                    }).error(
                    function (data, status,
                        config) {});
        };

        $scope.loginUser = function () {
            $scope.isSaving = true;
            authenticationService
                .loginUser($scope.login)
                .success(
                    function (data, status) {
                        $scope.isSaving = false;
                        if (data.userId != null && data.userStatus != -1 && data.dealerId == null) {
                            $rootScope.user = data;
                            if ($rootScope.alertInfo != undefined && $rootScope.alertInfo != null && $rootScope.user.eMail == $rootScope.alertInfo.email) {
                                $rootScope.alertInfo.userId = $rootScope.user.userId;
                                alertCarsService
                                    .saveAlert($rootScope.alertInfo)
                                    .success(
                                        function (data, status) {
                                            $scope.resetInput();
                                            notificationService.infoNotification($rootScope.messages.ALERT_SAVED_SUCCESSFULLY);
                                            $rootScope.alertInfo = null;
                                            $state.go('profile');
                                        }).error(
                                        function (data, status,
                                            config) {
                                            notificationService.errorNotification(data.message);
                                        });
                            } else if (data.dealerId != null) {
                                $rootScope.user = {};
                                notificationService.errorNotification($rootScope.messages.PLEASE_LOGIN_IN_DEALER_PAGE);
                            } else {
                                $rootScope.alertInfo = null;
                                $scope.resetInput();
                                notificationService.infoNotification($rootScope.messages.USER_LOGGINED_SUCCESSFULLY);
                                $rootScope.user = data;
                                $scope.getUserLocalInfoById($rootScope.user.userId, $rootScope.languageId)
                                $state.go('index');
                            }


                        } else if (data.dealerId != null) {
                            $rootScope.user = {};
                            notificationService.errorNotification($rootScope.messages.PLEASE_LOGIN_IN_DEALER_PAGE);
                        } else if (data.userId != null && data.userStatus == -1) {
                            $scope.isActiveUser = false;
                        } else if (data.userId == null) {
                            notificationService.errorNotification($rootScope.messages.PLEASE_CHECK_YOUR_EMAIL_AND_PASSWORD);
                        } else if (data.userId != null && data.userStatus == 0) {
                            notificationService.errorNotification(data.message);
                        }
                    }).error(
                    function (data, status,
                        config) {
                        notificationService.errorNotification(data.message);
                        $scope.isSaving = false;
                    });
        };

        // $scope.userLocalInfoById = function () {
        //     indexService
        //         .userLocalInfoById($rootScope.user.userId)
        //         .success(
        //             function (data, status) {
        //                 $rootScope.user = data;
        //             }
        //         )
        //         .error(
        //             function (data, status, config) {}
        //         )
        // }

        $scope.activeUser = function () {
            $scope.isSaving = true;
            if ($scope.newPassword == $scope.confirmPassword) {
                var userJson = {
                    "userName": $scope.login.userName,
                    "eMail": $scope.login.eMail,
                    "password": $scope.confirmPassword
                };
                authenticationService
                    .activeUser(userJson)
                    .success(
                        function (data, status) {
                            $scope.resetInput();
                            vm.activeIndex = 0;
                            $scope.isActiveUser = true;
                            $scope.isSaving = false;
                            notificationService.infoNotification($rootScope.messages.PLEASE_LOGIN_TO_CONTINUE);
                            $state.go('login');
                        }
                    )
                    .error(
                        function (data, status, config) {
                            notificationService.errorNotification($rootScope.messages.ERROR_WHILE_UPDATING_PASSWORD_PLEASE_TRY_AGAIN);
                            $scope.isSaving = true;
                        }
                    )
            }
        };

        $scope.FBLogin = function () {
            // FB.login(function(response) {
            //     if (response.status === 'connected') {
            //         FB.api('me?fields=id,name,first_name,last_name,email,picture{url}', function(userInfo) {
            //             $rootScope.user.userId = userInfo.id;
            //             $rootScope.user.userName = userInfo.name;
            //             $rootScope.user.eMail = userInfo.email;
            //             $rootScope.user.firstName = userInfo.first_name;
            //             $rootScope.user.lastName = userInfo.last_name;
            //             $rootScope.user.profileImage = userInfo.picture.data.url || "./img/noimage.jpg";
            //             $state.go('index');
            //             notificationService.infoNotification($rootScope.messages.USER_LOGGINED_SUCCESSFULLY);
            //         });
            //     } else {
            //         // The person is not logged into your app or we are unable to tell.
            //         console.log('Please log into this app.');
            //     }

            // });
        };

        $scope.GoogleLogin = function () {


            // gapi.auth2.getAuthInstance().signIn().then(function(GoogleUser) {
            //     if (GoogleUser.isSignedIn()) {
            //         var userInfo = {},
            //             BasicProfile = GoogleUser.getBasicProfile();
            //         userInfo.userId = BasicProfile.getId();
            //         userInfo.userName = BasicProfile.getName();
            //         userInfo.firstName = BasicProfile.getGivenName();
            //         userInfo.lastName = BasicProfile.getFamilyName();
            //         userInfo.profileImage = BasicProfile.getImageUrl();
            //         userInfo.eMail = BasicProfile.getEmail();
            //         $rootScope.user = userInfo;
            //         $state.go('index');
            //         notificationService.infoNotification($rootScope.messages.USER_LOGGINED_SUCCESSFULLY);
            //     } else {
            //         console.log('Please log into this app.');
            //     }
            // });

        };

    }]);
});