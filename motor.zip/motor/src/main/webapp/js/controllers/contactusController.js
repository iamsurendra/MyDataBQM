define(['./module'], function (controllers) {
    'use strict';
    controllers.controller('contactusController', ['$scope', '$http', '$rootScope', function ($scope, $http, $rootScope) {

        $scope.reasonList = [{
            label: "Become A Dealer",
            value: "Become A Dealer"
        }, {
            label: "Contact Information",
            value: "Contact Information"
        }, {
            label: "Dealer Access Issues",
            value: "Dealer Access Issues"
        }, {
            label: "General Contact",
            value: "General Contact"
        }, {
            label: "Report A Problem",
            value: "Report A Problem"
        }, {
            label: "Website Feedback",
            value: "Website Feedback"
        }
        ];

        $scope.provinceList = [{
            label: "Kabul",
            value: "Kabul"
        },
        {
            label: "Kandahar",
            value: "Kandahar"
        }, {
            label: "Herat",
            value: "Herat"
        }, {
            label: "Mazar-i-Sharif ",
            value: "Mazar-i-Sharif "
        }, {
            label: "Kunduz",
            value: "Kunduz"
        }, {
            label: "Jalalabad",
            value: "Jalalabad"
        }, {
            label: "Lashkar Gah",
            value: "Lashkar Gah"
        }, {
            label: "Taluqan",
            value: "Taluqan"
        }, {
            label: "Puli Khumri",
            value: "Puli Khumri"
        }
        ];

        $scope.contactUs = {
            "selectReason": "",
            "firstName": "",
            "email": "",
            "phone": "",
            "city": "",
            "province": "",
            "zipCode": "",
            "comments": ""
        }



        $scope.sendContact = function () {
            var contactUs = {
                "selectReason": $scope.contactUs.selectReason != undefined ? $scope.contactUs.selectReason.value : null,
                "firstName": $scope.contactUs.firstName,
                "email": $scope.contactUs.email,
                "phone": $scope.contactUs.phone,
                "city": $scope.contactUs.city,
                "province": $scope.contactUs.province != undefined ? $scope.contactUs.province.value : null,
                "zipCode": $scope.contactUs.zipCode,
                "comments": $scope.contactUs.comments,
            }
            console.log(contactUs);
        }
    }]);
});