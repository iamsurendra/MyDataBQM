define(['./module'], function(controllers) {
    'use strict';
    controllers.controller('navBarController', ['$scope', '$http', '$state', '$rootScope', 'authenticationService', 'resultsService', 'notificationService', 'indexService', function($scope, $http, $state, $rootScope, authenticationService, resultsService, notificationService, indexService) {

        $scope.logout = function() {
            // FB.getLoginStatus(function(response) {
            //     if (response.status === 'connected') {
            //         FB.logout(function(response) {
            //             console.log("facebook logout succesfully");
            //         });
            //     }
            // });

            // gapi.auth2.getAuthInstance().disconnect().then(function() {
            //     console.log("google logout succesfully");
            // });
            $rootScope.alertInfo = null;
            $rootScope.user = {};
            $rootScope.favioriteCarIdList = [];
            $rootScope.alertCarIdList = [];
            notificationService.infoNotification($rootScope.messages.SUCCESSFULLY_LOGGED_OUT);
            $state.go('index');
        };

        $scope.isSaving = false;
        $scope.user = {
            "userId": "",
            "dealerId": "",
            "cityAreaId": "",
            "provinceId": "",
            "eMail": "",
            "password": "",
            "confirmPassword": "",
            "phoneNo": "",
            "newPhoneNumber": "",
            "dealeru": null,
            "userLocaleDetails": [{
                    "id": "",
                    "languageId": 100,
                    "firstName": "",
                    "lastName": "",
                    "address": "",
                    // "dealerName": ""
                },
                {
                    "id": "",
                    "languageId": 101,
                    "firstName": "",
                    "lastName": "",
                    "address": "",
                    // "dealerName": ""
                },
                {
                    "id": "",
                    "languageId": 102,
                    "firstName": "",
                    "lastName": "",
                    "address": "",
                    // "dealerName": ""
                }
            ]
        };

        $scope.provinceList = [];
        $scope.cityAreaList = [];
       
        $scope.findAllProvinceDetails = function() {
            authenticationService
                .findAllProvinceDetails()
                .success(
                    function(data, status) {
                        data.forEach(function(element) {
                            $scope.provinceList.push({
                                "id": element.id,
                                "label": element.name,
                                "labelDari": element.nameDari,
                                "value": element.id
                            });

                        });
                    }).error(
                    function(data, status,
                        config) {});
        }


        $scope.getAreaCityByProvinceId = function() {
            $scope.location = null;
            $scope.cityAreaList = [];
            authenticationService
                .getAreaCityByProvinceId($scope.user.provinceId)
                .success(
                    function(data, status) {
                        data.forEach(function(element) {
                            $scope.cityAreaList.push({
                                "id": element.id,
                                "cityAreaId": element.id,
                                "label": element.cityArea,
                                "labelDari": element.cityAreaDari,
                                "value": element.id
                            });

                        });
                    }).error(
                    function(data, status,
                        config) {});

        };



        $scope.updateUser = function() {
            authenticationService
                .updateUser($scope.dealer)
                .success(
                    function(data, status) {
                        $scope.createDealer = false;
                        $scope.getAllEnglishDetailsUsers();
                        notificationService.infoNotification($rootScope.messages.DEALER_ACCOUNT_UPDATED_SUCCESSFULLY);
                    }).error(
                    function(data, status,
                        config) {
                        notificationService.infoNotification($rootScope.messages.ERROR_PLEAE_TRY_AGAIN);
                    });
        }

        $scope.updateUserDetails = function() {
            $scope.isSaving = true;
            authenticationService
                .updateUser($scope.user)
                .success(
                    function(data, status) {
                        $scope.isSaving = false;
                        angular.element('#profile-details').modal('hide')
                        $scope.userLocalInfoById();
                    }).error(
                    function(data, status,
                        config) {
                        if (data.message != undefined) {
                            notificationService.errorNotification(data.message);
                        } else {
                            notificationService.errorNotification($rootScope.messages.ERROR_WHILE_SAVING_INFORMATION);
                        }
                        $scope.isSaving = false;
                    });
        };

        $scope.userLocalInfoById = function() {
            if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                indexService
                    .getUserLocalInfoById($rootScope.user.userId, $rootScope.languageId)
                    .success(
                        function(data, status) {
                            $rootScope.user = data;
                            $scope.user = angular.copy(data);
                            $state.go('dealer');
                        }).error(
                        function(data, status,
                            config) {});
            }
        }

        $scope.getFavioriteCarIds = function() {
            var userId = $rootScope.user.userId;
            if (userId != null) {
                resultsService
                    .getFavioriteCarIds(userId)
                    .success(
                        function(data, status) {
                            $rootScope.favioriteCarIdList = data;
                        }).error(
                        function(data, status,
                            config) {
                            $rootScope.favioriteCarIdList = []
                        });
            } else {}
        };

        $scope.getViewedCarIds = function() {
            var userId = $rootScope.user.userId;
            if (userId != null) {
                authenticationService
                    .getViewedCarIds(userId)
                    .success(
                        function(data, status) {
                            $rootScope.viewedCarIdList = data;
                        }).error(
                        function(data, status,
                            config) {
                            $rootScope.viewedCarIdList = []
                        });
            } else {}
        };

        $scope.navigateToSellMyCar = function() {
            var userId = $rootScope.user.userId;
            if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                if ($rootScope.user.dealerId == null) {
                    $scope.findAllProvinceDetails();

                    if ($rootScope.user.lastName == '' || $rootScope.user.phoneNo == '' ||
                        $rootScope.user.province == '' || $rootScope.user.area == '') {
                        $scope.user.userId = $rootScope.user.userId;
                        $scope.user.eMail = $rootScope.user.eMail;
                        $scope.user.userLocaleDetails[0].firstName = $rootScope.user.firstName;
                        angular.element('#profile-details').modal('show');
                    } else {
                        resultsService.
                        getCountOfCarsByUserId(userId)
                            .success(
                                function(data, status) {
                                    $scope.carcount = data;
                                    if ($scope.carcount < 1) {
                                        $state.go('dealer');
                                    } else {
                                        notificationService.infoNotification($rootScope.messages.USER_HAS_NO_ACCESS);
                                    }
                                }).error(
                                function(data, status,
                                    config) {});
                    }
                } else {
                    $scope.checkDealercarsCount();
                }
            } else {
                notificationService.errorNotification($rootScope.messages.PLEASE_LOGIN_TO_CONTINUE);
            }
        };

        $scope.checkDealercarsCount = function() {
            indexService
                .checkDealercarsCount($rootScope.user.userId)
                .success(
                    function(data, status) {
                        if (data) {
                            $state.go('dealer');
                        } else {
                            notificationService.errorNotification($rootScope.messages.DEALER_CARS_EXCEEDED);
                        }
                    }).error(
                    function(data, status,
                        config) {});
        }

        $scope.updateUserObjectByUserId = function() {
            authenticationService
                .updateUserObjectByUserId($rootScope.user.userId)
                .success(
                    function(data, status) {
                        $rootScope.user = data;
                        $scope.user = angular.copy(data);
                        $state.go('dealer');
                    }).error(
                    function(data, status,
                        config) {});
        }


        $scope.navigateToFavorites = function(isFavorite) {
            if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                if (isFavorite) {
                    $rootScope.activeProfileIndex = 1;
                } else {
                    $rootScope.activeProfileIndex = 0;
                }
                $state.go('profile');
            } else {
                notificationService.errorNotification($rootScope.messages.PLEASE_LOGIN_TO_CONTINUE);
            }
        };
        $scope.initData = true;
        $scope.clearFilters = function() {
            if (!$scope.initData) {
                $rootScope.filterList = [];
                $rootScope.searchJson = {
                		"languageId": $rootScope.languageId
                };
            } else {
                $scope.initData = false;
            }
        };

        $rootScope.$watch('languageId', function() {
            if ($rootScope.user.userId != undefined && $rootScope.user.userId != null) {
                if ($rootScope.user.dealerId != null) {
                    indexService
                        .getUserLocalInfoById($rootScope.user.userId, $rootScope.languageId)
                        .success(
                            function(data, status) {
                                $rootScope.user = data;
                                $scope.loggedinUser = angular.copy(data);
                            }).error(
                            function(data, status,
                                config) {});
                } else {
                    var languageId = 100;
                    indexService
                        .getUserLocalInfoById($rootScope.user.userId, languageId)
                        .success(
                            function(data, status) {
                                $rootScope.user = data;
                                $scope.loggedinUser = angular.copy(data);
                            }).error(
                            function(data, status,
                                config) {});
                }
            }
            $scope.clearFilters();
        });




        (function() {
            $scope.getFavioriteCarIds();
            $scope.getViewedCarIds();
        })();

    }]);
});