define(['./module'], function (controllers) {
    'use strict';
    controllers.controller('dealerloginController', ['$scope', '$http', '$rootScope', 'authenticationService', '$state', 'notificationService', 'indexService', 'alertCarsService', function ($scope, $http, $rootScope, authenticationService, $state, notificationService, indexService, alertCarsService) {

        $scope.isSaving = false;

        $scope.isActiveUser = true;

        $scope.login = {
            userName: "",
            eMail: "",
            password: ""
        };
        
        $scope.resetInput = function () {
           
            $scope.login = {
                userName: "",
                eMail: "",
                password: ""
            };

        }

        $scope.loginUser = function () {
            $scope.isSaving = true;
            authenticationService
                .loginUser($scope.login)
                .success(
                    function (data, status) {
                        $scope.isSaving = false;
                        if (data.userId != null && data.userStatus != -1 && data.dealerId != null) {
                            $rootScope.user = data;
                            if ($rootScope.alertInfo != undefined && $rootScope.alertInfo != null && $rootScope.user.eMail == $rootScope.alertInfo.email) {
                                $rootScope.alertInfo.userId = $rootScope.user.userId;
                                alertCarsService
                                    .saveAlert($rootScope.alertInfo)
                                    .success(
                                        function (data, status) {
                                            $scope.resetInput();
                                            notificationService.infoNotification($rootScope.messages.ALERT_SAVED_SUCCESSFULLY);
                                            $rootScope.alertInfo = null;
                                            $state.go('profile');
                                        }).error(
                                        function (data, status,
                                            config) {
                                            notificationService.errorNotification(data.message);
                                        });
                            }
                            else {
                                $rootScope.user = data;
                                $scope.getUserLocalInfoById($rootScope.user.userId, $rootScope.languageId);
                                $state.go('index')
                            }
                            
                        } else if (data.userId == null) {
                            notificationService.errorNotification($rootScope.messages.PLEASE_CHECK_YOUR_EMAIL_AND_PASSWORD);
                        } else if (data.userId != null && data.userStatus == -1) {
                            $scope.isActiveUser = false;
                        } else if (data.dealerId == null) {
                            notificationService.errorNotification($rootScope.messages.PLEASE_LOGIN_IN_INDIVIDUAL_PAGE);
                        } else {
                            $rootScope.user = data;
                            $scope.getUserLocalInfoById($rootScope.user.userId, $rootScope.languageId);
                            $state.go('index')
                        }
                    }).error(
                    function (data, status,
                        config) {
                        notificationService.errorNotification(data.message);
                        $scope.isSaving = false;
                    });
        };

        $scope.activeUser = function () {
            $scope.isSaving = true;
            if ($scope.newPassword == $scope.confirmPassword) {
                var userJson = {
                    "userName": $scope.login.userName,
                    "eMail": $scope.login.eMail,
                    "password": $scope.confirmPassword
                };
                authenticationService
                    .activeUser(userJson)
                    .success(
                        function (data, status) {
                            $scope.isActiveUser = true;
                            $scope.isSaving = false;
                            notificationService.infoNotification($rootScope.messages.PLEASE_LOGIN_TO_CONTINUE);
                            // $scope.getUserLocalInfoById();
                            $state.go('dealerLogin');
                        }
                    )
                    .error(
                        function (data, status, config) {
                            notificationService.errorNotification($rootScope.messages.ERROR_WHILE_UPDATING_PASSWORD_PLEASE_TRY_AGAIN);
                            $scope.isSaving = true;
                        }
                    )
            }
        };

        $scope.getUserLocalInfoById = function () {
            indexService
                .getUserLocalInfoById($rootScope.user.userId, $rootScope.languageId)
                .success(
                    function (data, status) {
                        $rootScope.user = data;
                    }).error(
                    function (data, status,
                        config) {});
        };

    }]);
});