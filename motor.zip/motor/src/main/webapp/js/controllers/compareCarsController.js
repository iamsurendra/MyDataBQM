define(['./module'], function(controllers) {
    'use strict';
    controllers.controller('compareCarsController', ['$scope', '$http', '$state', '$rootScope', 'resultsService', 'notificationService', function($scope, $http, $state, $rootScope, resultsService, notificationService) {

        $scope.compareCarList = [];

        $scope.addToCompare = function(carId) {
            var userId = $rootScope.user.userId;
            var index = $rootScope.compareCarIdList.indexOf(carId);

            if (index != -1) {
                $rootScope.compareCarIdList.splice(index, 1);
                $scope.getCompareList();
            } else {
                if ($rootScope.compareCarIdList.length < 3) {
                    $rootScope.compareCarIdList.push(carId);
                    $scope.getCompareList();
                } else {
                    notificationService.errorNotification($rootScope.messages.MAX_COMPARE_CARS_REACHED);
                }
            }


        };
        $scope.getCompareList = function() {
            if ($rootScope.compareCarIdList.length > 0) {
            	var carDetailsView = {
            			"carIds": $rootScope.compareCarIdList,
            			"languageId": $rootScope.languageId
            	} 
                resultsService
                    .getCompareList(carDetailsView)
                    .success(
                        function(data, status) {
                            $scope.compareCarList = data;
                        }).error(
                        function(data, status,
                            config) {});
            } else {
                $state.go('result');
            }

        };

        $scope.range = function() {
            var length = 3 - $scope.compareCarIdList.length;
            return new Array(length);
        };

        (function() {
            $scope.getCompareList();
        })();

    }]);
});