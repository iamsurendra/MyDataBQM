define(['./module'], function (controllers) {
    'use strict';
    controllers.controller('adChoicesController', ['$scope', '$http', '$rootScope', function ($scope, $http, $rootScope) {

        $scope.adChoicesList = [{
            label: "Become A Dealer",
            value: "Become A Dealer"
        }, {
            label: "Contact Information",
            value: "Contact Information"
        }, {
            label: "Dealer Access Issues",
            value: "Dealer Access Issues"
        }, {
            label: "General Contact",
            value: "General Contact"
        }, {
            label: "Report A Problem",
            value: "Report A Problem"
        }, {
            label: "Website Feedback",
            value: "Website Feedback"
        }
        ];

        $scope.provinceList = [{
            label: "Kabul",
            value: "Kabul"
        },
        {
            label: "Kandahar",
            value: "Kandahar"
        }, {
            label: "Herat",
            value: "Herat"
        }, {
            label: "Mazar-i-Sharif ",
            value: "Mazar-i-Sharif "
        }, {
            label: "Kunduz",
            value: "Kunduz"
        }, {
            label: "Jalalabad",
            value: "Jalalabad"
        }, {
            label: "Lashkar Gah",
            value: "Lashkar Gah"
        }, {
            label: "Taluqan",
            value: "Taluqan"
        }, {
            label: "Puli Khumri",
            value: "Puli Khumri"
        }
        ];

        $scope.adChoices = {
            "selectReason": "",
            "firstName": "",
            "email": "",
            "phone": "",
            "city": "",
            "province": "",
            "zipCode": "",
            "comments": ""
        }



        $scope.sendAdchoices = function () {
            var adChoices = {
                "selectReason": $scope.adChoices.selectReason != undefined ? $scope.adChoices.selectReason.value : null,
                "firstName": $scope.adChoices.firstName,
                "email": $scope.adChoices.email,
                "phone": $scope.adChoices.phone,
                "city": $scope.adChoices.city,
                "province": $scope.adChoices.province != undefined ? $scope.adChoices.province.value : null,
                "zipCode": $scope.adChoices.zipCode,
                "comments": $scope.adChoices.comments,
            }
            console.log(adChoices);
        }
    }]);
});