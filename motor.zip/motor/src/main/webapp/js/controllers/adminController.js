define(['./module'], function (controllers) {
    'use strict';
    controllers.controller('adminController', ['$scope', '$http', '$rootScope', 'authenticationService', '$state', 'notificationService', function ($scope, $http, $rootScope, authenticationService, $state, notificationService) {
        if ($rootScope.user.admin != true || $rootScope.user.userId == null) {
            $state.go('index');
        } else {

            $scope.usersList = [];
            $scope.provinceList = [];
            $scope.cityAreaList = [];
            $scope.isSaving = false;
            $scope.isEdit = false;
            $scope.createDealer = false;

            $scope.openDealer = function () {
                $scope.createDealer = true;
                $scope.isEdit = false;
                $scope.clearFields();
            }

            $scope.showDealers = function () {
                $scope.createDealer = false;
                $scope.isEdit = false;
                $scope.clearFields();
            }

            $scope.clearFields = function () {
                $scope.dealer = {
                    "cityAreaId": "",
                    "provinceId": "",
                    "eMail": "",
                    "phoneNo": "",
                    "newPhoneNumber": "",
                    "dealeru": {
                        "id": "",
                        "regNo": "",
                        "maxVehicles": "",
                        "dealerLocaleDetails": [{
                                "name": "",
                                "languageId": 100
                            }, {
                                "name": "",
                                "languageId": 101
                            }, {
                                "name": "",
                                "languageId": 102
                            }

                        ]
                    },
                    "userLocaleDetails": [{
                            "id": "",
                            "languageId": 100,
                            "firstName": "",
                            "lastName": "",
                            "address": "",
                            // "dealerName": ""
                        },
                        {
                            "id": "",
                            "languageId": 101,
                            "firstName": "",
                            "lastName": "",
                            "address": "",
                            // "dealerName": ""
                        },
                        {
                            "id": "",
                            "languageId": 102,
                            "firstName": "",
                            "lastName": "",
                            "address": "",
                            // "dealerName": ""
                        }
                    ]
                };
            }


            $scope.dealer = {
                "userId": "",
                "dealerId": "",
                "cityAreaId": "",
                "provinceId": "",
                "eMail": "",
                "password": "",
                "confirmPassword": "",
                "phoneNo": "",
                "newPhoneNumber": "",
                "dealeru": {
                    "id": "",
                    "regNo": "",
                    "maxVehicles": "",
                    "dealerLocaleDetails": [{
                            "name": "",
                            "languageId": 100
                        }, {
                            "name": "",
                            "languageId": 101
                        }, {
                            "name": "",
                            "languageId": 102
                        }

                    ]
                },
                "userLocaleDetails": [{
                        "id": "",
                        "languageId": 100,
                        "firstName": "",
                        "lastName": "",
                        "address": "",
                        // "dealerName": ""
                    },
                    {
                        "id": "",
                        "languageId": 101,
                        "firstName": "",
                        "lastName": "",
                        "address": "",
                        // "dealerName": ""
                    },
                    {
                        "id": "",
                        "languageId": 102,
                        "firstName": "",
                        "lastName": "",
                        "address": "",
                        // "dealerName": ""
                    }
                ]
            }

            $scope.registerUser = function () {
                if ($scope.dealer.password == $scope.dealer.confirmPassword) {
                    authenticationService
                        .signUpUser($scope.dealer)
                        .success(
                            function (data, status) {
                                $scope.createDealer = false;
                                $scope.clearFields();
                                notificationService.infoNotification($rootScope.messages.DEALER_ACCOUNT_CREATED_SUCCESSFULLY);
                                $scope.getAllEnglishDetailsUsers();
                            }
                        ).error(
                            function (data, status, config) {
                                notificationService.errorNotification(data.message);
                            }
                        )
                } else {
                    notificationService.errorNotification($rootScope.messages.PASSWORD_AND_CONFIRM_PASSWORD_DOESNT_MATCH);
                }
            }


            $scope.editDealerDetailsByAdmin = function (userId) {
                $scope.createDealer = true;
                $scope.isEdit = true;
                authenticationService
                    .updateUserObjectByUserId(userId)
                    .success(
                        function (data, status) {
                            $scope.dealer = data;
                            $scope.isEdit = true;
                            $scope.getAreaCityByProvinceId();
                            $scope.disableRequiredFileds();
                        }).error(
                        function (data, status,
                            config) {});
            }

            $scope.disableRequiredFileds = function () {
                $scope.isEdit = true
            }

            $scope.updateUser = function () {
                authenticationService
                    .updateUser($scope.dealer)
                    .success(
                        function (data, status) {
                            $scope.createDealer = false;
                            $scope.getAllEnglishDetailsUsers();
                            notificationService.infoNotification($rootScope.messages.DEALER_ACCOUNT_UPDATED_SUCCESSFULLY);
                        }).error(
                        function (data, status,
                            config) {
                            notificationService.infoNotification($rootScope.messages.ERROR_PLEAE_TRY_AGAIN);
                        });
            }

            $scope.activateOrDeactivateUser = function (userId) {
                authenticationService
                    .activateOrDeactivateUser(userId)
                    .success(
                        function (data, status) {
                            $scope.getAllEnglishDetailsUsers();
                        }).error(
                        function (data, status,
                            config) {
                            notificationService.infoNotification($rootScope.messages.ERROR_PLEAE_TRY_AGAIN);
                        });
            }

            $scope.getAllEnglishDetailsUsers = function () {
                authenticationService
                    .getAllEnglishDetailsUsers()
                    .success(
                        function (data, status) {
                            angular.forEach(data, function (user) {
                                user.dealerOrInDividualStatus = user.dealerId == null ? $rootScope.labels.INDIVIDUAL : $rootScope.labels.DEALER;
                                user.userFullName = (user.firstName != null ? user.firstName : "") + " " + (user.lastName != null ? user.lastName : "");
                                user.maxVehicles = user.maxVehicles == null ? 1 : user.maxVehicles;
                            });
                            $scope.usersList = data;
                        }).error(
                        function (data, status,
                            config) {});
            };


            $scope.findAllProvinceDetails = function () {
                authenticationService
                    .findAllProvinceDetails()
                    .success(
                        function (data, status) {
                            data.forEach(function (element) {
                                $scope.provinceList.push({
                                    "id": element.id,
                                    "label": element.name,
                                    "labelDari": element.nameDari,
                                    "value": element.id
                                });

                            });
                        }).error(
                        function (data, status,
                            config) {});
            }


            $scope.getAreaCityByProvinceId = function () {
                $scope.location = null;
                $scope.cityAreaList = [];
                var provinceId = $scope.dealer.provinceId;
                authenticationService
                    .getAreaCityByProvinceId(provinceId)
                    .success(
                        function (data, status) {
                            data.forEach(function (element) {
                                $scope.cityAreaList.push({
                                    "id": element.id,
                                    "cityAreaId": element.id,
                                    "label": element.cityArea,
                                    "labelDari": element.cityAreaDari,
                                    "value": element.id
                                });

                            });
                        }).error(
                        function (data, status,
                            config) {});
            };

            (function () {
                $scope.getAllEnglishDetailsUsers();
                $scope.findAllProvinceDetails();
            })();
        }
    }]);
});