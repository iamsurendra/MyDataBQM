define(['./module'], function (controllers) {
    'use strict';
    controllers.controller('editDelearCarController', ['$scope', '$http', '$timeout', '$state', '$stateParams', '$rootScope', 'indexService', 'dealerCarsService', 'notificationService', 'singleCarService', '$anchorScroll', '$q', function ($scope, $http, $timeout, $state, $stateParams, $rootScope, indexService, dealerCarsService, notificationService, singleCarService, $anchorScroll, $q) {

        if ($rootScope.user.userId == undefined || $rootScope.user.userId == null) {
            notificationService.errorNotification($rootScope.messages.PLEASE_LOGIN_TO_CONTINUE);
            $state.go('index');
        } else {
            $scope.carObj = {
                "carId": JSON.parse($state.params.id),
                "userId": $rootScope.user.userId
            };

            $anchorScroll.yOffset = 80;

            $scope.newCar = true;
            $scope.dropSupported = true;

            $scope.makeList = [];
            $scope.modelList = [];
            $scope.colorsList = [];
            $scope.seatingTypeList = [];
            $scope.ccList = [];
            $scope.bhpList = [];
            $scope.tankCapacityList = [];

            $scope.selectedFeatures = [];

            $scope.isSaving = false;
            $scope.isElectric = false;

            $scope.disableIfElectric = function () {
                if ($scope.selectedFuelType.value == 'Electric') {
                    $scope.isElectric = true;
                    $scope.selectedCC = '';
                    $scope.selectedBHP = '';
                    $scope.tankCapacity = '';
                    $scope.selectedTransmission = '';
                    $scope.selectedCylinder = '';
                } else {
                    $scope.isElectric = false;
                }
            }

            $scope.getMakeData = function () {
                $scope.bodyType = null;
                indexService
                    .getMakeData()
                    .success(
                        function (data, status) {
                            data.forEach(function (element) {
                                $scope.makeList.push({
                                    "label": element,
                                    "value": element
                                });
                            });

                            if (!$scope.modelInit) {
                                $scope.initMakeModeldata();
                            }

                        }).error(
                        function (data, status,
                            config) {});
            };

            $scope.getColorsData = function () {
                dealerCarsService
                    .getColorsData()
                    .success(
                        function (data, status) {
                            data.forEach(function (element) {
                                $scope.colorsList.push({
                                    "label": "<i class=\"fa fa-square fa-2x\" aria-hidden=\"true\" style=\"color:" + element.name + "!important\"></i><span class=\"color-option-text\">" + element.name + "</span>",
                                    "value": element.id
                                });
                            });

                            if ($scope.carObj['color'] != undefined) {
                                var index = $scope.findWithAttr($scope.colorsList, 'value', $scope.carObj['color']);
                                $scope.carColor = $scope.colorsList[index];
                            }

                            if ($scope.carObj.carInterior['color'] != undefined) {
                                var index = $scope.findWithAttr($scope.colorsList, 'value', $scope.carObj.carInterior['color']);
                                $scope.carInterirorColor = $scope.colorsList[index];
                            }

                        }).error(
                        function (data, status,
                            config) {});
            };

            $scope.getSeatingInfo = function () {
                dealerCarsService
                    .getSeatingInfo()
                    .success(
                        function (data, status) {
                            data.forEach(function (element) {
                                $scope.seatingTypeList.push({
                                    "label": element.name,
                                    "value": element.id
                                });

                                if ($scope.carObj['seatingId'] != undefined) {
                                    var index = $scope.findWithAttr($scope.seatingTypeList, 'value', $scope.carObj['seatingId']);
                                    $scope.selectedSeating = $scope.seatingTypeList[index];
                                }
                            });
                        }).error(
                        function (data, status,
                            config) {});
            };


            // get engine cc list
            $scope.getEngineCC = function () {
                dealerCarsService
                    .getEngineccInfo()
                    .success(
                        function (data, status) {
                            data.forEach(function (element) {
                                $scope.ccList.push({
                                    "label": element.name,
                                    "value": element.id
                                });
                            });

                            if ($scope.carObj.carEngineDetails['ccId'] != undefined) {
                                var index = $scope.findWithAttr($scope.ccList, 'value', $scope.carObj.carEngineDetails['ccId']);
                                $scope.selectedCC = $scope.ccList[index];
                            }

                        }).error(
                        function (data, status,
                            config) {});
            };

            // get engine bhp list
            $scope.getEngineBhp = function () {
                dealerCarsService
                    .getEngineBhpInfo()
                    .success(
                        function (data, status) {
                            data.forEach(function (element) {
                                $scope.bhpList.push({
                                    "label": element.name,
                                    "value": element.id
                                });
                            });
                            if ($scope.carObj.carEngineDetails['bhpId'] != undefined) {
                                var index = $scope.findWithAttr($scope.bhpList, 'value', $scope.carObj.carEngineDetails['bhpId']);
                                $scope.selectedBHP = $scope.bhpList[index];
                            }
                        }).error(
                        function (data, status,
                            config) {});
            };

            // get tank capacity list
            $scope.getTankCapacity = function () {
                dealerCarsService
                    .getTankCapacity()
                    .success(
                        function (data, status) {
                            data.forEach(function (element) {
                                $scope.tankCapacityList.push({
                                    "label": element,
                                    "value": element
                                });
                            });

                            if ($scope.carObj['tankCapacity'] != undefined) {
                                var index = $scope.findWithAttr($scope.tankCapacityList, 'value', $scope.carObj['tankCapacity']);
                                $scope.tankCapacity = $scope.tankCapacityList[index];
                            }

                        }).error(
                        function (data, status,
                            config) {});
            };

            $scope.modelInit = false;
            $scope.modelName = null;

            $scope.initMakeModeldata = function () {
                dealerCarsService
                    .getMakeInfoByid($scope.carObj.makeId)
                    .success(
                        function (data, status) {
                            var makeIndex = $scope.findWithAttr($scope.makeList, 'value', data.name);
                            if (makeIndex != undefined) {
                                $scope.selectedMake = $scope.makeList[makeIndex];
                            }
                            $scope.modelName = data.model;
                            $scope.bodyTypeName = data.bodyType;
                            $scope.getModelDataByMakeName();

                        }).error(
                        function (data, status,
                            config) {});
            }

            $scope.getModelDataByMakeName = function () {
                // resetting the model value and model list
                $scope.selectedModel = null;
                $scope.bodyType = null;
                $scope.modelList = [];

                //getting the selected make


                var make = $scope.selectedMake != undefined ? $scope.selectedMake.value : null;
                // get model list
                if (make != null) {
                    indexService
                        .getModelDataByMakeName(make)
                        .success(
                            function (data, status) {
                                data.forEach(function (element) {
                                    $scope.modelList.push({
                                        "label": element,
                                        "value": element
                                    });
                                });

                                if (!$scope.modelInit) {
                                    var modelIndex = $scope.findWithAttr($scope.modelList, 'value', $scope.modelName);
                                    if (modelIndex != undefined) {
                                        $scope.selectedModel = $scope.modelList[modelIndex];
                                        $scope.getBodyStyleByMakeModel();
                                    }
                                }


                            }).error(
                            function (data, status,
                                config) {});
                }
            };

            $scope.bodyStyleList = [];

            //getBodyStyleByMakeModel
            $scope.getBodyStyleByMakeModel = function () {

                $scope.bodyType = null;
                $scope.bodyStyleList = [];

                var make = $scope.selectedMake != undefined ? $scope.selectedMake.value : null;
                var model = $scope.selectedModel != undefined ? $scope.selectedModel.value : null;
                if (model != null) {
                    dealerCarsService
                        .getBodyStyleByMakeModel(make, model)
                        .success(
                            function (data, status) {
                                data.forEach(function (element) {
                                    var idx = $scope.findWithAttr($scope.bodyStyleList, 'value', element);
                                    if (idx == undefined) {
                                        $scope.bodyStyleList.push({
                                            "label": element,
                                            "value": element
                                        });
                                    }
                                });

                                if (!$scope.modelInit) {
                                    var index = $scope.findWithAttr($scope.bodyStyleList, 'value', $scope.bodyTypeName);
                                    $scope.bodyType = $scope.bodyStyleList[index];
                                    $scope.getMakeId();
                                    $scope.modelInit = true;
                                }

                            }).error(
                            function (data, status,
                                config) {});
                }
            };


            $scope.certifiedCheckList = [{
                label: 'Certified Car',
                value: true
            }, {
                label: 'Non-Certified Car',
                value: false
            }];


            $scope.steeringList = [{
                label: 'Left Hand Drive',
                value: true
            }, {
                label: 'Right Hand Drive',
                value: false
            }];

            $scope.yearList = [{
                label: '2018',
                value: 2018
            }, {
                label: '2017',
                value: 2017
            }, {
                label: '2016',
                value: 2016
            }, {
                label: '2015',
                value: 2015
            }, {
                label: '2014',
                value: 2014
            }, {
                label: '2013',
                value: 2013
            }, {
                label: '2012',
                value: 2012
            }, {
                label: '2011',
                value: 2011
            }, {
                label: '2010',
                value: 2010
            }, {
                label: '2009',
                value: 2009
            }, {
                label: '2008',
                value: 2008
            }, {
                label: '2007',
                value: 2007
            }, {
                label: '2006',
                value: 2006
            }, {
                label: '2005',
                value: 2005
            }, {
                label: '2004',
                value: 2004
            }, {
                label: '2003',
                value: 2003
            }, {
                label: '2002',
                value: 2002
            }, {
                label: '2001',
                value: 2001
            }, {
                label: '2000',
                value: 2000
            }, {
                label: '1999',
                value: 1999
            }, {
                label: '1998',
                value: 1998
            }, {
                label: '1997',
                value: 1997
            }, {
                label: '1996',
                value: 1996
            }, {
                label: '1995',
                value: 1995
            }, {
                label: '1994',
                value: 1994
            }, {
                label: '1993',
                value: 1993
            }, {
                label: '1992',
                value: 1992
            }, {
                label: '1991',
                value: 1991
            }, {
                label: '1990',
                value: 1990
            }];

            $scope.trimList = [{
                label: "Base",
                value: "Base"
            }, {
                label: "Mid",
                value: "Mid"
            }, {
                label: "High-End",
                value: "High-End"
            }]

            $scope.transmissionList = [{
                "label": "Automatic",
                "value": "Automatic"
            }, {
                "label": "Manual",
                "value": "Manual"
            }, {
                "label": "Semi-Automatic",
                "value": "Semi-Automatic"
            }];

            $scope.cylindersTypeList = [{
                "label": "4 Cylinders",
                "value": 4
            }, {

                "label": "5 Cylinders",
                "value": 5
            }, {
                "label": "6 Cylinders",
                "value": 6
            }, {
                "label": "8 Cylinders",
                "value": 8
            }];

            $scope.fuelTypeList = [{
                "label": "PETROL",
                "value": "Petrol"
            }, {
                "label": "DIESEL",
                "value": "Diesel"
            }, {
                "label": "ELECTRIC",
                "value": "Electric"
            }, {
                "label": "HYBRID",
                "value": "Hybrid"
            }, {
                "label": "LPG",
                "value": "Lpg"
            }];

            $scope.transmissionList = [{
                "label": "Automatic",
                "value": "Automatic"
            }, {
                "label": "Manual",
                "value": "Manual"
            }, {
                "label": "Semi-Automatic",
                "value": "Semi-Automatic"
            }];

            $scope.featuresList = [{
                "label": "AC_FRONT",
                "value": "acFront",
            }, {
                "label": "AC_REAR",
                "value": "acRear"
            }, {
                "label": "CRUISE_CONTROL",
                "value": "cruiseControl"
            }, {
                "label": "NAVIGATION",
                "value": "navigation"
            }, {
                "label": "POWER_LOCKS",
                "value": "powerLocks"
            }, {
                "label": "POWER_STEERING",
                "value": "powerSteering"
            }, {
                "label": "KEYLESS_ENTRY",
                "value": "keylessEntry"
            }, {
                "label": "INTEGRATED_PHONE",
                "value": "integratedPhone"
            }, {
                "label": "KEYLESS_START",
                "value": "keyLessStart"
            }, {
                "label": "BUCKET_SEAT",
                "value": "bucketSeat"
            }, {
                "label": "LEATHER_SEATS",
                "value": "leatherSeats"
            }, {
                "label": "MEMORY_SEATS",
                "value": "memorySeats"
            }, {
                "label": "POWER_SEATS",
                "value": "powerSeats"
            }, {
                "label": "AIRBAG_DRIVER",
                "value": "airbagDriver"
            }, {
                "label": "AIRBAG_PASSENGER",
                "value": "airbagPassenger"
            }, {
                "label": "AIRBAG_SIDE",
                "value": "airbagSide"
            }, {
                "label": "ALARM",
                "value": "alarm"
            }, {
                "label": "ANTI_LOCK_BRAKES",
                "value": "antiLockBrakes"
            }, {
                "label": "FOG_LIGHTS",
                "value": "fogLights"
            }, {
                "label": "POWER_WINDOWS",
                "value": "powerWindows"
            }, {
                "label": "REAR_WINDOW_DEFROSTER",
                "value": "rearWindowDefroster"
            }, {
                "label": "REAR_WINDOW_WIPER",
                "value": "rearWindowWiper"
            }, {
                "label": "TINTED_GLASS",
                "value": "tintedGlass"
            }, {
                "label": "FM_STEREO",
                "value": "fmStereo"
            }, {
                "label": "CASSETTE_PLAYER",
                "value": "cassettePlayer"
            }, {
                "label": "CD_SINGLE_DISC",
                "value": "cdSingleDisc"
            }, {
                "label": "CD_MULTI_DISC",
                "value": "cdMultiDisc"
            }, {
                "label": "MP3_SINGLE_DISC",
                "value": "mp3SingleDisc"
            }, {
                "label": "PREMIUM_SOUND",
                "value": "premiumSound"
            }, {
                "label": "DVD_SYSTEM",
                "value": "dvdSystem"
            }, {
                "label": "BACKUP_CAMERA",
                "value": "backUpCamera"
            }, {
                "label": "ALLOY_WHEELS",
                "value": "alloyWheels"
            }, {
                "label": "MOONROOF_SUNROOF",
                "value": "moonroofSunroof"
            }, {
                "label": "THIRD_ROW_SEATS",
                "value": "thirdRowSeats"
            }];

            $scope.driveTypeList = [{
                "label": "FWD",
                "value": "FWD"
            }, {
                "label": "RWD",
                "value": "RWD"
            }, {
                "label": "AWD",
                "value": "AWD"
            }, {
                "label": "4X4",
                "value": "4X4"
            }];

            $scope.validatePrice = function () {
                var isReducedPrice = $scope.reducedPrice != undefined ? true : false;
                if (isReducedPrice) {
                    if (parseInt($scope.price) < parseInt($scope.reducedPrice)) {
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    $scope.reducedPrice = null;
                    return true;
                }
            };
            $scope.getMakeId = function () {

                var make = $scope.selectedMake != undefined ? $scope.selectedMake.value : null;
                var model = $scope.selectedModel != undefined ? $scope.selectedModel.value : null;
                var bodyType = $scope.bodyType != undefined ? $scope.bodyType.value : null;

                if (model != null) {
                    dealerCarsService
                        .getMakeIdByName(make, model, bodyType)
                        .success(
                            function (data, status) {
                                $scope.makeId = data;
                            }).error(
                            function (data, status,
                                config) {});
                }


            };

            $scope.saveCarInfo = function () {

                var carInterior = {};

                carInterior["id"] = $scope.carObj.id;
                carInterior["color"] = $scope.carInterirorColor != undefined ? $scope.carInterirorColor.value : null;

                angular.forEach($scope.featuresList, function (element) {
                    if ($scope.selectedFeatures.indexOf(element.value) != -1) {
                        this[element.value] = true;
                    } else {
                        this[element.value] = false;
                    }
                }, carInterior);

                var carJson = {
                    "id": $scope.carObj.id,
                    "userId": $scope.carObj.userId,
                    "vin": $scope.vin,
                    "newCar": $scope.newCar,
                    "makeId": $scope.makeId,
                    "year": $scope.selectedYear != undefined ? $scope.selectedYear.value : null,
                    "price": $scope.price,
                    "mileage": $scope.mileage,
                    "tankCapacity": $scope.tankCapacity != undefined ? $scope.tankCapacity.value : null,
                    "reducedPrice": $scope.reducedPrice,
                    "description": $scope.description,
                    "color": $scope.carColor != undefined ? $scope.carColor.value : null,
                    "seatingId": $scope.selectedSeating != undefined ? $scope.selectedSeating.value : null,
                    "drivingSeat": $scope.drivingSeat != undefined ? $scope.drivingSeat.value : null,
                    "carInterior": carInterior,
                    "certified": $scope.certified != undefined ? $scope.certified.value : null,
                    "bodyType": $scope.bodyType != undefined ? $scope.bodyType.value : null,
                    "carEngineDetails": {
                        "id": $scope.carObj.id,
                        "ccId": $scope.selectedCC != undefined ? $scope.selectedCC.value : null,
                        "bhpId": $scope.selectedBHP != undefined ? $scope.selectedBHP.value : null,
                        "fuelType": $scope.selectedFuelType != undefined ? $scope.selectedFuelType.value : null,
                        "transmission": $scope.selectedTransmission != undefined ? $scope.selectedTransmission.value : null,
                        "noOfCylinder": $scope.selectedCylinder != undefined ? $scope.selectedCylinder.value : null,
                        "driveType": $scope.selectedDriveType != undefined ? $scope.selectedDriveType.value : null,
                    }
                };

                dealerCarsService
                    .saveCarInfo(carJson)
                    .success(
                        function (data, status) {
                            // $timeout(function () {
                            $scope.isSaving = false;
                            notificationService.successNotification($rootScope.messages.CAR_INFORMATION_SAVED_SUCCESSFULLY);
                            $state.go('singleCar', {
                                id: $scope.carObj.id
                            });
                            // }, 3000);
                        }).error(
                        function (data, status,
                            config) {
                            $scope.isSaving = false;
                            if (data.message != undefined) {
                                notificationService.errorNotification(data.message);
                            } else {
                                notificationService.errorNotification($rootScope.messages.ERROR_WHILE_SAVING_CAR_INFORMATION);
                            }
                        });

            };

            $scope.findWithAttr = function (array, attr,
                value) {
                for (var i = 0; i < array.length; i += 1) {
                    if (array[i][attr] === value) {
                        return i;
                    }
                }
            };

            $scope.initDetails = function (data) {
                var carObj = data;
                $scope.newCar = carObj.newCar;
                $scope.vin = carObj.vin;
                $scope.price = carObj.price;
                $scope.reducedPrice = carObj.reducedPrice;
                $scope.mileage = carObj.mileage;
                $scope.description = carObj.description;

                if ($rootScope.user.dealerId == null) {
                    $scope.pageHeader = "USER_CAR_PAGE";
                    $scope.pageHeader1 = "EDIT_USER_CAR";
                } else {
                    $scope.pageHeader = "DEALER_CAR_PAGE";
                    $scope.pageHeader1 = "EDIT_DEALER_CAR";
                }
                if (carObj['year'] != undefined) {
                    var index = $scope.findWithAttr($scope.yearList, 'value', carObj['year']);
                    $scope.selectedYear = $scope.yearList[index];
                }
                if (carObj.carEngineDetails['fuelType'] != undefined) {
                    var index = $scope.findWithAttr($scope.fuelTypeList, 'value', carObj.carEngineDetails['fuelType']);
                    $scope.selectedFuelType = $scope.fuelTypeList[index];
                }
                if (carObj.carEngineDetails['transmission'] != undefined) {
                    var index = $scope.findWithAttr($scope.transmissionList, 'value', carObj.carEngineDetails['transmission']);
                    $scope.selectedTransmission = $scope.transmissionList[index];
                }
                if (carObj.carEngineDetails['fuelType'] == 'Electric') {
                    $scope.disableIfElectric();
                }
                if (carObj.carEngineDetails['noOfCylinder'] != undefined) {
                    var index = $scope.findWithAttr($scope.cylindersTypeList, 'value', parseInt(carObj.carEngineDetails['noOfCylinder']));
                    $scope.selectedCylinder = $scope.cylindersTypeList[index];
                }
                if (carObj.carEngineDetails['driveType'] != undefined) {
                    var index = $scope.findWithAttr($scope.driveTypeList, 'value', carObj.carEngineDetails['driveType']);
                    $scope.selectedDriveType = $scope.driveTypeList[index];
                }
                if (carObj['color'] != undefined) {
                    var index = $scope.findWithAttr($scope.colorsList, 'value', carObj['color']);
                    $scope.carColor = $scope.colorsList[index];
                }

                if (carObj.carInterior['color'] != undefined) {
                    var index = $scope.findWithAttr($scope.colorsList, 'value', carObj.carInterior['color']);
                    $scope.carInterirorColor = $scope.colorsList[index];
                }
                if (carObj.carEngineDetails['ccId'] != undefined) {
                    var index = $scope.findWithAttr($scope.ccList, 'value', carObj.carEngineDetails['ccId']);
                    $scope.selectedCC = $scope.ccList[index];
                }
                if (carObj.carEngineDetails['bhpId'] != undefined) {
                    var index = $scope.findWithAttr($scope.bhpList, 'value', carObj.carEngineDetails['bhpId']);
                    $scope.selectedBHP = $scope.bhpList[index];
                }
                if (carObj['seatingId'] != undefined) {
                    var index = $scope.findWithAttr($scope.seatingTypeList, 'value', carObj['seatingId']);
                    $scope.selectedSeating = $scope.seatingTypeList[index];
                }

                if (carObj['certified'] != undefined) {
                    var index = $scope.findWithAttr($scope.certifiedCheckList, 'value', carObj['certified']);
                    $scope.certified = $scope.certifiedCheckList[index];
                }

                if (carObj['drivingSeat'] != undefined) {
                    var index = $scope.findWithAttr($scope.steeringList, 'value', carObj['drivingSeat']);
                    $scope.drivingSeat = $scope.steeringList[index];
                }

                angular.forEach($scope.featuresList, function (element) {
                    if (carObj.carInterior[element.value] != undefined) {
                        if (carObj.carInterior[element.value]) {
                            $scope.selectedFeatures.push(element.value);
                        }
                    }
                });

                $scope.initMakeModeldata();


            };


            $scope.removeImage = function (profileName) {
                var profileObj = angular.copy($scope.imageList[profileName]);
                if ($scope.imageList[profileName].url != null && !$scope.imageList[profileName].first) {
                    $scope.imageList[profileName].url = null;
                    $scope.imageList[profileName].content = null;
                    dealerCarsService
                        .deleteProfileImage($scope.carObj.id, profileName)
                        .success(
                            function (data, status) {
                                $scope.imageList[profileName].url = null;
                                $scope.imageList[profileName].content = profileObj.content;
                            }).error(
                            function (data, status,
                                config) {
                                notificationService.errorNotification(data.message);

                            });
                };
                if ($scope.imageList[profileName].url != null && $scope.imageList[profileName].first) {
                    $scope.imageList[profileName].url = null;
                    $scope.imageList[profileName].content = null;
                }
            };

            $scope.imageDimensions = {
                width: 640,
                height: 480
            };

            $scope.$watch('imageList', function (newValues, oldValues, scope) {
                var firstImage = $scope.imageList['frontProfile'];
                if (firstImage.content != null || firstImage.url != null) {
                    angular.element('#frontProfile .card').first().removeClass("has-img-error");
                }
            });

            $scope.imageList = {
                "frontProfile": {
                    "content": null,
                    "first": true,
                    "url": null,
                    "label": "FRONT_PROFILE",
                    "profileImage": "img/upload_car_templates/Front_Profile.jpg"
                },
                "frontRightProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "FRONT_RIGHT_PROFILE",
                    "profileImage": "img/upload_car_templates/Front_Right_Profile.jpg"
                },
                "rightProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "RIGHT_PROFILE",
                    "profileImage": "img/upload_car_templates/Right_Profile.jpg"
                },
                "backLeftProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "BACK_LEFT_PROFILE",
                    "profileImage": "img/upload_car_templates/Back_Left_Profile.jpg"
                },
                "backProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "BACK_PROFILE",
                    "profileImage": "img/upload_car_templates/Back_Profile.jpg"
                },
                "backRightProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "BACK_RIGHT_PROFILE",
                    "profileImage": "img/upload_car_templates/Back_Right_Profile.jpg"
                },
                "leftProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "LEFT_PROFILE",
                    "profileImage": "img/upload_car_templates/Left_Profile.jpg"
                },
                "frontLeftProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "FRONT_LEFT_PROFILE",
                    "profileImage": "img/upload_car_templates/Front_Left_Profile.jpg"
                },
                "driverSideView": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "DRIVER_SIDE_VIEW",
                    "profileImage": "img/upload_car_templates/Driver_Side_View.jpg"
                },
                "driversDoorProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "DRIVERS_DOOR_PROFILE",
                    "profileImage": "img/upload_car_templates/Drivers_Door_Profile.jpg"
                },
                "roofProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "ROOF_PROFILE",
                    "profileImage": "img/upload_car_templates/Roof_Profile.jpg"
                },
                "passengerSideProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "PASSENGER_SIDE_PROFILE",
                    "profileImage": "img/upload_car_templates/Passenger_Side_Profile.jpg"
                },
                "dashboardView": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "DASHBOARD_VIEW",
                    "profileImage": "img/upload_car_templates/Dashboard_View.jpg"
                },
                "rearSeatsProfile": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "REAR_SEATS_PROFILE",
                    "profileImage": "img/upload_car_templates/Rear_Seats_Profile.jpg"
                },
                "engineView": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "ENGINE_VIEW",
                    "profileImage": "img/upload_car_templates/Engine_View.jpg"
                },
                "trunkView": {
                    "content": null,
                    "first": false,
                    "url": null,
                    "label": "TRUNK_VIEW",
                    "profileImage": "img/upload_car_templates/Trunk_View.jpg"
                }
            };


            $scope.getCarInfo = function () {
                dealerCarsService
                    .getCarInfo($scope.carObj.carId)
                    .success(
                        function (data, status) {
                            var imageData = data.images;
                            if (imageData.length > 0) {
                                angular.forEach(imageData, function (image, index) {
                                    var imageObj = $scope.imageList[image.profileName];
                                    imageObj.url = image.url;
                                    $scope.imageList[image.profileName] = imageObj;
                                });
                            }
                            $scope.carObj = data;
                            $scope.getMakeData();
                            $scope.getColorsData();
                            $scope.getSeatingInfo();
                            $scope.getEngineCC();
                            $scope.getEngineBhp();
                            $scope.getTankCapacity();
                            $scope.initDetails($scope.carObj);
                        }).error(
                        function (data, status,
                            config) {
                            $state.go('profile');
                        });

            };

            $scope.updateCarInfo = function () {


                var uploadUrl = $rootScope.serviceurl + '/image/upload';
                var firstImage = $scope.imageList['frontProfile'];


                var deferred = $q.defer();
                var urlCalls = [];

                if (firstImage.content != null || firstImage.url != null) {
                    $scope.isSaving = true;
                    angular.forEach($scope.imageList, function (value, key) {
                        if (value.content != null) {
                            var fd = new FormData();
                            fd.append('file', value.content);
                            urlCalls.push($http.post(uploadUrl, fd, {
                                transformRequest: angular.identity,
                                headers: {
                                    'Content-Type': undefined
                                },
                                params: {
                                    "carId": $scope.carObj.id,
                                    "first": value.first,
                                    "imageProfile": key
                                }
                            }));
                        }

                    });

                    $q.all(urlCalls)
                        .then(
                            function (results) {
                                deferred.resolve();
                                $timeout(function () {
                                    $scope.saveCarInfo();
                                }, 1000);
                            },
                            function (errors) {
                                $scope.isSaving = false;
                                deferred.reject(errors);
                                notificationService.errorNotification(errors.data.message);
                            })

                } else {
                    angular.element('#frontProfile .card').first().addClass("has-img-error");
                    $anchorScroll('frontProfile');
                }

            };

            (function () {
                $scope.getCarInfo();
            })();
        }
    }]);
});