define(['./module'], function(directives) {
    'use strict';
    directives.directive('placeHolder', [function() {
        return {
            restrict: 'A',
            link: function(scope, elem, attrs) {
                scope.$watch(attrs.placeHolder, function(newVal, oldVal) {
                    elem.attr('placeholder', newVal);
                });
            }
        };
    }]);
});
