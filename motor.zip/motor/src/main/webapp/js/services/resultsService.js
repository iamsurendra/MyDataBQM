define(['./module'], function (Services) {
    'use strict';
    Services.factory('resultsService', ['$http', '$rootScope', function ($http, $rootScope) {
        var serviceurl = $rootScope.serviceurl;
        var config = {
            headers: {
                'Content-Type': 'application/json'
            }
        };
        return {
            searchInfo: function (carJson) {
                var url = serviceurl + "/index/search";
                return $http.post(url, carJson, config);
            },
            addToFavorites: function (favorites) {
                var url = serviceurl + "/result/addToFavorites";
                return $http.post(url, favorites, config);
            },
            removeFromFavorites: function (favorites) {
                var url = serviceurl + "/result/removeFromFavorites";
                return $http.post(url, favorites, config);
            },
            getFavioriteCarIds: function (userId) {
                var url = serviceurl + "/result/findAllFavorites/" + userId;
                return $http.get(url);
            },
            getListofEngineCC: function () {
                var url = serviceurl + "/result/engineccList";
                return $http.get(url);
            },
            getFuelType: function () {
                var url = serviceurl + "/result/fueltype";
                return $http.get(url);
            },
            getEngineBhpList: function () {
                var url = serviceurl + "/result/engineBhp";
                return $http.get(url);
            },
            markFavioriteCar: function (src) {
                var srcList = src;
                if (angular.isArray(srcList)) {
                    angular.forEach(srcList, function (car) {
                        angular.merge(car, car, {
                            isFaviorite: false
                        });
                        angular.forEach($rootScope.favioriteCarIdList, function (favCar) {
                            if (car.id == favCar) {
                                car.isFaviorite = true;
                            }
                        });
                    });
                }
                return srcList;
            },

            markCompareCar: function (src) {
                var srcList = src;
                if (angular.isArray(srcList)) {
                    angular.forEach(srcList, function (car) {
                        angular.merge(car, car, {
                            isCompare: false
                        });
                        angular.forEach($rootScope.compareCarIdList, function (compareCar) {
                            if (car.id == compareCar) {
                                car.isCompare = true;
                            }
                        });
                    });
                }
                return srcList;
            },

            markViewedCar: function (src) {
                var srcList = src;
                if (angular.isArray(srcList)) {
                    angular.forEach(srcList, function (car) {
                        angular.merge(car, car, {
                            isViewed: false
                        });
                        angular.forEach($rootScope.viewedCarIdList, function (viewedCar) {
                            if (car.id == viewedCar) {
                                car.isViewed = true;
                            }
                        });
                    });
                }
                return srcList;
            },

            getFavoriteCars: function (carDetailsView) {
                var url = serviceurl + "/result/compare";
                return $http.post(url, carDetailsView, config);
            },
            getCompareList: function (carDetailsView) {
                var url = serviceurl + "/result/compare";
                return $http.post(url, carDetailsView, config);
            },
            getRecentlyViewedCars: function (carDetailsView) {
                var url = serviceurl + "/result/compare";
                return $http.post(url, carDetailsView, config);
            },
            getCountOfCarsByUserId: function (userId) {
                var url = serviceurl + "/result/carCount/" + userId;
                return $http.get(url);
            },
            getBodyStyle: function () {
                var url = serviceurl + "/motorLookups/bodyStyle";
                return $http.get(url);
            }
        };
    }]);
});