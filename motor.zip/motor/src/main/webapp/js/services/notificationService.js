define(['./module'], function(Services) {
    'use strict';
    Services.factory('notificationService', ['$timeout', function($timeout) {
        return {
            infoNotification: function(msg) {
                $timeout(function() {
                    $.alert(msg, {
                        type: 'info'
                    });
                }, 100);
            },
            warningNotification: function(msg) {
                $timeout(function() {
                    $.alert(msg, {
                        type: 'warning'
                    });
                }, 100);
            },
            errorNotification: function(msg) {
                $timeout(function() {
                    $.alert(msg, {
                        type: 'danger'
                    });
                }, 100);
            },
            successNotification: function(msg) {
                $timeout(function() {
                    $.alert(msg, {
                        type: 'success'
                    });
                }, 100);
            }
        };
    }]);
});
