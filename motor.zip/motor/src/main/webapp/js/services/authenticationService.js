define(['./module'], function (Services) {
    'use strict';
    Services.factory('authenticationService', ['$http', '$rootScope', function ($http, $rootScope) {
        var serviceurl = $rootScope.serviceurl;
        var config = {
            headers: {
                'Content-Type': 'application/json'
            }
        };
        return {
            signUpUser: function (user) {
                var url = serviceurl + "/user/create";
                return $http.post(url, user, config);
            },
            loginUser: function (userjson) {
                var url = serviceurl + "/user/validatePassword";
                return $http.post(url, userjson, config);
            },
            activeUser: function (userjson) {
                var url = serviceurl + "/user/updatePassword";
                return $http.post(url, userjson, config);
            },
            forgotPassword: function (userJson) {
                var url = serviceurl + "/user/forgotPassword";
                return $http.post(url, userJson, config);
            },
            getAreaCityByProvince: function (province) {
                var url = serviceurl + "/motorLookups/areaCityByProvince/" + province;
                return $http.get(url);
            },
            getUserObjectByUserName: function (userName) {
                var url = serviceurl + "/user/" + userName;
                return $http.get(url);
            },
            getViewedCarIds: function (userId) {
                var url = serviceurl + "/car/carIdByuserId/" + userId;
                return $http.get(url);
            },
            updateUserObjectByUserId: function (userId) {
                var url = serviceurl + "/user/userInfo/" + userId;
                return $http.get(url);
            },
            activateOrDeactivateUser: function (userId) {
                var url = serviceurl + "/user/activateOrDeactivateUser/" + userId;
                return $http.get(url);
            },
            getAllEnglishDetailsUsers: function () {
                var url = serviceurl + "/result/getAllEnglishDetailsUsers";
                return $http.get(url);
            },
            findAllProvinceDetails: function () {
                var url = serviceurl + "/motorLookups/findAllProvinceDetails";
                return $http.get(url);
            },
            getAreaCityByProvinceId: function (provinceId) {
                var url = serviceurl + "/motorLookups/getAreaCityByProvinceId/" + provinceId;
                return $http.get(url);
            },
            updateUser: function (user) {
                var url = serviceurl + "/user/updateUser";
                return $http.post(url, user, config);
            }
        };
    }]);
});