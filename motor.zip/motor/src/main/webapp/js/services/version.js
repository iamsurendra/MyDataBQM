define(['./module'], function(services) {
    'use strict';
    services.value('version', '0.1');
});
