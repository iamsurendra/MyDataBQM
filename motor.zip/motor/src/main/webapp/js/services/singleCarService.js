define(['./module'], function (Services) {
    'use strict';
    Services.factory('singleCarService', ['$http', '$rootScope', function ($http, $rootScope) {
        var serviceurl = $rootScope.serviceurl;
        var config = {
            headers: {
                'Content-Type': 'application/json'
            }
        };
        return {
            singleCarDetails: function (id) {
                var url = serviceurl + "/index/searchById/" + id;
                return $http.get(url);
            },
            addToRecentlyViewed: function (RecentViewCars) {
                var url = serviceurl + "/car/createRecentCars";
                return $http.post(url, RecentViewCars, config);
            },
            saveMessageSeller: function (comment) {
                var url = serviceurl + "/index/message";
                return $http.post(url, comment, config);
            },
            singleCarDetailsById: function (languageId,carId) {
                var url = serviceurl + "/index/carInfoById/" + carId;
                return $http.get(url, {
                    params: {
                        "languageId": languageId
                    }
                });
            }
        };
    }]);
});