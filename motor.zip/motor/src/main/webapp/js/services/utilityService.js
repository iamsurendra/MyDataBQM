define(['./module'], function(Services) {
    'use strict';
    Services.factory('utilityService', ['$timeout', '$rootScope', function($timeout, $rootScope) {
        return {
            getPropertyNameByLocale: function(prop) {
                switch ($rootScope.locale) {
                    case 'fr_PSH':
                        return prop + "Pashto";
                        break;
                    case 'fr_AFG':
                        return prop + "Dari";
                        break;
                    default:
                        return prop;
                        break;
                }
            }
        }
    }]);
});