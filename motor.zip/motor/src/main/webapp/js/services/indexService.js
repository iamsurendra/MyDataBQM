define(['./module'], function (Services) {
    'use strict';
    Services.factory('indexService', ['$http', '$rootScope', function ($http, $rootScope) {
        var serviceurl = $rootScope.serviceurl;
        var config = {
            headers: {
                'Content-Type': 'application/json'
            }
        };
        return {
            getMakeData: function (id) {
                var url = serviceurl + "/motorLookups/makers";
                return $http.get(url);
            },
            getModelDataByMakeName: function (name) {
                var url = serviceurl + "/motorLookups/modelbymake/" + name;
                return $http.get(url);
            },
            getBodyTypeCountList: function () {
                var url = serviceurl + "/index/bodyTypeCount";
                return $http.get(url);
            },
            getMakeCountList: function () {
                var url = serviceurl + "/index/makersCount";
                return $http.get(url);
            },
            getPriceCountList: function () {
                var url = serviceurl + "/index/priceCount";
                return $http.get(url);
            },
            checkDealercarsCount: function (id) {
                var url = serviceurl + "/result/checkDealercarsCount/" + id;
                return $http.get(url);
            },
            getUserLocalInfoById: function (userId, languageId) {
                var url = serviceurl + "/index/userLocalInfoById";
                return $http.get(url, {
                    params: {
                        "userId": userId,
                        "languageId": languageId,
                    }
                });
            }
        };
    }]);
});