define(['./module'], function (Services) {
    'use strict';
    Services.factory('dealerCarsService', ['$http', '$rootScope', function ($http, $rootScope) {
        var serviceurl = $rootScope.serviceurl;
        var config = {
            headers: {
                'Content-Type': 'application/json'
            }
        };
        return {
            saveCarInfo: function (carJson) {
                var url = serviceurl + "/car/save";
                return $http.post(url, carJson, config);
            },
            deleteCarInfo: function (carId) {
                var url = serviceurl + "/car/deleteCar/" + carId;
                return $http.get(url);
            },
            createCar: function (userId) {
                var url = serviceurl + "/car/createCar/" + userId;
                return $http.get(url);
            },
            getMakeIdByName: function (make, model, bodyType) {
                var url = serviceurl + "/motorLookups/makersIdByName";
                return $http.get(url, {
                    params: {
                        "name": make,
                        "model": model,
                        "bodyType": bodyType
                    }
                });
            },
            getColorsData: function () {
                var url = serviceurl + "/motorLookups/colorInfo";
                return $http.get(url);
            },
            getSeatingInfo: function () {
                var url = serviceurl + "/motorLookups/seatingInfo";
                return $http.get(url);
            },
            getEngineBhpInfo: function () {
                var url = serviceurl + "/motorLookups/engineBhpInfo";
                return $http.get(url);
            },
            getEngineccInfo: function () {
                var url = serviceurl + "/motorLookups/engineccInfo";
                return $http.get(url);
            },
            getTankCapacity: function () {
                var url = serviceurl + "/motorLookups/tankCapacity";
                return $http.get(url);
            },
            makeCarAsInactive: function (carId) {
                var url = serviceurl + "/car/makeCarAsInactive/" + carId;
                return $http.get(url);
            },
            getRecentlyViewedCars: function (userId) {
                var url = serviceurl + "/car/diplayRecentcarsById/" + userId;
                return $http.get(url);
            },
            getCarInfo: function (carId) {
                var url = serviceurl + "/car/carInfo/" + carId;
                return $http.get(url);
            },
            getMakeInfoByid: function (makeId) {
                var url = serviceurl + "/motorLookups/makeInfoByid/" + makeId;
                return $http.get(url);
            },
            getBodyStyleByMakeModel: function (name, model) {
                var url = serviceurl + "/motorLookups/bodyStyleByMakeModel";
                return $http.get(url, {
                    params: {
                        "name": name,
                        "model": model,
                    }
                });
            },
            deleteProfileImage: function (carId, profileName) {
                var url = serviceurl + "/image/deleteImage";
                return $http.get(url, {
                    params: {
                        "carId": carId,
                        "profileName": profileName
                    }
                });
            }
        };
    }]);
});