define(['./module'], function (Services) {
    'use strict';
    Services.factory('alertCarsService', ['$http', '$rootScope', function ($http, $rootScope) {
        var serviceurl = $rootScope.serviceurl;
        var config = {
            headers: {
                'Content-Type': 'application/json'
            }
        };
        return {
            saveAlert: function (carAlerts) {
                var url = serviceurl + "/result/createCarAlerts";
                return $http.post(url, carAlerts, config);
            },
            updateAlert: function (carAlerts) {
                var url = serviceurl + "/profile/editCarAlert";
                return $http.post(url, carAlerts, config);
            },
            getCarAlerts: function (userId) {
                var url = serviceurl + "/profile/carAlertDetails/" + userId;
                return $http.get(url);
            },
            deleteCarAlert: function (carAlerts) {
                var url = serviceurl + "/profile/deleteCarAlert";
                return $http.post(url, carAlerts, config);
            },
            getCarAlertDetailsById: function (alertId) {
                var url = serviceurl + "/profile/displayCarAlertByAlertId/" + alertId;
                return $http.get(url);
            },
            validateEail: function (email) {
                var url = serviceurl + "/user/validateEmail/";
                return $http.get(url, {
                    params: {
                        "email": email,
                    }
                });
            }
        };
    }]);
});