define(['./app'], function(app) {
    'use strict';
    app.provider("social", function() {
        var fbKey, fbApiV, googleKey, linkedInKey;
        return {
            setFbKey: function(obj) {
                fbKey = obj.appId;
                fbApiV = obj.apiVersion;
                var d = document,
                    fbJs, id = 'facebook-jssdk',
                    ref = d.getElementsByTagName('script')[0];
                fbJs = d.createElement('script');
                fbJs.id = id;
                fbJs.async = true;
                fbJs.src = "//connect.facebook.net/en_US/sdk.js";

                fbJs.onload = function() {
                    FB.init({
                        appId: fbKey,
                        status: true,
                        cookie: true,
                        xfbml: true,
                        version: fbApiV
                    });
                };

                ref.parentNode.insertBefore(fbJs, ref);
            },
            setGoogleKey: function(value) {
                googleKey = value;
                var d = document,
                    gJs, ref = d.getElementsByTagName('script')[0],
                    auth2;
                gJs = d.createElement('script');
                gJs.async = true;
                gJs.src = "//apis.google.com/js/api:client.js"

                gJs.onload = function() {
                    var params = {
                        client_id: value,
                        scope: 'profile'
                    }
                    gapi.load('auth2', function() {
                        gapi.auth2.init(params);
                    });
                };

                ref.parentNode.insertBefore(gJs, ref);
            },
            $get: function() {
                return {
                    fbKey: fbKey,
                    googleKey: googleKey,
                    fbApiV: fbApiV
                }
            }
        }
    })
});