/**
 * bootstraps angular onto the window.document node
 * NOTE: the ng-app attribute should not be on the index.html when using ng.bootstrap
 */
define([
    'require',
    'angular',
    'angular_animate',
    'angular_ui_route',
    'ngCookies',
    'angular_ui_bootstrap',
    'bootstrapper',
    'bootstrapnotify',
    'fontawesome',
    'jquery',
    'ng_file_upload',
    'nglazyload',
    'ngSanitize',
    'socialLoginProvider',
    'infinite_scroll',
    'angularStorage',
    'angularStrap',
    'angularStraptlp',
    'angularValidator',
    'app',
    'interceptor',
    'routes'
], function(require, ng) {
    'use strict';

    /*
     * place operations that need to initialize prior to app start here
     * using the `run` function on the top-level module
     */

    require(['domReady!'], function(document) {
        ng.bootstrap(document, ['app']);
    });
});