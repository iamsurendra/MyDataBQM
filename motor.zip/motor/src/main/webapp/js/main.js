/**
 * configure RequireJS prefer named modules to long paths, especially for
 * version mgt or 3rd party libraries
 */

require.config({
    urlArgs: "bust=" + ((new Date()).getFullYear() + "/" + ((new Date()).getMonth() + "/" + (new Date()).getDay() + "/" + (new Date()).getHours() + "/" + (new Date()).getMinutes())),
    paths: {
        // Jquery
        'jquery': '../libs/jquery',

        // angular
        'angular': '../libs/angular',

        'angular_animate': '../libs/angular-animate',

        'angular_ui_route': '../libs/angular-ui-router',

        'ngSanitize': '../libs/angular-sanitize.min',

        'ngCookies': '../libs/angular-cookies.min',

        // angular bootstrap
        'angular_ui_bootstrap': '../libs/ui-bootstrap-tpls.min',

        // bootstrap 
        'bootstrapper': '../libs/bootstrap.min',

        //font awesome
        'fontawesome': '../libs/fontawesome',

        // bootstrap notify
        'bootstrapnotify': '../libs/alert',

        // infinite scroll        
        'infinite_scroll': '../libs/infinite-scroll',

        // infinite scroll        
        'ng_file_upload': '../libs/ng-file-upload',

        // lazy load        
        'nglazyload': '../libs/angular-lazyload.min',

        // ng storage
        'angularStorage': '../libs/angular-local-storage',

        // angular strap
        'angularStrap': '../libs/angular-strap.min',

        // angular strap templates
        'angularStraptlp': '../libs/angular-strap.tpl.min',

        // angular validator
        'angularValidator': '../libs/angular-validator.min',

        // dom ready
        'domReady': '../libs/domReady',


    },
    waitSeconds: 200,
    /**
     * for libs that either do not support AMD out of the box, or require some
     * fine tuning to dependency mgt'
     */
    shim: {
        'angular': {
            deps: ['jquery'],
            exports: 'angular'
        },
        'jquery': {
            exports: '$'
        },
        'angular_animate': {
            deps: ['angular']
        },
        'angular_ui_route': {
            deps: ['angular']
        },
        'ngSanitize': {
            deps: ['angular']
        },
        'ngCookies': {
            deps: ['angular']
        },
        'angular_ui_bootstrap': {
            deps: ['angular']
        },
        'bootstrapper': {
            deps: ['jquery']
        },
        'bootstrapnotify': {
            deps: ['jquery']
        },
        'fontawesome': {
            deps: ['jquery']
        },
        'infinite_scroll': {
            deps: ['angular']
        },
        'angularStorage': {
            deps: ['angular']
        },
        'angularStrap': {
            deps: ['angular']
        },
        'angularStraptlp': {
            deps: ['angularStrap']
        },
        'angularValidator': {
            deps: ['angular']
        },
        'ng_file_upload': {
            deps: ['angular']
        },
        'nglazyload': {
            deps: ['angular']
        }

    },
    deps: [
        // kick start application... see bootstrap.js
        './bootstrap'
    ]
});