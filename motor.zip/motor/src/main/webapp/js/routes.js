/**
 * Defines the main routes in the application. The routes you see here will be
 * anchors '#/' unless specifically configured otherwise.
 */
define(['./app'], function(app) {
    'use strict';
    return app.
    config(['$stateProvider', '$urlRouterProvider', '$httpProvider', '$locationProvider', 'localStorageServiceProvider', function($stateProvider, $urlRouterProvider, $httpProvider, $locationProvider, localStorageServiceProvider) {

            var templateSuffix = ((new Date()).getFullYear() + "/" + (new Date()).getMonth() + "/" + (new Date()).getDay() + "/" + (new Date()).getHours() + "/" + (new Date()).getMinutes());

            var layout = 'views/app.html?' + "v=" + templateSuffix;

            $stateProvider
                .state('index', {
                    url: '/index',
                    templateUrl: 'views/index.html?' + "v=" + templateSuffix,
                    controller: 'indexController',
                    data: {
                        title: 'Welcome to Motar'
                    },
                    cache: false
                }).state('result', {
                    url: '/result',
                    templateUrl: 'views/result.html?' + "v=" + templateSuffix,
                    controller: 'resultsController',
                    data: {
                        title: 'Motar - Result'
                    },
                    cache: false
                }).state('singleCar', {
                    url: '/singleCar/:id',
                    templateUrl: 'views/single-car.html?' + "v=" + templateSuffix,
                    controller: 'singleCarController',
                    data: {
                        title: 'SingleCar Details'
                    }
                }).state('dealer', {
                    url: '/dealer',
                    templateUrl: 'views/dealer-cars.html?' + "v=" + templateSuffix,
                    controller: 'dealerCarsController',
                    data: {
                        title: 'Dealer-Cars'
                    }
                }).state('editDealerCar', {
                    url: '/editDealerCar/:id',
                    templateUrl: 'views/editDelearCar.html?' + "v=" + templateSuffix,
                    controller: 'editDelearCarController',
                    data: {
                        title: 'Dealer-Car- Edit'
                    }
                }).state('compareCars', {
                    url: '/compareCars',
                    templateUrl: 'views/compare-cars.html?' + "v=" + templateSuffix,
                    controller: 'compareCarsController',
                    data: {
                        title: 'Compare Cars'
                    }
                }).state('alerts', {
                    url: '/alerts/:id',
                    templateUrl: 'views/alert-cars.html?' + "v=" + templateSuffix,
                    controller: 'alertCarsController',
                    data: {
                        title: 'Alerts'
                    }
                }).state('profile', {
                    url: '/profile',
                    templateUrl: 'views/profile.html?' + "v=" + templateSuffix,
                    controller: 'profileController',
                    data: {
                        title: 'Profile'
                    }
                }).state('contactus', {
                    url: '/contactus',
                    templateUrl: 'views/contactus.html?' + "v=" + templateSuffix,
                    controller: 'contactusController',
                    data: {
                        title: 'Contactus'
                    }
                }).state('aboutus', {
                    url: '/aboutus',
                    templateUrl: 'views/aboutus.html?' + "v=" + templateSuffix,
                    controller: 'aboutusController',
                    data: {
                        title: 'Aboutus'
                    }
                }).state('login', {
                    url: '/login',
                    templateUrl: 'views/login.html?' + "v=" + templateSuffix,
                    controller: 'loginController',
                    controllerAs: 'vm',
                    data: {
                        title: 'Login'
                    }
                }).state('forgotPassword', {
                    url: '/forgotPassword',
                    templateUrl: 'views/forgotPassword.html?' + "v=" + templateSuffix,
                    controller: 'forgotPasswordController',
                    data: {
                        title: 'Forgot Password'
                    }
                }).state('userAgreement', {
                    url: '/userAgreement',
                    templateUrl: 'views/userAgreement.html?' + "v=" + templateSuffix,
                    data: {
                        title: 'User Agreement'
                    }
                }).state('privacy', {
                    url: '/privacy',
                    templateUrl: 'views/privacy.html?' + "v=" + templateSuffix,
                    data: {
                        title: 'Privacy'
                    }
                }).state('adChoices', {
                    url: '/adChoices',
                    templateUrl: 'views/choices.html?' + "v=" + templateSuffix,
                    controller: 'adChoicesController',
                    data: {
                        title: 'Ad Choices'
                    }
                }).state('dealerLogin', {
                    url: '/dealerLogin',
                    templateUrl: 'views/dealerlogin.html?' + "v=" + templateSuffix,
                    controller: 'dealerloginController',
                    data: {
                        title: 'Dealer login'
                    }
                }).state('admin', {
                    url: '/admin',
                    templateUrl: 'views/admin.html?' + "v=" + templateSuffix,
                    controller: 'adminController',
                    data: {
                        title: 'Admin'
                    }
                })

            $urlRouterProvider.otherwise('/index');

            $httpProvider.defaults.headers.common['Pragma'] = 'no-cache';
            $httpProvider.defaults.headers.common['Cache-Control']='no-cache';

            $httpProvider.interceptors.push('httpInterceptor');

            localStorageServiceProvider.setPrefix('motor')
                .setStorageType('sessionStorage')
                .setNotify(true, true)

            //use the HTML5 History API
            $locationProvider.html5Mode(true);

        }])
        // .config(function(socialProvider) {
        //     socialProvider.setGoogleKey('15301760887-t7p56gg3esl6si1glc3vhqgaj038tj2g.apps.googleusercontent.com');
        //     socialProvider.setFbKey({ appId: '833217350171721', apiVersion: 'v2.8' });
        // })
        .run(
            ['$rootScope', '$state', '$stateParams', '$http', '$location', '$anchorScroll', 'localStorageService', '$cookies',
                function($rootScope, $state, $stateParams, $http, $location, $anchorScroll, localStorageService, $cookies) {

                    // services url
                    $rootScope.serviceurl = "/motor/api";

                    // local storage implementation to store search object and user details

                    // init user details
                    $rootScope.user = {};

                    $rootScope.favioriteCarIdList = [];
                    $rootScope.compareCarIdList = [];
                    $rootScope.alertCarIdList = [];
                    $rootScope.filterList = [];
                    $rootScope.viewedCarIdList = [];

                    $rootScope.isCompareEnabled = false;
                    $rootScope.activeProfileIndex = 0;

                    // init searchJson
                    if (localStorageService.get('searchJson') != undefined) {
                        $rootScope.searchJson = localStorageService.get('searchJson');
                    } else {
                        $rootScope.searchJson = {};
                    }

                    // init alertInfo
                    if (localStorageService.get('alertInfo') != undefined) {
                        $rootScope.alertInfo = localStorageService.get('alertInfo');
                    } else {
                        $rootScope.alertInfo = null
                    }

                    // init searchJson
                    if (localStorageService.get('user') != undefined) {
                        $rootScope.user = localStorageService.get('user');
                    } else {
                        $rootScope.user = {};
                        $rootScope.favioriteCarIdList = [];
                        $rootScope.alertCarIdList = [];
                    }

                    // if ($cookies.get('current_user_id')) {
                    //     console.log("present");
                    // } else {
                    //     console.log("not present");
                    //     $cookies.put('current_user_id', 10);
                    // }

                    $rootScope.updateLocale = function(locale) {
                        $rootScope.locale = locale;
                        switch ($rootScope.locale) {
                            case 'fr_PSH':
                                $rootScope.selectedLanguage = "پښتو";
                                $rootScope.languageId = "102";
                                angular.element('body').removeClass('lang-en');
                                angular.element('body').addClass('lang-pa');
                                $cookies.put('locale', 'fr_PSH');
                                break;
                            case 'fr_AFG':
                                $rootScope.selectedLanguage = "دری";
                                $rootScope.languageId = "101";
                                angular.element('body').removeClass('lang-en');
                                angular.element('body').addClass('lang-pa');
                                $cookies.put('locale', 'fr_AFG');
                                break;
                            default:
                                $rootScope.locale = 'en_US';
                                $rootScope.languageId = "100";
                                $rootScope.selectedLanguage = "English";
                                angular.element('body').removeClass('lang-pa');
                                angular.element('body').addClass('lang-en');
                                $cookies.put('locale', 'en_US');
                                break;
                        };
                        
                        $rootScope.searchJson["languageId"]=$rootScope.languageId;

                        // initializing labels
                        $http.get("./assets/json/labels_" + $rootScope.locale + ".json").
                        success(function(data, status, headers, config) {
                            $rootScope.labels = data;
                        }).
                        error(function(data, status, headers, config) {
                            $location.path('/index');
                        });

                        //initializing messages
                        $http.get("./assets/json/messages_" + $rootScope.locale + ".json").
                        success(function(data, status, headers, config) {
                            $rootScope.messages = data;
                        }).
                        error(function(data, status, headers, config) {
                            $location.path('/index');
                        });

                        $rootScope.buildVesrion = new Date();
                        // $http.get($rootScope.serviceurl + "/app/version")
                        //     .success(
                        //         function (data, status) {
                        //             $rootScope.buildVesrion = data.release + " " + data.timeStamp;
                        //         }).error(
                        //         function (data, status,
                        //             config) {});

                    };

                    (function() {
                        $rootScope.updateLocale($cookies.get('locale'));
                    })();




                    if (localStorageService.get('searchedBy') != undefined) {
                        $rootScope.activeSearchIndex = localStorageService.get('activeSearchIndex');
                        $rootScope.showMore = localStorageService.get('showMore');
                        $rootScope.searchedBy = localStorageService.get('searchedBy');
                    } else {
                        $rootScope.activeSearchIndex = 0;
                        $rootScope.showMore = false;
                        $rootScope.searchedBy = undefined;
                    }

                    if (localStorageService.get('favioriteCarIdList') != undefined) {
                        $rootScope.favioriteCarIdList = localStorageService.get('favioriteCarIdList');
                    }

                    if (localStorageService.get('compareCarIdList') != undefined) {
                        $rootScope.compareCarIdList = localStorageService.get('compareCarIdList');
                        if ($rootScope.compareCarIdList.length > 0) {
                            $rootScope.isCompareEnabled = true;
                        }
                    }

                    if (localStorageService.get('viewedCarIdList') != undefined) {
                        $rootScope.viewedCarIdList = localStorageService.get('viewedCarIdList');
                    }

                    if (localStorageService.get('filterList') != undefined) {
                        $rootScope.filterList = localStorageService.get('filterList');
                    }

                    // on searchJson change updating localstorage
                    $rootScope.$watch('searchJson', function() {
                        localStorageService.set('searchJson', $rootScope.searchJson);
                    }, true);

                    // on searchJson change updating localstorage
                    $rootScope.$watch('user', function() {
                        localStorageService.set('user', $rootScope.user);
                    }, true);

                    // on search change
                    $rootScope.$watch('searchedBy', function() {
                        localStorageService.set('searchedBy', $rootScope.searchedBy);
                        localStorageService.set('showMore', $rootScope.showMore);
                        localStorageService.set('activeSearchIndex', $rootScope.activeSearchIndex);
                    });

                    $rootScope.$watch('alertInfo', function() {
                        localStorageService.set('alertInfo', $rootScope.alertInfo);
                    }, true);

                    $rootScope.$watchCollection('favioriteCarIdList', function(newVal, oldVal) {
                        localStorageService.set('favioriteCarIdList', $rootScope.favioriteCarIdList);
                    });

                    $rootScope.$watchCollection('compareCarIdList', function(newVal, oldVal) {
                        localStorageService.set('compareCarIdList', $rootScope.compareCarIdList);
                    });

                    $rootScope.$watchCollection('filterList', function(newVal, oldVal) {
                        localStorageService.set('filterList', $rootScope.filterList);
                    });

                    $rootScope.$watchCollection('viewedCarIdList', function(newVal, oldVal) {
                        localStorageService.set('viewedCarIdList', $rootScope.viewedCarIdList);
                    });
                    
                    $rootScope.$on('$stateChangeStart',function(event, toState, toParams, fromState, fromParams, options){  
                    	// check are you navigating to dealerLogin or login
                    	// if yes
                    		if(toState["name"]=="dealerLogin"||toState["name"]=="login"||toState["name"]=="forgotPassword"){
                    			// check the user is already logged in or not
                    			// if the user already logged in
                    			if($rootScope.user.userId!=undefined&&$rootScope.user.userId!=null){
                    				// check the previous state
                    				// navigating back from any state then preventing navigation
                    				if(fromState["name"]!=""){
                    					event.preventDefault();	
                    				}
                    				// else if you are directly changing the page url then navigate back to index
                    				else{
                    					 $location.path('/index');
                    				}
                    						
                    			}
                    		} 
                		});

                    // on rootscope change success
                    $rootScope.$on("$stateChangeSuccess", function(currentRoute, previousRoute) {
                        // setting page title     
                        document.body.scrollTop = document.documentElement.scrollTop = 0;
                        if ($state.current.data != undefined) {
                            $rootScope.title = ($state.current.data.title != undefined) ? $state.current.data.title : 'Welcome to Motor';
                        } else {
                            $rootScope.title = 'Welcome to Motor';
                        }

                    });


                }
            ]
        );
});