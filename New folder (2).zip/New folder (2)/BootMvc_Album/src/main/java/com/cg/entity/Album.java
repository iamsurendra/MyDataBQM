package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Albumss")
@SequenceGenerator(name="alseq",sequenceName="album_seq",initialValue=100)
public class Album {
	
	
//	private static final long serialVersionUID = 1L;
	
	@Id@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="alseq")
	private int ablum_id;
	@Column(length=30)
	private String title;
	private String artist;
	private double price;

	public Album() {
		
	}

	
	
	public Album(int ablum_id, String title, String artist, double price) {
		super();
		this.ablum_id = ablum_id;
		this.title = title;
		this.artist = artist;
		this.price = price;
	}



	public int getAblum_id() {
		return ablum_id;
	}

	public void setAblum_id(int ablum_id) {
		this.ablum_id = ablum_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}



	@Override
	public String toString() {
		return "Album [ablum_id=" + ablum_id + ", title=" + title + ", artist=" + artist + ", price=" + price + "]";
	}
}
