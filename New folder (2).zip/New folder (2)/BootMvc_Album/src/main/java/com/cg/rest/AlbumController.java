package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Album;

import com.cg.service.AlbumService;

@RestController
public class AlbumController {
	
	@Autowired
	private AlbumService service;
	
	@PostMapping(value="/add",consumes="application/json")
	public String addFlight(@RequestBody Album album) {
		int no=service.saveAlbum(album);
		return "Album Number Is:"+no;
	}
	@GetMapping(value="/getAll",produces="application/json")
	public List<Album> getAll(){
		return service.getAll();
	}
	@GetMapping(value="/get/{id}",produces="application/json")
	public Album get(@PathVariable int id) {
		return service.getById(id);
		
	}
	@PutMapping(value="/update", consumes="application/json")
	public String update(@RequestBody Album album) {
		service.updateAlbum(album);
		return "Album updated";
	}
	@DeleteMapping(value="/delete/{id}")
	public String delete(@PathVariable int id) {
		service.removeAlbum(id);
		return "AlbumS Deleted";
	}
	@GetMapping(value="/findByTitle", produces="application/json")
	public List<Album> findByName(@RequestParam("name") String name){
		return service.findByTitle(name);
	}
	@GetMapping(value="/findByPrice/{price}",produces="application/json")
	public List<Album> findByPrice(@PathVariable double price){
		return service.findByPrice(price);
	}


}
