package com.cg.service;

import java.util.List;

import com.cg.entity.Album;

public interface AlbumService {
	
int saveAlbum(Album al);
	
	Album getById(int id);
	
	List<Album> getAll();
	
	void removeAlbum(int id);
	
	void updateAlbum(Album album);

	List<Album> findByTitle(String name);
	
	List<Album> findByPrice(double price);
	
	List<Album> findByArtist(String artist);
	

}
