package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Album;

import com.cg.repo.AlbumRepo;

@Service
public class AlbumServiceImpl implements AlbumService {

	
	@Autowired
	private AlbumRepo repo;
	
	
	@Override
	public int saveAlbum(Album al) {
		return repo.saveAlbum(al);
		
	}

	@Override
	public Album getById(int id) {
		return repo.getById(id);
	}

	@Override
	public List<Album> getAll() {
		
		return repo.getAll();
	}

	@Override
	public void removeAlbum(int id) {
		 repo.removeAlbum(id);
	}

	@Override
	public void updateAlbum(Album album) {
		
		repo.updateAlbum(album);
		
	}
	
	public List<Album> findByTitle(String name) {
		return repo.findByTitle(name);
	}

	@Override
	public List<Album> findByPrice(double price) {
		// TODO Auto-generated method stub
		return repo.findByPrice(price);
	}

	@Override
	public List<Album> findByArtist(String artist) {
		
		return repo.findByArtist(artist);
	}

}
