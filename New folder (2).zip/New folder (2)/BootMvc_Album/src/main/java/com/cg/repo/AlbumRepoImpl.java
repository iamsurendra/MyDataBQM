package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Album;

@Repository
@Transactional
public class AlbumRepoImpl implements AlbumRepo {
	
	@PersistenceContext
	private EntityManager em;

	
	@Transactional(propagation=Propagation.REQUIRED)
	public int saveAlbum(Album al) {
		em.persist(al);
		return al.getAblum_id();
		
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public Album getById(int id) {
		
		return em.find(Album.class, id);
	}

	@Transactional
	public List<Album> getAll() {
		
		return  em.createQuery("from Album").getResultList();
	}

	@Transactional
	public void removeAlbum(int id) {
		
		Album album=em.find(Album.class, id);
		em.remove(album);
		
	}

	@Override
	public List<Album> findByTitle(String alb) {
		// TODO Auto-generated method stub
		String s="select album from Album album where album.title=:a";
		TypedQuery<Album> quary=em.createQuery(s, Album.class);
		quary.setParameter("a", alb);
		
		return quary.getResultList();
	}
	@Override
	public void updateAlbum(Album album) {
		
		em.merge(album);
		
	}
	@Override
	public List<Album> findByPrice(double pri) {
		
		String p="select album from Album album where album.price=:p";
		TypedQuery<Album> quary=em.createQuery(p, Album.class);
		quary.setParameter("p", pri);
		
		return quary.getResultList();
	}
	@Override
	public List<Album> findByArtist(String artist) {

		String a="select album from Album where album.artist=:a";
		TypedQuery<Album> quary=em.createQuery(a, Album.class);
		quary.setParameter("a", artist);
		
		return quary.getResultList();
	}

}
