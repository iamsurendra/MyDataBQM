package com.cg.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Album;




public interface AlbumRepo {
	
int saveAlbum(Album al);
	
	Album getById(int id);
	
	List<Album> getAll();
	
	void removeAlbum(int id);
	
	void updateAlbum(Album album);
	
	@Query("FROM Album WHERE title=:alb")
	public List<Album> findByTitle(@Param("alb") String alb);
	
	@Query("FROM Album WHERE price=:pri")
	public List<Album> findByPrice(@Param("pri") double pri);
	
	@Query("FROM Album WHERE artist=:art")
	public List<Album> findByArtist(@Param("art") String artist);

}
