package com.capgemini.cab.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.cab.util.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;

@Repository
public class CabRequestDAO implements ICabRequestDAO {
	
	@PersistenceContext
	private EntityManager em;
	
	@Transactional
	public int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException{
		
		em.persist(cabRequest);
		return cabRequest.getRequest_id();
	}

}
