package com.capgemini.cabs.ui;

import java.util.Date;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.cab.service.ICabService;
import com.capgemini.cab.util.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;

public class Client {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("appctx.xml");
		ICabService service = (ICabService) ctx.getBean("cabService");

		int choice = 0;
		String name = null;
		String number;
		Date dor;
		String addr = null;
		String pincode = null;
		String status = "Accepted";
		Scanner sc = new Scanner(System.in);

		do {
			CabRequest cabrequest = new CabRequest();
			System.out.println("Welcome to Car Rental Center");
			System.out.println("1.Provide Required Details");
			System.out.println("2.Exit");
			choice = sc.nextInt();

			switch (choice) {

			case 1:
				while (true) {
					System.out.println("Enter Customer Name");
					name = sc.next();
					boolean userEnteredname = service.isNameValid(name);
					if (userEnteredname)
						break;
				}
				while (true) {
					System.out.println("Enter Phone Number");
					number = sc.next();
					boolean userEnteredPhNo = service.isPhoneNumberValid(number);
					if (userEnteredPhNo)
						break;
				}

				// System.out.println("Enter Date of Request ");
				//
				// System.out.println("Enter Request Status");
				// status=sc.next();
				System.out.println("Enter Pick up address");
				addr = sc.next();
				while (true) {
					System.out.println("Enter Pin Code");
					pincode = sc.next();
					boolean userEnteredPincode = service.isPinCodeValid(pincode);
					break;
				}
				cabrequest.setCustomer_name(name);
				cabrequest.setPhone_number(Long.parseLong(number));
				cabrequest.setAddress_of_pickup(addr);
				cabrequest.setPincode(pincode);
				int request_id;
				try {
					request_id = service.addCabRequestDetails(cabrequest);
					System.out
					.println("Your cab Request has been successfully registered,your request ID is:" + request_id);
				} catch (CabRequestException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				
				break;

			case 2:
				System.out.println("Visit Again");
				System.out.println(2);
				break;
			default:
				System.out.println("Invalid Input Entered");
			}
			System.out.println("continue 1 else 0");
			choice = sc.nextInt();

		} while (choice != 0);
	}

}
