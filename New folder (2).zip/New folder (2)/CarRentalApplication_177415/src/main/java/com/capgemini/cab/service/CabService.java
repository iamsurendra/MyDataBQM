package com.capgemini.cab.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cab.util.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;

@Service
public class CabService implements ICabService {

	@Autowired
	private ICabRequestDAO dao;

	public int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException {
		
		return dao.addCabRequestDetails(cabRequest);

	}

	public boolean isNameValid(String name) {
		String namePattern = "[A-Za-z0-9]{2,20}";
		if (name.matches(namePattern))
			return true;
		else
			return false;
	}

	public boolean isPhoneNumberValid(String number) {
		String numberPattern = "[0-9]{10}";
		if (number.matches(numberPattern))
			return true;
		else
			return false;
	}

	public boolean isPinCodeValid(String pincode) {
		String PincodePattern = "[0-9]{6}";
		if (pincode.matches(PincodePattern))
			return true;
		else
			return false;
	}

}
