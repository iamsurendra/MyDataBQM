package com.capgemini.cab.util;

public class CabRequestException extends Exception{
		
	private String message;

	public CabRequestException(String message) {
		this.message = message;
	}
	public  String getMessage()
	{
		return message;
		
	}
	
	

}
