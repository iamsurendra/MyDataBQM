package com.capgemini.cab.service;

import com.capgemini.cab.util.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;

public interface ICabService {

	int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException;
	
	boolean isNameValid(String name);
	boolean isPhoneNumberValid(String number);
	boolean isPinCodeValid(String pincode);
}
