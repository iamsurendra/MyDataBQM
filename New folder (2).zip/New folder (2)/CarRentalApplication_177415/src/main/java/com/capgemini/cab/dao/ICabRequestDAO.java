package com.capgemini.cab.dao;

import com.capgemini.cab.util.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;

public interface ICabRequestDAO {
	
	int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException;

}
