package com.synergy.bqm.documents;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Transient;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ChecklistTemplate {

	@Id
	public String id;

	private String checklistName;

	private String checklistType;

	private String checklistService;
	
    private Integer checklistServiceId;
    
	@Transient
	private List<String> deletedIds = new ArrayList<>();

	// @JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<SectionTemplate> sectionList = new ArrayList<SectionTemplate>();

	public String getChecklistName() {
		return checklistName;
	}

	public void setChecklistName(String checklistName) {
		this.checklistName = checklistName;
	}

	public String getChecklistType() {
		return checklistType;
	}

	public void setChecklistType(String checklistType) {
		this.checklistType = checklistType;
	}

	public List<SectionTemplate> getSectionList() {
		return sectionList;
	}

	public void setSectionList(List<SectionTemplate> sectionList) {
		this.sectionList = sectionList;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getChecklistService() {
		return checklistService;
	}

	public void setChecklistService(String checklistService) {
		this.checklistService = checklistService;
	}

	public List<String> getDeletedIds() {
		return deletedIds;
	}

	public void setDeletedIds(List<String> deletedIds) {
		this.deletedIds = deletedIds;
	}

	public Integer getChecklistServiceId() {
		return checklistServiceId;
	}

	public void setChecklistServiceId(Integer checklistServiceId) {
		this.checklistServiceId = checklistServiceId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChecklistTemplate other = (ChecklistTemplate) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
