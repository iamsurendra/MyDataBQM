package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.FolderDocumentHistoryVw;
import com.synergy.bqm.models.FolderDocumentHistoryVwKey;

@Repository
public class FolderDocumentHistoryViewDAOImpl extends BaseDAOImpl<FolderDocumentHistoryVw, FolderDocumentHistoryVwKey>  implements FolderDocumentHistoryViewDAO{

	public FolderDocumentHistoryViewDAOImpl() {
		super(FolderDocumentHistoryVw.class);
		// TODO Auto-generated constructor stub
	}

	public List<FolderDocumentHistoryVw> getFolderDocumentHistoryByFolderId(Integer folderId){
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderDocumentHistoryVw> criteriaQuery = builder.createQuery(FolderDocumentHistoryVw.class);
		Root<FolderDocumentHistoryVw> root = criteriaQuery.from(FolderDocumentHistoryVw.class);
		criteriaQuery.select(root)
				.where(builder.equal(root.get("documentFolderId"), folderId)).orderBy(builder.desc(root.get("lastUpdatedDT")));
		return entityManager.createQuery(criteriaQuery).getResultList();
		
		
	}
	
	
}
