package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.FolderTemplate;

public interface FolderTemplateDAO extends BaseDAO<FolderTemplate, Integer> {

	public List<FolderTemplate> getFolderNameByTemplateId(Integer templateId);

	List<FolderTemplate> getFolderTemplateByTemplateId(Integer templateId);

	public Integer getMaxTemplateId();

	public List<String> findByTemplateName(String templateName);

	List<FolderTemplate> getChildFolderNameByTemplateId(Integer templateId, Integer folderId);

	List<FolderTemplate> getFolderInfoByFolderIdAndTemplateId(Integer templateId, Integer folderId);

	FolderTemplate getFolderInfoByFolderId(Integer folderId);

	List<FolderTemplate> getFolderInfoByParentId(Integer folderId);

	List<Integer> getFoldersInfoByFolderIds(List<Integer> folderIds);

	void delete(Integer id);

	List<FolderTemplate> getFolderInfoByTemplateIdandFolderName(Integer templateId, String folderName);

	List<FolderTemplate> getFirstLevelFolderInfoByTemplateId(Integer templateId);

	public Long checkFolderNameExists(Integer templateId, String folderName);

	Long checkChildFolderNameExits(Integer parentFolderId, String folderName);

	public Integer getMaxFolderId();
	
   FolderTemplate getFolderInfoByTemplateIdAndFolderId(Integer templateId,Integer folderId);
   
   List<FolderTemplate> getFolderInfoListByFolderId(Integer folderId);
   
   public List<String>getFoldeNamesByParentIds (Integer parentFolderId);
	
}
