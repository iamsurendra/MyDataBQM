package com.synergy.bqm.repositories;

import java.util.List;
import java.util.Map;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.QuestionOption;

public interface QuestionOptionDAO extends BaseDAO<QuestionOption, Integer>{

	public List<QuestionOption> getQuestionOptionByQuestionType(String questionType);
	
	public List<String> getQuestionType();
	
	public List<QuestionOption> getDistinctQuestionType();
	
	public List<QuestionOption> getQuestionOptionById(List<Long> Ids);
	
	public List<String> getQuestionOptionByType(String questionType);
	
	public List<String> getQuestionTypes();
	
	public Map<String,List<String>> getQuestionAnsInfo();
}
