package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.documents.Checklist;

public class CheckListTreeDTO {

	private String label;
	private String icon;
	private Checklist data;
	private List<CheckListTreeDTO> children;
	private String hierarchyType;
	private boolean leaf;
	private boolean selectable;
	private boolean expanded;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public Checklist getData() {
		return data;
	}

	public void setData(Checklist data) {
		this.data = data;
	}

	public List<CheckListTreeDTO> getChildren() {
		return children;
	}

	public void setChildren(List<CheckListTreeDTO> children) {
		this.children = children;
	}

	public String getHierarchyType() {
		return hierarchyType;
	}

	public void setHierarchyType(String hierarchyType) {
		this.hierarchyType = hierarchyType;
	}

	public boolean isLeaf() {
		return leaf;
	}

	public void setLeaf(boolean leaf) {
		this.leaf = leaf;
	}

	public boolean isSelectable() {
		return selectable;
	}

	public void setSelectable(boolean selectable) {
		this.selectable = selectable;
	}

	public boolean isExpanded() {
		return expanded;
	}

	public void setExpanded(boolean expanded) {
		this.expanded = expanded;
	}

}
