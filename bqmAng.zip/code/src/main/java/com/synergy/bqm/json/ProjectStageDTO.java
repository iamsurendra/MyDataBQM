package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.ProjectStage;

public class ProjectStageDTO {

	private List<ProjectStage> projectStage;
	
	private List<Integer> deletedIds;
	
	//Getters && Setters

	public List<ProjectStage> getProjectStage() {
		return projectStage;
	}

	public void setProjectStage(List<ProjectStage> projectStage) {
		this.projectStage = projectStage;
	}

	public List<Integer> getDeletedIds() {
		return deletedIds;
	}

	public void setDeletedIds(List<Integer> deletedIds) {
		this.deletedIds = deletedIds;
	}
	

	
	
}
