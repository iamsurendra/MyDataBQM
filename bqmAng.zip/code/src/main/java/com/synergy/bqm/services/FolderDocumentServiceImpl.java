package com.synergy.bqm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.guvvala.framework.errorHandler.AppException;
import com.mongodb.gridfs.GridFSDBFile;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.models.FolderDocument;
import com.synergy.bqm.mongoRepositories.FileMongoDAO;
import com.synergy.bqm.repositories.FolderDocumentDAO;

@Service("folderDocumentService")
public class FolderDocumentServiceImpl implements FolderDocumentService {

	@Autowired
	FolderDocumentDAO folderDocumentDAO;

	@Autowired
	FileMongoDAO fileMongoDAO;

	@Override
	@Transactional
	public Long checkDocumentNameExisit(Integer documentfolderid, String documentName, Double version) {

		return folderDocumentDAO.checkDocumentNameExisit(documentfolderid, documentName, version);
	}

	@Override
	@Transactional
	public FolderDocument getfolderDocumentObjcet(Integer documentfolderid, String documentName) {
		return folderDocumentDAO.getfolderDocumentObjcet(documentfolderid, documentName);

	}

	@Transactional
	public List<FolderDocument> getFolderDocumentInfo(Integer folderId) {
		List<FolderDocument> documents = folderDocumentDAO.getFolderDocumentInfo(folderId);
		for (FolderDocument document : documents) {
			if (document.getIndexFile() == null) {
				document.setIndexFile(false);
			}
		}
		return documents;

	}
	

	@Transactional
	public List<FolderDocument> getFolderDocumentsByfolderId(Integer folderId) {	
		return  folderDocumentDAO.getFolderDocumentInfo(folderId);

	}

	@Transactional
	public void updateFolderDocumentInfo(FolderDocument folderDocument) {
		if (folderDocumentDAO.checkDocumentNameExisit(folderDocument.getDocumentId(), folderDocument.getDocumentName(),
				folderDocument.getVersion()) > 0) {
			throw new AppException(MessagesEnum.DOCUMENT_ALREADY_EXIST);

		}
		FolderDocument document = folderDocumentDAO.findOne(folderDocument.getDocumentId());
		document.setDocumentDescription(folderDocument.getDocumentDescription());
		document.setVersion(folderDocument.getVersion());
		folderDocumentDAO.update(document);
	}

	@Transactional
	public List<GridFSDBFile> getListOfDocumentIds(List<Integer> Ids) {
		List<String> documentId = folderDocumentDAO.getListOfDocumentIds(Ids);

		return fileMongoDAO.getAllDocumentsByIds(documentId);

	}

	public List<Double> getVersion(Integer documentfolderid, String documentName) {
		return folderDocumentDAO.getVersion(documentfolderid, documentName);

	}

}
