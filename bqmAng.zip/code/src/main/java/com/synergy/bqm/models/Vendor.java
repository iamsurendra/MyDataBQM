package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.model.BaseModelListener;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "vendor")
@EntityListeners(BaseModelListener.class)
public class Vendor extends BaseModel implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "vendor_id")
	private Long vendorId;

	@Column(name = "vendor_name")
	private String vendorName;

	@Column(name = "vendor_company")
	private String vendorCompany;

	@Column(name = "vendor_contact_no")
	private String vendorContactNo;

	@Column(name = "vendor_email_id")
	private String vendorEmailId;

	@Transient
	String createdDT;

	@Transient
	String updatedDT;

	@Transient
	private String createdUser;

	@Transient
	private String upDatedUser;

	// getters & setters

	public Long getVendorId() {
		return vendorId;
	}

	public void setVendorId(Long vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorCompany() {
		return vendorCompany;
	}

	public void setVendorCompany(String vendorCompany) {
		this.vendorCompany = vendorCompany;
	}

	public String getVendorContactNo() {
		return vendorContactNo;
	}

	public void setVendorContactNo(String vendorContactNo) {
		this.vendorContactNo = vendorContactNo;
	}

	public String getVendorEmailId() {
		return vendorEmailId;
	}

	public void setVendorEmailId(String vendorEmailId) {
		this.vendorEmailId = vendorEmailId;
	}

	public String getCreatedDT() {
		return createdDT;
	}

	public void setCreatedDT(String createdDT) {
		this.createdDT = createdDT;
	}

	public String getUpdatedDT() {
		return updatedDT;
	}

	public void setUpdatedDT(String updatedDT) {
		this.updatedDT = updatedDT;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getUpDatedUser() {
		return upDatedUser;
	}

	public void setUpDatedUser(String upDatedUser) {
		this.upDatedUser = upDatedUser;
	}

	@PostLoad
	void postload() {
		setCreatedDT(DateUtils.convertToSimpleDateTimeFormat(getCreatedDate()));
		setUpdatedDT(DateUtils.convertToSimpleDateTimeFormat(getUpdatedDate()));

	}

}
