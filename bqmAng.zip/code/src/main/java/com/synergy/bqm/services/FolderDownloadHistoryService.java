package com.synergy.bqm.services;

import com.synergy.bqm.models.FolderDownloadHistory;

public interface FolderDownloadHistoryService {
	
	public void createFolderDownloadInfo(FolderDownloadHistory folderDownloadHistory);

}
