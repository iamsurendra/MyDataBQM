package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.Role;

@Repository
public class RolesDAOImpl extends BaseDAOImpl<Role, Integer> implements RolesDAO {

	public RolesDAOImpl() {
		super(Role.class);
		// TODO Auto-generated constructor stub
	}

	public List<String> getRoleNames() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Role> root = criteriaQuery.from(Role.class);
		criteriaQuery.select(root.get("roleName")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<Role> getRoleInfoById(List<Integer> ids) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Role> criteriaQuery = criteriaBuilder.createQuery(Role.class);
		Root<Role> root = criteriaQuery.from(Role.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(criteriaBuilder.in(root.get("roleId")).value(ids));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<Role> findAllRoles() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Role> criteriaQuery = criteriaBuilder.createQuery(Role.class);
		Root<Role> root = criteriaQuery.from(Role.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(criteriaBuilder.isNotNull(root.get("roleJson")));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public String getRoleNameById(Integer id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Role> root = criteriaQuery.from(Role.class);
		criteriaQuery.select(root.get("roleName"));
		criteriaQuery.where(criteriaBuilder.equal(root.get("roleId"), id));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}
	
	public List<String> getRoleNamesByListOfRoleIds(List<Integer>roleIds) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Role> root = criteriaQuery.from(Role.class);
		criteriaQuery.select(root.get("roleName")).distinct(true);
		criteriaQuery.where(root.get("roleId").in(roleIds));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
}
