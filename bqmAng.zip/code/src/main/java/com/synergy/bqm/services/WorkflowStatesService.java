package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.WorkflowStates;


public interface WorkflowStatesService {
	
	public List<WorkflowStates> saveWorkflowStates(Integer workFlowId,List<Integer> deleteStateIdsList,List<WorkflowStates> workflowStates);
	
	public List<WorkflowStates> getWorkflowStatesById(Integer workflowId);
	
	public void deleteWorkFlowStates(List<Integer> workflowIds);
	
	public void saveWorkflowNavigation(List<WorkflowStates> workflowStates);
	
	public List<Integer> getTargetIdsByStateId(Integer Id);
	
}
