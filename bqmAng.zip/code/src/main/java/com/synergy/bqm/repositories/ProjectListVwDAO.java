package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.ProjectListVw;

public interface ProjectListVwDAO extends BaseDAO<ProjectListVw, Integer>{
	
	public List<ProjectListVw> getProjectInfoByProjectIds(List<Integer> projectIds);

}
