package com.synergy.bqm.constants;

public enum ProjectType {
	RESIDENTIAL,MEDICALCARE;

}
