package com.synergy.bqm.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.synergy.bqm.json.WorkflowStateDTO;
import com.synergy.bqm.models.Workflow;
import com.synergy.bqm.models.WorkflowStates;
import com.synergy.bqm.services.WorkFlowService;
import com.synergy.bqm.services.WorkflowStatesService;

@RestController
@RequestMapping("/api/workflow")

public class WorkFlowController {

	@Autowired
	WorkFlowService workFlowService;

	@Autowired
	WorkflowStatesService workflowStatesService;

	// Retrieve All WorkFlows
	@RequestMapping(value = "/findAllWorkFlows", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Workflow> findAll() {
		return workFlowService.findAll();

	}

	// Retrieve WorkFlow Object By Id
	@RequestMapping(value = "/workFlowById/{workFlowId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Workflow workFlowById(@PathVariable("workFlowId") Integer workFlowId) {
		return workFlowService.findOne(workFlowId);

	}

	// Retrieve All Design WorkFlows
	@RequestMapping(value = "/getAllDesignWorkFlows", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Workflow> getAllDesignWorkFlows() {
		return workFlowService.getAllDesignWorkFlows();

	}

	// Create or update WorkFlow
	@RequestMapping(value = "/saveWorkflow", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Workflow saveWorkflow(@RequestBody Workflow workflow) {
		return workFlowService.saveWorkflow(workflow);
	}

	// Delete WorkFlow
	@RequestMapping(value = "/deleteWorkflowBYId", method = RequestMethod.POST)
	public void deleteworkflowBYId(@RequestParam("Id") Integer Id) {
		workFlowService.deleteworkflowBYId(Id);

	}

	// Retrieve all WorkFlowStates
	@RequestMapping(value = "/getWorkflowStatesById", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<WorkflowStates> getWorkflowStatesById(@RequestParam("workflowId") Integer workflowId  ) {
		return workflowStatesService.getWorkflowStatesById(workflowId);

	}

	// Save WorkFlowStates
	@RequestMapping(value = "/saveWorkFlowStates", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<WorkflowStates> createWorkFlowStates(@RequestBody WorkflowStateDTO workflowStateDTO) {
		return workflowStatesService.saveWorkflowStates(workflowStateDTO.getWorkflowId(),
				workflowStateDTO.getDeletedIds(), workflowStateDTO.getStates());
	}

	// Save TargetStates
	@RequestMapping(value = "/saveWorkFlowNavigation", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void saveWorkflowNavigation(@RequestBody List<WorkflowStates> workflowStates) {
		workflowStatesService.saveWorkflowNavigation(workflowStates);

	}

	// Retrieve all Targetstates By CurrentStateId
	@RequestMapping(value = "/getTargetIdsByStateId/{Id}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<Integer> getTargetIdsByStateId(@PathVariable("Id") Integer Id) {
		return workflowStatesService.getTargetIdsByStateId(Id);

	}

	// Retrieve WorkflowInfo by WorkflowId
	@RequestMapping(value = "/findOne/{workflowId}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<WorkflowStates> getWorkflowsInfo(@PathVariable("workflowId") Integer workflowId) {
		return workFlowService.getWorkflowsInfo(workflowId);
	}

	// Retrieve all TargetStates By stateId

	@RequestMapping(value = "/getTargetStates/{stateId}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<WorkflowStates> getTargetStates(@PathVariable("stateId") Integer stateId) {
		return workFlowService.getTargetStates(stateId);
	}
	
	@RequestMapping(value = "/checkRolesInProject", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<String> CheckProjectRolesInWorkflow(@RequestParam("workFlowId")Integer workFlowId, @RequestParam("departmentId") Integer departmentId,@RequestParam("projectId") Integer projectId){
		return workFlowService.CheckProjectRolesInWorkflow(workFlowId, departmentId, projectId);
	}
	
	
	
	

}
