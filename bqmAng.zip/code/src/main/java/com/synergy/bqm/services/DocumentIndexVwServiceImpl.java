package com.synergy.bqm.services;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.documents.DocumentChecklist;
import com.synergy.bqm.json.DocumentChecklistDTO;
import com.synergy.bqm.json.NormalSearchDTO;
import com.synergy.bqm.models.ActivityWorkflowMapping;
import com.synergy.bqm.models.DocumentIndexVw;
import com.synergy.bqm.models.Role;
import com.synergy.bqm.models.WorkflowStates;
import com.synergy.bqm.mongoRepositories.DocumentChecklistRepository;
import com.synergy.bqm.repositories.ActivityWorkflowMappingDAO;
import com.synergy.bqm.repositories.DocumentIndexVwDAO;
import com.synergy.bqm.repositories.ProjectMemberDAO;
import com.synergy.bqm.repositories.RolesDAO;
import com.synergy.bqm.repositories.WorkflowStatesDAO;

@Service("DocumentIndexVwService")
public class DocumentIndexVwServiceImpl implements DocumentIndexVwService {

	@Autowired
	DocumentIndexVwDAO documentIndexVwDAO;

	@Autowired
	ActivityWorkflowMappingDAO activityWorkflowMappingDAO;

	@Autowired
	DocumentChecklistRepository documentChecklistRepository;

	@Autowired
	WorkflowStatesDAO workflowStatesDAO;

	@Autowired
	ProjectMemberDAO projectMemberDAO;

	@Autowired
	RolesDAO rolesDAO;

	@Transactional
	public List<DocumentIndexVw> getDocumentIndexVwByProjectId(Integer projectId) {
		return documentIndexVwDAO.getDocumentIndexVwListByProjectId(projectId);

	}

	@Transactional
	public List<DocumentIndexVw> getFolderDocumentIndexSearch(Integer projectId, String searchValues)
			throws ParseException {
		return documentIndexVwDAO.getFolderDocumentIndexSearch(projectId, searchValues);

	}

	@Transactional
	public DocumentIndexVw getDocumentIndexById(Integer Id) {
		return documentIndexVwDAO.findOne(Id);

	}

	@Transactional
	public DocumentIndexVw getDocumentIndexViewByIndexId(Integer documentIndexid) {
		List<DocumentChecklistDTO> documentDto = new ArrayList<DocumentChecklistDTO>();
		// retrieving documentIndexObj by IndexId

		DocumentIndexVw documentIndexObj = documentIndexVwDAO.findOne(documentIndexid);
		if (documentIndexObj.getCurrentResponsibleId() != null) {
			String role = getRoleId(documentIndexObj.getProjectId(),
					documentIndexObj.getCurrentResponsibleId().longValue(), documentIndexObj.getDepartmentId());

			if (role != null) {
				documentIndexObj.setRole(role);
			}
		}
		if (documentIndexObj != null) {
			// getting multiple checklist
			List<ActivityWorkflowMapping> mappingobj = activityWorkflowMappingDAO
					.getActivityWorkflowMappingObjListByIndexId(documentIndexid);
			for (ActivityWorkflowMapping map : mappingobj) {
				DocumentChecklistDTO dto = new DocumentChecklistDTO();
				if (map.getChecklistId() != null) {
					DocumentChecklist documentChecklist = documentChecklistRepository.findOne(map.getChecklistId());

					if (documentChecklist != null) {
						dto.setDocumentCheckListName(documentChecklist.getChecklistName());
						dto.setDocumentChecklist(documentChecklist);
					}
				}
				dto.setStateId(map.getStateId());
				WorkflowStates statesObj = workflowStatesDAO.findOne(map.getStateId());
				dto.setStateName(statesObj.getName());
				documentDto.add(dto);
			}
		}
		documentIndexObj.setDocumentChecklistDto(documentDto);
		return documentIndexObj;
	}

	private String getRoleId(Integer projectId, Long userId, Integer deptId) {
		Integer roleId = projectMemberDAO.getRoleId(projectId, userId, deptId);
		Role roleObj = new Role();
		if (roleId != null) {
			roleObj = rolesDAO.findOne(roleId);
		}
		return roleObj.getRoleName();
	}

	@Transactional
	public List<DocumentIndexVw> getDocumentIndexNotification(Integer userId) {
		return documentIndexVwDAO.getDocumentIndexNotification(userId);

	}

	@Transactional
	public List<DocumentIndexVw> getFolderDocumentListByMainActivityAndProjectId(Integer activityId,
			Integer projectId) {
		return documentIndexVwDAO.getFolderDocumentListByMainActivityAndProjectId(activityId, projectId);

	}

	public List<DocumentIndexVw> getFolderDocumentIndexNormalSearch(NormalSearchDTO normalSearch) {
		return documentIndexVwDAO.getFolderDocumentIndexNormalSearch(normalSearch);
	}

	@Transactional
	public Map<Integer, Long> countOfDocumentIndexBystate(Integer projectId) {
		Map<Integer, Long> counOfIndex = new HashMap<Integer, Long>();
		List<DocumentIndexVw> documentIndexVwcount = documentIndexVwDAO.countOfDocumentIndexBystate(projectId);
		// List<String>names=workflowStatesDAO.getWorkflowStateNamesByworkflowId(documentIndexVwcount.get(0).getWorkflowId());
		for (DocumentIndexVw count : documentIndexVwcount) { // open
			counOfIndex.put(count.getActivityStage(), count.getIndexCount());
		}
		if (!counOfIndex.containsKey(0)) {
			counOfIndex.put(0, 0l);
		}
		if (!counOfIndex.containsKey(1)) {
			counOfIndex.put(1, 0l);
		}
		if (!counOfIndex.containsKey(2)) {
			counOfIndex.put(2, 0l);
		}
		return counOfIndex;

	}

	public Map<String, Map<Integer, Long>> countOfDocumentIndexByDepartment(Integer projectId) {
		Map<String, Map<Integer, Long>> countOfIndex = new HashMap<String, Map<Integer, Long>>();

		List<DocumentIndexVw> documentIndexVwcount = documentIndexVwDAO.countOfDocumentIndexByDepartment(projectId);
		for (DocumentIndexVw count : documentIndexVwcount) {
			Map<Integer, Long> inMap = new HashMap<Integer, Long>();
			if (countOfIndex.containsKey(count.getDepartment())) {
				inMap = countOfIndex.get(count.getDepartment());
				inMap.put(count.getActivityStage(), count.getIndexCount());
				// countOfIndex.put(count.getDepartment(), inMap);
			} else {
				countOfIndex.put(count.getDepartment(), inMap);
				inMap.put(count.getActivityStage(), count.getIndexCount());

			}

		}
		// checking not existing values
		for (Entry<String, Map<Integer, Long>> values : countOfIndex.entrySet()) {
			if (!values.getValue().containsKey(0)) {
				values.getValue().put(0, 0l);
			}
			if (!values.getValue().containsKey(1)) {
				values.getValue().put(1, 0l);
			}
			if (!values.getValue().containsKey(2)) {
				values.getValue().put(2, 0l);
			}

		}

		return countOfIndex;

	}
	
	@Transactional
	public Map<String, Map<Integer, Long>> countOfDocumentIndexByHierarchy(Integer projectId) {
		Map<String, Map<Integer, Long>> countOfIndex = new HashMap<String, Map<Integer, Long>>();

		List<DocumentIndexVw> documentIndexVwcount = documentIndexVwDAO.countOfDocumentIndexByHierarchy(projectId);
		for (DocumentIndexVw count : documentIndexVwcount) {
			Map<Integer, Long> inMap = new HashMap<Integer, Long>();
			if (countOfIndex.containsKey(count.getHierarchy())) {
				inMap = countOfIndex.get(count.getHierarchy());
				inMap.put(count.getActivityStage(), count.getIndexCount());
				// countOfIndex.put(count.getDepartment(), inMap);
			} else {
				countOfIndex.put(count.getHierarchy(), inMap);
				inMap.put(count.getActivityStage(), count.getIndexCount());

			}

		}
		// checking not existing values
		for (Entry<String, Map<Integer, Long>> values : countOfIndex.entrySet()) {
			if (!values.getValue().containsKey(0)) {
				values.getValue().put(0, 0l);
			}
			if (!values.getValue().containsKey(1)) {
				values.getValue().put(1, 0l);
			}
			if (!values.getValue().containsKey(2)) {
				values.getValue().put(2, 0l);
			}

		}

		return countOfIndex;

	}

}
