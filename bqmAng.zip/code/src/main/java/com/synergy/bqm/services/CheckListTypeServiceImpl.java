package com.synergy.bqm.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synergy.bqm.json.CheckListTypeDTO;
import com.synergy.bqm.models.CheckListType;
import com.synergy.bqm.repositories.CheckListTypeDAO;

@Service("ChecklisttypeService")
public class CheckListTypeServiceImpl implements CheckListTypeService {

	@Autowired
	CheckListTypeDAO checklisttypeDAO;

	@Transactional
	public List<CheckListType> getAllChecklistType() {
		return checklisttypeDAO.findAll();

	}

	@Transactional
	public List<String> getCheckListTypeName() {
		return checklisttypeDAO.getCheckListTypeNames();

	}

	@Transactional
	public void deleteCheckListTypeById(Integer Id) {
		CheckListType deleteCheckListType = checklisttypeDAO.findOne(Id);
		checklisttypeDAO.delete(deleteCheckListType);

	}

	// create or update checklist types
	@Transactional
	public void createAndUpdateChecklisttypes(CheckListTypeDTO CheckListTypeDTO) {

		if (!CheckListTypeDTO.getChecklistTypes().isEmpty()) {
			for (CheckListType checklisttype : CheckListTypeDTO.getChecklistTypes()) {
				if (checklisttype.getCheckListTypeId() == null) {
					checklisttypeDAO.create(checklisttype);
				} else {
					checklisttypeDAO.update(checklisttype);
				}
			}

		}

		if (!CheckListTypeDTO.getDeletedIds().isEmpty()) {
			List<CheckListType> checkListTypes = checklisttypeDAO
					.getCheckListTypeInfoById(CheckListTypeDTO.getDeletedIds());
			for (CheckListType checkListType : checkListTypes) {
				checklisttypeDAO.delete(checkListType);
			}
		}
	}

}
