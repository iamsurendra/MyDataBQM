package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "foldertemplate_dept_mapping")
public class FolderTemplateDeptMapping implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	@Column(name = "id")
	private Integer id;

	@Column(name = "department_id")
	private Integer departmentId;

	@Column(name = "folder_template_id")
	private Integer folderTemplateId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public Integer getFolderTemplateId() {
		return folderTemplateId;
	}

	public void setFolderTemplateId(Integer folderTemplateId) {
		this.folderTemplateId = folderTemplateId;
	}

}
