package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.ProjectType;

public class ProjectTypeDTO {
	
	private List<ProjectType>projectTypeList;
	private List<Integer>ids;
	
	//Getters and Setters
	
	public List<ProjectType> getProjectTypeList() {
		return projectTypeList;
	}
	public void setProjectTypeList(List<ProjectType> projectTypeList) {
		this.projectTypeList = projectTypeList;
	}
	public List<Integer> getIds() {
		return ids;
	}
	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}
	
	
	
	

}
