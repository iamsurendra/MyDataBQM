package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.FolderTemplateDeptMapping;

@Repository
public class FolderTemplateDeptMappingDAOImpl extends BaseDAOImpl<FolderTemplateDeptMapping, Integer>
		implements FolderTemplateDeptMappingDAO {

	public FolderTemplateDeptMappingDAOImpl() {
		super(FolderTemplateDeptMapping.class);

	}

	public List<FolderTemplateDeptMapping> getDepartmentTemplateMapping(Integer folderTemplateId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderTemplateDeptMapping> criteriaQuery = criteriaBuilder
				.createQuery(FolderTemplateDeptMapping.class);
		Root<FolderTemplateDeptMapping> root = criteriaQuery.from(FolderTemplateDeptMapping.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("folderTemplateId"), folderTemplateId));
		;
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<Integer> getTemplateIds(Integer departmentId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = criteriaBuilder.createQuery(Integer.class);
		Root<FolderTemplateDeptMapping> root = criteriaQuery.from(FolderTemplateDeptMapping.class);
		criteriaQuery.select(root.get("folderTemplateId"))
				.where(criteriaBuilder.equal(root.get("departmentId"), departmentId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<Integer> getDepartmentIds(Integer folderTemplateId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = criteriaBuilder.createQuery(Integer.class);
		Root<FolderTemplateDeptMapping> root = criteriaQuery.from(FolderTemplateDeptMapping.class);
		criteriaQuery.select(root.get("departmentId"))
				.where(criteriaBuilder.equal(root.get("folderTemplateId"), folderTemplateId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<Integer> getFolderTemplateIds() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<FolderTemplateDeptMapping> root = criteriaQuery.from(FolderTemplateDeptMapping.class);
		criteriaQuery.select(root.get("folderTemplateId")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
