package com.synergy.bqm.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.mongodb.gridfs.GridFSDBFile;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.documents.Checklist;
import com.synergy.bqm.models.Project;
import com.synergy.bqm.models.ProjectMember;
import com.synergy.bqm.models.VendorProjectMapping;
import com.synergy.bqm.mongoRepositories.CheckListRepository;
import com.synergy.bqm.mongoRepositories.FileMongoDAO;
import com.synergy.bqm.repositories.ProjectDAO;
import com.synergy.bqm.repositories.ProjectMemberDAO;
import com.synergy.bqm.repositories.VendorProjectMappingDAO;

@Service("projectService")
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	ProjectDAO projectDAO;

	@Autowired
	ProjectMemberDAO projectMemberDAO;

	@Autowired
	VendorProjectMappingDAO vendorProjectMappingDAO;

	@Autowired
	FileMongoDAO fileMongoDAO;

	@Autowired
	CheckListRepository checkListRepository;

	@Transactional
	public Project createProject(Project project) {
		Long count = projectDAO.projectNameExists(project.getProjectName());
		if(project.getProjectMembers().isEmpty()){

			throw new AppException(MessagesEnum.PLEASE_ADD_AT_LEAST_ONE_TEAM_MEMBER );
		}
		if (count == null || count == 0) {
			Project projectObj = projectDAO.create(project);
			List<ProjectMember> members = new ArrayList<>();
			members.addAll(projectObj.getProjectMembers());
			for (ProjectMember member : members) {
				member.setProject(projectObj);
			}
			List<VendorProjectMapping> vendors = new ArrayList<>();
			vendors.addAll(projectObj.getVendorProjectMapping());
			for (VendorProjectMapping vendorService : vendors) {
				vendorService.setProject(projectObj);
			}
			return projectObj;
		} else {
			throw new AppException(MessagesEnum.DUPLICATE_PROJECT_NAME);

		}

	}

	@Transactional
	public Project getProjectByProjectId(Integer projectId) {
		return projectDAO.findOne(projectId);
	}

	@Transactional
	public List<Project> getAllProjects() {
		return projectDAO.findAll();
	}

	@Transactional
	public void UpdateLogo(MultipartFile file, Integer Id) throws IOException {
		Project project = projectDAO.findOne(Id);
		if(project.getLogo()!=null){
			fileMongoDAO.deletefiles(project.getLogo());
		}
		if(file!=null){
			String id = fileMongoDAO.storeImage(file.getInputStream(), null);
			project.setLogo(id);
			projectDAO.update(project);
		}
	}

	public GridFSDBFile downloadProjectLogo(Integer projectId) {
		Project project = projectDAO.findOne(projectId);
		return fileMongoDAO.getById(project.getLogo());
	}

	@Transactional
	@Override
	public List<Project> getAllArchiveProjects() {
		return projectDAO.getAllArchiveProjects();

	}

	@Transactional
	@Override
	public void deleteProject(Integer projectId) {
		Project projectObj = projectDAO.findOne(projectId);
		projectObj.setArchive(Boolean.TRUE);
		projectDAO.update(projectObj);

	}

	@Transactional
	@Override
	public void updateProject(Project project) {

		// Updating projectName in checklist
		List<Checklist> checklists = checkListRepository.getCheckListByProjectId(project.getProjectId());
		if (!checklists.isEmpty()) {
			if (!project.getProjectName().equals(checklists.get(0).getProjectName())) {
				for (Checklist checklist : checklists) {
					checklist.setProjectName(project.getProjectName());
					checkListRepository.save(checklist);
				}
			}
		}
		Project projectObj = projectDAO.findOne(project.getProjectId());
		projectObj.setProjectName(project.getProjectName());
		projectObj.setProjectNumber(project.getProjectNumber());
		projectObj.setEnquiryNo(project.getEnquiryNo());
		projectObj.setType(project.getType());
		projectObj.setSubType(project.getSubType());
		projectObj.setStatus(project.getStatus());
		projectObj.setStage(project.getStage());
		projectObj.setStartDate(project.getStartDate());
		projectObj.setEndDate(project.getEndDate());
		projectObj.setProjectManager(project.getProjectManager());
		projectObj.setRole(project.getRole());
		projectObj.setClientContact(project.getClientContact());
		projectObj.setProjectClient(project.getProjectClient());
		projectObj.setJobNo(project.getJobNo());
		projectObj.setLocation(project.getLocation());
		projectObj.setUpdatedDate(DateUtils.getCurrentISTDateTime());
		projectObj.setUpdatedBy(ThreadLocalUtil.getUserName());
		for (ProjectMember member : project.getProjectMembers()) {
			if (member.getId() < 1 || member.getId() == null) {
				member.setId(null);
				member.setProject(project);
				projectMemberDAO.create(member);
			} else {
				member.setProject(project);
				projectMemberDAO.update(member);
			}
		}

		for (VendorProjectMapping mapping : project.getVendorProjectMapping()) {
			if (mapping.getId() == null) {
				mapping.setId(null);
				mapping.setProject(project);
				vendorProjectMappingDAO.create(mapping);
			} else {
				mapping.setProject(project);
				vendorProjectMappingDAO.update(mapping);
			}
		}

		// deleting ProjectMembers
		if (project.getDeletedProjectMembers() != null) {
			for (Integer projectMember : project.getDeletedProjectMembers()) {
				ProjectMember member = projectMemberDAO.findOne(projectMember);
				projectObj.getProjectMembers().remove(member);
				// projectMemberDAO.delete(member);
			}
		}

		// deleting Vendors
		if (project.getDeletedVendors() != null) {
			for (Integer vendor : project.getDeletedVendors()) {
				VendorProjectMapping projectMapping = vendorProjectMappingDAO.findOne(vendor);
				projectObj.getVendorProjectMapping().remove(projectMapping);
			}
		}
		projectDAO.update(projectObj);
	}

	@Transactional
	@Override
	public void applyTemplateFlagForProject(Integer projectId) {
		Project project = projectDAO.findOne(projectId);
		project.setTemplate(Boolean.TRUE);
		projectDAO.update(project);

	}

	@Transactional
	@Override
	public Project getProjectInfoById(Integer projectId) {
		return projectDAO.findOne(projectId);

	}

	@Transactional
	public Long countOfProjects() {
		return projectDAO.countOfProjects();
	} 

	@Transactional
	public void deleteProjectLogo(Integer projectId) {
		Project projectObj = projectDAO.findOne(projectId);
		fileMongoDAO.deletefiles(projectObj.getLogo());
		projectObj.setLogo(null);
		projectDAO.update(projectObj);

	}

}