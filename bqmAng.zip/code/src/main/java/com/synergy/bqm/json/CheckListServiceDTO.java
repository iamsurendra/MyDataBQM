package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.ChecklistService;

public class CheckListServiceDTO {

	List<ChecklistService> checkListServices;
	List<Integer> deletedIds;

	// getters and setters

	public List<Integer> getDeletedIds() {
		return deletedIds;
	}

	public List<ChecklistService> getCheckListServices() {
		return checkListServices;
	}

	public void setCheckListServices(List<ChecklistService> checkListServices) {
		this.checkListServices = checkListServices;
	}

	public void setDeletedIds(List<Integer> deletedIds) {
		this.deletedIds = deletedIds;
	}

}
