package com.synergy.bqm.services;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.guvvala.framework.constants.ErrorCodeEnum;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.AppUser;
import com.guvvala.framework.util.AppWebUtils;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.PasswordEncryptor;
import com.guvvala.framework.util.PasswordGenerator;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.mongodb.gridfs.GridFSDBFile;
import com.synergy.bqm.constants.BqmConstants;
import com.synergy.bqm.constants.MailTemplateEnum;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.constants.UserStatus;
import com.synergy.bqm.json.UserJson;
import com.synergy.bqm.models.Department;
import com.synergy.bqm.models.Designation;
import com.synergy.bqm.models.ProjectMember;
import com.synergy.bqm.models.User;
import com.synergy.bqm.mongoRepositories.FileMongoDAO;
import com.synergy.bqm.repositories.DepartmentDAO;
import com.synergy.bqm.repositories.DesignationDAO;
import com.synergy.bqm.repositories.OauthAccessTokenDAO;
import com.synergy.bqm.repositories.ProjectMemberDAO;
import com.synergy.bqm.repositories.UserDAO;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userDAO;

	@Autowired
	DepartmentDAO departmentDAO;

	@Autowired
	DesignationDAO designationDAO;

	@Autowired
	ProjectMemberDAO projectMemberDAO;

	@Autowired
	private MailService ms;

	@Autowired
	OauthAccessTokenDAO oAuthAccessTokenDAO;

	@Autowired
	FileMongoDAO fileMongoDAO;

	@Transactional
	public List<User> getUserNameList() {
		return userDAO.getUserNameList();
	}

	@Transactional
	public User getUser(String uname) {
		return userDAO.getUser(uname);
	}

	@Transactional
	public boolean uniqueUserName(String userName) {
		return userDAO.uniqueUserName(userName);
	}

	public boolean uniqueEmail(String email) {
		return userDAO.validateEmail(email);

	}

	public User getUserForLogin(String uname) {
		User user = userDAO.getUser(uname);
		return user;
	}

	@Transactional
	public List<String> getMailIdsByUserIds(List<Long> userIds) {
		return userDAO.getMailIdsByUserIds(userIds);
	}

	// create new user
	@Transactional
	public Integer createNewUser(User user) {
		if (uniqueUserName(user.getUserName())) {
			throw new AppException(MessagesEnum.LOGIN_NAME_ALREADY_EXISTS);
		}
		/*
		 * if (uniqueEmail(user.getUserEmail())) { throw new
		 * AppException(MessagesEnum.USER_EMAIL_EXIST); }
		 */ else {
			String password = String.valueOf(PasswordGenerator.generatePassword());
			String salt = PasswordEncryptor.generateSalt();
			String hash = PasswordEncryptor.applySHA256(password + salt);
			user.setUserSalt(salt);
			user.setPwdHash(hash);
			user.setLastLoginDate(DateUtils.getCurrentISTDateTime());
			user.setUserStatus(UserStatus.USER_FIRST_LOGIN.value);
			// user.setPasswordExpirationDate(DateUtils.addDays(Calendar.getInstance().getTime(),
			// 90));
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(BqmConstants.PASSWORD, password);
			values.put(BqmConstants.LOGIN_NAME, user.getUserName());
			values.put(BqmConstants.FNAME, user.getUserFirstName());
			values.put(BqmConstants.EMAIL, user.getUserEmail());
			String[] to = { user.getUserEmail() };
			Object[] subject = { user.getUserName() };
			ms.sendEmail(MailTemplateEnum.CREATE_USER, values, to, subject);
			User userObject = userDAO.create(user);
			return userObject.getUserId().intValue();

		}

	}

	public boolean isValidPassword(User user, String password) {
		return PasswordEncryptor.isValidPassword(password + user.getUserSalt(), user.getPwdHash());
	}

	@Transactional
	@Override
	public User validatePassword(UserJson userJson) {
		User user = userDAO.getUser(userJson.getUserName());
		if (user != null) {

			if (isValidPassword(user, userJson.getPassword())) {
				ThreadLocalUtil.setThreadVariable(ThreadLocalUtil.CURRENT_USER, user);
				return user;
			}

		}
		return new User();
	}

	@Transactional
	public AppUser getUserForLogin(String userNameOrEmail, String password) {
		AppUser appUser = null;
		User user = userDAO.getUser(userNameOrEmail);
		if (user == null) {
			throw new AppException(ErrorCodeEnum.INVALID_EMAIL_OR_USERNAME.key);
		} else if (user != null) {
			ThreadLocalUtil.setThreadVariable(ThreadLocalUtil.USER_NAME, user.getUserName());
			boolean valid = false;
			/*
			 * if (user.hasPasswordExpired()) {
			 * user.setUserStatus(Integer.valueOf(UserStatus.USER_EXPIRED.value)
			 * ); }
			 */ if (user.getUserStatus().equals(Integer.valueOf(UserStatus.USER_DISABLED.value))) {
				throw new AppException(ErrorCodeEnum.USER_DISABLED_MSG.key);
			} else if (user.getUserStatus().equals(Integer.valueOf(UserStatus.USER_LOCKED.value))) {
				throw new AppException(ErrorCodeEnum.USER_LOCKED_MSG.key);
			} else {
				int loginAttemptCount = user.getLoginAttempts();
				valid = isValidPassword(user, password);
				if (valid) {
					user.setLastLoginDate(new Date());
					user.setLoginAttempts(0);
					oAuthAccessTokenDAO.deleteOauthTokenName(userNameOrEmail);
					user = userDAO.update(user);
				} else {
					++loginAttemptCount;
					if (loginAttemptCount >= 3) {
						user.setUserStatus(UserStatus.USER_LOCKED.value);
					}
					user.setLoginAttempts(loginAttemptCount);
					user = userDAO.update(user);
				}
			}
			appUser = (valid ? new AppUser(user) : null);
		}
		return appUser;
	}

	@Transactional
	public void updateUser(User user) {
		User updateUser = userDAO.getUser(user.getUserName());
		updateUser.setUserAddress(user.getUserAddress());
		updateUser.setUserCompany(user.getUserCompany());
		updateUser.setUserDesignation(user.getUserDesignation());
		updateUser.setUserDesignationID(user.getUserDesignationID());
		updateUser.setDepartmentId(user.getDepartmentId());

		User userObj = userDAO.getUserByemailId(user.getUserEmail());

		if (userObj != null && !(userObj.getUserId().equals(user.getUserId()))) {

			throw new AppException(MessagesEnum.USER_EMAIL_EXIST);

		}

		updateUser.setUserEmail(user.getUserEmail());
		updateUser.setUserFaxNo(user.getUserFaxNo());
		updateUser.setUserHomeContactNo(user.getUserHomeContactNo());
		updateUser.setUserFirstName(user.getUserFirstName());
		updateUser.setUserLastName(user.getUserLastName());
		updateUser.setAdmin(user.getAdmin());
		updateUser.setAccessToCreateProject(user.getAccessToCreateProject());
		updateUser.setUserOfficeContactNo(user.getUserOfficeContactNo());
		User userObject = userDAO.update(updateUser);
		List<ProjectMember> projectmembers = projectMemberDAO.getprojectInfoByUserId(userObject.getUserId().intValue());
		for (ProjectMember member : projectmembers) {
			member.setDepartmentId(userObject.getDepartmentId());
			member.setDesignationId(userObject.getUserDesignationID());
			projectMemberDAO.update(member);
		}

		/*
		 * Map<String, Object> values = new HashMap<String, Object>();
		 * values.put(BqmConstants.FNAME, user.getUserFirstName()); String[] to
		 * = { user.getUserEmail() };
		 * 
		 * ms.sendEmail(MailTemplateEnum.UPDATE_USER, values, to);
		 */

	}

	@Transactional
	public void updateUserImage(Integer Id, MultipartFile file) throws IOException {
		User user = userDAO.findOne(Id.longValue());
		if (user.getUserImage() != null) {
			fileMongoDAO.deletefiles(user.getUserImage());
		}
		String id = fileMongoDAO.storeImage(file.getInputStream(), null);
		user.setUserImage(id);
		userDAO.update(user);
	}

	@Transactional
	public void deleteUserImage(Integer userId) {
		User user = userDAO.findOne(userId.longValue());
		fileMongoDAO.deletefiles(user.getUserImage());
		user.setUserImage(null);
		userDAO.update(user);

	}

	@Transactional
	public void resetpwd(String password, String userName) {
		User user = userDAO.getUser(userName);
		String salt = PasswordEncryptor.generateSalt();
		String hash = PasswordEncryptor.applySHA256(password + salt);
		user.setUserSalt(salt);
		user.setPwdHash(hash);
		user.setUserStatus(UserStatus.USER_ENABLED.value);
		userDAO.update(user);
		Map<String, Object> values = new HashMap<String, Object>();
		values.put(BqmConstants.PASSWORD, password);
		values.put(BqmConstants.LOGIN_NAME, user.getUserName());
		values.put(BqmConstants.FNAME, user.getUserFirstName());
		String[] to = { user.getUserEmail() };
		Object[] subject = { user.getUserName() };
		ms.sendEmail(MailTemplateEnum.RESET_PASSWORD, values, to, subject);
	}

	@Transactional
	public Integer forgotPassword(String email, String userName) {
		User user = userDAO.getUserByemailIdAndUser(email, userName);

		if (user != null) {
			if (user.getUserStatus() == UserStatus.USER_INACTIVE.value) {
				return user.getUserStatus();
			} else {
				AppWebUtils.loadThreadLocalUtils(new AppUser(user));
				String password = String.valueOf(PasswordGenerator.generatePassword());
				String salt = PasswordEncryptor.generateSalt();
				String hash = PasswordEncryptor.applySHA256(password + salt);
				user.setUserSalt(salt);
				user.setPwdHash(hash);
				user.setUserStatus(UserStatus.USER_FIRST_LOGIN.value);
				Map<String, Object> values = new HashMap<String, Object>();
				values.put(BqmConstants.PASSWORD, password);
				values.put(BqmConstants.LOGIN_NAME, user.getUserName());
				values.put(BqmConstants.FNAME, user.getUserFirstName());
				String[] to = { user.getUserEmail() };
				Object[] subject = { user.getUserName() };
				ms.sendEmail(MailTemplateEnum.FORGOT_PASSWORD, values, to, subject);
			}

		} else {
			throw new AppException(MessagesEnum.INVALID_EMAIL);

		}
		User newUser = userDAO.update(user);
		return newUser.getUserStatus();

	}

	@Transactional
	public List<User> findAllUsers() {
		List<User> users = userDAO.findAll();
		for (User user : users) {
			if (user.getDepartmentId() != null) {
				Department deportment = departmentDAO.findOne(user.getDepartmentId());
				user.setDepartment(deportment.getDepartmentName());
			}
			if (user.getUserDesignationID() != null) {
				Designation designation = designationDAO.findOne(user.getUserDesignationID());
				user.setUserDesignation(designation.getDesignationName());
			}
		}
		return users;

	}

	@Transactional
	public Integer makeUserActiveOrInActive(Long userId) {
		User user = userDAO.findOne(userId);
		if (user.getUserStatus() == UserStatus.USER_INACTIVE.value) {
			user.setUserStatus(UserStatus.USER_ENABLED.value);
		} else {
			user.setUserStatus(UserStatus.USER_INACTIVE.value);
		}
		User userStatus = userDAO.update(user);
		return userStatus.getUserStatus();
	}

	@Transactional
	public Integer makeUserLockedOrUnlocked(Long userId) {
		User user = userDAO.findOne(userId);
		if (user.getUserStatus() == UserStatus.USER_LOCKED.value) {
			user.setUserStatus(UserStatus.USER_ENABLED.value);
			user.setLoginAttempts(0);
		} else {
			user.setUserStatus(UserStatus.USER_LOCKED.value);
		}
		return userDAO.update(user).getUserStatus();

	}

	@Transactional
	public User getUserInfoByUserId(Long userId) {
		User user = userDAO.findOne(userId);
		return user;
	}

	@Transactional
	public List<User> findAllNormalUsers() {

		return userDAO.findAllNormalUsers();
	}

	public GridFSDBFile downloadUsertLogo(Integer userId) {
		User user = userDAO.findOne(userId.longValue());
		String id = user.getUserImage();
		return fileMongoDAO.getById(id);
	}

}
