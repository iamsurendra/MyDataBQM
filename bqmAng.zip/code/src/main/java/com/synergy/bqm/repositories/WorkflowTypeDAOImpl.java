package com.synergy.bqm.repositories;

import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.springframework.stereotype.Repository;
import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.WorkflowType;

@Repository
public class WorkflowTypeDAOImpl extends BaseDAOImpl<WorkflowType, Integer> implements WorkflowTypeDAO{

	public WorkflowTypeDAOImpl() {
		super(WorkflowType.class);
		
	}

	@Override
	public List<String> getWorkflowTypes() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<WorkflowType> root = criteriaQuery.from(WorkflowType.class);
		criteriaQuery.select(root.get("type")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	@Override
	public List<String> getSubTypesByTypes(String type) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<WorkflowType> makeRoot = criteriaQuery.from(WorkflowType.class);
		criteriaQuery.select(makeRoot.get("subType")).distinct(true);
		criteriaQuery.where(criteriaBuilder.equal(makeRoot.get("type"), type));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<WorkflowType> getSubTypesByWorkflowType(String type) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<WorkflowType> criteriaQuery = criteriaBuilder.createQuery(WorkflowType.class);
		Root<WorkflowType> root = criteriaQuery.from(WorkflowType.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("type"), type));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	public List<WorkflowType> getWorkflowTypeInfoById(List<Integer> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<WorkflowType> criteriaQuery = builder.createQuery(WorkflowType.class);
		Root<WorkflowType> root = criteriaQuery.from(WorkflowType.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(builder.in(root.get("id")).value(Ids));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
