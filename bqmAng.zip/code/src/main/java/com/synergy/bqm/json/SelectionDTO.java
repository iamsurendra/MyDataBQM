package com.synergy.bqm.json;

public class SelectionDTO {

}
