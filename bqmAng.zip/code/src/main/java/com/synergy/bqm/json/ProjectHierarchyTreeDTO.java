package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.ProjectHierarchy;

public class ProjectHierarchyTreeDTO {

	private String label;
	private String icon;
	private ProjectHierarchy data;
	private boolean expanded;
	private List<ProjectHierarchyTreeDTO> children;

	// getters and setters

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public ProjectHierarchy getData() {
		return data;
	}

	public void setData(ProjectHierarchy data) {
		this.data = data;
	}

	public boolean isExpanded() {
		return expanded;
	}

	public void setExpanded(boolean expanded) {
		this.expanded = expanded;
	}

	public List<ProjectHierarchyTreeDTO> getChildren() {
		return children;
	}

	public void setChildren(List<ProjectHierarchyTreeDTO> children) {
		this.children = children;
	}

}
