package com.synergy.bqm.documents;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class InfoQuestionType extends BaseAnswerType{

	public static final String ANSWERTYPE= "INFO";
	
	
	public InfoQuestionType() {

	}

	@JsonCreator
	public InfoQuestionType(@JsonProperty("lineItemQuestion") String lineItemQuestion,
			@JsonProperty("lineItemToolTip") String lineItemToolTip,
			@JsonProperty("answerType") String answerType) {
		super(lineItemQuestion, lineItemToolTip, answerType);

	}
}
