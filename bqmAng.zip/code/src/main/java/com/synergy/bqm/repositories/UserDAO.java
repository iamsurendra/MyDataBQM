package com.synergy.bqm.repositories;

import java.util.List;
import java.util.Map;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.User;

public interface UserDAO extends BaseDAO<User, Long> {
	public List<User> getUserNameList();

	public User getUser(String uname);

	boolean uniqueUserName(String userName);

	boolean validateEmail(String email);

	public User getUserInfoByUserId(Long userId);

	public User getUserByemailId(String email);

	public List<User> getAllActiveAndInactiveUsers();

	public List<String> getMailIdsByUserIds(List<Long> userIds);

	public Long countOfEmailsForUpdateUser(String email);
	
	 List<User> findAllNormalUsers();
	 
	 public User getUserByemailIdAndUser(String email,String userName);
	 
	 public Map<Integer, String> getUserNamesByIds(List<Integer> userIds);
	 
	 public List<User> getUserList(List<Integer> userIds);

}
