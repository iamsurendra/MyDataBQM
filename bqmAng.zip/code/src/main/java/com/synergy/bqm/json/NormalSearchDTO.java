package com.synergy.bqm.json;

public class NormalSearchDTO {

	private String globalsearchString;

	private Integer departmentId;

	private Integer activityId;

	private Integer subActivityId;

	private Integer projectId;

	private Boolean isglobalsearch;

	private String department;

	private String stageId;

	private Integer hierarchyId;

	// getters and setters

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getStageId() {
		return stageId;
	}

	public void setStageId(String stageId) {
		this.stageId = stageId;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public String getGlobalsearchString() {
		return globalsearchString;
	}

	public void setGlobalsearchString(String globalsearchString) {
		this.globalsearchString = globalsearchString;
	}

	public Boolean getIsglobalsearch() {
		return isglobalsearch;
	}

	public void setIsglobalsearch(Boolean isglobalsearch) {
		this.isglobalsearch = isglobalsearch;
	}

	public Integer getSubActivityId() {
		return subActivityId;
	}

	public void setSubActivityId(Integer subActivityId) {
		this.subActivityId = subActivityId;
	}

	public Integer getHierarchyId() {
		return hierarchyId;
	}

	public void setHierarchyId(Integer hierarchyId) {
		this.hierarchyId = hierarchyId;
	}

}
