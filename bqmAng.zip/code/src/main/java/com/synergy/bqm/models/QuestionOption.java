package com.synergy.bqm.models;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the question_option database table.
 * 
 */
@Entity
@Table(name = "question_option")
@NamedQuery(name = "QuestionOption.findAll", query = "SELECT q FROM QuestionOption q")
public class QuestionOption implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private Long id;

	private String questionOption;

	private String questionType;

	@Transient
	private Long deletedIds;

	public QuestionOption() {
	}

	public QuestionOption(String questionOption, String questionType) {
		super();
		this.questionOption = questionOption;
		this.questionType = questionType;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getQuestionOption() {
		return questionOption;
	}

	public void setQuestionOption(String questionOption) {
		this.questionOption = questionOption;
	}

	public String getQuestionType() {
		return questionType;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	public Long getDeletedIds() {
		return deletedIds;
	}

	public void setDeletedIds(Long deletedIds) {
		this.deletedIds = deletedIds;
	}

}