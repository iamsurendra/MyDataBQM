package com.synergy.bqm.services;

public interface UserRoleMappingService {

}
