package com.synergy.bqm.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.models.ProjectListVw;
import com.synergy.bqm.models.User;
import com.synergy.bqm.repositories.ProjectListVwDAO;
import com.synergy.bqm.repositories.ProjectMemberDAO;
import com.synergy.bqm.repositories.UserDAO;

@Service
public class ProjectListVwServiceImpl implements ProjectListVwService {

	@Autowired
	ProjectListVwDAO projectListVwDAO;

	@Autowired
	ProjectMemberDAO projectMemberDAO;
	
	@Autowired 
	UserDAO userDAO;

	@Transactional
	public List<ProjectListVw> getProjectListVwInfo(Integer userId) {
		User user=userDAO.findOne(userId.longValue());
		List<Integer> projectIds = projectMemberDAO.getProjectsIdByUserIds(userId);
		if(user.getAdmin()!=null && user.getAdmin()){
			return projectListVwDAO.findAll();
		}else if (!projectIds.isEmpty()) {
			return projectListVwDAO.getProjectInfoByProjectIds(projectIds);

		} else {
			return new ArrayList<>();
		}
	}
}
