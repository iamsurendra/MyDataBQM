package com.synergy.bqm.constants;

public enum PDFTemplateEnum {

	CHECKLIST_TEMPLATE("CHECKLIST_TEMPLATE","checklistTemplate.jrxml"),
	SECTION_TEMPLATE_LIST("SECTION_LIST_TEMPLATE_INFO","sectionTemplateList.jrxml"),
	QUESTION_TEMPLATE_LIST("QUESTION_LIST_TEMPLATE_INFO","questionTemplateList.jrxml"),
	SUB_SECTION_TEMPLATE_LIST("SUB_SECTION_LIST_TEMPLATE_INFO","subSectionTemplateList.jrxml"),
	CHECKLIST("CHECKLIST","checklist.jrxml"),
	SECTION_LIST("SECTION_LIST_INFO","sectionList.jrxml"),
	QUESTION_LIST("QUESTION_LIST_INFO","questionList.jrxml"),
	SUB_SECTION_LIST("SUB_SECTION_LIST_INFO","subSectionList.jrxml"),
	DOCUMENT_ACTIVITY("DOCUMENT_ACTIVITY", "documentActivity.jrxml"),
	FOLDER_DOCUMENT_HISTORY("FOLDER_DOC_HISTORY", "folderDocumentHistory.jrxml"),
	FOLDER_HISTORY("FOLDER_HISTORY", "folderHistory.jrxml");
	
	public String filename;
	public String name;
	public static final String PATH = "pdfTemplates/";

	private PDFTemplateEnum(String name,String filename) {
		this.filename = filename;
		this.name=name;
	}

}
