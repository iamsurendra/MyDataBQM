package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.ActivityWorkflowMapping;

public interface ActivityWorkflowMappingDAO extends BaseDAO<ActivityWorkflowMapping, Integer> {
	
	public String getChecklistId(Integer indexId,Integer stateId) ;
	
	public List<ActivityWorkflowMapping> getActivityWorkflowMappingObjListByIndexId(Integer indexId);
	
	public ActivityWorkflowMapping getActivityWorkflowMapping(Integer indexId, Integer stateId);
	
	public ActivityWorkflowMapping getActivityWorkflowMappingByChecklistId(String checklistId);
	
	public List<ActivityWorkflowMapping> getActivityWorkflowMappingByWorkflowId(Integer indexId, Integer workflowId);
	
	public List<ActivityWorkflowMapping> getActivityWorkflowMappingByWorkflowId(Integer indexId);

}
