package com.synergy.bqm.repositories;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.RoleActions;

@Repository
public class RoleActionDAOImpl extends BaseDAOImpl<RoleActions, Integer> implements RoleActionDAO {

	public RoleActionDAOImpl() {
		super(RoleActions.class);
		// TODO Auto-generated constructor stub
	}

}
