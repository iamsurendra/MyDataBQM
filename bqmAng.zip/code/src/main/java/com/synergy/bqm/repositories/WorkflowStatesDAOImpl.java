package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.Workflow;
import com.synergy.bqm.models.WorkflowStates;

@Repository
public class WorkflowStatesDAOImpl extends BaseDAOImpl<WorkflowStates, Integer> implements WorkflowStatesDAO {

	public WorkflowStatesDAOImpl() {
		super(WorkflowStates.class);

	}

	public List<WorkflowStates> getWorkflowStatesById(Integer workflowId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<WorkflowStates> criteriaQuery = criteriaBuilder.createQuery(WorkflowStates.class);
		Root<WorkflowStates> root = criteriaQuery.from(WorkflowStates.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal(root.get("workflow").get("id"), workflowId));
		criteriaQuery.orderBy(criteriaBuilder.asc(root.get("seqId")));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	    public List<WorkflowStates> getOrderBySeqId(Integer workflowId){
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<WorkflowStates> criteriaQuery = criteriaBuilder.createQuery(WorkflowStates.class);
		Root<WorkflowStates> root = criteriaQuery.from(WorkflowStates.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal(root.get("workflow"), workflowId));
		criteriaQuery.orderBy(criteriaBuilder.asc(root.get("seqId")));
		return entityManager.createQuery(criteriaQuery).getResultList();
		
		
	}
	
	
	
	public void deleteWorkFlowStatesByIds(List<Integer> workflowIds) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaDelete delete = criteriaBuilder.createCriteriaDelete(WorkflowStates.class);
		Root root = delete.from(WorkflowStates.class);
		delete.where(criteriaBuilder.in(root.get("id")).value(workflowIds));
		Query query = entityManager.createQuery(delete);
		query.executeUpdate();
	}

	public List<String> getWorkflowStatesNames(List<Integer> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);
		Root<WorkflowStates> root = criteriaQuery.from(WorkflowStates.class);
		criteriaQuery.select(root.get("name"));
		criteriaQuery.where(root.get("id").in(Ids));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public String getWorkflowState(Integer Id) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);
		Root<WorkflowStates> root = criteriaQuery.from(WorkflowStates.class);
		criteriaQuery.select(root.get("name"));
		criteriaQuery.where(builder.equal(root.get("id"), Id));
		List<String> states = entityManager.createQuery(criteriaQuery).getResultList();
		if (!states.isEmpty()) {
			return states.get(0);
		}
		return null;

	}

	public List<WorkflowStates> getWorkflowStates(List<Integer> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<WorkflowStates> criteriaQuery = builder.createQuery(WorkflowStates.class);
		Root<WorkflowStates> root = criteriaQuery.from(WorkflowStates.class);
		criteriaQuery.select(builder.construct(WorkflowStates.class, root.get("id"), root.get("name")));
		criteriaQuery.where(root.get("id").in(Ids));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<Integer> getSeqIds(Integer workflowId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<WorkflowStates> root = criteriaQuery.from(WorkflowStates.class);
		criteriaQuery.select(root.get("seqId"));
		criteriaQuery.where(builder.equal(root.get("workflow").get("id"), workflowId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	
	public List<Integer> getRoleIdsByworkFlowId(Integer workflowId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<WorkflowStates> root = criteriaQuery.from(WorkflowStates.class);
		criteriaQuery.select(root.get("roleId"));
		criteriaQuery.where(builder.equal(root.get("workflow").get("id"), workflowId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public Integer getSeqIdByStateId(Integer stateId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<WorkflowStates> root = criteriaQuery.from(WorkflowStates.class);
		criteriaQuery.select(root.get("seqId"));
		criteriaQuery.where(builder.equal(root.get("id"), stateId));
		List<Integer> seqs = entityManager.createQuery(criteriaQuery).getResultList();
		if (!seqs.isEmpty()) {
			return seqs.get(0);
		}
		return null;
	}
	

	public Integer getCurrentStatusByWorkflowId(Integer workflowId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<WorkflowStates> criteriaQuery = builder.createQuery(WorkflowStates.class);
		Root<WorkflowStates> root = criteriaQuery.from(WorkflowStates.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.equal(root.get("workflow").get("id"), workflowId));
		List<WorkflowStates> workflowStatesObj = entityManager.createQuery(criteriaQuery).getResultList();
		for (WorkflowStates currentStatus : workflowStatesObj) {
			if (currentStatus.getSeqId() == 1) {
				Integer Status = currentStatus.getId();
				return Status;
			}
		}
		return null;

	}
	
	
	public List<String> getWorkflowStateNamesByworkflowId(Integer workflowId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<WorkflowStates> root = criteriaQuery.from(WorkflowStates.class);
		criteriaQuery.select(root.get("name"));
		criteriaQuery.where(criteriaBuilder.equal(root.get("workflow").get("id"), workflowId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
