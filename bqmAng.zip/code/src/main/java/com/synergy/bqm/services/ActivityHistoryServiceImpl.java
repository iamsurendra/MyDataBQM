package com.synergy.bqm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.models.ActivityHistory;
import com.synergy.bqm.repositories.ActivityHistoryDAO;

@Service
public class ActivityHistoryServiceImpl implements ActivityHistoryService {

	@Autowired
	ActivityHistoryDAO activityHistoryDAO;

	@Transactional
	public List<ActivityHistory> getActivityHistoryByIndexId(Integer indexId) {
		return activityHistoryDAO.getActivityHistoryByIndexId(indexId);
	}

	@Transactional
	public void createActivityHistory(ActivityHistory activityHistory) {
		activityHistoryDAO.create(activityHistory);

	}
}
