package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vendor_services")
public class VendorServices implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "vendor_service_id")
	private Long vendorServiceId;

	@Column(name = "vendor_service_names")
	private String vendorServiceNames;

	// Getters and Setters

	public String getVendorServiceNames() {
		return vendorServiceNames;
	}

	public Long getVendorServiceId() {
		return vendorServiceId;
	}

	public void setVendorServiceId(Long vendorServiceId) {
		this.vendorServiceId = vendorServiceId;
	}

	public void setVendorServiceNames(String vendorServiceNames) {
		this.vendorServiceNames = vendorServiceNames;
	}

}
