package com.synergy.bqm.repositories;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.User;

@Repository
public class UserDAOImpl extends BaseDAOImpl<User, Long> implements UserDAO {

	public UserDAOImpl() {
		super(User.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<User> getUserNameList() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> criteriaQuery = criteriaBuilder.createQuery(User.class);
		Root<User> root = criteriaQuery.from(User.class);
		criteriaQuery.select(root.get("userName")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<User> getAllActiveAndInactiveUsers() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> criteriaQuery = criteriaBuilder.createQuery(User.class);
		Root<User> root = criteriaQuery.from(User.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(criteriaBuilder.in(root.get("userStatus")).value(1).value(0).value(-1));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	@Override
	public User getUser(String uname) {

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> user = cQuery.from(User.class);
		cQuery.select(user).where(builder.or(builder.equal(user.get("userName"), uname)));
		List<User> userList = entityManager.createQuery(cQuery).getResultList();
		if (null != userList && !userList.isEmpty()) {
			return userList.get(0);
		} else {
			return null;
		}
	}

	public User getUserByemailId(String email) {

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> user = cQuery.from(User.class);
		cQuery.select(user).where(builder.or(builder.equal(user.get("userEmail"), email)));
		List<User> userList = entityManager.createQuery(cQuery).getResultList();
		if (null != userList && !userList.isEmpty()) {
			return userList.get(0);
		} else {
			return null;
		}
	}

	public User getUserByemailIdAndUser(String email, String userName) {

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> user = cQuery.from(User.class);
		cQuery.select(user).where(builder.and(builder.equal(user.get("userEmail"), email),
				builder.equal(user.get("userName"), userName)));
		List<User> userList = entityManager.createQuery(cQuery).getResultList();
		if (null != userList && !userList.isEmpty()) {
			return userList.get(0);
		} else {
			return null;
		}
	}

	public List<String> getMailIdsByUserIds(List<Long> userIds) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<User> root = criteriaQuery.from(User.class);
		criteriaQuery.select(root.get("userEmail")).distinct(true);
		criteriaQuery.where(criteriaBuilder.in(root.get("userId")).value(userIds));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	@Override
	public boolean uniqueUserName(String userName) {
		TypedQuery<Long> query = entityManager
				.createQuery("SELECT count(u) from User u where userName ='" + userName + "'", Long.class);
		if (query.getSingleResult() == 0) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public boolean validateEmail(String email) {
		TypedQuery<Long> query = entityManager
				.createQuery("SELECT count (e) from User e where userEmail='" + email + "'", Long.class);
		if (query.getSingleResult() == 0) {

			return false;
		} else {

			return true;
		}
	}

	public User getUserInfoByUserId(Long userId) {
		TypedQuery<User> query = entityManager.createQuery("SELECT f from User f where userId ='" + userId + "'",
				User.class);
		return query.getSingleResult();
	}

	public Long countOfEmailsForUpdateUser(String email) {
		TypedQuery<Long> query = entityManager
				.createQuery("select count(e) from User e where userEmail='" + email + "' ", Long.class);
		return query.getSingleResult();
	}

	public List<User> findAllNormalUsers() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> criteriaQuery = criteriaBuilder.createQuery(User.class);
		Root<User> root = criteriaQuery.from(User.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal(root.get("admin"), false));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public Map<Integer, String> getUserNamesByIds(List<Integer> userIds) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> criteriaQuery = criteriaBuilder.createQuery(User.class);
		Root<User> root = criteriaQuery.from(User.class);
		criteriaQuery.multiselect(root.get("userId"), root.get("userName")).distinct(true);
		criteriaQuery.where(criteriaBuilder.in(root.get("userId")).value(userIds));
		List<User> userNames = entityManager.createQuery(criteriaQuery).getResultList();
		userNames.removeAll(Collections.singleton(null));
		Map<Integer, String> userNamesIds = new LinkedHashMap<>();
		for (User userObj : userNames) {
			userNamesIds.put(userObj.getUserId().intValue(), userObj.getUserName());
		}
		return userNamesIds;

	}

	public List<User> getUserList(List<Integer> userIds) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<User> criteriaQuery = criteriaBuilder.createQuery(User.class);
		Root<User> root = criteriaQuery.from(User.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.in(root.get("userId")).value(userIds));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
