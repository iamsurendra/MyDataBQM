package com.synergy.bqm.documents;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;

@Document
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentChecklist {
	@Id
	public String id;

	private String checklistName;

	private String checklistType;

	private String checklistService;

	private String updatedBy;

	private String updatedOn;

	private List<DocumentRemarks>remarks=new ArrayList<DocumentRemarks>();
	// @JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<Section> sectionList = new ArrayList<Section>();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getChecklistName() {
		return checklistName;
	}

	public void setChecklistName(String checklistName) {
		this.checklistName = checklistName;
	}

	public String getChecklistType() {
		return checklistType;
	}

	public void setChecklistType(String checklistType) {
		this.checklistType = checklistType;
	}

	public String getChecklistService() {
		return checklistService;
	}

	public void setChecklistService(String checklistService) {
		this.checklistService = checklistService;
	}

	public List<Section> getSectionList() {
		return sectionList;
	}

	public void setSectionList(List<Section> sectionList) {
		this.sectionList = sectionList;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(String updatedOn) {
		this.updatedOn = updatedOn;
	}

	public List<DocumentRemarks> getRemarks() {
		return remarks;
	}

	public void setRemarks(List<DocumentRemarks> remarks) {
		this.remarks = remarks;
	}

}
