package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.WorkflowDTO;
import com.synergy.bqm.models.WorkflowType;

public interface WorkflowTypeService {

	public List<String> getWorkflowTypes();
	
	public List<String> getSubTypesByTypes(String type);
	
	public List<WorkflowType> getSubTypesByWorkflowType(String workflowType);
	
	public void deleteWorkflowSubType(Integer Id);
	
	public void createOrUpdateWorkflowTypes(WorkflowDTO workflowDTO) ;
	
	
	
	
}
