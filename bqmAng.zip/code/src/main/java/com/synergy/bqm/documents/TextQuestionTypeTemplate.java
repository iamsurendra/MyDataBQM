package com.synergy.bqm.documents;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TextQuestionTypeTemplate extends BaseQuestionTypeTemplate {

	public static final String QUESTION_TYPE = "TEXT";

	private String lowerLimit;
	private String upperLimit;

	@JsonCreator
	public TextQuestionTypeTemplate() {

	}

	@JsonCreator
	public TextQuestionTypeTemplate(@JsonProperty("lineItemQuestion") String lineItemQuestion,
			@JsonProperty("lineItemToolTip") String lineItemToolTip, @JsonProperty("questionType") String questionType,
			@JsonProperty("lowerLimit") String lowerLimit, @JsonProperty("upperLimit") String upperLimit) {
		super(lineItemQuestion, lineItemToolTip, questionType);
		this.lowerLimit = lowerLimit;
		this.upperLimit = upperLimit;
	}

	public String getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(String lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public String getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(String upperLimit) {
		this.upperLimit = upperLimit;
	}

}
