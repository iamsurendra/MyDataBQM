package com.synergy.bqm.json;

import com.synergy.bqm.documents.DocumentChecklist;
import com.synergy.bqm.models.DocumentIndexVw;

public class DocumentChecklistDTO {

	private DocumentChecklist DocumentChecklist;
	private DocumentIndexVw documentIndex;
	private Integer stateId;
	private String StateName;
	private String DocumentCheckListName;
	private String checklistId;
	private Integer workflowId;

	// getters and setters
	public DocumentChecklist getDocumentChecklist() {
		return DocumentChecklist;
	}

	public void setDocumentChecklist(DocumentChecklist documentChecklist) {
		DocumentChecklist = documentChecklist;
	}

	public Integer getStateId() {
		return stateId;
	}

	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}

	public String getStateName() {
		return StateName;
	}

	public void setStateName(String stateName) {
		StateName = stateName;
	}

	public DocumentIndexVw getDocumentIndex() {
		return documentIndex;
	}

	public void setDocumentIndex(DocumentIndexVw documentIndex) {
		this.documentIndex = documentIndex;
	}

	public String getDocumentCheckListName() {
		return DocumentCheckListName;
	}

	public void setDocumentCheckListName(String documentCheckListName) {
		DocumentCheckListName = documentCheckListName;
	}

	public String getChecklistId() {
		return checklistId;
	}

	public void setChecklistId(String checklistId) {
		this.checklistId = checklistId;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	

}
