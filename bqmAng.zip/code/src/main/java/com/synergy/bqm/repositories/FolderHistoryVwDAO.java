package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.FolderHistoryVw;
import com.synergy.bqm.models.FolderHistoryVwKey;

public interface FolderHistoryVwDAO extends BaseDAO<FolderHistoryVw, FolderHistoryVwKey> {

	public List<FolderHistoryVw> getFolderHistoryByFolderId(Integer folderId);
	
	public List<FolderHistoryVw> getFolderHistoryByParentId(Integer parentId);

}
