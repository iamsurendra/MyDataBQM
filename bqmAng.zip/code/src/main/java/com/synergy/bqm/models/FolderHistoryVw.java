package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "folder_history_v")
public class FolderHistoryVw implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonIgnore
	private FolderHistoryVwKey folderHistoryVwKey;

	@Column(name = "folder_id")
	private Long folderId;

	@Column(name = "folder_name")
	private String folderName;

	@Column(name = "parent_folder_id", insertable = false, updatable = false)
	private Long parentFolderId;

	@Column(name = "REVISION_TYPE", insertable = false, updatable = false)
	private Long revisionType;

	@Column(name = "LAST_UPD_DT", insertable = false, updatable = false)
	private Date lastUpdateDt;

	@Column(name = "LAST_UPD_BY")
	private String lastUpdatedDt;

	@Column(name = "LAST_UPD_BY_USER")
	private String lastUpdatedByUser;

	@Transient
	private String updatedDt;

	public FolderHistoryVw() {

	}

	public FolderHistoryVw(Long parentFolderId, Long revisionType, Date lastUpdateDt) {
		this.parentFolderId = parentFolderId;
		this.revisionType = revisionType;
		this.lastUpdateDt = lastUpdateDt;

	}

	// getters and setters

	public FolderHistoryVwKey getFolderHistoryVwKey() {
		return folderHistoryVwKey;
	}

	public void setFolderHistoryVwKey(FolderHistoryVwKey folderHistoryVwKey) {
		this.folderHistoryVwKey = folderHistoryVwKey;
	}

	public Long getFolderId() {
		return folderId;
	}

	public void setFolderId(Long folderId) {
		this.folderId = folderId;
	}

	public Long getParentFolderId() {
		return parentFolderId;
	}

	public void setParentFolderId(Long parentFolderId) {
		this.parentFolderId = parentFolderId;
	}

	public Long getRevisionType() {
		return revisionType;
	}

	public void setRevisionType(Long revisionType) {
		this.revisionType = revisionType;
	}

	public Date getLastUpdateDt() {
		return lastUpdateDt;
	}

	public void setLastUpdateDt(Date lastUpdateDt) {
		this.lastUpdateDt = lastUpdateDt;
	}

	public String getLastUpdatedDt() {
		return lastUpdatedDt;
	}

	public void setLastUpdatedDt(String lastUpdatedDt) {
		this.lastUpdatedDt = lastUpdatedDt;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getFolderName() {
		return folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

	public String getLastUpdatedByUser() {
		return lastUpdatedByUser;
	}

	public void setLastUpdatedByUser(String lastUpdatedByUser) {
		this.lastUpdatedByUser = lastUpdatedByUser;
	}

	@PostLoad
	void postload() {
		setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(getLastUpdateDt()));
	}
}
