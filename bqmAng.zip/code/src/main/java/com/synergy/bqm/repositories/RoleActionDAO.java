package com.synergy.bqm.repositories;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.RoleActions;

public interface RoleActionDAO extends BaseDAO<RoleActions, Integer> {

}
