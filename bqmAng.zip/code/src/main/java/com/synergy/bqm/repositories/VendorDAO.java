package com.synergy.bqm.repositories;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.Vendor;

public interface VendorDAO extends BaseDAO<Vendor, Long> {

	public Vendor getVendorInfoByVendorId(Long vendorId);
}
