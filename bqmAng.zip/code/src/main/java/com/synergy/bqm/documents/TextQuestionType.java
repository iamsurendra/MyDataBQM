package com.synergy.bqm.documents;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TextQuestionType extends BaseAnswerType{

	public static final String ANSWERTYPE= "TEXT";

	private String lowerLimit;
	private String upperLimit;
	
	
	@JsonCreator
	public TextQuestionType() {

	}

	@JsonCreator
	public TextQuestionType(@JsonProperty("lineItemQuestion") String lineItemQuestion,
			@JsonProperty("lineItemToolTip") String lineItemToolTip, @JsonProperty("answerType") String answerType,
			@JsonProperty("lowerLimit") String lowerLimit, @JsonProperty("upperLimit") String upperLimit) {
		super(lineItemQuestion, lineItemToolTip, answerType);
		this.lowerLimit = lowerLimit;
		this.upperLimit = upperLimit;
	}
	
	
	public String getLowerLimit() {
		return lowerLimit;
	}
	public void setLowerLimit(String lowerLimit) {
		this.lowerLimit = lowerLimit;
	}
	
	public static String getQuestionType() {
		return ANSWERTYPE;
	}
	public String getUpperLimit() {
		return upperLimit;
	}
	public void setUpperLimit(String upperLimit) {
		this.upperLimit = upperLimit;
	}
	
	
	
}
