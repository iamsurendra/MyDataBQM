package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.FolderTemplateNames;

@Repository
public class FolderTemplateNamesDAOImpl extends BaseDAOImpl<FolderTemplateNames, Integer> implements FolderTemplateNamesDAO{

	public FolderTemplateNamesDAOImpl() {
		super(FolderTemplateNames.class);
		// TODO Auto-generated constructor stub
	}

	public Long folderTemplateNameExists(String templateName) {
		TypedQuery<Long> query = entityManager
				.createQuery("select count(*) from FolderTemplateNames where templateName = :templateName", Long.class);
		query.setParameter("templateName", templateName);
		return query.getSingleResult();

	}
	
	 public List<FolderTemplateNames> getFoldersInfoByFolderIds(List<Integer>templateIds){
		 CriteriaBuilder builder = entityManager.getCriteriaBuilder();
	  CriteriaQuery<FolderTemplateNames> criteriaQuery = builder.createQuery(FolderTemplateNames.class);
	  Root<FolderTemplateNames> root = criteriaQuery.from(FolderTemplateNames.class);
	  criteriaQuery.select(root);
	  criteriaQuery.where(root.get("templateId").in(templateIds));
	  return entityManager.createQuery(criteriaQuery).getResultList(); }

}
