package com.synergy.bqm.services;

import java.util.Map;

import org.springframework.core.io.InputStreamSource;

import com.synergy.bqm.constants.MailTemplateEnum;

public interface MailService {
	
	
	
	 void sendEmail(MailTemplateEnum mailTemplate, Map<String, Object> values, String[] to, Object... subject) ;
	 
	 public void sendEmailWithAttachments(MailTemplateEnum mailTemplate, Map<String, Object> values, String[] to,String[] cc,String userSpecSubject,Map<String,InputStreamSource> attachMents,  Object... params);

	 public void sendEmailWithAttachmentsOfDifferentContentTypes(MailTemplateEnum mailTemplate, Map<String, Object> values, String[] to,String[] cc,String userSpecSubject,Map<String,InputStreamSource> attachMents,  Object... params);

}
