package com.synergy.bqm.services;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.synergy.bqm.models.Client;



public interface ClientService {
	
	List<String> getClientNameList();

	List<Client> findAllClients();

	public Client createClients(Client client);
	
	public Client getClientInfoByClientId(Integer clientId);
	
	public void uploadLogo(Integer Id, MultipartFile logo)throws IOException;
	
	public Client upDateClient(Client client);
	
	public void deleteClientInfo(Integer clientId);
}
