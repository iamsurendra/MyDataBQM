package com.synergy.bqm.repositories;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.ProjectMember;

@Repository
public class ProjectMemberDAOImpl extends BaseDAOImpl<ProjectMember, Integer> implements ProjectMemberDAO {

	public ProjectMemberDAOImpl() {
		super(ProjectMember.class);
		// TODO Auto-generated constructor stub
	}

	public List<ProjectMember> getProjectMemberInfo(Integer projectId) {
		TypedQuery<ProjectMember> query = entityManager.createQuery(
				"SELECT f from ProjectMember f where project_id ='" + projectId + "'", ProjectMember.class);
		return query.getResultList();

	}
	public List<ProjectMember>getprojectInfoByUserId(Integer userId){
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ProjectMember> criteriaQuery = criteriaBuilder.createQuery(ProjectMember.class);
		Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal(root.get("userId"), userId));
		return entityManager.createQuery(criteriaQuery).getResultList();
		
	}
	
	public List<ProjectMember> getProjectMemberInfo(Integer projectId,Integer userId,List<Integer> departmentIds) {	
	CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
	CriteriaQuery<ProjectMember> criteriaQuery = criteriaBuilder.createQuery(ProjectMember.class);
	Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
	criteriaQuery.select(root);
	List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBuilder.equal(root.get("project").get("projectId"), projectId));
		predicates.add(criteriaBuilder.equal(root.get("userId"), userId));
		predicates.add(criteriaBuilder.in(root.get("departmentId")).value(departmentIds));
		criteriaQuery.where(criteriaBuilder.and(predicates.toArray(new Predicate[] {})));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<Long> getUserIdListByProjectId(Integer projectId) {
		TypedQuery<Long> query = entityManager
				.createQuery("SELECT f.userId from ProjectMember f where project_id ='" + projectId + "'", Long.class);
		return query.getResultList();

	}

	public List<ProjectMember> getProjectMemberInfoByDepartmentIdsNotInoperator(List<Integer> departmentIds) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ProjectMember> criteriaQuery = criteriaBuilder.createQuery(ProjectMember.class);
		Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(criteriaBuilder.not(criteriaBuilder.in(root.get("departmentId")).value(departmentIds)));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<ProjectMember> getProjectMemberInfoByDepartmentIdInOperator(List<Integer> departmentIds) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ProjectMember> criteriaQuery = criteriaBuilder.createQuery(ProjectMember.class);
		Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.in(root.get("departmentId")).value(departmentIds));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<Integer> getRoleIdsByProjectIdsAndUserIds(Integer projectId, Integer userId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
		criteriaQuery.select(root.get("roleId"));
		criteriaQuery.where(builder.and(builder.equal(root.get("project").get("projectId"), projectId)),
				builder.equal(root.get("userId"), userId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	public Integer getProjectMemberInfo(Integer projectId, Integer userId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
		criteriaQuery.select(root.get("departmentId"));
		criteriaQuery.where(builder.and(builder.equal(root.get("project").get("projectId"), projectId)),
				builder.equal(root.get("userId"), userId));
		return entityManager.createQuery(criteriaQuery).getSingleResult();

	}

	public ProjectMember getProjectMember(Integer projectId, Integer userId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ProjectMember> criteriaQuery = builder.createQuery(ProjectMember.class);
		Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(builder.equal(root.get("project").get("projectId"), projectId)),
				builder.equal(root.get("userId"), userId));
		return entityManager.createQuery(criteriaQuery).getSingleResult();

	}
	public List<Integer> getProjectsIdByUserIds(Integer userId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
		criteriaQuery.select(root.get("project").get("projectId"));
		criteriaQuery.where(builder.equal(root.get("userId"), userId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	
	public List<Integer> getUserIdslist(Integer projectId, Integer roleId,Integer deptId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
		criteriaQuery.select(root.get("userId"));
		criteriaQuery.where(builder.and(builder.equal(root.get("project").get("projectId"), projectId)),
				builder.equal(root.get("roleId"), roleId),builder.equal(root.get("departmentId"), deptId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	
	public Integer getRoleId(Integer projectId, Long userId,Integer deptId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
		criteriaQuery.select(root.get("roleId"));
		criteriaQuery.where(builder.and(builder.equal(root.get("project").get("projectId"), projectId)),
				builder.equal(root.get("userId"), userId),builder.equal(root.get("departmentId"), deptId));
		List<Integer> idList=entityManager.createQuery(criteriaQuery).getResultList();
		if(!idList.isEmpty()&& idList!=null){
		return idList.get(0);
		}
		else{
			return null;
		}
	}
	
	
	public List<Integer> getProjectMemberByprojectIdDepartmentId(Integer projectId, Integer departmentId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<ProjectMember> root = criteriaQuery.from(ProjectMember.class);
		criteriaQuery.select(root.get("roleId"));
		criteriaQuery.where(builder.and(builder.equal(root.get("project").get("projectId"), projectId)),
				builder.equal(root.get("departmentId"), departmentId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
}
