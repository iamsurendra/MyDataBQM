package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.FolderTemplateDeptMapping;

public interface  FolderTemplateDeptMappingDAO  extends BaseDAO<FolderTemplateDeptMapping, Integer>{
	
	public List<FolderTemplateDeptMapping> getDepartmentTemplateMapping(Integer folderTemplateId);
	
	public List<Integer> getTemplateIds(Integer departmentId);
	
	public List<Integer> getDepartmentIds(Integer folderTemplateId);

	public List<Integer> getFolderTemplateIds();

}
