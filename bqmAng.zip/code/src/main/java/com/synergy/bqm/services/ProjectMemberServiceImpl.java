package com.synergy.bqm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.models.ProjectMember;
import com.synergy.bqm.repositories.ProjectMemberDAO;

@Service("projectMemberService")
public class ProjectMemberServiceImpl implements ProjectMemberService {

	@Autowired
	ProjectMemberDAO projectMemberDAO;

	@Transactional
	public ProjectMember createProjectMember(ProjectMember projectMember) {
		return projectMemberDAO.create(projectMember);
	}

	@Transactional
	public ProjectMember getProjectMemberInfoById(Integer Id) {
		return projectMemberDAO.findOne(Id);
	}

	@Transactional
	public ProjectMember upDateProjectMember(ProjectMember member) {
		return projectMemberDAO.update(member);
	}

	@Transactional
	public void deleteProjectMember(ProjectMember projectMember) {
		projectMemberDAO.delete(projectMember);
	}
	@Transactional
	public List<Long> getUserIdsByProjectId(Integer projectId){
		return projectMemberDAO.getUserIdListByProjectId(projectId);
	}
	
	@Transactional
	public Integer getProjectMemberInfo(Integer projectId, Integer userId){
		return projectMemberDAO.getProjectMemberInfo(projectId,userId);
		
	}
	
	@Transactional
	public ProjectMember getProjectMember(Integer projectId, Integer userId){
		return projectMemberDAO.getProjectMember(projectId, userId);
		
	}
}
