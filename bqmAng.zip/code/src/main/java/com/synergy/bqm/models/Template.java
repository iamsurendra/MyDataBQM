package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.guvvala.framework.model.BaseModel;

/**
 * The persistent class for the templates database table.
 * 
 */
@Entity
@Table(name = "templates")
@NamedQuery(name = "Template.findAll", query = "SELECT t FROM Template t")
public class Template extends BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "template_id")
	private int templateId;

	/*
	 * @Column(name="created_by") private int createdBy;
	 * 
	 * @Temporal(TemporalType.TIMESTAMP)
	 * 
	 * @Column(name="created_dt") private Date createdDt;
	 */

	@Column(name = "template_name")
	private String templateName;

	@Column(name = "template_type")
	private String templateType;

	/*
	 * @Column(name="updated_by") private int updatedBy;
	 * 
	 * @Temporal(TemporalType.TIMESTAMP)
	 * 
	 * @Column(name="updated_dt") private Date updatedDt;
	 */

	// bi-directional many-to-one association to TemplateLineItem
	@OneToMany(mappedBy = "template")
	private List<TemplateLineItem> templateLineItems;

	public Template() {
	}

	public int getTemplateId() {
		return this.templateId;
	}

	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	/*
	 * public int getCreatedBy() { return this.createdBy; }
	 * 
	 * public void setCreatedBy(int createdBy) { this.createdBy = createdBy; }
	 * 
	 * public Date getCreatedDt() { return this.createdDt; }
	 * 
	 * public void setCreatedDt(Date createdDt) { this.createdDt = createdDt; }
	 */

	public String getTemplateName() {
		return this.templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getTemplateType() {
		return this.templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	/*
	 * public int getUpdatedBy() { return this.updatedBy; }
	 * 
	 * public void setUpdatedBy(int updatedBy) { this.updatedBy = updatedBy; }
	 * 
	 * public Date getUpdatedDt() { return this.updatedDt; }
	 * 
	 * public void setUpdatedDt(Date updatedDt) { this.updatedDt = updatedDt; }
	 */

	public List<TemplateLineItem> getTemplateLineItems() {
		return this.templateLineItems;
	}

	public void setTemplateLineItems(List<TemplateLineItem> templateLineItems) {
		this.templateLineItems = templateLineItems;
	}

	public TemplateLineItem addTemplateLineItem(TemplateLineItem templateLineItem) {
		getTemplateLineItems().add(templateLineItem);
		templateLineItem.setTemplate(this);

		return templateLineItem;
	}

	public TemplateLineItem removeTemplateLineItem(TemplateLineItem templateLineItem) {
		getTemplateLineItems().remove(templateLineItem);
		templateLineItem.setTemplate(null);

		return templateLineItem;
	}

}