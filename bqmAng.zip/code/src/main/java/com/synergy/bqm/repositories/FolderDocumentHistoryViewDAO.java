package com.synergy.bqm.repositories;


import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.FolderDocumentHistoryVw;
import com.synergy.bqm.models.FolderDocumentHistoryVwKey;

public interface FolderDocumentHistoryViewDAO extends BaseDAO<FolderDocumentHistoryVw, FolderDocumentHistoryVwKey>{
	
	public List<FolderDocumentHistoryVw> getFolderDocumentHistoryByFolderId(Integer folderId);

	
}
