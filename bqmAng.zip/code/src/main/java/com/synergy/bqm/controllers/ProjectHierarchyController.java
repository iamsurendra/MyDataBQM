package com.synergy.bqm.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.synergy.bqm.documents.Checklist;
import com.synergy.bqm.json.ProjectHierarchyTreeDTO;
import com.synergy.bqm.models.ProjectHierarchy;
import com.synergy.bqm.mongoRepositories.CheckListRepository;
import com.synergy.bqm.services.ProjectHierarchyService;

@RestController
@RequestMapping("/api/projectHierarchy")
public class ProjectHierarchyController {

	@Autowired
	ProjectHierarchyService projectHierarchyService;

	@Autowired
	CheckListRepository checkListRepository;

	/*
	 * creating ProjectHierarchy
	 */
	@RequestMapping(value = "/createProjectHierarchy", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<ProjectHierarchyTreeDTO> createProjectHierarchy(@RequestBody ProjectHierarchy projectHierarchy) {
		return generateProjectHierarchyTreeDTO(projectHierarchyService.createProjectHierarchy(projectHierarchy));
	}

	@RequestMapping(value = "/updateProjectHierarchy", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateHierarchy(@RequestBody ProjectHierarchy projectHierarchy) {
		projectHierarchyService.updateHierarchy(projectHierarchy);
	}

	/*
	 * ProjectHierarchyList by ProjectId
	 */
	@RequestMapping(value = "/getProjectHierarchyList/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProjectHierarchyTreeDTO> getProjectHierarchyByProjectId(@PathVariable("projectId") Integer projectId) {
		return generateProjectHierarchyTreeDTO((projectHierarchyService.getProjectHierarchyByProjectId(projectId)));
	}
	
	/*
	 * parentHierarchy by ProjectId
	 */
	@RequestMapping(value = "/getParentHierarchyByProjectId/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProjectHierarchy> getParentHierarchyByProjectId(@PathVariable("projectId") Integer projectId){
		return projectHierarchyService.getProjectHierarchyByProjectId(projectId);
		
	}

	/*
	 * Building TreeStructure
	 */
	private List<ProjectHierarchyTreeDTO> generateProjectHierarchyTreeDTO(List<ProjectHierarchy> hierarchies) {
		List<ProjectHierarchyTreeDTO> tree = new ArrayList();
		for (ProjectHierarchy hierarchy : hierarchies) {
			ProjectHierarchyTreeDTO hierarchyTreeDTO = new ProjectHierarchyTreeDTO();
			hierarchyTreeDTO.setLabel(hierarchy.getHierarchyName());
			hierarchyTreeDTO.setData(hierarchy);
			hierarchyTreeDTO.setIcon(hierarchy.getIcon() != null ? hierarchy.getIcon() : "fa fa-building");
			hierarchyTreeDTO.setChildren(hierarchy.getProjectHierarchies().isEmpty() ? new ArrayList()
					: generateProjectHierarchyTreeDTO(hierarchy.getProjectHierarchies()));
			tree.add(hierarchyTreeDTO);
		}
		return tree;

	}

	/*
	 * Delete ProjectHierarchy By Id
	 */
	@RequestMapping(value = "/deleteProjectHierarchy/{Id}", method = RequestMethod.GET)
	public void deleteProjectHierarchy(@PathVariable("Id") Integer Id) {
		ProjectHierarchy hierarchy = projectHierarchyService.getProjectHierarchyByHierarchyId(Id);
		if (!hierarchy.getProjectHierarchies().isEmpty()) {
			for (ProjectHierarchy projectHierarchy : hierarchy.getProjectHierarchies()) {
				deleteChecklistByHierarchyId(projectHierarchy.getProjectHierarchyId());
			}
		}
		deleteChecklistByHierarchyId(hierarchy.getProjectHierarchyId());
		projectHierarchyService.deleteHierarchyById(Id);

	}

	// Deleting HierarchyChecklists
	private void deleteChecklistByHierarchyId(Integer hierarchyId) {
		java.util.List<Checklist> list = checkListRepository.getChecklistByHierarchy(hierarchyId);
		if (!list.isEmpty()) {
			for (Checklist checklist : list) {
				checkListRepository.delete(checklist.getId());
			}
		}
	}

	@RequestMapping(value = "/getHierarchyList/{hierarchyId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getHierarchyList(@PathVariable("hierarchyId") Integer hierarchyId) {
		return projectHierarchyService.getHierarchyList(hierarchyId);

	}

}
