package com.synergy.bqm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.json.ActivityTypesDTO;
import com.synergy.bqm.models.ActivityTypes;
import com.synergy.bqm.repositories.ActivityTypesDAO;

@Service
public class ActivityTypesServiceImpl implements ActivityTypesService{

	@Autowired
	ActivityTypesDAO activityTypesDAO;
	

		
		
		@Transactional
		public void createAndUpdateActivityTypes(ActivityTypesDTO activityTypesDTO) {

			// create or update department
			if (!activityTypesDTO.getActivityTypesList().isEmpty()) {
				for (ActivityTypes activityType : activityTypesDTO.getActivityTypesList()) {
					if (activityType.getId() == null) {
						activityTypesDAO.create(activityType);
					} else {
						activityTypesDAO.update(activityType);
					}
				}
			
			// delete departments
			if (!activityTypesDTO.getDeletedIds().isEmpty()) {
				activityTypesDAO.deleteActivitesByIds(activityTypesDTO.getDeletedIds());
			}
				}
				

	}
	

	@Transactional
	public List<ActivityTypes>findAllActivities(){
		return activityTypesDAO.findAll();
		
	}
	
}
