package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.Department;

public class DepartmentDTO {
	
	
	List<Department>departmentList;
	List<Integer>deletedIds;
	
	public List<Department> getDepartmentList() {
		return departmentList;
	}
	public void setDepartmentList(List<Department> departmentList) {
		this.departmentList = departmentList;
	}
	public List<Integer> getDeletedIds() {
		return deletedIds;
	}
	public void setDeletedIds(List<Integer> deletedIds) {
		this.deletedIds = deletedIds;
	}
	
	
	
	
	
	

}
