package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.*;

/**
 * The persistent class for the designations database table.
 * 
 */
@Entity
@Table(name = "designations")
@NamedQuery(name = "Designation.findAll", query = "SELECT d FROM Designation d")
public class Designation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "designation_id")
	private Integer designationId;

	@Column(name = "designation_name")
	private String designationName;

	public Designation() {
	}

	public Integer getDesignationId() {
		return designationId;
	}

	public void setDesignationId(Integer designationId) {
		this.designationId = designationId;
	}

	public String getDesignationName() {
		return this.designationName;
	}

	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}

}