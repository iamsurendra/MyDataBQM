package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.DocumentIndex;
import com.synergy.bqm.models.User;

public interface DocumentIndexService {

	public List<DocumentIndex> getDocumentIndexListByProjectId(Integer projectId);

	public void createDocumentIndex(DocumentIndex documentIndex);

	public List<DocumentIndex> getDocumentIndexListByProjectIdDocumentPathNull(Integer projectId);

	public DocumentIndex getDocumentIndexByIndexId(Integer documentIndexid);

	public List<User> getResponsibleUsersList(Integer stateId, Integer folderId,boolean editActivity);

	public void updateIndex(DocumentIndex documentIndex);

	public DocumentIndex getDocumentIndexByDocumentId(Integer documentId);

	public List<DocumentIndex> getDocumentIndexByActivityId(Integer activityId,Integer projectId);

	public void updateActivity(DocumentIndex documentIndex);
	
	public void checkForDepartmentAccess(Integer folderId);

}
