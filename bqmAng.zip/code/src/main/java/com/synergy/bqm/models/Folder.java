package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.util.DateUtils;

/**
 * The persistent class for the folder database table.
 * 
 */
@Entity
@NamedQuery(name = "Folder.findAll", query = "SELECT f FROM Folder f")
@JsonInclude(JsonInclude.Include.NON_NULL)
@Audited
@Table(name = "folder")
public class Folder extends BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "folder_id")
	private Integer folderId;

	@Column(name = "folder_name")
	private String folderName;

	// bi-directional many-to-one association to Folder
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JoinColumn(name = "parent_folder_id")
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@NotAudited
	private Folder folder;

	// bi-directional many-to-one association to Folder
	@OneToMany(mappedBy = "folder", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	private Set<Folder> folders;

	@NotAudited
	@Column(name = "project_hierarchy_id")
	private Integer projectHierarchyId;

	@ManyToOne
	@JsonIgnore
	@JoinColumn(name = "project_id")
	@NotAudited
	private Project project;

	@Transient
	private String createdDt;

	@Transient
	private String updatedDt;

	@Transient
	private Integer projectId;

	@Transient
	private List<Integer> folderIds;

	@Transient
	private List<Integer> documentIds;

	// bi-directional many-to-one association to FolderDocument
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@OneToMany(mappedBy = "folder", fetch = FetchType.EAGER)
	private Set<FolderDocument> folderDocuments;

	@Transient
	private Integer parentId;

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public Folder() {
	}

	public Integer getFolderId() {
		return folderId;
	}

	public void setFolderId(Integer folderId) {
		this.folderId = folderId;
	}

	public String getFolderName() {
		return this.folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

	public Folder getFolder() {
		return this.folder;
	}

	public void setFolder(Folder folder) {
		this.folder = folder;
	}

	public Set<Folder> getFolders() {
		return this.folders;
	}

	public void setFolders(Set<Folder> folders) {
		this.folders = folders;
	}

	public Folder addFolder(Folder folder) {
		getFolders().add(folder);
		folder.setFolder(this);

		return folder;
	}

	public Folder removeFolder(Folder folder) {
		getFolders().remove(folder);
		folder.setFolder(null);

		return folder;
	}

	public Integer getProjectHierarchyId() {
		return projectHierarchyId;
	}

	public void setProjectHierarchyId(Integer projectHierarchyId) {
		this.projectHierarchyId = projectHierarchyId;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	public Set<FolderDocument> getFolderDocuments() {
		return this.folderDocuments;
	}

	public void setFolderDocuments(Set<FolderDocument> folderDocuments) {
		this.folderDocuments = folderDocuments;
	}

	public FolderDocument addFolderDocument(FolderDocument folderDocument) {
		getFolderDocuments().add(folderDocument);
		folderDocument.setFolder(this);

		return folderDocument;
	}

	public FolderDocument removeFolderDocument(FolderDocument folderDocument) {
		getFolderDocuments().remove(folderDocument);
		folderDocument.setFolder(null);

		return folderDocument;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public List<Integer> getFolderIds() {
		return folderIds;
	}

	public void setFolderIds(List<Integer> folderIds) {
		this.folderIds = folderIds;
	}

	public List<Integer> getDocumentIds() {
		return documentIds;
	}

	public void setDocumentIds(List<Integer> documentIds) {
		this.documentIds = documentIds;
	}

	@PostLoad
	void postload() {
		setCreatedDt(DateUtils.convertToSimpleDateTimeFormat(getCreatedDate()));
		setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(getUpdatedDate()));

	}
}