package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.Vendor;

public interface VendorService {
	public List<Vendor> findAllVendors();

	public void createVendor(Vendor vendors);

	public void updateVendor(Vendor vendors);

	public void deleteVendor(Long Id);

	public Vendor getvendorByVendorId(Long vendorId);

}
