package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.util.DateUtils;

/**
 * The persistent class for the folder_document database table.
 * 
 */
@Entity
@Table(name = "folder_document")
@NamedQuery(name = "FolderDocument.findAll", query = "SELECT f FROM FolderDocument f")
@Audited
public class FolderDocument extends BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "document_id")
	private Integer documentId;

	@Column(name = "document_link")
	private String documentLink;

	@Column(name = "document_name")
	private String documentName;

	@Column(name = "document_description")
	private String documentDescription;

	@Column(name = "filetype")
	private String fileType;

	@Column(name = "version")
	private Double version;
	
	@Column(name = "index_file")
	@Type(type = "boolean")
	private Boolean indexFile;

	// bi-directional many-to-one association to Folder
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name = "document_folder_id")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	private Folder folder;

	@Transient
	private String createdDt;

	@Transient
	private String updatedDt;

	public FolderDocument() {
	}

	public FolderDocument(String documentName, String documentLink) {
		this.documentName = documentName;
		this.documentLink = documentLink;
	}

	public Integer getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	public String getDocumentLink() {
		return this.documentLink;
	}

	public void setDocumentLink(String documentLink) {
		this.documentLink = documentLink;
	}

	public String getDocumentName() {
		return this.documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public Folder getFolder() {
		return this.folder;
	}

	public void setFolder(Folder folder) {
		this.folder = folder;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getDocumentDescription() {
		return documentDescription;
	}

	public void setDocumentDescription(String documentDescription) {
		this.documentDescription = documentDescription;
	}

	public Double getVersion() {
		return version;
	}

	public void setVersion(Double version) {
		this.version = version;
	}
	
	public Boolean getIndexFile() {
		return indexFile;
	}

	public void setIndexFile(Boolean indexFile) {
		this.indexFile = indexFile;
	}

	@PostLoad
	void postload() {
		setCreatedDt(DateUtils.convertToSimpleDateTimeFormat(getCreatedDate()));
		setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(getUpdatedDate()));

	}
}