package com.synergy.bqm.services;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.synergy.bqm.json.NormalSearchDTO;
import com.synergy.bqm.models.DocumentIndexVw;

public interface DocumentIndexVwService {

	public List<DocumentIndexVw> getDocumentIndexVwByProjectId(Integer projectId);

	public List<DocumentIndexVw> getFolderDocumentIndexSearch(Integer projectId, String searchValues)
			throws ParseException;

	public DocumentIndexVw getDocumentIndexById(Integer Id);

	public DocumentIndexVw getDocumentIndexViewByIndexId(Integer documentIndexid);
	
	public List<DocumentIndexVw> getDocumentIndexNotification(Integer userId);
	
	public List<DocumentIndexVw> getFolderDocumentListByMainActivityAndProjectId(Integer activityId,Integer projectId);
	
	public List<DocumentIndexVw> getFolderDocumentIndexNormalSearch(NormalSearchDTO normalSearch);
	
	public Map<Integer, Long> countOfDocumentIndexBystate(Integer projectId);
	
	public Map<String, Map<Integer, Long>> countOfDocumentIndexByDepartment(Integer projectId);
	
	public Map<String, Map<Integer, Long>> countOfDocumentIndexByHierarchy(Integer projectId);

}
