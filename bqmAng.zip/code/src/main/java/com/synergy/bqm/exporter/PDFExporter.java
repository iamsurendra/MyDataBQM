package com.synergy.bqm.exporter;

import java.io.ByteArrayOutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import com.synergy.bqm.constants.PDFTemplateEnum;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Component
public class PDFExporter implements InitializingBean {
	private Map<PDFTemplateEnum, JasperReport> reports = new HashMap<>();

	@Override
	public void afterPropertiesSet() throws Exception {
		for (PDFTemplateEnum key : PDFTemplateEnum.values()) {
			JasperReport jasperReport = JasperCompileManager.compileReport(
					this.getClass().getClassLoader().getResourceAsStream(PDFTemplateEnum.PATH + key.filename));
			reports.put(key, jasperReport);
		}
	}

	public ByteArrayOutputStream export(PDFTemplateEnum reportName, List<PDFTemplateEnum> subReports,
			Collection<?>... reportData) throws Exception {
		Collection<?> data = reportData[0];
		Map<String, Object> parameters = new HashMap<String, Object>();
		JasperReport jasperReport = reports.get(reportName);
		// If subreports are not null, iterate through, compile, and put in
		// cache , then add them back to the new map
		if (subReports != null) {
			for (PDFTemplateEnum pdfsub : subReports) {
				JasperReport jasperSubReport = reports.get(pdfsub);
				parameters.put(pdfsub.name, jasperSubReport);
			}
		}
		// pass the subreport parameters to fill the report
		JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters,
				new JRBeanCollectionDataSource(data));
		byte[] bytes = JasperExportManager.exportReportToPdf(jasperPrint);
		ByteArrayOutputStream baos = new ByteArrayOutputStream(bytes.length);
		baos.write(bytes, 0, bytes.length);
		return baos;
	}

}
