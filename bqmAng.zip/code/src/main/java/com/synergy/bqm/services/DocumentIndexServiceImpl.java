package com.synergy.bqm.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.constants.activityStatus;
import com.synergy.bqm.documents.BaseAnswerType;
import com.synergy.bqm.documents.BaseQuestionTypeTemplate;
import com.synergy.bqm.documents.ChecklistTemplate;
import com.synergy.bqm.documents.DocumentChecklist;
import com.synergy.bqm.documents.InfoQuestionType;
import com.synergy.bqm.documents.InfoQuestionTypeTemplate;
import com.synergy.bqm.documents.Section;
import com.synergy.bqm.documents.SectionTemplate;
import com.synergy.bqm.documents.SelectionQuestionType;
import com.synergy.bqm.documents.SelectionQuestionTypeTemplate;
import com.synergy.bqm.documents.Subsection;
import com.synergy.bqm.documents.SubsectionTemplate;
import com.synergy.bqm.documents.TextQuestionType;
import com.synergy.bqm.documents.TextQuestionTypeTemplate;
import com.synergy.bqm.json.DocumentChecklistDTO;
import com.synergy.bqm.models.ActivityHistory;
import com.synergy.bqm.models.ActivityWorkflowMapping;
import com.synergy.bqm.models.Department;
import com.synergy.bqm.models.DocumentIndex;
import com.synergy.bqm.models.DocumentIndexVw;
import com.synergy.bqm.models.Folder;
import com.synergy.bqm.models.FolderDocument;
import com.synergy.bqm.models.ProjectMember;
import com.synergy.bqm.models.Role;
import com.synergy.bqm.models.User;
import com.synergy.bqm.models.WorkflowStates;
import com.synergy.bqm.mongoRepositories.CheckListTemplateRepository;
import com.synergy.bqm.mongoRepositories.DocumentChecklistRepository;
import com.synergy.bqm.repositories.ActivityHistoryDAO;
import com.synergy.bqm.repositories.ActivityWorkflowMappingDAO;
import com.synergy.bqm.repositories.DepartmentDAO;
import com.synergy.bqm.repositories.DocumentIndexDAO;
import com.synergy.bqm.repositories.FolderDAO;
import com.synergy.bqm.repositories.FolderDocumentDAO;
import com.synergy.bqm.repositories.ProjectMemberDAO;
import com.synergy.bqm.repositories.QuestionOptionDAO;
import com.synergy.bqm.repositories.RolesDAO;
import com.synergy.bqm.repositories.UserDAO;
import com.synergy.bqm.repositories.WorkFlowDAO;
import com.synergy.bqm.repositories.WorkflowStatesDAO;

@Service
public class DocumentIndexServiceImpl implements DocumentIndexService {

	private static final String Role = "Role Doesn't exist in";

	private static final String Department = "Department.";

	@Autowired
	DocumentIndexDAO documentIndexDAO;

	@Autowired
	ActivityWorkflowMappingDAO activityWorkflowMappingDAO;

	@Autowired
	CheckListTemplateRepository checkListTemplateRepository;

	@Autowired
	QuestionOptionDAO questionOptionDAO;

	@Autowired
	DocumentChecklistRepository documentChecklistRepository;

	@Autowired
	WorkflowStatesDAO workflowStatesDAO;

	@Autowired
	FolderDAO folderDAO;

	@Autowired
	UserDAO userDAO;

	@Autowired
	ProjectMemberDAO projectMemberDAO;

	@Autowired
	RolesDAO rolesDAO;

	@Autowired
	WorkFlowDAO workflowDAO;

	@Autowired
	FolderDocumentDAO folderDocumentDAO;

	@Autowired
	FolderDepartmentMappingService folderDepartmentMappingService;

	@Autowired
	ActivityHistoryDAO activityHistoryDAO;

	@Autowired
	DocumentIndexVwService documentIndexVwService;

	@Autowired
	DocumentIndexService documentIndexService;

	@Autowired
	DepartmentDAO departmentDAO;

	@Transactional
	public List<DocumentIndex> getDocumentIndexListByProjectId(Integer projectId) {
		return documentIndexDAO.getDocumentIndexListByProjectId(projectId);

	}

	@Transactional
	public void createDocumentIndex(DocumentIndex documentIndex) {
		Boolean check = documentIndexDAO.checkDuplicateActivity(documentIndex.getName(),
				documentIndex.getDepartmentId(), documentIndex.getActivityType(),documentIndex.getHierarchyId());
		if (check) {
			throw new AppException(MessagesEnum.DUPLICATE_ACTIVITY_NAME);
		} else {
			Integer currentStatus = workflowStatesDAO.getCurrentStatusByWorkflowId(documentIndex.getWorkflowId());
			if (currentStatus != null) {
				documentIndex.setStateId(currentStatus);
			}
			documentIndex.setPercentageOfCompleted(0);
			// separating FolderNames with ">"
			String path = String.join(">", documentIndex.getReferenceDrawingList());
			documentIndex.setReferenceDrawingPath(path);
			documentIndex.setActivityStage(activityStatus.OPEN.value);
			documentIndex.setDateOfCompletion(DateUtils.getCurrentISTDateTime());
			DocumentIndex index = documentIndexDAO.create(documentIndex);
			for (DocumentChecklistDTO mapping : documentIndex.getDocumentChecklist()) {
				ActivityWorkflowMapping workflowMapping = new ActivityWorkflowMapping();
				workflowMapping.setIndexId(index.getId());
				workflowMapping.setStateId(mapping.getStateId());
				workflowMapping.setWorkflowId(documentIndex.getWorkflowId());
				if (mapping.getChecklistId() != null) {
					DocumentChecklist documentChecklist = importChecklistTemplate(mapping.getChecklistId());
					DocumentChecklist checklist = documentChecklistRepository.save(documentChecklist);
					workflowMapping.setChecklistId(checklist.getId());
				}
				activityWorkflowMappingDAO.create(workflowMapping);
			}
		}
	}

	private DocumentChecklist importChecklistTemplate(String checklistId) {

		Map<String, List<String>> questionOptionsMap = questionOptionDAO.getQuestionAnsInfo();

		ChecklistTemplate checklistTemplate = checkListTemplateRepository.findOne(checklistId);
		if (checklistTemplate != null) {
			DocumentChecklist checklist = new DocumentChecklist();
			checklist.setChecklistName(checklistTemplate.getChecklistName());
			checklist.setChecklistType(checklistTemplate.getChecklistType());
			checklist.setChecklistService(checklistTemplate.getChecklistService());

			checklist.setUpdatedBy(ThreadLocalUtil.getUserName());
			checklist.setUpdatedOn(DateUtils.getCurrentISTDateTime().toString());

			for (SectionTemplate sectionTemplate : checklistTemplate.getSectionList()) {
				Section template = new Section();
				template.setSectionName(sectionTemplate.getSectionName());
				template.setSectionInfo(sectionTemplate.getSectionInfo());
				template.setReference(sectionTemplate.getReference());
				checklist.getSectionList().add(template);
				if (!sectionTemplate.getQuestionList().isEmpty()) {
					template.setAnswerType(sectionTemplate.getQuestionType());
					template.getQuestionList()
							.addAll(getQuestionList(sectionTemplate.getQuestionList(), questionOptionsMap));
				}
				for (SubsectionTemplate subsection : sectionTemplate.getSubsectionList()) {
					Subsection section = new Subsection();
					section.setSubsectionName(subsection.getSubsectionName());
					section.setSubsectionInfo(subsection.getSubsectionInfo());
					section.setReference(subsection.getReference());
					template.getSubsectionList().add(section);
					if (!subsection.getQuestionList().isEmpty()) {
						section.setAnswerType(subsection.getQuestionType());
						section.getQuestionList()
								.addAll(getQuestionList(subsection.getQuestionList(), questionOptionsMap));

					}
				}

			}
			return checklist;
		} else {
			return new DocumentChecklist();
		}
	}

	private List<BaseAnswerType> getQuestionList(List<BaseQuestionTypeTemplate> baseQuestionTypeTemplate,
			Map<String, List<String>> questionOptionsMap) {
		List<BaseAnswerType> baseAnswerType = new ArrayList<>();
		for (BaseQuestionTypeTemplate questionTypeTemplate : baseQuestionTypeTemplate) {
			if (questionTypeTemplate instanceof TextQuestionTypeTemplate) {
				TextQuestionType textQuestionType = new TextQuestionType();
				textQuestionType.setLowerLimit(((TextQuestionTypeTemplate) questionTypeTemplate).getLowerLimit());
				textQuestionType.setUpperLimit(((TextQuestionTypeTemplate) questionTypeTemplate).getUpperLimit());
				textQuestionType.setAnswerType(questionTypeTemplate.getQuestionType());
				textQuestionType.setLineItemToolTip(questionTypeTemplate.getLineItemToolTip());
				textQuestionType.setLineItemQuestion(questionTypeTemplate.getLineItemQuestion());
				baseAnswerType.add(textQuestionType);
			} else if (questionTypeTemplate instanceof InfoQuestionTypeTemplate) {
				InfoQuestionType infoQuestionType = new InfoQuestionType();
				infoQuestionType.setAnswerType(questionTypeTemplate.getQuestionType());
				infoQuestionType.setLineItemToolTip(questionTypeTemplate.getLineItemToolTip());
				infoQuestionType.setLineItemQuestion(questionTypeTemplate.getLineItemQuestion());
				baseAnswerType.add(infoQuestionType);
			} else if (questionTypeTemplate instanceof SelectionQuestionTypeTemplate) {
				SelectionQuestionType selectionQuestionType = new SelectionQuestionType();
				selectionQuestionType.setAnswerType(questionTypeTemplate.getQuestionType());
				selectionQuestionType
						.setOptionType(((SelectionQuestionTypeTemplate) questionTypeTemplate).getOptionType());
				selectionQuestionType.setLineItemToolTip(questionTypeTemplate.getLineItemToolTip());
				selectionQuestionType.setLineItemQuestion(questionTypeTemplate.getLineItemQuestion());
				selectionQuestionType.getQuestionOptions()
						.addAll((((SelectionQuestionTypeTemplate) questionTypeTemplate).getQuestionOptions()));
				baseAnswerType.add(selectionQuestionType);
			}
		}
		return baseAnswerType;
	}

	@Transactional
	public List<DocumentIndex> getDocumentIndexListByProjectIdDocumentPathNull(Integer projectId) {
		Long userId = ThreadLocalUtil.getUserId();
		ProjectMember projectMembers = projectMemberDAO.getProjectMember(projectId, userId.intValue());
		return documentIndexDAO.getDocumentIndexListByProjectIdDocumentPathNull(projectId,
				Arrays.asList(projectMembers.getDepartmentId()));
	}

	@Transactional
	public DocumentIndex getDocumentIndexByIndexId(Integer documentIndexid) {
		DocumentIndex documentIndex = documentIndexDAO.findOne(documentIndexid);
		return getDocumentIndex(documentIndex, false);
	}

	@Transactional
	public DocumentIndex getDocumentIndexByDocumentId(Integer documentId) {

		DocumentIndex documentIndex = documentIndexDAO.getDocumentIndexByDocumentId(documentId);
		User user = ThreadLocalUtil.getAppUser().getUserObject();
		if (documentIndex.getPercentageOfCompleted() >= 100) {
			throw new AppException(MessagesEnum.ACTIVITY_COMPLETED_SUCCESFULLY);
		}

		if (documentIndex.getCurrentResponsibleId() != null
				&& documentIndex.getCurrentResponsibleId().longValue() != user.getUserId()) {
			throw new AppException(MessagesEnum.DOCUMENT_PERMISSION_REQUIRED);
		}
		if (documentIndex.getDependentActivityId() != null) {
			DocumentIndex dependent = documentIndexDAO.findOne(documentIndex.getDependentActivityId());

			if (dependent.getPercentageOfCompleted() < 100) {
				throw new AppException(MessagesEnum.ACTIVITY_LOCKED);
			}

		}
		return getDocumentIndex(documentIndex, true);

	}

	private DocumentIndex getDocumentIndex(DocumentIndex documentIndex, boolean document) {

		List<DocumentChecklistDTO> documentDto = new ArrayList<DocumentChecklistDTO>();
		// Retrieving documentIndexObj by IndexId
		if (documentIndex.getWorkflowId() != null) {
			documentIndex.setWorkflowName(workflowDAO.findOne(documentIndex.getWorkflowId()).getName());
		}
		if (documentIndex.getStateId() != null) {
			documentIndex.setCurrentState(workflowStatesDAO.getWorkflowState(documentIndex.getStateId()));
		}
		// getting multiple checklist
		List<ActivityWorkflowMapping> mappingobj = activityWorkflowMappingDAO
				.getActivityWorkflowMappingObjListByIndexId(documentIndex.getId());
		for (ActivityWorkflowMapping map : mappingobj) {
			DocumentChecklistDTO dto = new DocumentChecklistDTO();
			// previous state checkList added to list
			if (document) {
				if (documentIndex.getStateId() >= map.getStateId()) {
					if (map.getChecklistId() != null) {
						DocumentChecklistDTO documentChecklistDTO = getChecklistById(map.getChecklistId());
						dto = documentChecklistDTO;
					}
				}
			} else {
				if (map.getChecklistId() != null) {
					DocumentChecklistDTO documentChecklistDTO = getChecklistById(map.getChecklistId());
					dto = documentChecklistDTO;
				}
				// For Edit Activity
				if (documentIndex.getDocumentName() != null && !documentIndex.getDocumentName().isEmpty()) {
					List<User> responsibleUser = getResponsibleUsersList(documentIndex.getStateId(),
							documentIndex.getDocumentFolderId(), true);
					List<WorkflowStates> states = workflowStatesDAO
							.getWorkflowStatesById(documentIndex.getWorkflowId());
					if (!responsibleUser.isEmpty()) {
						documentIndex.setResponsibleUsers(responsibleUser);
					}
					if (!states.isEmpty()) {
						documentIndex.setStates(states);
					}
				}
			}
			dto.setStateId(map.getStateId());
			WorkflowStates statesObj = workflowStatesDAO.findOne(map.getStateId());
			dto.setStateName(statesObj.getName());
			dto.setWorkflowId(statesObj.getWorkflow().getId());
			documentDto.add(dto);
		}
		documentIndex.setDocumentChecklist(documentDto);
		return documentIndex;

	}

	private DocumentChecklistDTO getChecklistById(String checklistId) {
		DocumentChecklistDTO dto = new DocumentChecklistDTO();

		DocumentChecklist documentChecklist = documentChecklistRepository.findOne(checklistId);
		if (documentChecklist != null) {
			dto.setDocumentChecklist(documentChecklist);
			dto.setDocumentCheckListName(documentChecklist.getChecklistName());
			dto.setChecklistId(documentChecklist.getId());
		}
		return dto;
	}

	@Transactional
	public void checkForDepartmentAccess(Integer folderId) {
		List<Folder> folders = new ArrayList<>();
		// fetching parentFolderId
		folders = getFolderInfo(folderId, folders);
		Collections.reverse(folders);
		List<Integer> departmentIds = folderDepartmentMappingService.getDepartmentIds(folders.get(0).getFolderId());
		Long userId = ThreadLocalUtil.getUserId();
		Folder folder = folderDAO.findOne(folderId);
		Integer projectId = folder.getProject().getProjectId();
		List<ProjectMember> projectMembers = projectMemberDAO.getProjectMemberInfo(projectId, userId.intValue(),
				departmentIds);

		if (projectMembers.isEmpty()) {
			// &&
			// !departmentIds.contains(projectMembers.get(0).getDepartmentId())
			throw new AppException("Access Denied");
		}
	}

	@Transactional
	public List<User> getResponsibleUsersList(Integer stateId, Integer folderId, boolean editActivity) {
		WorkflowStates workflowState = workflowStatesDAO.findOne(stateId);
		List<Folder> folders = new ArrayList<>();
		// fetching parentFolderId
		folders = getFolderInfo(folderId, folders);
		Collections.reverse(folders);

		// Fetching DepartmentName with ParentFolderId
		List<Integer> departmentIds = folderDepartmentMappingService.getDepartmentIds(folders.get(0).getFolderId());
		Integer projectId = folderDAO.findOne(folders.get(0).getFolderId()).getProject().getProjectId();
		Long userId = ThreadLocalUtil.getUserId();
		List<ProjectMember> projectMembers = projectMemberDAO.getProjectMemberInfo(projectId, userId.intValue(),
				departmentIds);

		Role role = rolesDAO.findOne(workflowState.getRoleId());
		Department department = departmentDAO.findOne(projectMembers.get(0).getDepartmentId());
		if (!projectMembers.isEmpty()) {
			List<Integer> userIds = projectMemberDAO.getUserIdslist(projectId, workflowState.getRoleId(),
					projectMembers.get(0).getDepartmentId());
			if (!userIds.isEmpty()) {
				return userDAO.getUserList(userIds);

			} else {
				throw new AppException(
						role.getRoleName() + " " + Role + " " + department.getDepartmentName() + " " + Department);

			}
		}
		if (editActivity) {
			return new ArrayList<>();
		} else {
			throw new AppException(
					role.getRoleName() + " " + Role + " " + department.getDepartmentName() + " " + Department);

		}

	}

	// fetching FolderPath by folderId
	private List<Folder> getFolderInfo(Integer folderId, List<Folder> folders) {
		Folder folder = folderDAO.findOne(folderId);
		Folder folderObj = new Folder();
		folderObj.setFolderName(folder.getFolderName());
		folderObj.setFolderId(folder.getFolderId());
		folders.add(folderObj);
		if (folder.getFolder() != null) {
			getFolderInfo(folder.getFolder().getFolderId(), folders);
		}
		return folders;

	}

	@Transactional
	public void updateIndex(DocumentIndex documentIndex) {
		// DocumentManagement level checklistUpdate
		if (documentIndex.getDocumentChecklist() != null) {
			for (DocumentChecklistDTO checklistDTO : documentIndex.getDocumentChecklist()) {

				if (checklistDTO.getDocumentChecklist() != null) {
					documentChecklistRepository.save(checklistDTO.getDocumentChecklist());
				}
			}
		}
		// calculating percentage of completion based on CurrentState
		List<Integer> ids = workflowStatesDAO.getSeqIds(documentIndex.getWorkflowId());
		if (!ids.isEmpty()) {
			Integer presentState = workflowStatesDAO.getSeqIdByStateId(documentIndex.getStateId());

			float status = (float) (((presentState - 1) * 100) / (ids.size() - 1));
			documentIndex.setPercentageOfCompleted((int) (status + 0.5f));

		}
		if (documentIndex.getFolderId() != null) {
			List<String> names = new ArrayList<>();
			List<Folder> folders = new ArrayList<>();
			// fetching FolderPath by folderId
			folders = getFolderInfo(documentIndex.getFolderId(), folders);
			Collections.reverse(folders);
			folders.forEach(folder -> names.add(folder.getFolderName()));

			// separating FolderNames with ">"
			String path = String.join(">", names);
			documentIndex.setDocumentPath(path);
			documentIndex.setDateOfCompletion(DateUtils.getCurrentISTDateTime());
			documentIndex.setPreviousStateUser(ThreadLocalUtil.getUserName());
		}
		List<WorkflowStates> workflowStatesObjList = workflowStatesDAO
				.getWorkflowStatesById(documentIndex.getWorkflowId());
		WorkflowStates workFlowObj = workflowStatesObjList.get(workflowStatesObjList.size() - 1);
		if (workFlowObj.getId().equals(documentIndex.getStateId())) {
			documentIndex.setActivityStage(activityStatus.COMPLETED.value);
		} else {
			documentIndex.setActivityStage(activityStatus.INPROGRESS.value);
		}
		if (documentIndex.getDocumentId() != null) {
			// Fetching folderId
			documentIndex.setDocumentFolderId(
					folderDocumentDAO.findOne(documentIndex.getDocumentId()).getFolder().getFolderId());
		}

		// Deleting Already Existing File in Activity
		DocumentIndex index = documentIndexDAO.findOne(documentIndex.getId());
		if (index.getDocumentId() != null) {
			FolderDocument document = folderDocumentDAO.findOne(index.getDocumentId());
			folderDocumentDAO.delete(document);
		}
		// moving Already Existing File to nonIndex
		/*
		 * DocumentIndex index=documentIndexDAO.findOne(documentIndex.getId());
		 * if(index.getDocumentId()!=null){ FolderDocument
		 * Document=folderDocumentDAO.findOne(index.getDocumentId());
		 * Document.setIndexFile(false); folderDocumentDAO.delete(Document); }
		 */

		// create Activity History
		createActivityHistory(documentIndex);
		//
		documentIndexDAO.update(documentIndex);
	}

	@Transactional
	public List<DocumentIndex> getDocumentIndexByActivityId(Integer activityId,Integer projectId) {
		return documentIndexDAO.getDocumentIndexByActivityId(activityId,projectId);

	}

	@Transactional
	public void updateActivity(DocumentIndex documentIndex) {
		Long check = documentIndexDAO.checkDuplicateUpdateActivity(documentIndex.getName(),
				documentIndex.getDepartmentId(), documentIndex.getActivityType(),documentIndex.getHierarchyId());
		if (check >1) {
			throw new AppException(MessagesEnum.DUPLICATE_ACTIVITY_NAME);
		}
		// List of deleted checklist Id's
		if (!documentIndex.getDeletedCheckListIds().isEmpty()) {
			for (String id : documentIndex.getDeletedCheckListIds()) {
				DocumentChecklist checklist = documentChecklistRepository.findOne(id);
				if (checklist != null) {
					// deleting checklist
					documentChecklistRepository.delete(checklist);
					// setting checklistId as null
					ActivityWorkflowMapping activityWorkflowMapping = activityWorkflowMappingDAO
							.getActivityWorkflowMappingByChecklistId(id);
					activityWorkflowMapping.setChecklistId(null);
					activityWorkflowMappingDAO.update(activityWorkflowMapping);
				}
			}
		}
		// DocumentManagement level checklistUpdate
		if (documentIndex.getDocumentChecklist() != null) {

			// Checking for existing Records with workflowId and indexId
			List<ActivityWorkflowMapping> activityWorkflowMappingList = activityWorkflowMappingDAO
					.getActivityWorkflowMappingByWorkflowId(documentIndex.getId(),
							documentIndex.getDocumentChecklist().get(0).getWorkflowId());
			if (activityWorkflowMappingList.isEmpty()) {
				// Checking for existing Records with indexId
				List<ActivityWorkflowMapping> activityList = activityWorkflowMappingDAO
						.getActivityWorkflowMappingObjListByIndexId(documentIndex.getId());
				if (!activityList.isEmpty()) {
					for (ActivityWorkflowMapping entity : activityList) {
						activityWorkflowMappingDAO.delete(entity);
					}
				}
				//creating new Activity
				Integer currentStatus = workflowStatesDAO.getCurrentStatusByWorkflowId(documentIndex.getWorkflowId());
				if (currentStatus != null) {
					documentIndex.setStateId(currentStatus);
				}
				for (DocumentChecklistDTO mapping : documentIndex.getDocumentChecklist()) {
					ActivityWorkflowMapping workflowMapping = new ActivityWorkflowMapping();
					workflowMapping.setIndexId(documentIndex.getId());
					workflowMapping.setStateId(mapping.getStateId());
					workflowMapping.setWorkflowId(documentIndex.getWorkflowId());
					if (mapping.getChecklistId() != null) {
						DocumentChecklist documentChecklist = importChecklistTemplate(mapping.getChecklistId());
						DocumentChecklist checklist = documentChecklistRepository.save(documentChecklist);
						workflowMapping.setChecklistId(checklist.getId());
					}
					activityWorkflowMappingDAO.create(workflowMapping);
				}
			} else {

			for (DocumentChecklistDTO checklistDTO : documentIndex.getDocumentChecklist()) {

				ActivityWorkflowMapping activityWorkflowMapping = activityWorkflowMappingDAO
						.getActivityWorkflowMapping(documentIndex.getId(), checklistDTO.getStateId());

				if (checklistDTO.getChecklistId() != null) {
					// Adding new Checklist to state
					if (activityWorkflowMapping.getChecklistId() == null) {
						activityWorkflowMapping.setChecklistId(" ");
					}
					if (!activityWorkflowMapping.getChecklistId().equals(checklistDTO.getChecklistId())) {
						DocumentChecklist documentChecklist = importChecklistTemplate(checklistDTO.getChecklistId());
						DocumentChecklist checklist = documentChecklistRepository.save(documentChecklist);
						activityWorkflowMapping.setChecklistId(checklist.getId());
						activityWorkflowMappingDAO.update(activityWorkflowMapping);
					}

				}}
			}
		}
		String path = String.join(">", documentIndex.getReferenceDrawingList());
		documentIndex.setReferenceDrawingPath(path);
		documentIndex.setDateOfCompletion(DateUtils.getCurrentISTDateTime());
		documentIndexDAO.update(documentIndex);

	}

	public void createActivityHistory(DocumentIndex documentIndex) {
		ActivityHistory activityHistory = new ActivityHistory();
		DocumentIndexVw indexView = documentIndexVwService.getDocumentIndexById(documentIndex.getId());
		if (indexView != null) {
			activityHistory.setWorkflowName(indexView.getWorkflow());
			activityHistory.setStateName(indexView.getWorkflowState());
			activityHistory.setDocumentName(indexView.getDocumentName());
			activityHistory.setDocumentIndex(documentIndex);
			activityHistory.setUpdatedBy(ThreadLocalUtil.getUserName());
			activityHistory.setUpdatedDate(DateUtils.getCurrentISTDateTime());
			activityHistoryDAO.create(activityHistory);
		}
	}

}
