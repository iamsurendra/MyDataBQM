package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.ProjectStatus;

@Repository
public class ProjectStatusDAOImpl extends BaseDAOImpl<ProjectStatus, Integer> implements ProjectStatusDAO{

	public ProjectStatusDAOImpl() {
		super(ProjectStatus.class);
		// TODO Auto-generated constructor stub
	}
	public List<String> getprojectStatusNames() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<ProjectStatus> root = criteriaQuery.from(ProjectStatus.class);
		criteriaQuery.select(root.get("projectStatusName")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}
	
	public List<String> getProjectStatusInfoById(List<Integer> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);
		Root<ProjectStatus> root = criteriaQuery.from(ProjectStatus.class);
		criteriaQuery.select(root.get("projectStatusName")).distinct(true);
		criteriaQuery.where(builder.in(root.get("projectStatusId")).value(Ids));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
