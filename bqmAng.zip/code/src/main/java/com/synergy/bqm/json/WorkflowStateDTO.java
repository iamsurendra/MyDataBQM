package com.synergy.bqm.json;

import java.util.ArrayList;
import java.util.List;

import com.synergy.bqm.models.WorkflowStates;

public class WorkflowStateDTO {

	private Integer workflowId;
	
	private List<WorkflowStates> states = new ArrayList<WorkflowStates>();
	
	private List<Integer> deletedIds = new ArrayList<>();
	
	//getters && Setters
	
	

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public List<WorkflowStates> getStates() {
		return states;
	}

	public void setStates(List<WorkflowStates> states) {
		this.states = states;
	}

	public List<Integer> getDeletedIds() {
		return deletedIds;
	}

	public void setDeletedIds(List<Integer> deletedIds) {
		this.deletedIds = deletedIds;
	}
	

	
	
	

}
