package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.json.CheckListTypeDTO;
import com.synergy.bqm.models.CheckListType;


public interface CheckListTypeService {
	
	

	public void deleteCheckListTypeById(Integer Id);
	
	public void createAndUpdateChecklisttypes(CheckListTypeDTO CheckListTypeDTO);
	
	public List<CheckListType> getAllChecklistType();
	
	public List<String> getCheckListTypeName();

}
