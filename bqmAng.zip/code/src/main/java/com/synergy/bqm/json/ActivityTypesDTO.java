package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.ActivityTypes;

public class ActivityTypesDTO {
	
	private List<Integer>deletedIds;
	private List<ActivityTypes>activityTypesList;
	
	
	
	public List<Integer> getDeletedIds() {
		return deletedIds;
	}
	public void setDeletedIds(List<Integer> deletedIds) {
		this.deletedIds = deletedIds;
	}
	public List<ActivityTypes> getActivityTypesList() {
		return activityTypesList;
	}
	public void setActivityTypesList(List<ActivityTypes> activityTypesList) {
		this.activityTypesList = activityTypesList;
	}
	
	
	
	

}
