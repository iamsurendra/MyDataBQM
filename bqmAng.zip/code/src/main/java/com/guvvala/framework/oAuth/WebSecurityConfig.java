package com.guvvala.framework.oAuth;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.access.channel.ChannelProcessingFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@EnableWebSecurity(debug = true)
@Order(Ordered.HIGHEST_PRECEDENCE)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	WorkbenchAuthProvider workbenchAuthProvider;

	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(workbenchAuthProvider);
	}

	@Override
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManager();
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/assets/**", "/css/**", "/js/**", "/");
	}
	
	

	@Override
	protected void configure(final HttpSecurity http) throws Exception {
		CorsConfigurationSource source = corsConfigurationSource();
		http.requestMatchers().antMatchers("/app/**").antMatchers(HttpMethod.OPTIONS).and()
				.addFilterBefore(new org.springframework.web.filter.CorsFilter(source), ChannelProcessingFilter.class)
				.addFilterAfter(new HtmlModeFilter(), ChannelProcessingFilter.class).sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS).and().anonymous().disable().securityContext()
				.and().csrf().disable().httpBasic().disable().formLogin().disable().logout().disable().csrf().disable().exceptionHandling().authenticationEntryPoint((request, response, e) -> {
		            String json = String.format("{\"message\": \"%s\"}", e.getMessage());
		            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		            response.setContentType("application/json");
		            response.setCharacterEncoding("UTF-8");
		            response.getWriter().write(json);                
		        });;

	}

	

	@Bean(name = "corsConfigurationSource")
	public CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(Arrays.asList("*"));
		ArrayList<String> methods = new ArrayList<>();
		methods.add("POST");
		methods.add("PUT");
		methods.add("GET");
		methods.add("OPTIONS");
		methods.add("DELETE");
		configuration.setAllowedMethods(methods);
		configuration.setAllowCredentials(true);
		String str = "Content-Type,Authorization,x-requested-with,Access-Control-Allow-Origin,Access-Control-Allow-Headers,x-auth-token,x-app-id,Origin,Accept,X-Requested-With,Access-Control-Request-Method,Access-Control-Request-Headers,Cache-Control,content-disposition";
		List<String> items = Arrays.asList(str.split("\\s*,\\s*"));
		configuration.setAllowedHeaders(items);
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}

}
